#!/usr/bin/env python3
"""EASE-6G revised model (v2) and full experiment rerun.

Changes relative to ease6g_revision_model.py (which is left untouched):
  * ratio scoring (best/candidate) replaces min-max for energy and carbon scores; each KPI-headroom ratio is capped at CAP_RATIO;
  * latency gate: service latency + access transmission + execution + R_min-quantile of the M/D/1 waiting time at RHO_MAX;
  * efficiencies on one published basis: 730 GFLOP/J for T1-T4 (MLPerf data-center system), 461 GFLOP/J and 2,890 GFLOP/s for T5 (Orin NX);
  * one JPEG-compressed 224x224 image (0.12 Mbit) per inference; carbon signal floored at 11 g/kWh (life-cycle wind);
  * carbon: compute at the destination grid, access at the user's grid, path energy split phi:(1-phi) (PHI in code);
  * static results weighted by request volume over the served profiles; profiles with no feasible tier are reported as unserved;
  * baselines B3 (latency-first), B4, B5 (carbon weight moved to energy), E-min, Oracle-KA and Oracle-K; weight frontier over 24 mappings.
Outputs go to results/v2/.
"""
from __future__ import annotations
import itertools, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import lil_matrix
import ease6g_revision_model as base
from ease6g_queue import md1_quantile

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results" / "v2"; OUT.mkdir(parents=True, exist_ok=True)
TIER = list(base.TIERS.tier); VAR = list(base.VARIANTS.variant); NT, NV = len(TIER), len(VAR)
REGIONS = ["London", "South East England", "East England", "North Scotland"]
REFMAP = dict(T1="North Scotland", T2="East England", T3="South East England", T4="London", T5="London")   # rule-based: far edge on the user grid, cloud remote
OLDMAP = dict(base.TIER_REGION_NAMES)
W = (0.40, 0.40, 0.20)
CAP_RATIO = 2.0
SCALE = 1000.0
RHO = base.RHO_B
SEEDS = base.RNG_SEEDS

T = base.TIERS
PUE = T.PUE.to_numpy(float); EE = T.accelerator_EE_GFLOPS_per_W.to_numpy(float)
LAT = T.service_latency_ms.to_numpy(float); BW = T.bandwidth_Gbps.to_numpy(float)
REL = T.reliability.to_numpy(float); JIT = T.jitter_ms.to_numpy(float)
EPS = np.array([12.66, 6.48, 3.39, 0.30, 0.0])                     # nJ/bit; T4 = gateway only
CAPV = T.CAP_AI_GFLOPS_per_s.to_numpy(float) * SCALE; CAPV[4] = T.CAP_AI_GFLOPS_per_s.to_numpy(float)[4]
RATE = np.array([40000.0, 40000.0, 40000.0, 40000.0, 2890.0])       # per-request compute rate, GFLOP/s; T5 = Jetson Orin NX MaxQ single-stream (MLPerf v3.1: 4.1 GFLOP / 1.419 ms)
EE = EE.copy(); EE[:4] = 730.0; EE[4] = 461.0                          # T1-T4: one server-class value (MLPerf Datacenter v1.0, 5x Cloud AI 100: 730 GFLOP/J); T5 = Jetson Orin NX MaxQ (MLPerf Edge v3.1): 461 GFLOP/J
CAPV[4] = np.inf                                                       # on-device capacity is per device, not shared
USER = 4                                                               # the user's grid is the T5/T4 grid
PHI = 0.5                                                            # phi in Eq. (7): share of path energy charged to the destination grid
ACC_AT_USER = True                                                     # access energy is consumed on the user's grid
RHO_MAX = 0.7                                                          # admission limit CAP_AI = RHO_MAX x physical capacity on shared tiers T1-T4; bounds queueing delay
PAYLOAD_MBIT = 0.12                                                    # one JPEG-compressed 224x224 image (about 15 kB) per inference, all services
RAW_MBIT = 1.2                                                         # the uncompressed 224x224x3 8-bit input tensor (sensitivity)
CI_FLOOR = 11.0                                                        # g CO2/kWh: life-cycle intensity of wind (harmonized median), floor on the carbon signal
F = base.VARIANTS.GFLOPs_per_inference.to_numpy(float); DELTA = base.VARIANTS.precision_energy_factor.to_numpy(float)
ACC = base.VARIANTS.accuracy_percent.to_numpy(float)

UC = base.USE_CASES.copy()
UC.loc[len(UC)] = ["UC5", "Interactive visual recognition", 100.0, 1.0, 0.999, 10.0, 80.0, 1.2, 10.0, 2.0]
UC["payload_Mbit"] = PAYLOAD_MBIT                                       # model-consistent payload
SERV_ALL = list(UC.uc); SERV = list(SERV_ALL)
PEAK = {"UC1": 6800.0, "UC2": 6800.0, "UC3": 12000.0, "UC4": 200000.0, "UC5": 4000.0}   # inferences/s
STRESS = {"UC1": 4000.0, "UC2": 4000.0, "UC3": 6000.0, "UC4": 100000.0, "UC5": 2000.0}


def ucrow(u): return UC[UC.uc == u].iloc[0]


def build(u, eps=None, rate=None, cap_ratio=CAP_RATIO, payload_scale=1.0, rho=RHO, tx_scale=1.0, transport_scale=1.0, ee=None, acc_gate=True, phi=None, acc_user=None, rho_max=None,
          lat=None, rel=None, jit=None, pue=None, rho_tier=None, gate="tail", exq=None):
    uc = ucrow(u); eps = EPS if eps is None else np.asarray(eps, float); rate = RATE if rate is None else np.asarray(rate, float)
    ee = EE if ee is None else np.asarray(ee, float)
    LAT_ = LAT if lat is None else np.asarray(lat, float); REL_ = REL if rel is None else np.asarray(rel, float); JIT_ = JIT if jit is None else np.asarray(jit, float)
    PUE_ = PUE if pue is None else np.asarray(pue, float)
    D = float(uc.payload_Mbit) * 1e6 * payload_scale
    e_acc = float(uc.access_tx_power_W) * tx_scale * D / (rho * float(uc.access_bandwidth_Gbps) * 1e9)
    e_tr = D * eps * transport_scale * 1e-9
    eacc = np.full(NT, e_acc); eacc[4] = 0.0; epath = e_tr.copy(); epath[4] = 0.0
    comm = eacc + epath
    e_comp = (PUE_ / ee)[:, None] * (F * DELTA)[None, :]
    E = e_comp + comm[:, None]
    rm = RHO_MAX if rho_max is None else rho_max
    rt = np.full(NT, rm) if rho_tier is None else np.asarray(rho_tier, float)
    svc = 1000.0 * F[None, :] / rate[:, None]                                       # execution time, ms
    if gate == "tail": xq = np.array([md1_quantile(float(r_), float(uc.Rmin)) for r_ in rt])   # R_min-quantile of the M/D/1 waiting time at the utilisation ceiling, in service times
    else: xq = rt / (2 * (1 - rt))                                                   # mean M/D/1 waiting time (sensitivity)
    wq = np.where(np.arange(NT)[:, None] < 4, xq[:, None] * svc, 0.0)
    ttx = np.where(np.arange(NT) < 4, 1000.0 * D / (rho * float(uc.access_bandwidth_Gbps) * 1e9), 0.0)   # access transmission time, ms (Eq. 3)
    leff = LAT_[:, None] + ttx[:, None] + svc + wq
    if exq is not None: leff = LAT_[:, None] + ttx[:, None] + np.asarray(exq(uc), float)   # measured execution-plus-queueing latency [tier, variant] in ms replaces the last two terms of Eq. (9) (review check B)
    gB = BW >= uc.Bmin_Gbps; gB[4] = True
    Kt = gB & (REL_ >= uc.Rmin) & (JIT_ <= uc.Jmax_ms)
    K = Kt[:, None] & (leff <= uc.Lmax_ms)
    A = np.ones(NV, bool) if (pd.isna(uc.Accmin_percent) or not acc_gate) else ACC >= uc.Accmin_percent
    mask = K & A[None, :]
    sB = np.minimum(BW / uc.Bmin_Gbps, cap_ratio); sB[4] = cap_ratio
    raw = (np.minimum(uc.Lmax_ms / leff, cap_ratio) + sB[:, None] + np.minimum(REL_ / uc.Rmin, cap_ratio)[:, None]
           + np.minimum(uc.Jmax_ms / JIT_, cap_ratio)[:, None])
    kpi = raw / raw[mask].max() if mask.any() else raw * 0             # Eq. (13): normalised over the hard-feasible set (K = A = 1)
    return dict(E=E, e_comp=e_comp, comm=comm, eacc=eacc, epath=epath, mask=mask, K=K, kpi=kpi, leff=leff, Lmax=float(uc.Lmax_ms),
                phi=PHI if phi is None else phi, acc_user=ACC_AT_USER if acc_user is None else acc_user)


def carbon(b, idx, ci):
    """mg CO2 per inference for flat candidate indices idx under hourly tier intensities ci [H,T] (kg/kWh).
    Compute is charged at the destination grid, access energy at the user's grid, path energy split phi:(1-phi)."""
    ci = np.atleast_2d(ci); idx = np.asarray(idx); ti = idx // NV
    ec = b["e_comp"].ravel()[idx][None, :]; ea = b["eacc"][ti][None, :]; ep = b["epath"][ti][None, :]
    ct = ci[:, ti]; cu = ci[:, [USER]]
    ca = cu if b["acc_user"] else ct
    return (ec * ct + ea * ca + ep * (b["phi"] * ct + (1 - b["phi"]) * cu)) / 3.6


def _pick(score, C, e):
    best = score.max(1, keepdims=True); tie = score >= best - 1e-12
    cm = np.where(tie, C, np.inf); cmin = cm.min(1, keepdims=True)
    tie2 = cm <= cmin * (1 + 1e-12) + 1e-300
    return np.where(tie2, e[None, :], np.inf).argmin(1)


def scores(b, ci, w=W, mask=None):
    mask = b["mask"] if mask is None else mask
    ci = np.atleast_2d(ci); idx = np.flatnonzero(mask.ravel()); ti = idx // NV
    e = b["E"].ravel()[idx]; k = b["kpi"].ravel()[idx]; lr = (b["leff"].ravel()[idx]) / b["Lmax"]
    C = carbon(b, idx, ci)
    eta = e.min() / e; cmin = C.min(1, keepdims=True)
    ce = np.where(C > 0, cmin / np.where(C > 0, C, 1.0), 1.0)
    return idx, e, k, lr, C, eta, ce


def decide(b, ci, w=W):
    idx, e, k, lr, C, eta, ce = scores(b, ci, w)
    H = C.shape[0]; rep = lambda x: np.repeat(x[None, :], H, 0)
    S = w[0] * eta[None, :] + w[1] * ce + w[2] * k[None, :]
    pk = {"EASE": _pick(S, C, e),
          "B5": _pick(rep((W[0] + W[1]) * eta + W[2] * k), rep(e), e),
          "B3": _pick(rep(-lr * 1e6 - e), rep(e), e),
          "B4": _pick(rep(-(lr + e / e.max())), C, e),
          "Emin": _pick(rep(-e), C, e),
          "Oracle-KA": _pick(-C, C, e)}
    r = np.arange(H)
    return {p: dict(i=idx[j], C=C[r, j], E=e[j], S=S[r, j]) for p, j in pk.items()}


lab = lambda i: f"{TIER[i // NV]}-{VAR[i % NV]}"
WIN = {w_: v_.assign(**{r_: v_[r_].clip(lower=CI_FLOOR) for r_ in REGIONS}) for w_, v_ in base.load_carbon_trace_windows().items()}   # floored carbon signal
_ALL = pd.concat(WIN.values())


def ci_static(mp=REFMAP): return np.array([[float(_ALL[mp[t]].mean()) / 1000 for t in TIER]])
def ci_hourly(w, mp=REFMAP): return np.stack([WIN[w][mp[t]].to_numpy(float) / 1000 for t in TIER], 1)


def make_rates(hours=168, scale=0.25, warm=0):
    out = {}
    for s in SEEDS:
        rng = np.random.default_rng(s); r5 = np.random.default_rng(s + 1000); rows = []
        for h in range(hours + warm):
            r = base.rates_for_hour(h, rng, scale=scale * SCALE)
            r["UC5"] = scale * PEAK["UC5"] * base.daily_load_fraction(h % 24) * float(np.clip(r5.normal(1, 0.08), 0.75, 1.25))
            rows.append(r)
        out[s] = pd.DataFrame(rows)
    return out


B_ALL = {u: build(u) for u in SERV_ALL}
SERV = [u for u in SERV_ALL if B_ALL[u]["mask"].any()]; UNSERVED = [u for u in SERV_ALL if u not in SERV]   # profiles with no feasible tier in the reference
B = {u: B_ALL[u] for u in SERV}
CS = ci_static()
S = {"served": SERV, "unserved": UNSERVED, "settings": dict(phi=PHI, access_at_user=ACC_AT_USER, rho_max=RHO_MAX, payload_Mbit=PAYLOAD_MBIT, device_EE=float(EE[4]), weights=W, cap_ratio=CAP_RATIO, scale=SCALE, eps_nJ_per_bit=EPS.tolist(), per_request_rate_GFLOPs=RATE.tolist(), capacity_GFLOPs=CAPV.tolist(),
                      reference_CI_kg_per_kWh=dict(zip(TIER, CS[0].tolist())), UC5=ucrow("UC5").to_dict())}

# ------------------------------------------------------------ E1 static placements, E2 baselines/oracles
rows = []; brow = []
for u in SERV:
    b = B[u]; d = decide(b, CS)
    i = int(d["EASE"]["i"][0]); t, v = divmod(i, NV)
    rows.append(dict(uc=u, placement=lab(i), score=float(d["EASE"]["S"][0]), E_compute_J=b["e_comp"][t, v], E_comm_J=b["comm"][t], E_total_J=b["E"][t, v],
                     carbon_mg=float(d["EASE"]["C"][0]), latency_eff_ms=b["leff"][t, v], chi_GFLOP_per_Mbit=F[v] * DELTA[v] / float(ucrow(u).payload_Mbit),
                     feasible_tiers=",".join(sorted({TIER[j // NV] for j in np.flatnonzero(b["mask"].ravel())})), feasible_pairs=int(b["mask"].sum())))
    bk = build(u, acc_gate=False); dk = decide(bk, CS)
    for p, x in d.items():
        brow.append(dict(method=p, uc=u, placement=lab(int(x["i"][0])), E_total_J=float(x["E"][0]), carbon_mg=float(x["C"][0])))
    brow.append(dict(method="Oracle-K", uc=u, placement=lab(int(dk["Oracle-KA"]["i"][0])), E_total_J=float(dk["Oracle-KA"]["E"][0]), carbon_mg=float(dk["Oracle-KA"]["C"][0])))
    allE = b["E"]; allC = carbon(b, np.arange(NT * NV), CS)[0].reshape(NT, NV)
    brow.append(dict(method="B1", uc=u, placement="uniform-20", E_total_J=float(allE.mean()), carbon_mg=float(allC.mean())))
static = pd.DataFrame(rows); static.to_csv(OUT / "static_placements.csv", index=False)
bl = pd.DataFrame(brow); bl.to_csv(OUT / "baselines.csv", index=False)
S["static"] = static.round(6).to_dict("records")
S["baseline_means"] = bl.groupby("method")[["E_total_J", "carbon_mg"]].mean().round(6).reset_index().to_dict("records")
S["baseline_placements"] = bl.pivot(index="uc", columns="method", values="placement").reset_index().to_dict("records")
ok = bl[bl.method == "Oracle-K"].set_index("uc").carbon_mg; ea = bl[bl.method == "EASE"].set_index("uc").carbon_mg
oka = bl[bl.method == "Oracle-KA"].set_index("uc").carbon_mg
S["accuracy_enforcement_gap_percent"] = (100 * (oka / ok - 1)).round(2).to_dict()                 # Oracle-KA / Oracle-K - 1
WGT = pd.Series({u: PEAK[u] for u in SERV})                                   # request-volume weights over served profiles (proportional to mean arrival rate)
def weighted(blk):
    pc = blk.pivot(index="uc", columns="method", values="carbon_mg"); pe = blk.pivot(index="uc", columns="method", values="E_total_J")
    out = {m_: dict(carbon_mg=float((pc[m_] * WGT).sum() / WGT.sum()), E_J=float((pe[m_] * WGT).sum() / WGT.sum())) for m_ in pc.columns}
    for b_ in ("B3", "B4", "B5", "Emin", "Oracle-KA"):
        out["EASE"]["red_vs_" + b_] = 100 * (1 - out["EASE"]["carbon_mg"] / out[b_]["carbon_mg"]); out["EASE"]["dE_vs_" + b_] = 100 * (out["EASE"]["E_J"] / out[b_]["E_J"] - 1)
    return out
S["static_weighted"] = weighted(bl[bl.method != "B1"])
S["volume_share"] = (WGT / WGT.sum()).round(4).to_dict()

# ------------------------------------------------------------ E3 ablation and weight sweep (static, reference)
_pr = lambda w: tuple(x / sum(w) for x in w)                                # remove one term and renormalise the others proportionally
abl = {"Full EASE-6G": (W, True), "No carbon": (_pr((W[0], 0, W[2])), True), "No KPI score": (_pr((W[0], W[1], 0)), True), "No energy": (_pr((0, W[1], W[2])), True), "No accuracy gate": (W, False)}
ar = []
for name, (w, ag) in abl.items():
    pl = {}; e = c = 0; inv = 0
    for u in SERV:
        b = build(u, acc_gate=ag); d = decide(b, CS, w)["EASE"]; i = int(d["i"][0]); pl[u] = lab(i); e += d["E"][0]; c += d["C"][0]
        inv += int(not B[u]["mask"].ravel()[i])
    ar.append(dict(configuration=name, **pl, mean_E_J=e / len(SERV), mean_carbon_mg=c / len(SERV), accuracy_invalid=inv))
pd.DataFrame(ar).to_csv(OUT / "ablation.csv", index=False); S["ablation"] = pd.DataFrame(ar).round(6).to_dict("records")
vals = np.round(np.arange(0, 1.0001, 0.05), 2); wr = []
for we in vals:
    for wc in vals:
        wk = round(1 - we - wc, 2)
        if wk < -1e-9: continue
        for u in SERV:
            wr.append(dict(wE=we, wC=wc, wK=wk, uc=u, placement=lab(int(decide(B[u], CS, (we, wc, wk))["EASE"]["i"][0]))))
wr = pd.DataFrame(wr); wr.to_csv(OUT / "weight_sweep_static.csv", index=False)
S["weight_sweep_static_counts"] = wr.groupby(["uc", "placement"]).size().reset_index(name="count").to_dict("records")

# ------------------------------------------------------------ MILP
def solve(svcs, caps, avail, allow_unserved=True, objective="score", time_limit=30.0, gap=1e-9):
    """svcs: list of dict(u, rate, idx, score, carbon). Returns list of chosen flat index or None."""
    pairs = [(s, i, sv) for s, sv in enumerate(svcs) for i in range(len(sv["idx"])) if avail[sv["idx"][i] // NV]]
    n = len(pairs) + (len(svcs) if allow_unserved else 0)
    A = lil_matrix((len(svcs) + NT, n)); c = np.zeros(n)
    for col, (s, i, sv) in enumerate(pairs):
        fi = sv["idx"][i]; A[s, col] = 1; A[len(svcs) + fi // NV, col] = sv["rate"] * F[fi % NV]
        c[col] = -sv["score"][i] if objective == "score" else sv["rate"] * (sv["carbon"][i] if objective == "carbon" else sv["energy"][i])
    if allow_unserved:
        for s in range(len(svcs)):
            A[s, len(pairs) + s] = 1; c[len(pairs) + s] = (len(svcs) + 1.0) if objective == "score" else 1e12   # M exceeds the largest possible total suitability
    lb = np.r_[np.ones(len(svcs)), -np.inf * np.ones(NT)]; ub = np.r_[np.ones(len(svcs)), caps]   # CAP_AI is the admission limit = RHO_MAX x physical capacity
    t0 = time.perf_counter()
    res = milp(c=c, integrality=np.ones(n), bounds=Bounds(0, 1), constraints=LinearConstraint(A.tocsr(), lb, ub), options={"mip_rel_gap": gap, "time_limit": time_limit})
    dt = time.perf_counter() - t0
    if res.x is None: return None, dt, res.status
    x = np.rint(res.x).astype(int); out = [None] * len(svcs)
    for col, (s, i, sv) in enumerate(pairs):
        if x[col]: out[s] = int(sv["idx"][i])
    return out, dt, res.status


def svc_list(rates, ci=CS, blds=B):
    L = []
    for u in SERV:
        idx, e, k, lr, C, eta, ce = scores(blds[u], ci)
        L.append(dict(u=u, rate=rates[u], idx=idx, score=(W[0] * eta + W[1] * ce[0] + W[2] * k), carbon=C[0], energy=e))
    return L

# ------------------------------------------------------------ E4 capacity stress
sv = svc_list(STRESS); avail = np.ones(NT, bool)
ind = {u: int(decide(B[u], CS)["EASE"]["i"][0]) for u in SERV}
ms, _, _ = solve(sv, CAPV, avail, allow_unserved=False)
mo, _, _ = solve(sv, CAPV, avail, allow_unserved=False, objective="carbon")
def sysm(sel):
    e = c = 0; load = np.zeros(NT)
    for u, i in zip(SERV, sel):
        e += STRESS[u] * B[u]["E"].ravel()[i]; c += STRESS[u] * carbon(B[u], [i], CS)[0, 0]; load[i // NV] += STRESS[u] * F[i % NV]
    return e, c, load
ei, ci_, li = sysm([ind[u] for u in SERV]); em, cm, lm = sysm(ms); eo, co, lo = sysm(mo)
cap_rows = []
for u, i0, i1, i2 in zip(SERV, [ind[u] for u in SERV], ms, mo):
    b = B[u]; E0, E1 = b["E"].ravel()[i0], b["E"].ravel()[i1]; C0, C1 = carbon(b, [i0], CS)[0, 0], carbon(b, [i1], CS)[0, 0]
    cap_rows.append(dict(uc=u, normal=lab(i0), stress=lab(i1), oracle_stress=lab(i2), d_latency_ms=b["leff"].ravel()[i1] - b["leff"].ravel()[i0],
                         d_energy_percent=100 * (E1 / E0 - 1), d_carbon_percent=100 * (C1 / C0 - 1), d_accuracy_pp=ACC[i1 % NV] - ACC[i0 % NV]))
pd.DataFrame(cap_rows).to_csv(OUT / "capacity_fallback_per_uc.csv", index=False)
S["capacity"] = dict(per_uc=pd.DataFrame(cap_rows).round(3).to_dict("records"),
                     independent=dict(energy_J_per_s=ei, carbon_mg_per_s=ci_, load=dict(zip(TIER, li.tolist())), feasible=bool((li[:4] <= CAPV[:4]).all())),
                     milp=dict(energy_J_per_s=em, carbon_mg_per_s=cm, load=dict(zip(TIER, lm.tolist())), feasible=bool((lm[:4] <= CAPV[:4]).all())),
                     oracle_ka=dict(energy_J_per_s=eo, carbon_mg_per_s=co), capacity=dict(zip(TIER, CAPV.tolist())), rho_max=RHO_MAX,
                     energy_increase_percent=100 * (em / ei - 1), carbon_increase_percent=100 * (cm / ci_ - 1), milp_vs_oracle_carbon_percent=100 * (cm / co - 1))

# ------------------------------------------------------------ E5 controlled capacity-and-outage simulation
R_full = make_rates(hours=168, scale=1.0, warm=24); sim = []; simp = []
for s in SEEDS:
    rt = R_full[s]
    for h in range(24, 192):
        ah = h - 24; outage = ah in set(range(48, 51)) | set(range(120, 124))
        av = np.ones(NT, bool); av[3] = not outage; rates_h = rt.iloc[h].to_dict(); svs_h = svc_list(rates_h)
        for pol, obj in (("EASE", "score"), ("Emin", "energy"), ("Oracle-KA", "carbon")):
            sel, _, _ = solve(svs_h, CAPV, av, allow_unserved=True, objective=obj)
            for u, i in zip(SERV, sel):
                if pol == "EASE": sim.append(dict(seed=s, hour=ah, uc=u, tier="UNSERVED" if i is None else TIER[i // NV], variant="-" if i is None else VAR[i % NV], outage=outage))
                simp.append(dict(policy=pol, seed=s, hour=ah, uc=u, tier="UNSERVED" if i is None else TIER[i // NV], outage=outage,
                                 E_J=0.0 if i is None else rates_h[u] * 3600 * B[u]["E"].ravel()[i], C_mg=0.0 if i is None else rates_h[u] * 3600 * carbon(B[u], [i], CS)[0, 0]))
simp = pd.DataFrame(simp); simp.to_csv(OUT / "controlled_simulation_policies.csv", index=False)
_tot = simp.groupby(["policy", "seed"])[["E_J", "C_mg"]].sum().groupby("policy").mean()
_uns = simp[simp.tier == "UNSERVED"].groupby(["policy", "seed"]).size().groupby("policy").mean().reindex(_tot.index, fill_value=0)
S["controlled_sim_policies"] = {p_: dict(unserved_service_hours=float(_uns[p_]), E_kWh_week=float(_tot.loc[p_, "E_J"] / 3.6e6), C_kg_week=float(_tot.loc[p_, "C_mg"] / 1e6),
                                         tier_hours={u: simp[(simp.policy == p_) & (simp.uc == u)].groupby("tier").size().div(len(SEEDS)).round(2).to_dict() for u in SERV}) for p_ in _tot.index}
_m5 = simp[(simp.policy == "Emin") & (simp.uc == "UC5") & (simp.tier == "T3")]; _expl = []
for r_ in _m5.itertuples():                                    # E-min moves UC5 off the far edge only when the far edge is out or has no room for it
    g_ = simp[(simp.policy == "Emin") & (simp.seed == r_.seed) & (simp.hour == r_.hour)]; rt_ = R_full[r_.seed].iloc[r_.hour + 24]
    l4 = sum(rt_[x.uc] * F[VAR.index("V2")] for x in g_.itertuples() if x.tier == "T4"); _expl.append(bool(r_.outage or l4 + rt_["UC5"] * F[VAR.index("V2")] > CAPV[3] + 1e-6))
S["controlled_sim_policies_Emin_UC5_explained"] = dict(hours=len(_expl), explained=int(sum(_expl)))
S["controlled_sim_policies"]["EASE_vs_Emin"] = dict(red=float(100 * (1 - _tot.loc["EASE", "C_mg"] / _tot.loc["Emin", "C_mg"])), dE=float(100 * (_tot.loc["EASE", "E_J"] / _tot.loc["Emin", "E_J"] - 1)),
                                                     gap_oracle=float(100 * (_tot.loc["EASE", "C_mg"] / _tot.loc["Oracle-KA", "C_mg"] - 1)))
sim = pd.DataFrame(sim); sim.to_csv(OUT / "controlled_simulation_paths.csv", index=False)
tc = sim.groupby(["seed", "uc", "tier"]).size().reset_index(name="hours")
S["controlled_sim_tier_hours_mean_sd"] = tc.groupby(["uc", "tier"]).hours.agg(["mean", "std"]).round(2).reset_index().to_dict("records")

# ------------------------------------------------------------ E6/E7 seasonal traces, reference and 24 mappings
R = make_rates(); POL = ["EASE", "B3", "B4", "B5", "Emin", "Oracle-KA"]; cells = []; hrs = []; TRACE_PEAK_LOAD = np.zeros(NT)
for mid, perm in enumerate(itertools.permutations(REGIONS), 1):
    mp = dict(zip(TIER[:4], perm)); mp["T5"] = mp["T4"]; ref = all(mp[t] == REFMAP[t] for t in TIER)
    for wname in WIN:
        ch = ci_hourly(wname, mp); dec = {u: decide(B[u], ch) for u in SERV}
        if ref:
            for u in SERV:
                hrs.append(dict(window=wname, uc=u, **{p + "_tier_hours": json.dumps(pd.Series([TIER[i // NV] for i in dec[u][p]["i"]]).value_counts().to_dict(), sort_keys=True) for p in POL},
                                hours_EASE_differs_B5=int((dec[u]["EASE"]["i"] != dec[u]["B5"]["i"]).sum()), hours_EASE_differs_Emin=int((dec[u]["EASE"]["i"] != dec[u]["Emin"]["i"]).sum()), hours_EASE_differs_B3=int((dec[u]["EASE"]["i"] != dec[u]["B3"]["i"]).sum()),
                                hours_EASE_matches_oracle=int((dec[u]["EASE"]["i"] == dec[u]["Oracle-KA"]["i"]).sum())))
        for p_ in POL:
            for s in SEEDS:
                ld = np.zeros((len(ch), NT))
                for u in SERV:
                    i_ = dec[u][p_]["i"]; np.add.at(ld, (np.arange(len(ch)), i_ // NV), R[s][u].to_numpy() * F[i_ % NV])
                TRACE_PEAK_LOAD[:] = np.maximum(TRACE_PEAK_LOAD, ld.max(0))
        for s in SEEDS:
            for scope, ucs in (("noUC5", [u for u in SERV if u != "UC5"]), ("UC5", ["UC5"]), ("all", SERV)):
                row = dict(mapping_id=mid, is_reference=ref, window=wname, seed=s, scope=scope)
                for p in POL:
                    row["C_" + p] = sum((dec[u][p]["C"] * R[s][u].to_numpy() * 3600).sum() for u in ucs) / 1e6      # kg CO2 per week
                    row["E_" + p] = sum((dec[u][p]["E"] * R[s][u].to_numpy() * 3600).sum() for u in ucs) / 3.6e6    # kWh per week
                cells.append(row)
cells = pd.DataFrame(cells).groupby(["mapping_id", "is_reference", "window", "scope"]).mean(numeric_only=True).drop(columns="seed").reset_index()
with np.errstate(divide="ignore", invalid="ignore"):
    for b_ in ("B3", "B4", "B5", "Emin"):
        cells["red_vs_" + b_] = 100 * (cells["C_" + b_] - cells.C_EASE) / cells["C_" + b_]
        cells["dE_vs_" + b_] = 100 * (cells.E_EASE - cells["E_" + b_]) / cells["E_" + b_]
    cells["gap_vs_oracle"] = 100 * (cells.C_EASE - cells["C_Oracle-KA"]) / cells["C_Oracle-KA"]
cells["gap_vs_oracle_kg"] = cells.C_EASE - cells["C_Oracle-KA"]
cells = cells.replace([np.inf, -np.inf], np.nan); cells.to_csv(OUT / "mapping_trace_cells.csv", index=False)
pd.DataFrame(hrs).to_csv(OUT / "reference_trace_tier_hours.csv", index=False)
S["trace_capacity"] = dict(peak_load=dict(zip(TIER[:4], TRACE_PEAK_LOAD[:4].tolist())), admission=dict(zip(TIER[:4], CAPV[:4].tolist())),
                           utilisation=dict(zip(TIER[:4], (TRACE_PEAK_LOAD[:4] / CAPV[:4]).tolist())), binding=bool((TRACE_PEAK_LOAD[:4] > CAPV[:4]).any()))
S["seasonal_reference"] = cells[cells.is_reference].drop(columns=["mapping_id", "is_reference"]).round(4).to_dict("records")
S["seasonal_reference_tier_hours"] = pd.DataFrame(hrs)[["window", "uc", "EASE_tier_hours", "B5_tier_hours", "B3_tier_hours", "Emin_tier_hours", "hours_EASE_differs_B5", "hours_EASE_differs_Emin", "hours_EASE_differs_B3", "hours_EASE_matches_oracle"]].to_dict("records")
def dist(g, col):
    x = g[col].dropna(); return dict(cells=int(len(g)), defined=int(len(x)), positive=int((x > 1e-9).sum()), negative=int((x < -1e-9).sum()), median=float(x.median()), q25=float(x.quantile(.25)), q75=float(x.quantile(.75)), min=float(x.min()), max=float(x.max()))
S["mapping_distribution"] = {sc: {c: dist(g, c) for c in ("red_vs_B3", "red_vs_B4", "red_vs_B5", "red_vs_Emin", "dE_vs_B3", "dE_vs_B5", "dE_vs_Emin", "gap_vs_oracle")} for sc, g in cells.groupby("scope")}
mst = []
for mid, perm in enumerate(itertools.permutations(REGIONS), 1):
    mp = dict(zip(TIER[:4], perm)); mp["T5"] = mp["T4"]; c = ci_static(mp)
    for u in SERV:
        d = decide(B[u], c); mst.append(dict(mapping_id=mid, uc=u, **{p: lab(int(d[p]["i"][0])) for p in POL}, **{"C_" + p: float(d[p]["C"][0]) for p in POL}, **{"E_" + p: float(d[p]["E"][0]) for p in POL}))
mst = pd.DataFrame(mst); mst.to_csv(OUT / "mapping_static.csv", index=False)
mw = []
for mid, g in mst.groupby("mapping_id"):
    w_ = WGT[g.uc].to_numpy(); row = dict(mapping_id=int(mid))
    for p_ in POL: row["C_" + p_] = float((g["C_" + p_].to_numpy() * w_).sum() / w_.sum()); row["E_" + p_] = float((g["E_" + p_].to_numpy() * w_).sum() / w_.sum())
    for b_ in ("B3", "B4", "B5", "Emin"): row["red_vs_" + b_] = 100 * (1 - row["C_EASE"] / row["C_" + b_]); row["dE_vs_" + b_] = 100 * (row["E_EASE"] / row["E_" + b_] - 1)
    row["gap_vs_oracle"] = 100 * (row["C_EASE"] / row["C_Oracle-KA"] - 1); mw.append(row)
mw = pd.DataFrame(mw); mw.to_csv(OUT / "mapping_static_weighted.csv", index=False)
S["mapping_static_weighted"] = {c_: dist(mw, c_) for c_ in ("red_vs_B3", "red_vs_B5", "red_vs_Emin", "dE_vs_B3", "dE_vs_B5", "dE_vs_Emin", "gap_vs_oracle")}
S["mapping_static"] = {u: dict(ease_equals_oracle=int((g.EASE == g["Oracle-KA"]).sum()), ease_differs_B5=int((g.EASE != g.B5).sum()), ease_differs_Emin=int((g.EASE != g.Emin).sum()), ease_differs_B3=int((g.EASE != g.B3).sum()),
                               max_gap_percent_EASE=float(100 * (g.C_EASE / g["C_Oracle-KA"] - 1).max()), max_gap_percent_B3=float(100 * (g.C_B3 / g["C_Oracle-KA"] - 1).max()),
                               max_gap_percent_B5=float(100 * (g.C_B5 / g["C_Oracle-KA"] - 1).max())) for u, g in mst.groupby("uc")}
# weight ratio that closes the UC3 gap in its worst mapping
g3 = mst[mst.uc == "UC3"]; worst = g3.loc[(g3.C_EASE / g3["C_Oracle-KA"]).idxmax()]
S["UC3_worst_mapping"] = dict(mapping_id=int(worst.mapping_id), EASE=worst.EASE, oracle=worst["Oracle-KA"], energy_ratio=float(worst["E_Oracle-KA"] / worst.E_EASE), carbon_ratio=float(worst.C_EASE / worst["C_Oracle-KA"]))

# ------------------------------------------------------------ E8 UC4 T2/T3 operational-intensity envelope; E9 crossover range
u4 = ucrow("UC4"); eacc = float(u4.access_tx_power_W) / (RHO * float(u4.access_bandwidth_Gbps)) * 1e-3
def a_(t, ee=EE): return PUE[t] / ee[t]
def b_(t): return EPS[t] * 1e-3
def epm(t, chi, ee=EE): return a_(t, ee) * chi + eacc + b_(t)
def chi_E(i, j, ee=EE):
    d = a_(j, ee) - a_(i, ee); return (b_(i) - b_(j)) / d if d > 0 else None
def chi_C(i, j, ci, ee=EE, phi=PHI):
    cu = ci[USER]; al = lambda t: ci[t] * a_(t, ee); be = lambda t: cu * eacc + b_(t) * (phi * ci[t] + (1 - phi) * cu); d = al(i) - al(j)
    x = (be(j) - be(i)) / d if d != 0 else None; return x if (x is not None and x > 0) else None
kp = B["UC4"]["kpi"][[1, 2], 3]
CHI_UC4 = float(F[VAR.index("V4")] * DELTA[VAR.index("V4")] / PAYLOAD_MBIT)
GRID = sorted([0.01, 0.03, 0.1, 0.3, 0.5, 1.0, 3.0, 10.0, CHI_UC4, 30.0, 100.0])
def env_pick(chi, ci2, cu):
    e = np.array([epm(1, chi), epm(2, chi)]); aa = np.array([a_(1), a_(2)]); bb = np.array([b_(1), b_(2)]); cu = np.asarray(cu, float)[:, None]
    C = (aa[None, :] * chi * ci2 + eacc * cu + bb[None, :] * (PHI * ci2 + (1 - PHI) * cu)) / 3.6
    eta = e.min() / e; ce = np.where(C > 0, C.min(1, keepdims=True) / np.where(C > 0, C, 1), 1.0); H = len(C); rep = lambda x: np.repeat(x[None, :], H, 0)
    return e, C, _pick(W[0] * eta[None, :] + W[1] * ce + W[2] * kp[None, :], C, e), _pick(rep((W[0] + W[1]) * eta + W[2] * kp), rep(e), e), C.argmin(1)
env = []
for chi in GRID:
    e, C, pe, pb, po = env_pick(chi, CS[:, [1, 2]], CS[:, USER])
    env.append(dict(window="static mean", chi=chi, EASE="T%d" % (pe[0] + 2), B5="T%d" % (pb[0] + 2), oracle="T%d" % (po[0] + 2), reduction_vs_B5_percent=100 * (C[0, pb[0]] - C[0, pe[0]]) / C[0, pb[0]],
                    energy_change_percent=100 * (e[pe[0]] / e[pb[0]] - 1), gap_vs_oracle_percent=100 * (C[0, pe[0]] / C[0, po[0]] - 1), hours_differ=int(pe[0] != pb[0]),
                    Emin="T%d" % (int(np.argmin(e)) + 2), reduction_vs_Emin_percent=100 * (C[0, int(np.argmin(e))] - C[0, pe[0]]) / C[0, int(np.argmin(e))], energy_change_vs_Emin_percent=100 * (e[pe[0]] / e.min() - 1),
                    hours_in_disagreement=int((e[0] - e[1]) * (C[0, 0] - C[0, 1]) < 0)))
    for wname in WIN:
        chh = ci_hourly(wname); ch = chh[:, [1, 2]]; e, C, pe, pb, po = env_pick(chi, ch, chh[:, USER]); rr = np.arange(len(C)); acc_ = []
        for s in SEEDS:
            w = R[s]["UC4"].to_numpy() * 3600
            pm = np.full(len(C), int(np.argmin(e)))                                   # pure energy minimizer
            cb, ce_, co, cm_ = (C[rr, pb] * w).sum(), (C[rr, pe] * w).sum(), (C[rr, po] * w).sum(), (C[rr, pm] * w).sum(); eb, ee_, em_ = (e[pb] * w).sum(), (e[pe] * w).sum(), (e[pm] * w).sum()
            acc_.append((100 * (cb - ce_) / cb, 100 * (ee_ / eb - 1), 100 * (ce_ / co - 1), 100 * (cm_ - ce_) / cm_, 100 * (ee_ / em_ - 1)))
        m = np.mean(acc_, 0)
        env.append(dict(window=wname, chi=chi, EASE="", B5="", oracle="", reduction_vs_B5_percent=m[0], energy_change_percent=m[1], gap_vs_oracle_percent=m[2], hours_differ=int((pe != pb).sum()),
                        reduction_vs_Emin_percent=m[3], hours_differ_Emin=int((pe != pm).sum()), energy_change_vs_Emin_percent=m[4],
                        hours_in_disagreement=int(((e[0] - e[1]) * (C[:, 0] - C[:, 1]) < 0).sum()),   # hours in which the energy and carbon orderings of T2 and T3 disagree (Eq. 24)
                        hours_departed_outside=int(((pe != pm) & ~((e[0] - e[1]) * (C[:, 0] - C[:, 1]) < 0)).sum()),
                        outside_carbon_penalty_max_percent=float(np.max(np.where((pe != pm) & ~((e[0] - e[1]) * (C[:, 0] - C[:, 1]) < 0), 100 * (C[rr, pe] / C[rr, pm] - 1), 0.0)))))
env = pd.DataFrame(env); env.to_csv(OUT / "intensity_envelope.csv", index=False)
dense = np.logspace(-2, 2, 2001); dr = []
for chi in dense:
    e, C, pe, pb, po = env_pick(chi, CS[:, [1, 2]], CS[:, USER]); dr.append(100 * (C[0, pb[0]] - C[0, pe[0]]) / C[0, pb[0]])
se = env[env.window != "static mean"]
S["envelope"] = dict(chi_E_T2_T3=chi_E(1, 2), chi_C_T2_T3_mean=chi_C(1, 2, CS[0]), static_max_declared=float(env[env.window == "static mean"].reduction_vs_B5_percent.max()), static_max_dense=float(max(dr)),
                     seasonal_cells=int(len(se)), positive=int((se.reduction_vs_B5_percent > 1e-9).sum()), negative=int((se.reduction_vs_B5_percent < -1e-9).sum()),
                     max_seasonal=float(se.reduction_vs_B5_percent.max()), min_seasonal=float(se.reduction_vs_B5_percent.min()),
                     Emin_positive=int((se.reduction_vs_Emin_percent > 1e-9).sum()), Emin_negative=int((se.reduction_vs_Emin_percent < -1e-9).sum()), Emin_max=float(se.reduction_vs_Emin_percent.max()),
                     Emin_pos_dE_max=float(se[se.reduction_vs_Emin_percent > 1e-9].energy_change_vs_Emin_percent.max()), Emin_gap_max=float(se.gap_vs_oracle_percent.max()),
                     Emin_pos_without_disagreement=int(((se.reduction_vs_Emin_percent > 1e-9) & (se.hours_in_disagreement == 0)).sum()),
                     departed_outside_hours=int(se.hours_departed_outside.sum()), departed_hours=int(se.hours_differ_Emin.sum()), departed_outside_cells=int((se.hours_departed_outside > 0).sum()),
                     outside_carbon_penalty_max=float(se.outside_carbon_penalty_max_percent.max()),
                     disagreement_without_saving=int(((se.reduction_vs_Emin_percent <= 1e-9) & (se.hours_in_disagreement > 0)).sum()),
                     Emin_pos_outside_mean_interval=int(((se.reduction_vs_Emin_percent > 1e-9) & ~se.chi.between(min(chi_C(1, 2, CS[0]), chi_E(1, 2)), max(chi_C(1, 2, CS[0]), chi_E(1, 2)))).sum()),
                     table=env.round(3).to_dict("records"))
anch = [("Reference (one server value)", 730, 730), ("Server high / module low", 1274, 461), ("Server high / module high", 1274, 627), ("Server mid / module mid", 730, 613), ("Server low / module low", 471, 461), ("Server low / module high", 471, 627), ("Previous profile", 350, 275)]   # MLPerf ResNet-50 Offline power results, 4.1 GFLOP/image
xr = []
for n, e2, e3 in anch:
    ee = EE.copy(); ee[1], ee[2] = e2, e3
    xr.append(dict(case=n, EE_T2=e2, EE_T3=e3, ratio=e2 / e3, exists=bool(e2 / e3 > PUE[1] / PUE[2]), chi_E=chi_E(1, 2, ee), chi_C_mean=chi_C(1, 2, CS[0], ee)))
pd.DataFrame(xr).to_csv(OUT / "crossover_efficiency_range.csv", index=False)
S["crossover_range"] = dict(existence_threshold_EE_ratio=float(PUE[1] / PUE[2]), cases=xr)

# ------------------------------------------------------------ E9b energy-carbon weight frontier over all 24 mappings (static, volume-weighted)
WC_GRID = [round(x, 2) for x in np.arange(0.0, 0.8001, 0.05)]; fr = []
_wg = WGT / WGT.sum()
for mid, perm in enumerate(itertools.permutations(REGIONS), 1):
    mp = dict(zip(TIER[:4], perm)); mp["T5"] = mp["T4"]; cs_ = ci_static(mp)
    base_ = {u: decide(B[u], cs_, (0.8, 0.0, 0.2)) for u in SERV}
    c5 = sum(_wg[u] * base_[u]["B5"]["C"][0] for u in SERV); e5 = sum(_wg[u] * base_[u]["B5"]["E"][0] for u in SERV)
    cm5 = sum(_wg[u] * base_[u]["Emin"]["C"][0] for u in SERV); em5 = sum(_wg[u] * base_[u]["Emin"]["E"][0] for u in SERV)
    co = sum(_wg[u] * base_[u]["Oracle-KA"]["C"][0] for u in SERV); eo = sum(_wg[u] * base_[u]["Oracle-KA"]["E"][0] for u in SERV)
    for wc in WC_GRID:
        dd = {u: decide(B[u], cs_, (round(0.8 - wc, 2), wc, 0.2))["EASE"] for u in SERV}
        c_ = sum(_wg[u] * dd[u]["C"][0] for u in SERV); e_ = sum(_wg[u] * dd[u]["E"][0] for u in SERV)
        fr.append(dict(mapping_id=mid, user=mp["T4"], w_C=wc, red_vs_B5=100 * (1 - c_ / c5), dE_vs_B5=100 * (e_ / e5 - 1), differs_B5=int(any(dd[u]["i"][0] != base_[u]["B5"]["i"][0] for u in SERV)),
                       red_vs_Emin=100 * (1 - c_ / cm5), dE_vs_Emin=100 * (e_ / em5 - 1), differs_Emin=int(any(dd[u]["i"][0] != base_[u]["Emin"]["i"][0] for u in SERV)),
                       matches_oracle=int(all(dd[u]["i"][0] == base_[u]["Oracle-KA"]["i"][0] for u in SERV)), gap_vs_oracle=100 * (c_ / co - 1),
                       oracle_red_vs_Emin=100 * (1 - co / cm5), oracle_dE_vs_Emin=100 * (eo / em5 - 1), oracle_differs_Emin=int(any(base_[u]["Oracle-KA"]["i"][0] != base_[u]["Emin"]["i"][0] for u in SERV)),
                       oracle_red_vs_B5=100 * (1 - co / c5), oracle_dE_vs_B5=100 * (eo / e5 - 1), oracle_differs_B5=int(any(base_[u]["Oracle-KA"]["i"][0] != base_[u]["B5"]["i"][0] for u in SERV))))
fr = pd.DataFrame(fr); fr.to_csv(OUT / "weight_frontier_24_mappings.csv", index=False)
S["weight_frontier"] = fr.groupby("w_C").agg(mappings_differ=("differs_B5", "sum"), red_median=("red_vs_B5", "median"), red_min=("red_vs_B5", "min"), red_max=("red_vs_B5", "max"), dE_max=("dE_vs_B5", "max"), dE_median=("dE_vs_B5", "median"),
                                              mappings_differ_Emin=("differs_Emin", "sum"), redE_median=("red_vs_Emin", "median"), redE_min=("red_vs_Emin", "min"), redE_max=("red_vs_Emin", "max"),
                                              dEE_median=("dE_vs_Emin", "median"), dEE_max=("dE_vs_Emin", "max"), oracle_match=("matches_oracle", "sum"), gap_max=("gap_vs_oracle", "max")).reset_index().round(4).to_dict("records")
g0 = fr[fr.w_C == 0.0]; S["oracle_vs_B5_24"] = dict(differ=int(g0.oracle_differs_B5.sum()), red_min=float(g0.oracle_red_vs_B5.min()), red_max=float(g0.oracle_red_vs_B5.max()), dE_max=float(g0.oracle_dE_vs_B5.max()))
S["oracle_vs_Emin_24"] = dict(differ=int(g0.oracle_differs_Emin.sum()), red_min=float(g0.oracle_red_vs_Emin.min()), red_median=float(g0.oracle_red_vs_Emin.median()), red_max=float(g0.oracle_red_vs_Emin.max()), dE_max=float(g0.oracle_dE_vs_Emin.max()))

# ------------------------------------------------------------ E10 communication sensitivity (81 scenarios)
cs_rows = []
for ps, rb, tx, tr in itertools.product((0.5, 1, 10), (0.4, 0.6, 0.8), (0.5, 1, 1.5), (0.5, 1, 2)):
    for u in SERV:
        bcs_ = build(u, payload_scale=ps, rho=rb, tx_scale=tx, transport_scale=tr)
        if not bcs_["mask"].any():
            cs_rows.append(dict(payload=ps, rho=rb, tx=tx, transport=tr, uc=u, EASE="INFEASIBLE", B5="INFEASIBLE", B3="INFEASIBLE", oracle="INFEASIBLE", red_vs_B5=np.nan, red_vs_B3=np.nan)); continue
        d = decide(bcs_, CS)
        cs_rows.append(dict(payload=ps, rho=rb, tx=tx, transport=tr, uc=u, EASE=lab(int(d["EASE"]["i"][0])), B5=lab(int(d["B5"]["i"][0])), B3=lab(int(d["B3"]["i"][0])), oracle=lab(int(d["Oracle-KA"]["i"][0])),
                            red_vs_B5=100 * (1 - d["EASE"]["C"][0] / d["B5"]["C"][0]), red_vs_B3=100 * (1 - d["EASE"]["C"][0] / d["B3"]["C"][0])))
cs = pd.DataFrame(cs_rows); cs.to_csv(OUT / "communication_sensitivity_81.csv", index=False)
refp = static.set_index("uc").placement
S["comm_sensitivity"] = [dict(uc=u, reference=refp[u], stable=int((g.EASE == refp[u]).sum()), infeasible=int((g.EASE == "INFEASIBLE").sum()), matches_oracle=int(((g.EASE == g.oracle) & (g.EASE != "INFEASIBLE")).sum()), red_vs_B5_min=float(g.red_vs_B5.min()), red_vs_B5_max=float(g.red_vs_B5.max()),
                              red_vs_B3_min=float(g.red_vs_B3.min()), red_vs_B3_max=float(g.red_vs_B3.max()), placements=g.EASE.value_counts().to_dict()) for u, g in cs.groupby("uc")]

# ------------------------------------------------------------ E11 parameter sensitivities
sens = {}
def place_all(**kw):
    out = {}
    for u in SERV_ALL:
        b = build(u, **kw); out[u] = lab(int(decide(b, CS)["EASE"]["i"][0])) if b["mask"].any() else "INFEASIBLE"
    return out
def scenario(win=None, ci_static_=None, **kw):
    """Static (volume-weighted) and seasonal EASE-6G savings against B3 and B5 for one input variant."""
    win = WIN if win is None else win; cs_ = CS if ci_static_ is None else ci_static_
    bb_ = {u: build(u, **kw) for u in SERV_ALL}; sv = [u for u in SERV_ALL if bb_[u]["mask"].any()]; wg = pd.Series({u: PEAK[u] for u in sv})
    st_ = {p_: {} for p_ in POL}
    for u in sv:
        d = decide(bb_[u], cs_)
        for p_ in POL: st_[p_][u] = (float(d[p_]["C"][0]), float(d[p_]["E"][0]), lab(int(d[p_]["i"][0])))
    wc = {p_: sum(wg[u] * st_[p_][u][0] for u in sv) / wg.sum() for p_ in POL}; we = {p_: sum(wg[u] * st_[p_][u][1] for u in sv) / wg.sum() for p_ in POL}
    res = dict(served=sv, placements={u: st_["EASE"][u][2] for u in SERV_ALL if u in sv}, B5_placements={u: st_["B5"][u][2] for u in sv},
               static_red_vs_B3=100 * (1 - wc["EASE"] / wc["B3"]), static_dE_vs_B3=100 * (we["EASE"] / we["B3"] - 1),
               static_red_vs_B5=100 * (1 - wc["EASE"] / wc["B5"]), static_dE_vs_B5=100 * (we["EASE"] / we["B5"] - 1),
               static_red_vs_Emin=100 * (1 - wc["EASE"] / wc["Emin"]), static_dE_vs_Emin=100 * (we["EASE"] / we["Emin"] - 1),
               static_oracle_red_vs_Emin=100 * (1 - wc["Oracle-KA"] / wc["Emin"]), Emin_placements={u: st_["Emin"][u][2] for u in sv}, Oracle_placements={u: st_["Oracle-KA"][u][2] for u in sv}, seasonal={})
    for wname, wdf in win.items():
        ch = np.stack([wdf[REFMAP[t]].to_numpy(float) / 1000 for t in TIER], 1); dec = {u: decide(bb_[u], ch) for u in sv}; vals_ = []
        for sd in SEEDS:
            tot = {p_: sum((dec[u][p_]["C"] * R[sd][u].to_numpy()).sum() for u in sv) for p_ in ("EASE", "B3", "B5", "Emin", "Oracle-KA")}
            en = {p_: sum((dec[u][p_]["E"] * R[sd][u].to_numpy()).sum() for u in sv) for p_ in ("EASE", "B3", "B5", "Emin", "Oracle-KA")}
            vals_.append((100 * (1 - tot["EASE"] / tot["B3"]), 100 * (en["EASE"] / en["B3"] - 1), 100 * (1 - tot["EASE"] / tot["B5"]), 100 * (en["EASE"] / en["B5"] - 1),
                          100 * (1 - tot["EASE"] / tot["Emin"]), 100 * (en["EASE"] / en["Emin"] - 1), 100 * (1 - tot["Oracle-KA"] / tot["Emin"])))
        a_ = np.mean(vals_, 0); res["seasonal"][wname] = dict(red_vs_B3=float(a_[0]), dE_vs_B3=float(a_[1]), red_vs_B5=float(a_[2]), dE_vs_B5=float(a_[3]),
                                                             red_vs_Emin=float(a_[4]), dE_vs_Emin=float(a_[5]), oracle_red_vs_Emin=float(a_[6]))
    return res
sens["T4_transport_nJ_per_bit"] = {str(e4): place_all(eps=np.r_[EPS[:3], e4, 0.0]) for e4 in (0.0, 0.30, 1.03, 2.06, 3.39)}
sens["per_request_rate_scale"] = {str(k): place_all(rate=np.r_[RATE[:4] * k, RATE[4]]) for k in (0.25, 0.5, 1, 2, 4)}
def min_rate(u, t, v="V2"):
    x = md1_quantile(RHO_MAX, float(ucrow(u).Rmin)) if t < 4 else 0.0; txm = (1000.0 * float(ucrow(u).payload_Mbit) * 1e6 / (RHO * float(ucrow(u).access_bandwidth_Gbps) * 1e9)) if t < 4 else 0.0
    slack = float(ucrow(u).Lmax_ms) - LAT[t] - txm; return float(1000 * F[VAR.index(v)] * (1 + x) / slack) if slack > 0 else None
sens["min_rate_GFLOPs_for_reference_placement"] = {u: min_rate(u, TIER.index(refp[u].split("-")[0]), refp[u].split("-")[1]) for u in SERV if not refp[u].startswith("T5")}
sens["min_rate_UC1_at_T4"] = min_rate("UC1", 3); sens["queue_quantile_service_times"] = {u: md1_quantile(RHO_MAX, float(ucrow(u).Rmin)) for u in SERV_ALL}
sens["device_rate_GFLOPs"] = {str(r5): place_all(rate=np.r_[RATE[:4], r5]) for r5 in (4, 58.1, 230, 2890)}
sens["device_EE_GFLOP_per_J"] = {str(e5): place_all(ee=np.r_[EE[:4], e5]) for e5 in (100, 200, 300, 461, 730)}
sens["efficiency_level_x_path"] = {f"{k}|{m_}": place_all(ee=EE * k, transport_scale=m_) for k in (0.1, 0.25, 0.5, 1.0) for m_ in (0.5, 1.0, 2.0)}
sens["rho_max"] = {str(r_): place_all(rho_max=r_) for r_ in (0.3, 0.5, 0.7, 0.9)}
sens["headroom_cap"] = {str(c): place_all(cap_ratio=c) for c in (1.5, 2.0, 3.0, 5.0, 1e9)}
# input-variant scenarios on the headline quantities
sens["carbon_accounting"] = {name: scenario(acc_user=au, phi=kp_) for name, (au, kp_) in {"all at user grid": (True, 0.0), "reference (access at user, path split)": (True, 0.5), "all at destination grid": (False, 1.0)}.items()}
WIN_RAW = base.load_carbon_trace_windows(); _ALL_RAW = pd.concat(WIN_RAW.values())
sens["variants"] = {"reference": scenario(),
                    "no carbon floor": scenario(win=WIN_RAW, ci_static_=np.array([[float(_ALL_RAW[REFMAP[t]].mean()) / 1000 for t in TIER]])),
                    "uncompressed payload (1.2 Mbit)": scenario(payload_scale=RAW_MBIT / PAYLOAD_MBIT),
                    "previous efficiency profile (500/350/275/200)": scenario(ee=np.r_[500.0, 350.0, 275.0, 200.0, EE[4]]),
                    "mean-delay latency gate": scenario(gate="mean"),
                    "uniform intensity in every region (marginal-unit proxy)": scenario(win={w_: v_.assign(**{r_: 394.0 for r_ in REGIONS}) for w_, v_ in WIN.items()}, ci_static_=np.full((1, NT), 0.394))}
def _brief(r_): return dict(served=r_["served"], placements=r_["placements"], Emin_placements=r_["Emin_placements"], B5_placements=r_["B5_placements"], Oracle_placements=r_["Oracle_placements"],
                            static_red_vs_Emin=r_["static_red_vs_Emin"], static_dE_vs_Emin=r_["static_dE_vs_Emin"], static_red_vs_B5=r_["static_red_vs_B5"], static_oracle_red_vs_Emin=r_["static_oracle_red_vs_Emin"],
                            seasonal_red_vs_Emin={k_: v_["red_vs_Emin"] for k_, v_ in r_["seasonal"].items()}, seasonal_red_vs_B5={k_: v_["red_vs_B5"] for k_, v_ in r_["seasonal"].items()},
                            seasonal_oracle_red_vs_Emin={k_: v_["oracle_red_vs_Emin"] for k_, v_ in r_["seasonal"].items()})
# efficiency profiles on the savings (T1-T2 one value, T3-T4 another; T5 module value)
EFF_PROF = {"reference (730 all servers)": (730, 730, 461), "server high T1-T2 / low T3-T4 (1274/471)": (1274, 471, 461), "server low T1-T2 / high T3-T4 (471/1274)": (471, 1274, 461),
            "server mid / module mid (730/730, T5 613)": (730, 730, 613), "server high all (1274)": (1274, 1274, 461), "server low all (471)": (471, 471, 461), "previous profile (500/350/275/200)": None}
sens["efficiency_profiles_savings"] = {}
for n_, v_ in EFF_PROF.items():
    ee_ = np.r_[500.0, 350.0, 275.0, 200.0, EE[4]] if v_ is None else np.r_[v_[0], v_[0], v_[1], v_[1], v_[2]]
    sens["efficiency_profiles_savings"][n_] = _brief(scenario(ee=ee_))
# one tier 10% more or less efficient than the others (T2 or T3), on the savings
sens["single_tier_efficiency_savings"] = {f"T{t + 1} x{f_}": _brief(scenario(ee=np.where(np.arange(NT) == t, EE * f_, EE))) for t in (1, 2) for f_ in (0.9, 0.95, 1.05, 1.1)}
sens["efficiency_level_x_path_savings"] = {f"{k}|{m_}": _brief(scenario(ee=EE * k, transport_scale=m_)) for k in (0.1, 0.25, 0.5, 1.0) for m_ in (0.5, 1.0, 2.0)}
sens["payload_kB_savings"] = {str(kb): _brief(scenario(payload_scale=kb * 8e-3 / PAYLOAD_MBIT)) for kb in (10, 12, 14, 14.4, 15, 16, 18, 20)}
# B5 headroom weight (EASE fixed at 0.40/0.40/0.20)
b5w = {}
for wk in (0.10, 0.15, 0.20, 0.22, 0.25, round(1 / 3, 4), 0.40):
    cE = cB = eE = eB = 0.0; pl_ = {}
    for u in SERV:
        d0 = decide(B[u], CS); j = _pick((1 - wk) * (B[u]["E"].ravel()[np.flatnonzero(B[u]["mask"].ravel())].min() / B[u]["E"].ravel()[np.flatnonzero(B[u]["mask"].ravel())])[None, :] + wk * B[u]["kpi"].ravel()[np.flatnonzero(B[u]["mask"].ravel())][None, :],
                                         B[u]["E"].ravel()[np.flatnonzero(B[u]["mask"].ravel())][None, :], B[u]["E"].ravel()[np.flatnonzero(B[u]["mask"].ravel())])[0]
        ib = int(np.flatnonzero(B[u]["mask"].ravel())[j]); pl_[u] = lab(ib)
        cB += _wg[u] * carbon(B[u], [ib], CS)[0, 0]; eB += _wg[u] * B[u]["E"].ravel()[ib]; cE += _wg[u] * d0["EASE"]["C"][0]; eE += _wg[u] * d0["EASE"]["E"][0]
    b5w[str(wk)] = dict(B5_placements=pl_, red_vs_B5=100 * (1 - cE / cB), dE_vs_B5=100 * (eE / eB - 1))
sens["B5_headroom_weight"] = b5w
# UC4 B5 score margin between its two best candidates
_u4 = B["UC4"]; _ix = np.flatnonzero(_u4["mask"].ravel()); _e = _u4["E"].ravel()[_ix]; _sc = (W[0] + W[1]) * _e.min() / _e + W[2] * _u4["kpi"].ravel()[_ix]; _o = np.argsort(-_sc)
sens["UC4_B5_margin"] = dict(best=lab(int(_ix[_o[0]])), second=lab(int(_ix[_o[1]])), margin=float(_sc[_o[0]] - _sc[_o[1]]))
# per-window T2/T3 crossover structure for UC4 (hourly)
def _ab(t, ci):
    a = PUE[t] / EE[t]; return ci[:, t] * a, ci[:, USER] * eacc + b_(t) * (PHI * ci[:, t] + (1 - PHI) * ci[:, USER])
cwin = {}
for wname in WIN:
    ch = ci_hourly(wname); a2, b2 = _ab(1, ch); a3, b3 = _ab(2, ch)
    same = a2 < a3; xc = np.where(same, (b2 - b3) / np.where(a3 - a2 != 0, a3 - a2, np.nan), np.nan)
    cm_ = ch.mean(0, keepdims=True); A2, B2 = _ab(1, cm_); A3, B3 = _ab(2, cm_)
    cwin[wname] = dict(hours=int(len(ch)), opposite_slope_hours=int((~same).sum()), chi_C_median=float(np.nanmedian(xc)) if same.any() else None,
                       chi_C_q10=float(np.nanquantile(xc, .1)) if same.any() else None, chi_C_q90=float(np.nanquantile(xc, .9)) if same.any() else None,
                       mean_CI_T2=float(ch[:, 1].mean() * 1000), mean_CI_T3=float(ch[:, 2].mean() * 1000),
                       window_mean_opposite=bool(A2[0] >= A3[0]), window_mean_chi_C=float((B2[0] - B3[0]) / (A3[0] - A2[0])) if A2[0] < A3[0] else None)
S["crossover_by_window"] = cwin
_ix4 = np.flatnonzero(B["UC4"]["mask"].ravel()); _e4 = B["UC4"]["E"].ravel()[_ix4]; _k4 = B["UC4"]["kpi"].ravel()[_ix4]
_t2, _t3 = [int(np.flatnonzero(_ix4 == 1 * NV + VAR.index("V4"))[0]), int(np.flatnonzero(_ix4 == 2 * NV + VAR.index("V4"))[0])]
sens["UC4_B5_margin"].update(eta_T2=float(_e4.min() / _e4[_t2]), eta_T3=float(_e4.min() / _e4[_t3]), kpi_T2=float(_k4[_t2]), kpi_T3=float(_k4[_t3]),
                          weight_at_tie=float((_e4.min() / _e4[_t3] - _e4.min() / _e4[_t2]) / ((_e4.min() / _e4[_t3] - _e4.min() / _e4[_t2]) + (_k4[_t2] - _k4[_t3]))))
_a3 = PUE[2] / EE[2]; _a2s = _a3 - (b_(1) - b_(2)) / CHI_UC4                                      # T2 coefficient at which chi_E(T2,T3) = chi(UC4)
def _cdiff(ee3):
    ci_ = CS[0]; cu_ = ci_[USER]; f_ = lambda t, a: a * CHI_UC4 * ci_[t] + eacc * cu_ + b_(t) * (PHI * ci_[t] + (1 - PHI) * cu_)
    return f_(1, PUE[1] / EE[1]) - f_(2, PUE[2] / ee3)
from scipy.optimize import brentq
_ee3 = brentq(_cdiff, EE[2], 10 * EE[2])                                                       # T3 efficiency at which chi_C(T2,T3) = chi(UC4)
S["disagreement_band_UC4"] = dict(reference_T2_lead=float(_a3 / (PUE[1] / EE[1]) - 1), T2_lead_max=float(_a3 / _a2s - 1), T3_lead_max=float((PUE[1] / EE[1]) / (PUE[2] / _ee3) - 1),
                                  EE_T2_at_upper=float(PUE[1] / _a2s), EE_T3_at_lower=float(_ee3))
# static volume-weighted saving against E-min over the 24 mappings without the carbon floor, and floor statistics
_nf = []
for mid, perm in enumerate(itertools.permutations(REGIONS), 1):
    mp = dict(zip(TIER[:4], perm)); mp["T5"] = mp["T4"]; c_ = np.array([[float(_ALL_RAW[mp[t]].mean()) / 1000 for t in TIER]]); d_ = {u: decide(B[u], c_) for u in SERV}
    _nf.append(100 * (1 - sum(_wg[u] * d_[u]["EASE"]["C"][0] for u in SERV) / sum(_wg[u] * d_[u]["Emin"]["C"][0] for u in SERV)))
S["no_floor_mappings"] = dict(min=float(min(_nf)), median=float(np.median(_nf)), max=float(max(_nf)))
S["floor_stats"] = {r_: dict(hours_below_floor=int((_ALL_RAW[r_] < CI_FLOOR).sum()), hours=int(len(_ALL_RAW)), mean_raw=float(_ALL_RAW[r_].mean()), mean_floored=float(_ALL[r_].mean())) for r_ in REGIONS}
S["sensitivity"] = sens

# ------------------------------------------------------------ E13 robustness requested in review: floor in the score only, zero-safe score, marginal bound, forecast error, volume mix
def decide2(b, ci_score, ci_acc, w=W, offset_ci=None):
    """EASE-6G, E-min and Oracle-KA with the carbon score computed on ci_score and carbon accounted on ci_acc ([H,T], kg/kWh).
    offset_ci (kg/kWh): no floor; the carbon score is (c_min + c0)/(c + c0) with c0 = E_min x offset_ci / 3.6, which stays defined when c_min = 0."""
    ci_score = np.atleast_2d(ci_score); ci_acc = np.atleast_2d(ci_acc)
    idx = np.flatnonzero(b["mask"].ravel()); e = b["E"].ravel()[idx]; k = b["kpi"].ravel()[idx]
    Cs = carbon(b, idx, ci_score); Ca = carbon(b, idx, ci_acc)
    if offset_ci is None: ce = np.where(Cs > 0, Cs.min(1, keepdims=True) / np.where(Cs > 0, Cs, 1.0), 1.0)
    else: c0 = e.min() * offset_ci / 3.6; ce = (Cs.min(1, keepdims=True) + c0) / (Cs + c0)
    eta = e.min() / e; H = Cs.shape[0]; rep = lambda x: np.repeat(x[None, :], H, 0); r = np.arange(H)
    pk = {"EASE": _pick(w[0] * eta[None, :] + w[1] * ce + w[2] * k[None, :], Cs, e), "Emin": _pick(rep(-e), Ca, e), "Oracle-KA": _pick(-Ca, Ca, e)}
    return {p_: dict(i=idx[j], C=Ca[r, j], E=e[j]) for p_, j in pk.items()}
def run_variant(score_win, acc_win, offset_ci=None, mappings=True):
    aS, aA = pd.concat(score_win.values()), pd.concat(acc_win.values())
    stat = lambda ax, mp: np.array([[float(ax[mp[t]].mean()) / 1000 for t in TIER]])
    def wstat(mp):
        d = {u: decide2(B[u], stat(aS, mp), stat(aA, mp), offset_ci=offset_ci) for u in SERV}; c = {p_: sum(_wg[u] * d[u][p_]["C"][0] for u in SERV) for p_ in ("EASE", "Emin", "Oracle-KA")}
        e = {p_: sum(_wg[u] * d[u][p_]["E"][0] for u in SERV) for p_ in ("EASE", "Emin")}
        return 100 * (1 - c["EASE"] / c["Emin"]), 100 * (e["EASE"] / e["Emin"] - 1), {u: lab(int(d[u]["EASE"]["i"][0])) for u in SERV}, 100 * (c["EASE"] / c["Oracle-KA"] - 1)
    red, dE, pl, gap = wstat(REFMAP); sea = {}; sig = []
    for wname in WIN:
        chS = np.stack([score_win[wname][REFMAP[t]].to_numpy(float) / 1000 for t in TIER], 1); chA = np.stack([acc_win[wname][REFMAP[t]].to_numpy(float) / 1000 for t in TIER], 1)
        dec = {u: decide2(B[u], chS, chA, offset_ci=offset_ci) for u in SERV}; v_ = []; sig += [int(i_) for u in SERV for i_ in dec[u]["EASE"]["i"]]
        for sd in SEEDS:
            tot = {p_: sum((dec[u][p_]["C"] * R[sd][u].to_numpy()).sum() for u in SERV) for p_ in ("EASE", "Emin", "Oracle-KA")}
            v_.append((100 * (1 - tot["EASE"] / tot["Emin"]) if tot["Emin"] > 0 else 0.0, 100 * (tot["EASE"] / tot["Oracle-KA"] - 1) if tot["Oracle-KA"] > 0 else 0.0))
        sea[wname] = dict(red_vs_Emin=float(np.mean([x[0] for x in v_])), gap_vs_oracle=float(np.mean([x[1] for x in v_])))
    out = dict(static_red_vs_Emin=red, static_dE_vs_Emin=dE, placements=pl, static_gap_vs_oracle=gap, seasonal=sea)
    if mappings:
        rs = []
        for perm in itertools.permutations(REGIONS):
            mp = dict(zip(TIER[:4], perm)); mp["T5"] = mp["T4"]; rs.append(wstat(mp)); sig += sorted(rs[-1][2].items())
        out["mappings"] = dict(min=float(min(x[0] for x in rs)), median=float(np.median([x[0] for x in rs])), max=float(max(x[0] for x in rs)), gap_max=float(max(x[3] for x in rs)))
    out["_sig"] = sig
    return out
_floor = lambda fl: {w_: v_.assign(**{r_: v_[r_].clip(lower=fl) for r_ in REGIONS}) for w_, v_ in WIN_RAW.items()}
rob = {}
rob["floor"] = {"11 g/kWh in signal (reference)": run_variant(WIN, WIN)}
for fl in (11.0, 5.0, 1.0): rob["floor"][f"{fl:g} g/kWh in score only"] = run_variant(_floor(fl), WIN_RAW)
rob["floor"]["no floor, zero-safe score (offset 1 g/kWh)"] = run_variant(WIN_RAW, WIN_RAW, offset_ci=0.001)
rob["floor"]["no floor, zero-safe score (offset 0.1 g/kWh)"] = run_variant(WIN_RAW, WIN_RAW, offset_ci=0.0001)
_ref_sig = rob["floor"]["11 g/kWh in signal (reference)"]["_sig"]
rob["floor_same_EASE_decisions"] = {k_: bool(v_["_sig"] == _ref_sig) for k_, v_ in rob["floor"].items()}
rob["floor_decisions_differing"] = {k_: dict(differ=int(sum(a_ != b_ for a_, b_ in zip(v_["_sig"], _ref_sig))), total=len(_ref_sig)) for k_, v_ in rob["floor"].items()}
for v_ in rob["floor"].values(): v_.pop("_sig", None)
rob["floor_counts"] = dict(zero_hours={r_: int((pd.concat(WIN_RAW.values())[r_] <= 0).sum()) for r_ in REGIONS})
# bounded marginal-emissions scenario: accounting and score on lam x regional average + (1 - lam) x a uniform marginal factor (Hawkes: 0.69 kg/kWh for GB)
MEF = 690.0
rob["marginal_blend"] = {}
for lam in (1.0, 0.75, 0.5, 0.25, 0.0):
    wb = {w_: v_.assign(**{r_: lam * v_[r_] + (1 - lam) * MEF for r_ in REGIONS}) for w_, v_ in WIN.items()}
    rob["marginal_blend"][str(lam)] = run_variant(wb, wb, mappings=True); rob["marginal_blend"][str(lam)].pop("_sig", None)
# forecast error: decisions on a noisy signal, carbon accounted on the signal itself (multiplicative lognormal error, independent per hour and region)
rob["forecast_error"] = {}
for sig in (0.1, 0.25, 0.5):
    acc_ = []
    for ns in range(5):
        rg = np.random.default_rng(1000 + ns)
        wn = {w_: v_.assign(**{r_: (v_[r_] * np.exp(sig * rg.standard_normal(len(v_)) - sig ** 2 / 2)).clip(lower=CI_FLOOR) for r_ in REGIONS}) for w_, v_ in WIN.items()}
        acc_.append(run_variant(wn, WIN, mappings=False))
    for run_ in acc_: run_.pop("_sig", None)
    rob["forecast_error"][str(sig)] = {w_: dict(red_vs_Emin=float(np.mean([a["seasonal"][w_]["red_vs_Emin"] for a in acc_])), gap_vs_oracle=float(np.mean([a["seasonal"][w_]["gap_vs_oracle"] for a in acc_]))) for w_ in WIN}
# request-volume mix (static, reference): UC4 share varied, the other services keep their relative volumes; and equal weights
_d0 = {u: decide(B[u], CS) for u in SERV}; _cE = {u: _d0[u]["EASE"]["C"][0] for u in SERV}; _cM = {u: _d0[u]["Emin"]["C"][0] for u in SERV}
_eE = {u: _d0[u]["EASE"]["E"][0] for u in SERV}; _eM = {u: _d0[u]["Emin"]["E"][0] for u in SERV}
def _mix(wts):
    return dict(red_vs_Emin=float(100 * (1 - sum(wts[u] * _cE[u] for u in SERV) / sum(wts[u] * _cM[u] for u in SERV))), dE_vs_Emin=float(100 * (sum(wts[u] * _eE[u] for u in SERV) / sum(wts[u] * _eM[u] for u in SERV) - 1)))
_oth = {u: PEAK[u] for u in SERV if u != "UC4"}; _os = sum(_oth.values())
rob["volume_mix"] = {f"UC4 {int(round(100 * sh))}%": _mix({**{u: (1 - sh) * _oth[u] / _os for u in _oth}, "UC4": sh}) for sh in (float(WGT["UC4"] / WGT.sum()), 0.75, 0.5, 0.25, 0.1, 0.0)}
rob["volume_mix"]["equal weights"] = _mix({u: 1.0 for u in SERV})
rob["per_service_red_vs_Emin"] = {u: float(100 * (1 - _cE[u] / _cM[u])) for u in SERV}
S["robustness_review"] = rob

# ------------------------------------------------------------ E12 MILP scaling
def scale_run(n, seed):
    rng = np.random.default_rng(seed); types = rng.choice(SERV, size=n); svs = []
    for u in types:
        idx, e, k, lr, C, eta, ce = scores(B[u], CS)
        svs.append(dict(u=u, rate=STRESS[u] * rng.uniform(0.5, 1.5), idx=idx, score=W[0] * eta + W[1] * ce[0] + W[2] * k, carbon=C[0]))
    caps = CAPV * (n / 5.0); caps[4] = CAPV[4]
    sel, dt, status = solve(svs, caps, np.ones(NT, bool), allow_unserved=True, time_limit=30.0, gap=1e-4)
    return dict(services=n, binaries=sum(len(s["idx"]) for s in svs) + n, solve_s=dt, status=int(status), unserved=None if sel is None else int(sum(x is None for x in sel)))
sc = pd.DataFrame([scale_run(n, s) for n in (5, 50, 250, 1000) for s in (0, 1, 2)]); sc.to_csv(OUT / "milp_scaling.csv", index=False)
S["milp_scaling"] = sc.groupby("services").agg(binaries=("binaries", "mean"), solve_s_mean=("solve_s", "mean"), solve_s_max=("solve_s", "max"), hit_time_limit=("status", lambda x: int((x == 1).sum())), unserved_mean=("unserved", "mean"), unserved_max=("unserved", "max"), runs_with_unserved=("unserved", lambda x: int((x > 0).sum()))).round(4).reset_index().to_dict("records")

(OUT / "v2_summary.json").write_text(json.dumps(S, indent=1, default=float))
print("done", OUT)
