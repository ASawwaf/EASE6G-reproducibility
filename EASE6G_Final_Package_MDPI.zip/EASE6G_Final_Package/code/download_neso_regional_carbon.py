#!/usr/bin/env python3
"""Download and freeze the NESO Regional Carbon Intensity Forecast archive.

The research pipeline itself never performs a live API call. This utility refreshes
NESO's official archive, validates the three pre-specified 2026 windows, and writes
compact CSV extracts plus retrieval metadata for reproducibility.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

import pandas as pd

URL = (
    "https://api.neso.energy/dataset/"
    "bf3d723b-b4ae-4ec7-9fc9-e584c651a9da/resource/"
    "c16b0e19-c02a-44a8-ba05-4db2c0545a2a/download/"
    "regional_carbon_intensity.csv"
)
WINDOWS = [
    ("winter_2026", "2026-01-12T00:00:00Z", "2026-01-19T00:00:00Z"),
    ("spring_2026", "2026-04-13T00:00:00Z", "2026-04-20T00:00:00Z"),
    ("summer_2026", "2026-07-06T00:00:00Z", "2026-07-13T00:00:00Z"),
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent / "data")
    args = ap.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    archive = args.output_dir / "regional_carbon_intensity_archive.csv"
    req = Request(URL, headers={"User-Agent": "EASE-6G-reproducibility/1.0"})
    with urlopen(req, timeout=120) as r, archive.open("wb") as f:
        f.write(r.read())

    df = pd.read_csv(archive)
    df["datetime"] = pd.to_datetime(df["datetime"], utc=True)
    outputs = []
    for label, start, end in WINDOWS:
        start_ts, end_ts = pd.Timestamp(start), pd.Timestamp(end)
        w = df[(df.datetime >= start_ts) & (df.datetime < end_ts)].copy()
        if len(w) != 336:
            raise RuntimeError(f"{label}: expected 336 half-hour rows, found {len(w)}")
        if w.drop(columns=["datetime"]).isna().any().any():
            raise RuntimeError(f"{label}: archive contains missing regional values")
        out = args.output_dir / f"neso_regional_{label}.csv"
        w.to_csv(out, index=False)
        outputs.append({"label": label, "start": start, "end": end, "rows": len(w), "file": out.name, "sha256": sha256(out)})

    meta = {
        "source_url": URL,
        "retrieved_utc": datetime.now(timezone.utc).isoformat(),
        "archive_file": archive.name,
        "archive_sha256": sha256(archive),
        "selection_rule": "Second complete Monday-Sunday week of January, April, and July 2026 available before manuscript cutoff.",
        "windows": outputs,
    }
    (args.output_dir / "neso_2026_trace_metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
