#!/usr/bin/env python3
"""6G-direction extensions on the v2 model (additive).
X1  Device-network split inference for UC5 (ViT blocks split after block k; feature of 197 x d tokens sent uplink).
X2  2030 grid scenario: uniform decarbonisation to the Clean Power 2030 level and regional convergence.
Outputs: results/v2_6g/.
"""
import itertools, json
from pathlib import Path
import numpy as np, pandas as pd
import ease6g_v2 as m

OUT = Path(__file__).resolve().parent.parent / "results" / "v2_6g"; OUT.mkdir(parents=True, exist_ok=True)
NB = 12; TOK = 198; DIM = {"V1": 768, "V2": 384, "V3": 768, "V4": 384}
NATIVE_BITS = {"V1": 32, "V2": 32, "V3": 8, "V4": 32}
uc = m.ucrow("UC5"); D0 = m.RAW_MBIT * 1e6          # split analysis on the uncompressed input tensor; with the compressed input the 8-bit feature (0.61 Mbit) is larger than the input
EE5 = m.EE[4]; S = {}

def cands(r5, feat_bits="native", allow_split=True):
    """Candidate list for UC5: (tier, variant, k). k=0 full offload, 1..11 split, 12 full on-device.
    Energy is split into device compute, access, path and network compute so that each part is charged to its own grid."""
    rows = []
    for vi, v in enumerate(m.VAR):
        if m.ACC[vi] < uc.Accmin_percent: continue
        Fv, dl = m.F[vi], m.DELTA[vi]
        for k in ([0] + (list(range(1, NB)) if allow_split else [])):
            bits = D0 if k == 0 else TOK * DIM[v] * (NATIVE_BITS[v] if feat_bits == "native" else feat_bits)
            for t in range(4):
                if not (m.BW[t] >= uc.Bmin_Gbps and m.REL[t] >= uc.Rmin and m.JIT[t] <= uc.Jmax_ms): continue
                e_dev = (k / NB) * Fv * dl / EE5
                e_acc = float(uc.access_tx_power_W) * bits / (m.RHO * float(uc.access_bandwidth_Gbps) * 1e9)
                e_path = bits * m.EPS[t] * 1e-9
                e_cn = m.PUE[t] / m.EE[t] * ((NB - k) / NB) * Fv * dl
                svc = 1000 * ((NB - k) / NB) * Fv / m.RATE[t]
                lat = 1000 * (k / NB) * Fv / r5 + m.LAT[t] + 1000 * bits / (m.RHO * float(uc.access_bandwidth_Gbps) * 1e9) + svc + m.RHO_MAX * svc / (2 * (1 - m.RHO_MAX))
                if lat > uc.Lmax_ms: continue
                kp = (min(uc.Lmax_ms / lat, m.CAP_RATIO) + min(m.BW[t] / uc.Bmin_Gbps, m.CAP_RATIO) + min(m.REL[t] / uc.Rmin, m.CAP_RATIO) + min(uc.Jmax_ms / m.JIT[t], m.CAP_RATIO))
                rows.append(dict(tier=t, variant=v, k=k, e_dev=e_dev, e_acc=e_acc, e_path=e_path, e_cn=e_cn, lat=lat, kpi_raw=kp, mbit=bits / 1e6,
                                 chi=((NB - k) / NB) * Fv * dl / (bits / 1e6)))
        lat = 1000 * Fv / r5 + m.LAT[4]           # full on-device
        if lat <= uc.Lmax_ms and m.REL[4] >= uc.Rmin and m.JIT[4] <= uc.Jmax_ms:
            kp = min(uc.Lmax_ms / lat, m.CAP_RATIO) + m.CAP_RATIO + min(m.REL[4] / uc.Rmin, m.CAP_RATIO) + min(uc.Jmax_ms / m.JIT[4], m.CAP_RATIO)
            rows.append(dict(tier=4, variant=v, k=NB, e_dev=Fv * dl / EE5, e_acc=0.0, e_path=0.0, e_cn=0.0, lat=lat, kpi_raw=kp, mbit=0.0, chi=0.0))
    c = pd.DataFrame(rows); c["e_net"] = c.e_acc + c.e_path + c.e_cn; c["E"] = c.e_dev + c.e_net; c["kpi"] = c.kpi_raw / c.kpi_raw.max(); return c

def decide(c, ci, w=m.W):
    ci = np.atleast_2d(ci); e = c.E.to_numpy(); k = c.kpi.to_numpy(); lr = c.lat.to_numpy() / uc.Lmax_ms
    ct = ci[:, c.tier.to_numpy()]; cu = ci[:, [m.USER]]
    C = ((c.e_dev.to_numpy() + c.e_acc.to_numpy())[None, :] * cu + c.e_cn.to_numpy()[None, :] * ct
         + c.e_path.to_numpy()[None, :] * (m.PHI * ct + (1 - m.PHI) * cu)) / 3.6
    eta = e.min() / e; cmin = C.min(1, keepdims=True); ce = np.where(C > 0, cmin / np.where(C > 0, C, 1), 1.0)
    H = len(C); rep = lambda x: np.repeat(x[None, :], H, 0)
    pk = {"EASE": m._pick(w[0] * eta[None, :] + w[1] * ce + w[2] * k[None, :], C, e), "B5": m._pick(rep((w[0] + w[1]) * eta + w[2] * k), rep(e), e),
          "B3": m._pick(rep(-lr * 1e6 - e), rep(e), e), "Emin": m._pick(rep(-e), C, e), "Oracle": m._pick(-C, C, e)}
    r = np.arange(H); return {p: dict(j=j, C=C[r, j], E=e[j]) for p, j in pk.items()}

lab = lambda c, j: f"{m.TIER[int(c.tier.iloc[j])]}-{c.variant.iloc[j]}-k{int(c.k.iloc[j])}"
CS = m.ci_static()

# feature size and effective intensity by split point (V2)
tab = cands(1e9, "native"); t8 = cands(1e9, 8)
S["X1_chi_by_split_V2_T1"] = [dict(k=k, mbit_fp32=float(tab[(tab.variant == "V2") & (tab.tier == 0) & (tab.k == k)].mbit.iloc[0]), chi_fp32=float(tab[(tab.variant == "V2") & (tab.tier == 0) & (tab.k == k)].chi.iloc[0]),
                                    mbit_8bit=float(t8[(t8.variant == "V2") & (t8.tier == 0) & (t8.k == k)].mbit.iloc[0]), chi_8bit=float(t8[(t8.variant == "V2") & (t8.tier == 0) & (t8.k == k)].chi.iloc[0])) for k in (0, 1, 3, 6, 9, 11)]

rows = []; seas = []
for r5 in (4, 58.1, 230, 2890):
    for fb in ("native", 8):
        base_c = cands(r5, fb, allow_split=False); c = cands(r5, fb)
        d0 = decide(base_c, CS); d = decide(c, CS)
        rows.append(dict(device_rate=r5, feature_bits=fb, n_candidates=len(c), n_split_feasible=int(((c.k > 0) & (c.k < NB)).sum()),
                         no_split=lab(base_c, d0["EASE"]["j"][0]), EASE=lab(c, d["EASE"]["j"][0]), B3=lab(c, d["B3"]["j"][0]), B5=lab(c, d["B5"]["j"][0]), Emin=lab(c, d["Emin"]["j"][0]), Oracle=lab(c, d["Oracle"]["j"][0]),
                         gap_vs_oracle_percent=100 * (d["EASE"]["C"][0] / d["Oracle"]["C"][0] - 1), red_vs_Emin_percent=100 * (1 - d["EASE"]["C"][0] / d["Emin"]["C"][0]), dE_vs_Emin_percent=100 * (d["EASE"]["E"][0] / d["Emin"]["E"][0] - 1),
                         E_no_split=float(d0["EASE"]["E"][0]), E_EASE=float(d["EASE"]["E"][0]), C_no_split=float(d0["EASE"]["C"][0]), C_EASE=float(d["EASE"]["C"][0]), C_oracle=float(d["Oracle"]["C"][0]),
                         carbon_change_vs_no_split_percent=100 * (d["EASE"]["C"][0] / d0["EASE"]["C"][0] - 1), energy_change_vs_no_split_percent=100 * (d["EASE"]["E"][0] / d0["EASE"]["E"][0] - 1),
                         red_vs_B3_percent=100 * (1 - d["EASE"]["C"][0] / d["B3"]["C"][0]), red_vs_B5_percent=100 * (1 - d["EASE"]["C"][0] / d["B5"]["C"][0])))
        for w in m.WIN:
            ch = m.ci_hourly(w); dh0 = decide(base_c, ch); dh = decide(c, ch); acc = []
            for s in m.SEEDS:
                wt = m.R[s]["UC5"].to_numpy() * 3600
                f = lambda x: (x * wt).sum()
                acc.append([f(dh["EASE"]["C"]) / 1e6, f(dh0["EASE"]["C"]) / 1e6, f(dh["B3"]["C"]) / 1e6, f(dh["Oracle"]["C"]) / 1e6, f(dh["EASE"]["E"]) / 3.6e6, f(dh0["EASE"]["E"]) / 3.6e6, f(dh["Emin"]["C"]) / 1e6])
            a = np.mean(acc, 0); kk = c.k.to_numpy()[dh["EASE"]["j"]]
            seas.append(dict(device_rate=r5, feature_bits=fb, window=w, kg_EASE=a[0], kg_no_split=a[1], kg_B3=a[2], kg_oracle=a[3], kg_Emin=a[6], gap_vs_oracle_percent=100 * (a[0] / a[3] - 1),
                             carbon_change_vs_no_split_percent=100 * (a[0] / a[1] - 1) if a[1] > 0 else np.nan,
                             energy_change_vs_no_split_percent=100 * (a[4] / a[5] - 1), hours_split=int(((kk > 0) & (kk < NB)).sum()), hours_on_device=int((kk == NB).sum()), hours_offload=int((kk == 0).sum())))
x1 = pd.DataFrame(rows); x1.to_csv(OUT / "X1_split_static.csv", index=False); xs = pd.DataFrame(seas); xs.to_csv(OUT / "X1_split_seasonal.csv", index=False)
S["X1_static"] = x1.round(5).to_dict("records"); S["X1_seasonal"] = xs.round(4).to_dict("records")
# split across 24 mappings
mp_rows = []
for mid, perm in enumerate(itertools.permutations(m.REGIONS), 1):
    mp = dict(zip(m.TIER[:4], perm)); mp["T5"] = mp["T4"]; cs = m.ci_static(mp)
    for r5, fb in ((58.1, 8), (58.1, "native"), (2890, 8), (2890, "native")):
        c = cands(r5, fb); c0 = cands(r5, fb, allow_split=False); d = decide(c, cs); d0 = decide(c0, cs); kk = int(c.k.iloc[d["EASE"]["j"][0]])
        mp_rows.append(dict(mapping_id=mid, device_rate=r5, feature_bits=fb, EASE=lab(c, d["EASE"]["j"][0]), is_split=0 < kk < NB, on_device=kk == NB, matches_oracle=bool(abs(d["EASE"]["C"][0] - d["Oracle"]["C"][0]) <= 1e-12 * max(1, d["Oracle"]["C"][0])),
                            gap_vs_oracle_percent=100 * (d["EASE"]["C"][0] / d["Oracle"]["C"][0] - 1),
                            carbon_change_vs_no_split_percent=100 * (d["EASE"]["C"][0] / d0["EASE"]["C"][0] - 1) if d0["EASE"]["C"][0] > 0 else np.nan))
mpd = pd.DataFrame(mp_rows); mpd.to_csv(OUT / "X1_split_24_mappings.csv", index=False)
S["X1_24_mappings"] = mpd.groupby(["device_rate", "feature_bits"]).agg(split=("is_split", "sum"), on_device=("on_device", "sum"), matches_oracle=("matches_oracle", "sum"), carbon_change_min=("carbon_change_vs_no_split_percent", "min"),
                                  carbon_change_median=("carbon_change_vs_no_split_percent", "median"), carbon_change_max=("carbon_change_vs_no_split_percent", "max"), gap_max=("gap_vs_oracle_percent", "max")).reset_index().astype({"feature_bits": str}).round(3).to_dict("records")

# ---------------------------------------------------------------- X2 2030 grid
allw = pd.concat(m.WIN.values()); regs = m.REGIONS; mean_now = float(allw[regs].to_numpy().mean()); TARGET = 50.0
S["X2_setup"] = dict(mean_2026_four_regions_g_per_kWh=mean_now, target_2030_g_per_kWh=TARGET, scale=TARGET / mean_now)
def ci_scn(w, s, g):
    h = m.WIN[w]; mh = h[regs].to_numpy(float).mean(1, keepdims=True)
    return np.stack([np.maximum(s * (mh[:, 0] + g * (h[m.REFMAP[t]].to_numpy(float) - mh[:, 0])), m.CI_FLOOR) / 1000 for t in m.TIER], 1)
x2 = []
for name, s, g in (("2026 traces", 1.0, 1.0), ("2030 uniform", TARGET / mean_now, 1.0), ("2030, spread halved", TARGET / mean_now, 0.5), ("2030, spread quartered", TARGET / mean_now, 0.25), ("2030, no regional spread", TARGET / mean_now, 0.0)):
    for w in m.WIN:
        ch = ci_scn(w, s, g); dec = {u: m.decide(m.B[u], ch) for u in m.SERV}; acc = []
        for sd in m.SEEDS:
            C = {p: sum((dec[u][p]["C"] * m.R[sd][u].to_numpy() * 3600).sum() for u in m.SERV) / 1e6 for p in ("EASE", "B3", "B5", "Emin", "Oracle-KA")}
            E = {p: sum((dec[u][p]["E"] * m.R[sd][u].to_numpy() * 3600).sum() for u in m.SERV) / 3.6e6 for p in ("EASE", "B3", "B5", "Emin")}
            acc.append([C["EASE"], C["B3"], C["B5"], C["Oracle-KA"], E["EASE"], E["B3"], C["Emin"], E["Emin"]])
        a = np.mean(acc, 0); dif = sum(int((dec[u]["EASE"]["i"] != dec[u]["B3"]["i"]).sum()) for u in m.SERV)
        x2.append(dict(scenario=name, window=w, kg_EASE=a[0], kg_B3=a[1], kg_saved_vs_B3=a[1] - a[0], red_vs_B3_percent=100 * (1 - a[0] / a[1]), red_vs_B5_percent=100 * (1 - a[0] / a[2]), red_vs_Emin_percent=100 * (1 - a[0] / a[6]), kg_saved_vs_Emin=a[6] - a[0], dE_vs_Emin_percent=100 * (a[4] / a[7] - 1), gap_vs_oracle_percent=100 * (a[0] / a[3] - 1),
                       energy_change_vs_B3_percent=100 * (a[4] / a[5] - 1), service_hours_differ_B3=dif))
x2 = pd.DataFrame(x2); x2.to_csv(OUT / "X2_grid_2030.csv", index=False); S["X2"] = x2.round(4).to_dict("records")
# X2b: value of carbon awareness (EASE vs carbon-unaware B5) across all 24 mappings under the same scenarios
def ci_scn_map(w, s_, g_, mp):
    h = m.WIN[w]; mh = h[regs].to_numpy(float).mean(1)
    return np.stack([np.maximum(s_ * (mh + g_ * (h[mp[t]].to_numpy(float) - mh)), m.CI_FLOOR) / 1000 for t in m.TIER], 1)
WG = m.WGT / m.WGT.sum(); x2b = []
for name, s_, g_ in (("2026 traces", 1.0, 1.0), ("2030 uniform", TARGET / mean_now, 1.0), ("2030, spread halved", TARGET / mean_now, 0.5), ("2030, spread quartered", TARGET / mean_now, 0.25), ("2030, no regional spread", TARGET / mean_now, 0.0)):
    for mid, perm in enumerate(itertools.permutations(m.REGIONS), 1):
        mp = dict(zip(m.TIER[:4], perm)); mp["T5"] = mp["T4"]
        cst = np.concatenate([ci_scn_map(w, s_, g_, mp) for w in m.WIN]).mean(0, keepdims=True)
        dst = {u: m.decide(m.B[u], cst) for u in m.SERV}
        cE = sum(WG[u] * dst[u]["EASE"]["C"][0] for u in m.SERV); c5 = sum(WG[u] * dst[u]["B5"]["C"][0] for u in m.SERV); cm_ = sum(WG[u] * dst[u]["Emin"]["C"][0] for u in m.SERV)
        eE = sum(WG[u] * dst[u]["EASE"]["E"][0] for u in m.SERV); e5 = sum(WG[u] * dst[u]["B5"]["E"][0] for u in m.SERV)
        row = dict(scenario=name, mapping_id=mid, user_grid=mp["T4"], static_red_vs_B5=100 * (1 - cE / c5) if c5 > 0 else np.nan, static_dE_vs_B5=100 * (eE / e5 - 1), static_red_vs_Emin=100 * (1 - cE / cm_) if cm_ > 0 else np.nan)
        for w in m.WIN:
            ch = ci_scn_map(w, s_, g_, mp); dec = {u: m.decide(m.B[u], ch) for u in m.SERV}; acc = []
            for sd in m.SEEDS:
                C = {p: sum((dec[u][p]["C"] * m.R[sd][u].to_numpy() * 3600).sum() for u in m.SERV) / 1e6 for p in ("EASE", "B5", "Emin")}
                E = {p: sum((dec[u][p]["E"] * m.R[sd][u].to_numpy() * 3600).sum() for u in m.SERV) / 3.6e6 for p in ("EASE", "B5", "Emin")}
                acc.append([C["B5"] - C["EASE"], C["B5"], E["EASE"] / E["B5"] - 1, C["Emin"] - C["EASE"], C["Emin"], E["EASE"] / E["Emin"] - 1])
            a = np.mean(acc, 0); row[w.split()[0] + "_kg_saved_vs_B5"] = a[0]; row[w.split()[0] + "_red_vs_B5"] = 100 * a[0] / a[1] if a[1] > 1e-9 else np.nan; row[w.split()[0] + "_dE_vs_B5"] = 100 * a[2]
            row[w.split()[0] + "_kg_saved_vs_Emin"] = a[3]; row[w.split()[0] + "_red_vs_Emin"] = 100 * a[3] / a[4] if a[4] > 1e-9 else np.nan; row[w.split()[0] + "_dE_vs_Emin"] = 100 * a[5]
        x2b.append(row)
x2b = pd.DataFrame(x2b); x2b.to_csv(OUT / "X2b_carbon_awareness_24_mappings.csv", index=False)
def _x2b(g):
    kg = g[[w.split()[0] + "_kg_saved_vs_B5" for w in m.WIN]].to_numpy().ravel(); rd = g[[w.split()[0] + "_red_vs_B5" for w in m.WIN]].to_numpy().ravel()
    de = g[[w.split()[0] + "_dE_vs_B5" for w in m.WIN]].to_numpy().ravel()
    kgE = g[[w.split()[0] + "_kg_saved_vs_Emin" for w in m.WIN]].to_numpy().ravel(); rdE = g[[w.split()[0] + "_red_vs_Emin" for w in m.WIN]].to_numpy().ravel()
    deE = g[[w.split()[0] + "_dE_vs_Emin" for w in m.WIN]].to_numpy().ravel()
    return dict(static_positive=int((g.static_red_vs_B5 > 1e-9).sum()), static_max=float(g.static_red_vs_B5.max()), static_dE_max=float(g.static_dE_vs_B5.max()),
                cells_positive=int((kg > 1e-9).sum()), cells_red_median=float(np.nanmedian(rd)), kg_saved_mean=float(kg.mean()), kg_saved_max=float(kg.max()), dE_max=float(de.max()),
                static_positive_Emin=int((g.static_red_vs_Emin > 1e-9).sum()), static_max_Emin=float(g.static_red_vs_Emin.max()), static_median_Emin=float(g.static_red_vs_Emin.median()),
                cells_positive_Emin=int((kgE > 1e-9).sum()), cells_red_median_Emin=float(np.nanmedian(rdE)), cells_red_min_Emin=float(np.nanmin(rdE)), cells_red_max_Emin=float(np.nanmax(rdE)),
                kg_saved_mean_Emin=float(kgE.mean()), kg_saved_max_Emin=float(kgE.max()), dE_max_Emin=float(deE.max()))
S["X2b"] = {name: _x2b(g) for name, g in x2b.groupby("scenario", sort=False)}
# ---------------------------------------------------------------- X1b device-efficiency sweep (MLPerf device rate)
ee_rows = []
for ee in (100, 200, 300, 461):
    EE5 = ee
    for fb in ("native", 8):
        c = cands(m.RATE[4], fb); c0 = cands(m.RATE[4], fb, allow_split=False); d = decide(c, CS); d0 = decide(c0, CS); ns = nd = 0
        for perm in itertools.permutations(m.REGIONS):
            mp = dict(zip(m.TIER[:4], perm)); mp["T5"] = mp["T4"]; dd = decide(c, m.ci_static(mp)); kk = int(c.k.iloc[dd["EASE"]["j"][0]]); ns += 0 < kk < NB; nd += kk == NB
        ee_rows.append(dict(device_EE=ee, feat=fb, static_ref=lab(c, d["EASE"]["j"][0]), static_dC=100 * (d["EASE"]["C"][0] / d0["EASE"]["C"][0] - 1), static_dE=100 * (d["EASE"]["E"][0] / d0["EASE"]["E"][0] - 1), maps_split=int(ns), maps_device=int(nd)))
EE5 = m.EE[4]
pd.DataFrame(ee_rows).to_csv(OUT / "X1_device_efficiency_sweep.csv", index=False); S["X1_device_efficiency"] = ee_rows
# ---------------------------------------------------------------- X3 6G: inference co-located with the RAN (AI-RAN far edge)
# T4 is replaced by a RAN-co-located tier: 0.1-ms service latency, 0.05-ms jitter, 1-1e-7 reliability, no backhaul path,
# and inference admitted on the shared baseband accelerators only up to 30% utilisation (baseband processing has priority).
AIRAN = dict(lat=np.r_[m.LAT[:3], 0.1, m.LAT[4]], jit=np.r_[m.JIT[:3], 0.05, m.JIT[4]], rel=np.r_[m.REL[:3], 0.9999999, m.REL[4]], eps=np.r_[m.EPS[:3], 0.0, 0.0],
             rho_tier=np.r_[m.RHO_MAX, m.RHO_MAX, m.RHO_MAX, 0.3, m.RHO_MAX])
x3 = []
for name, kw in (("5G-class far edge (reference)", {}), ("AI-RAN far edge", AIRAN)):
    for u in m.SERV_ALL:
        b = m.build(u, **kw)
        if not b["mask"].any(): x3.append(dict(scenario=name, uc=u, EASE="INFEASIBLE")); continue
        d = m.decide(b, m.CS); i = int(d["EASE"]["i"][0]); t, v = divmod(i, m.NV)
        x3.append(dict(scenario=name, uc=u, EASE=m.lab(i), B5=m.lab(int(d["B5"]["i"][0])), Emin=m.lab(int(d["Emin"]["i"][0])), C_Emin_ug=1000 * float(d["Emin"]["C"][0]), latency_ms=float(b["leff"][t, v]), E_mJ=1000 * float(d["EASE"]["E"][0]), C_ug=1000 * float(d["EASE"]["C"][0]),
                       C_B5_ug=1000 * float(d["B5"]["C"][0]), E_B5_mJ=1000 * float(d["B5"]["E"][0])))
x3 = pd.DataFrame(x3); x3.to_csv(OUT / "X3_ai_ran.csv", index=False); S["X3"] = x3.round(5).to_dict("records")
def rmin(L, R, lat_t=0.1, rho_t=0.3, rel_t=0.9999999, Fv=4.6, D=m.PAYLOAD_MBIT * 1e6, Bacc=10.0):
    """Minimum per-request rate (GFLOP/s) that meets L (ms) at reliability R; None if the tier's link reliability is below R or no latency slack remains."""
    if rel_t < R: return None
    x = m.md1_quantile(rho_t, R); slack = L - lat_t - 1000 * D / (m.RHO * Bacc * 1e9); return None if slack <= 0 else 1000 * Fv * (1 + x) / slack
S["X3_min_rate"] = [dict(Lmax_ms=L, reliability=R, airan_GFLOPs=rmin(L, R), far_edge_GFLOPs=rmin(L, R, 0.5, m.RHO_MAX, float(m.REL[3]))) for L in (1.0, 0.5, 0.25) for R in (0.99999, 0.9999999)]
(OUT / "v2_6g_summary.json").write_text(json.dumps(S, indent=1, default=float))
pd.set_option("display.width", 260); pd.set_option("display.max_columns", 40); pd.set_option("display.max_rows", 200)
print(pd.DataFrame(S["X1_chi_by_split_V2_T1"]).round(3).to_string())
print(x1[["device_rate", "feature_bits", "n_split_feasible", "no_split", "EASE", "B3", "B5", "Oracle", "carbon_change_vs_no_split_percent", "energy_change_vs_no_split_percent", "red_vs_B3_percent", "red_vs_B5_percent"]].round(2).to_string())
print(xs.round(3).to_string()); print(pd.DataFrame(S["X1_24_mappings"]).to_string()); print(S["X2_setup"]); print(x2.round(3).to_string()); print(pd.DataFrame(S["X2b"]).T.round(3).to_string())
