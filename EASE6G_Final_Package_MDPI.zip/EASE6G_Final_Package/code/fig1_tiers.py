"""Figure 1 (five-tier continuum) at 600 dpi.

Shows the five tiers with the reference inputs of Table 3 that drive placement (service latency, PUE, path
energy), the request travelling from the user device directly to the executing tier, the grid region of each
tier in the reference tier-to-grid mapping with its mean carbon intensity, and the far edge as the tier that the
6G what-if of Section 7.3 replaces with a RAN-co-located (AI-RAN) tier. All values are read from
parameters/v2/table_III_tiers.csv, the file behind Table 3.
Usage: python3 fig1_tiers.py [output.png]   (default: figures_v2/fig1_tiers.png)"""
import csv
import sys
from pathlib import Path
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle, Circle
from matplotlib.colors import to_rgb

ROOT = Path(__file__).resolve().parent.parent
rows = list(csv.DictReader(open(ROOT / "parameters" / "v2" / "table_III_tiers.csv")))
assert [r["tier"] for r in rows] == ["T1", "T2", "T3", "T4", "T5"]
assert rows[3]["grid_region"] == rows[4]["grid_region"]          # far edge and device share the user's grid

plt.rcParams.update({"font.family": "serif", "font.serif": ["Liberation Serif"], "mathtext.fontset": "stix"})
WU, HU = 1400, 358                                   # drawing units; 200 units per inch
fig = plt.figure(figsize=(WU / 200, HU / 200)); ax = fig.add_axes([0, 0, 1, 1])
ax.set(xlim=(0, WU), ylim=(HU, 0)); ax.axis("off")
BL, FC, INK, GREY, ACC = "#3B6DB3", "#F5F8FD", "#16315A", "#526176", "#C0601A"

SUB = {"T1": "Central computing", "T2": "Regional facility", "T3": "Metro facility",
       "T4": "Near-radio execution", "T5": "Local inference"}
def num(x, nd):
    return f"{float(x):.{nd}f}".rstrip("0").rstrip(".") if nd else f"{float(x):g}"

x0, bw, gap = 10, 236, 18
top, bot = 96, 288
cx = [x0 + k * (bw + gap) + bw / 2 for k in range(5)]
for k, r in enumerate(rows):
    X0 = cx[k] - bw / 2
    ax.add_patch(FancyBboxPatch((X0, top), bw, bot - top, boxstyle="round,pad=0,rounding_size=7", fc=FC, ec=BL, lw=1.0))
    ax.text(cx[k], 117, r["tier"], ha="center", va="center", fontsize=9, fontweight="bold", color=INK)
    ax.text(cx[k], 145, r["name"], ha="center", va="center", fontsize=7, color=INK)
    ax.text(cx[k], 168, SUB[r["tier"]], ha="center", va="center", fontsize=5.9, style="italic", color=GREY)
    ax.plot([X0 + 14, X0 + bw - 14], [184, 184], color=BL, lw=0.4, alpha=0.6)
    lines = [("Latency", f"{num(r['service_latency_ms'], 0)} ms"),
             ("PUE", f"{float(r['PUE']):.2f}"),
             ("Path energy", f"{float(r['path_energy_nJ_per_bit']):.2f} nJ/bit" if float(r['path_energy_nJ_per_bit']) else "none")]
    for j, (lab, val) in enumerate(lines):
        y = 205 + j * 26
        ax.text(X0 + 22, y, lab, ha="left", va="center", fontsize=6.2, color=GREY)
        ax.text(X0 + bw - 22, y, val, ha="right", va="center", fontsize=6.2, color=INK)

# user device (request source) on the right
ux = 1338
ax.add_patch(FancyBboxPatch((ux - 17, 128), 34, 62, boxstyle="round,pad=0,rounding_size=5", fc="white", ec=INK, lw=0.9))
ax.add_patch(Rectangle((ux - 12, 136), 24, 42, fc=FC, ec=BL, lw=0.5))
ax.add_patch(Circle((ux, 184), 2.6, fc=INK, ec="none"))
ax.text(ux, 212, "User device", ha="center", va="center", fontsize=6.2, color=INK)
ax.text(ux, 232, "(request source)", ha="center", va="center", fontsize=5.6, style="italic", color=GREY)

# request bus: straight from the device to the executing tier, not hop by hop
BUS = 46
ax.plot([ux, ux], [126, BUS], color=INK, lw=0.9, solid_capstyle="butt")
ax.plot([cx[0], ux], [BUS, BUS], color=INK, lw=0.9, solid_capstyle="butt")
for c in cx:
    ax.annotate("", xy=(c, top - 1), xytext=(c, BUS), arrowprops=dict(arrowstyle="-|>,head_length=0.5,head_width=0.22",
                lw=0.9, color=INK, mutation_scale=7, shrinkA=0, shrinkB=0))
ax.text((cx[1] + cx[3]) / 2, BUS - 14, "Inference request with its input data, sent directly to the tier that executes it",
        ha="center", va="center", fontsize=6.2, color=INK)

# 6G marker on the far edge
bx0, bx1 = cx[3] + 14, cx[3] + bw / 2 - 4
ax.add_patch(FancyBboxPatch((bx0, 56), bx1 - bx0, 23, boxstyle="round,pad=0,rounding_size=10", fc="white", ec=ACC, lw=0.9))
ax.text((bx0 + bx1) / 2, 67.5, "AI-RAN (6G)", ha="center", va="center", fontsize=5.8, fontweight="bold", color=ACC)

# grid regions of the reference mapping, shaded by mean carbon intensity
lo, hi = to_rgb("#E6F2E3"), to_rgb("#F3CFA6")
ci = [float(r["CI_mean_kg_per_kWh"]) for r in rows]
cmin, cmax = min(ci), max(ci)
def shade(v):
    t = (v - cmin) / (cmax - cmin); return tuple(a + (b - a) * t for a, b in zip(lo, hi))
segs = [(cx[0] - bw / 2, cx[0] + bw / 2, 0), (cx[1] - bw / 2, cx[1] + bw / 2, 1),
        (cx[2] - bw / 2, cx[2] + bw / 2, 2), (cx[3] - bw / 2, WU - 6, 3)]
YB0, YB1 = 302, 350
for a, b, k in segs:
    r = rows[k]
    ax.add_patch(Rectangle((a, YB0), b - a, YB1 - YB0, fc=shade(ci[k]), ec="white", lw=1.5))
    region = r["grid_region"] + (" (user’s grid: T4, T5)" if k == 3 else "")
    ax.text((a + b) / 2, YB0 + 15, region, ha="center", va="center", fontsize=6.2, color=INK)
    ax.text((a + b) / 2, YB0 + 34, f"CI {ci[k]:.4f} kg CO$_2$/kWh", ha="center", va="center", fontsize=5.8, color=GREY)

OUT = sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "figures_v2" / "fig1_tiers.png")
fig.savefig(OUT, dpi=600)
