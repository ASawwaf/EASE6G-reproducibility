#!/usr/bin/env python3
"""Independent equation-by-equation check of the revised manuscript.

Each of Eqs. (1)-(24) is re-implemented here with plain loops from the parameter values printed in
Tables III-V (plus the full-precision carbon intensities), without using any scoring, gating or
optimisation code from ease6g_v2.py. Results are compared with (a) the rerun outputs in results/v2 and
(b) the numbers printed in the manuscript tables (build/tables.json).
"""
import itertools, json, math, re
from pathlib import Path
import pandas as pd
import mpmath

def md1_wait_quantile(rho, p):
    """Independent M/D/1 waiting-time quantile: Erlang's formula P(W <= x D) = (1-rho) sum_k (rho(k-x))^k/k! e^{-rho(k-x)}, bisection, 50 digits."""
    mpmath.mp.dps = 50; rho = mpmath.mpf(rho)
    cdf = lambda x: (1 - rho) * mpmath.fsum((rho * (k - x)) ** k / mpmath.factorial(k) * mpmath.exp(-rho * (k - x)) for k in range(int(mpmath.floor(x)) + 1))
    if p <= 1 - rho: return 0.0
    lo, hi = mpmath.mpf(0), mpmath.mpf(1)
    while cdf(hi) < p: hi *= 2
    for _ in range(50):
        mid = (lo + hi) / 2
        if cdf(mid) < p: lo = mid
        else: hi = mid
    return float(hi)

ROOT = Path(__file__).resolve().parent.parent
S = json.loads((ROOT / "results/v2/v2_summary.json").read_text())
TAB = json.loads((ROOT / "build/tables.json").read_text())
NUM = json.loads((ROOT / "build/numbers.json").read_text())
st = pd.read_csv(ROOT / "results/v2/static_placements.csv").set_index("uc")
bl = pd.read_csv(ROOT / "results/v2/baselines.csv")
rows = lambda key: [re.split(r"\s*\|\s*", ln.strip().strip("|").strip()) for ln in TAB[key].split("\n")[2:]]
num = lambda x: float(x.replace(",", ""))

# ---- inputs parsed from the printed Tables III and IV
TIERS = ["T1", "T2", "T3", "T4", "T5"]; USER = "T4"                       # T5 shares the T4 (user) grid
t2 = {r[0]: r for r in rows("II")}
PUE = {t: num(t2[t][2]) for t in TIERS}; L = {t: num(t2[t][5]) for t in TIERS}; B = {t: num(t2[t][6]) for t in TIERS}
R = {t: num(t2[t][7]) for t in TIERS}; J = {t: num(t2[t][8]) for t in TIERS}; EE = {t: num(t2[t][9]) for t in TIERS}
RATE = {t: num(t2[t][10]) for t in TIERS}; CAP = {t: (math.inf if t2[t][11] == "Per device" else num(t2[t][11])) for t in TIERS}
EPS = {t: num(t2[t][12]) for t in TIERS}
CI = S["settings"]["reference_CI_kg_per_kWh"]                              # full precision; Table III prints 4 decimals
CI_PRINTED = {t: num(t2[t][4]) for t in TIERS}
t4 = {r[0]: r for r in rows("IV")}
UCS = {}
for u, r in t4.items():
    acc = None if r[6] == "None" else num(r[6].rstrip("%")); bacc, ptx = (num(x) for x in r[8].split(";"))
    UCS[u] = (num(r[2]), num(r[3]), num(r[4]), num(r[5]), acc, num(r[7]), bacc, ptx)   # Lmax,Bmin,Rmin,Jmax,Accmin,payload Mbit,access Gbit/s,Ptx W
VARS = {"V1": (17.6, 81.8, 1.0), "V2": (4.6, 81.2, 1.0), "V3": (17.6, 81.29, 0.45), "V4": (2.9, 79.3, 1.0)}   # Table IV: F, accuracy, delta
RHO = 0.60; W = (0.40, 0.40, 0.20); SCAP = 2.0; PHI = 0.5; RHO_MAX = 0.7
PEAK = NUM["rates"]["peak"]; STRESS = NUM["rates"]["stress"]
out = []
def rec(eq, what, ok, detail): out.append(dict(eq=eq, check=what, ok=bool(ok), detail=detail))
close = lambda a, b, tol=1e-9: abs(a - b) <= tol * max(1.0, abs(a), abs(b))
p3 = lambda x: f"{1000 * x:.3f}"                                           # Table VI prints mJ and ug to three decimals

QX = {r_: md1_wait_quantile(RHO_MAX, r_) for r_ in {v[2] for v in UCS.values()}}
cand = {}
for u, (Lmax, Bmin, Rmin, Jmax, Accmin, pay, Bacc, Ptx) in UCS.items():
    D = pay * 1e6                                                          # bits
    Beff = RHO * Bacc                                                      # (2) Gbit/s
    Ttx = D / (Beff * 1e9)                                                 # (3) s
    for t in TIERS:
        for v, (F, acc, dl) in VARS.items():
            e1 = PUE[t] * F / EE[t] * dl                                   # (1)
            eacc = 0.0 if t == "T5" else Ptx * Ttx; epath = 0.0 if t == "T5" else D * EPS[t] * 1e-9
            e4 = eacc + epath                                              # (4)
            e5 = e1 + e4                                                   # (5)
            c7 = (e1 * CI[t] + eacc * CI[USER] + epath * (PHI * CI[t] + (1 - PHI) * CI[USER])) / 3.6   # (7)
            svc = 1e3 * F / RATE[t]; wq = 0.0 if t == "T5" else QX[Rmin] * svc
            ttx = 0.0 if t == "T5" else 1e3 * Ttx
            l9 = L[t] + ttx + svc + wq                                     # (9)
            IL = l9 <= Lmax; IB = True if t == "T5" else B[t] >= Bmin; IR = R[t] >= Rmin; IJ = J[t] <= Jmax
            K10 = IL and IB and IR and IJ                                  # (10)
            A11 = True if Accmin is None else acc >= Accmin                # (11)
            sL, sB, sR, sJ = Lmax / l9, (SCAP if t == "T5" else B[t] / Bmin), R[t] / Rmin, Jmax / J[t]
            k12 = sum(min(s, SCAP) for s in (sL, sB, sR, sJ))              # (12)
            cand[(u, t, v)] = dict(e1=e1, e4=e4, e5=e5, c7=c7, l9=l9, wq=wq, K=K10, A=A11, k12=k12, F=F, Beff=Beff, Ttx=Ttx)
score = {}; SERVED = [u for u in UCS if any(c["K"] and c["A"] for k, c in cand.items() if k[0] == u)]
rec("(9)-(11)", "unserved profiles (no feasible tier under the tail-latency gate)", SERVED == S["served"], f"served {SERVED}; rerun {S['served']}")
for u in SERVED:
    feas = {k: c for k, c in cand.items() if k[0] == u and c["K"] and c["A"]}
    emin = min(c["e5"] for c in feas.values()); cmin = min(c["c7"] for c in feas.values()); kmax = max(c["k12"] for c in feas.values())   # Eq. (13): maximum over the hard-feasible set (K = A = 1)
    for k, c in cand.items():
        if k[0] != u: continue
        c["eta"] = emin / c["e5"]                                          # (6)
        c["ceff"] = cmin / c["c7"] if c["c7"] > 0 else 1.0                 # (8)
        c["kpi"] = c["k12"] / kmax                                         # (13)
        c["Q"] = W[0] * c["eta"] + W[1] * c["ceff"] + W[2] * c["kpi"]      # (14)
        c["S"] = (1 if c["K"] else 0) * (1 if c["A"] else 0) * c["Q"]      # (15)
    score[u] = feas

# ---- compare with the rerun and with the printed Table VI
tv = {r[0]: r for r in rows("V")}
for u in SERVED:
    best = max(score[u], key=lambda k: (score[u][k]["S"], -score[u][k]["c7"], -score[u][k]["e5"])); c = score[u][best]; pl = f"{best[1]}-{best[2]}"; r = st.loc[u]
    rec("(1)", f"{u} compute energy at {pl}", close(c["e1"], r.E_compute_J) and p3(c["e1"]) == tv[u][3], f"{c['e1']:.6f} J; rerun {r.E_compute_J:.6f}; printed {tv[u][3]} mJ")
    rec("(2)-(4)", f"{u} communication energy at {pl}", close(c["e4"], r.E_comm_J) and p3(c["e4"]) == tv[u][4], f"B_eff {c['Beff']:g} Gbit/s, T_tx {c['Ttx']:.3e} s, {c['e4']:.6f} J; printed {tv[u][4]} mJ")
    rec("(5)", f"{u} total energy", close(c["e5"], r.E_total_J) and p3(c["e5"]) == tv[u][5], f"{c['e5']:.6f} J; rerun {r.E_total_J:.6f}; printed {tv[u][5]} mJ")
    rec("(7)", f"{u} carbon (compute at destination, access at user, path split)", close(c["c7"], r.carbon_mg) and p3(c["c7"]) == tv[u][6], f"{c['c7']:.6f} mg; rerun {r.carbon_mg:.6f}; printed {tv[u][6]} ug")
    rec("(9)", f"{u} effective latency incl. transmission and queueing", close(c["l9"], r.latency_eff_ms), f"{c['l9']:.4f} ms (queue {c['wq']:.4f}); rerun {r.latency_eff_ms:.4f}")
    ft = ",".join(sorted({k[1] for k in score[u]}))
    rec("(10)-(11)", f"{u} feasible set", ft == r.feasible_tiers and len(score[u]) == int(r.feasible_pairs) and ft.replace(",", ", ") == tv[u][7], f"tiers {ft}; {len(score[u])} pairs; rerun {r.feasible_tiers}; {int(r.feasible_pairs)} pairs")
    rec("(6),(8),(12)-(15)", f"{u} suitability score and selection", pl == r.placement and close(c["S"], r.score, 1e-5) and pl == tv[u][1], f"S = {c['S']:.6f} (eta {c['eta']:.4f}, c_eff {c['ceff']:.4f}, KPI_norm {c['kpi']:.4f}) -> {pl}; rerun {r.score:.6f} -> {r.placement}")
    orc = min(score[u], key=lambda k: (score[u][k]["c7"], score[u][k]["e5"])); ro = bl[(bl.method == "Oracle-KA") & (bl.uc == u)].iloc[0]
    rec("(7) oracle", f"{u} minimum-carbon candidate", f"{orc[1]}-{orc[2]}" == ro.placement and close(score[u][orc]["c7"], ro.carbon_mg), f"{orc[1]}-{orc[2]}; rerun {ro.placement}")

# ---- volume-weighted headline (weights = peak arrival coefficients printed in Section V-A)
def wmean(pick):
    return sum(PEAK[u] * pick(u) for u in SERVED) / sum(PEAK[u] for u in SERVED)
ease = {u: max(score[u], key=lambda k: (score[u][k]["S"], -score[u][k]["c7"], -score[u][k]["e5"])) for u in SERVED}
def lat_first(u): return min(score[u], key=lambda k: (score[u][k]["l9"] / UCS[u][0], score[u][k]["e5"]))   # B3: lowest effective latency, then energy
b3 = {u: lat_first(u) for u in SERVED}
cE = wmean(lambda u: cand[ease[u]]["c7"]); c3 = wmean(lambda u: cand[b3[u]]["c7"]); eE = wmean(lambda u: cand[ease[u]]["e5"]); e3 = wmean(lambda u: cand[b3[u]]["e5"])
red = 100 * (1 - cE / c3); de = 100 * (eE / e3 - 1); sw = S["static_weighted"]["EASE"]
rec("weighted", "volume-weighted static carbon and energy change vs B3", close(red, sw["red_vs_B3"], 1e-6) and close(de, sw["dE_vs_B3"], 1e-6), f"{red:.3f}% carbon, {de:+.3f}% energy; rerun {sw['red_vs_B3']:.3f}%, {sw['dE_vs_B3']:+.3f}%")
def emin_pick(u): return min(score[u], key=lambda k: (score[u][k]["e5"], score[u][k]["c7"]))                    # E-min: lowest energy, then lowest carbon
em = {u: emin_pick(u) for u in SERVED}; cM = wmean(lambda u: cand[em[u]]["c7"]); eM = wmean(lambda u: cand[em[u]]["e5"])
rec("weighted", "volume-weighted static carbon and energy change vs E-min (primary comparator)", close(100 * (1 - cE / cM), sw["red_vs_Emin"], 1e-6) and close(100 * (eE / eM - 1), sw["dE_vs_Emin"], 1e-6),
    f"{100 * (1 - cE / cM):.3f}% carbon, {100 * (eE / eM - 1):+.3f}% energy; rerun {sw['red_vs_Emin']:.3f}%, {sw['dE_vs_Emin']:+.3f}%; E-min placements {', '.join(f'{u}:{k[1]}-{k[2]}' for u, k in em.items())}")
tvi = {r[0]: r for r in rows("VI")}
rec("weighted", "Table VII: E-min row", tvi["E-min"][3] == f"{100 * (1 - cE / cM):.1f}%" and tvi["E-min"][2] == p3(cM) and tvi["E-min"][1] == p3(eM), f"printed {tvi['E-min'][1]} mJ, {tvi['E-min'][2]} ug, {tvi['E-min'][3]}")
rec("weighted", "UC4 share of served requests", abs(PEAK["UC4"] / sum(PEAK[u] for u in SERVED) - S["volume_share"]["UC4"]) < 1e-4, f"{100 * PEAK['UC4'] / sum(PEAK[u] for u in SERVED):.1f}%")

# ---- (16)-(19): exhaustive search replaces the MILP
def brute(rates, objective):
    keys = [list(score[u].keys()) for u in SERVED]; best = None
    for combo in itertools.product(*keys):
        load = {t: 0.0 for t in TIERS}
        for k in combo: load[k[1]] += rates[k[0]] * cand[k]["F"]                       # (18)
        if any(load[t] > CAP[t] + 1e-9 for t in TIERS): continue
        val = sum(cand[k]["S"] for k in combo) if objective == "score" else -sum(rates[k[0]] * cand[k]["c7"] for k in combo)
        tie = (-sum(rates[k[0]] * cand[k]["c7"] for k in combo), -sum(rates[k[0]] * cand[k]["e5"] for k in combo))
        if best is None or (val, tie) > best[0]: best = ((val, tie), combo)
    return best[1]
cp = pd.read_csv(ROOT / "results/v2/capacity_fallback_per_uc.csv").set_index("uc")
bs = brute(STRESS, "score"); bo = brute(STRESS, "carbon")
ok = all(f"{k[1]}-{k[2]}" == cp.loc[k[0], "stress"] for k in bs)
e = sum(STRESS[k[0]] * cand[k]["e5"] for k in bs); c = sum(STRESS[k[0]] * cand[k]["c7"] for k in bs); cm = S["capacity"]["milp"]
rec("(16)-(19)", "capacity stress: exhaustive search over all assignments vs MILP", ok and close(e, cm["energy_J_per_s"]) and close(c, cm["carbon_mg_per_s"]),
    f"{', '.join(f'{k[1]}-{k[2]}' for k in bs)}; {e:,.1f} J/s, {c:,.1f} mg/s; MILP {cm['energy_J_per_s']:,.1f} J/s, {cm['carbon_mg_per_s']:,.1f} mg/s")
rec("(16)-(19)", "capacity stress: carbon-optimal assignment equals the MILP assignment", bo == bs or all(f"{k[1]}-{k[2]}" == cp.loc[k[0], "oracle_stress"] for k in bo), ", ".join(f"{k[1]}-{k[2]}" for k in bo))
loads = {t: sum(STRESS[k[0]] * cand[k]["F"] for k in bs if k[1] == t) for t in TIERS}
rec("(18)", "tier loads under stress within the admission limits", all(loads[t] <= CAP[t] for t in TIERS) and all(close(loads[t], S["capacity"]["milp"]["load"][t]) for t in TIERS), ", ".join(f"{t} {loads[t]:,.0f}" for t in TIERS))

# ---- (20)-(23)
a = lambda t, ee=EE: PUE[t] / ee[t]; b = lambda t: EPS[t] * 1e-3
u4 = UCS["UC4"]; eacc = u4[7] / (RHO * u4[6]) * 1e-3
chi4 = VARS["V4"][0] * VARS["V4"][2] / u4[5]
lhs = cand[("UC4", "T3", "V4")]["e5"] / u4[5]; rhs = a("T3") * chi4 + eacc + b("T3")
rec("(20)", "E/D from Eq. (20) equals Eq. (5) divided by payload (UC4, T3-V4)", close(lhs, rhs), f"{rhs:.9f} vs {lhs:.9f} J/Mbit at chi = {chi4:.4f}")
xE = lambda i, j, ee=EE: (b(j) - b(i)) / (a(i, ee) - a(j, ee))
for (i, j), ref in ((("T2", "T3"), 45.11), (("T3", "T4"), 45.11), (("T1", "T2"), 45.11)):
    v = xE(i, j); rec("(21)", f"energy crossover {i}/{j}", abs(v - ref) < 0.005 and (i != "T2" or close(v, S["envelope"]["chi_E_T2_T3"])), f"{v:.4f} GFLOP/Mbit; manuscript {ref}")
v = xE("T2", "T3"); rec("(21)", "energies equal at the crossover", close(a("T2") * v + b("T2"), a("T3") * v + b("T3")), f"both {a('T2') * v + b('T2'):.9f} J/Mbit plus access")
thr = PUE["T2"] / PUE["T3"]; rec("(22)", "existence threshold for T2/T3", abs(thr - 0.963) < 5e-4 and close(thr, S["crossover_range"]["existence_threshold_EE_ratio"]), f"{thr:.4f}")
def xC(ee, ci=CI, ea=eacc):
    al = lambda t: ci[t] * a(t, ee); be = lambda t: ci[USER] * ea + b(t) * (PHI * ci[t] + (1 - PHI) * ci[USER]); d = al("T2") - al("T3")
    x = (be("T3") - be("T2")) / d; return x if x > 0 else None
for row, c in zip(rows("XII"), S["crossover_range"]["cases"]):
    ee = dict(EE); ee["T2"], ee["T3"] = c["EE_T2"], c["EE_T3"]; exists = ee["T2"] / ee["T3"] > thr
    ve = xE("T2", "T3", ee) if exists else None; vc = xC(ee) if exists else None
    f = lambda x: "None" if x is None else f"{x:.2f}"
    dd = PUE["T5"] / EE["T5"] - PUE["T2"] / ee["T2"]; vd = (eacc + b("T2")) / dd if dd > 0 else None   # T2 vs device: access does not cancel
    rec("(21)-(23)", f"Table XIII: {c['case']} ({c['EE_T2']}/{c['EE_T3']})", f(ve) == row[4] and f(vc) == row[5] and f(vd) == row[6] and exists == c["exists"], f"chi_E {f(ve)}, chi_C {f(vc)}, T2-device {f(vd)}; printed {row[4]}, {row[5]}, {row[6]}")
vc = xC(EE); rec("(23)", "mean-carbon crossover T2/T3", abs(vc - 5.11) < 0.005 and close(vc, S["envelope"]["chi_C_T2_T3_mean"]), f"{vc:.4f}; manuscript 5.11")
al = lambda t: CI[t] * a(t); be = lambda t: CI[USER] * eacc + b(t) * (PHI * CI[t] + (1 - PHI) * CI[USER])
rec("(23)", "carbon equal at the crossover", close(al("T2") * vc + be("T2"), al("T3") * vc + be("T3")), "verified")
rec("(23)", "access energy cancels from the carbon crossover", close(xC(EE, ea=0.0), vc) and close(xC(EE, ea=10 * eacc), vc), f"{xC(EE, ea=0.0):.6f} with no access energy vs {vc:.6f}")
xr = xC(EE, ci=CI_PRINTED)
rec("(23)", "carbon crossover reproducible from the carbon intensities printed in Table III", abs(xr - vc) < 0.005, f"{xr:.4f} from printed values vs {vc:.4f} at full precision")
k_, m_ = 0.25, 2.0
rec("(21)", "crossover scales with efficiency level x path energy", close((EPS["T3"] - EPS["T2"]) * m_ * 1e-3 / (PUE["T2"] / (k_ * EE["T2"]) - PUE["T3"] / (k_ * EE["T3"])), k_ * m_ * xE("T2", "T3")), f"k = {k_}, m = {m_}: {k_ * m_ * xE('T2', 'T3'):.4f}")

# ---- (24): the energy and carbon orderings of T2 and T3 disagree exactly where (dE)(dC) < 0; efficiency band for UC4
dE = lambda x, ee=EE: (a("T2", ee) - a("T3", ee)) * x + b("T2") - b("T3")
def dC(x, ee=EE, ci=CI):                                                   # carbon per Mbit of T2 minus T3 (Eq. 7 / D); the access term is common to both and cancels
    return (ci["T2"] * a("T2", ee) - ci["T3"] * a("T3", ee)) * x + b("T2") * (PHI * ci["T2"] + (1 - PHI) * ci[USER]) - b("T3") * (PHI * ci["T3"] + (1 - PHI) * ci[USER])
rec("(24)", "UC4 at mean intensity lies in the T2/T3 disagreement set", dE(chi4) * dC(chi4) < 0, f"dE {dE(chi4):.3e}, dC {dC(chi4):.3e} at chi = {chi4:.2f}")
def bisect(f, lo, hi):
    for _ in range(200):
        mid = (lo + hi) / 2
        if (f(lo) > 0) == (f(mid) > 0): lo = mid
        else: hi = mid
    return (lo + hi) / 2
ee2 = bisect(lambda e_: dE(chi4, {**EE, "T2": e_}), 730.0, 2000.0); ee3 = bisect(lambda e_: dC(chi4, {**EE, "T3": e_}), 730.0, 5000.0)
bd = S["disagreement_band_UC4"]; lead2 = (PUE["T3"] / EE["T3"]) / (PUE["T2"] / ee2) - 1; lead3 = (PUE["T2"] / EE["T2"]) / (PUE["T3"] / ee3) - 1
rec("(24)", "efficiency band: T2 lead at chi_E = chi(UC4), T3 lead at chi_C = chi(UC4)", close(lead2, bd["T2_lead_max"], 1e-6) and close(lead3, bd["T3_lead_max"], 1e-6), f"T2 lead {100 * lead2:.2f}% (EE {ee2:.1f}), T3 lead {100 * lead3:.2f}% (EE {ee3:.1f})")
x13 = {r[0]: r for r in rows("XIII")}
def cx13(ee, msc=1.0):
    bb = lambda t: EPS[t] * 1e-3 * msc; aa = lambda t: PUE[t] / ee[t]
    xe_ = (bb("T2") - bb("T3")) / (aa("T3") - aa("T2")) if aa("T3") > aa("T2") else None
    al_ = lambda t: CI[t] * aa(t); be_ = lambda t: CI[USER] * eacc + bb(t) * (PHI * CI[t] + (1 - PHI) * CI[USER]); xc_ = (be_("T3") - be_("T2")) / (al_("T2") - al_("T3"))
    return ("None" if xe_ is None else f"{xe_:.1f}"), ("--" if xc_ <= 0 else f"{xc_:.1f}")
cases13 = {"Reference (730 GFLOP/J at T1--T4; 15 kB)": (EE, 1.0), "T2 efficiency ×0.9": ({**EE, "T2": 657.0}, 1.0), "T2 efficiency ×1.05": ({**EE, "T2": 766.5}, 1.0), "T3 efficiency ×0.95": ({**EE, "T3": 693.5}, 1.0),
           "T3 efficiency ×1.1": ({**EE, "T3": 803.0}, 1.0), "T1--T2 1,274, T3--T4 471 GFLOP/J": ({**EE, "T2": 1274.0, "T3": 471.0}, 1.0), "T1--T2 471, T3--T4 1,274 GFLOP/J": ({**EE, "T2": 471.0, "T3": 1274.0}, 1.0),
           "All servers 1,274 GFLOP/J": ({**EE, "T2": 1274.0, "T3": 1274.0}, 1.0), "All servers 471 GFLOP/J": ({**EE, "T2": 471.0, "T3": 471.0}, 1.0), "Previous profile (500/350/275/200)": ({**EE, "T2": 350.0, "T3": 275.0}, 1.0),
           "Efficiency ×0.5, path energy ×1": ({t: 0.5 * EE[t] for t in TIERS}, 1.0), "Efficiency ×1, path energy ×2": (EE, 2.0)}
for name, (ee_, ms_) in cases13.items():
    xe_, xc_ = cx13(ee_, ms_); rec("(21),(23)", f"Table XIV crossovers: {name}", xe_ == x13[name][3] and xc_ == x13[name][2], f"chi_C {xc_}, chi_E {xe_}; printed {x13[name][2]}, {x13[name][3]}")

# ---- Fig. 7: the plotted energy and carbon ratios cross one at the crossovers printed in Table XIII
cur = pd.read_csv(ROOT / "results/v2/fig7_crossover_curves.csv"); x12 = {r[0]: r for r in rows("XII")}
import numpy as np
for case, g in cur.groupby("case", sort=False):
    def cross(col):
        y = g[col].to_numpy() - 1.0; x = g.chi.to_numpy(); i = np.flatnonzero(np.sign(y[:-1]) != np.sign(y[1:]))
        return None if len(i) == 0 else float(np.exp(np.interp(0.0, [y[i[0] + 1], y[i[0]]] if y[i[0] + 1] < y[i[0]] else [y[i[0]], y[i[0] + 1]], [np.log(x[i[0] + 1]), np.log(x[i[0]])] if y[i[0] + 1] < y[i[0]] else [np.log(x[i[0]]), np.log(x[i[0] + 1])])))
    ce, cc = cross("energy_ratio"), cross("carbon_ratio"); pe_, pc_ = x12[case][4], x12[case][5]
    okE = (pe_ == "None" and ce is None) or (ce is not None and abs(ce - float(pe_)) < 0.01 * float(pe_) + 0.01)
    okC = (pc_ == "None" and cc is None) or (cc is not None and abs(cc - float(pc_)) < 0.01 * float(pc_) + 0.01)
    rec("Fig. 7", f"plotted curves cross one at the Table XIII crossovers: {case}", okE and okC, f"energy {ce if ce is None else round(ce, 3)} vs {pe_}; carbon {cc if cc is None else round(cc, 3)} vs {pc_}")

# ---- Table XVIII: required per-request rate, F (1 + x_p) / (L_max - L - T_tx), AI-RAN tier (L = 0.1 ms, rho = 0.3, R = 1 - 1e-7) and 5G-class far edge (Table III: L = 0.5 ms, R = 0.99999; rho = 0.7)
X6 = json.loads((ROOT / "results/v2_6g/v2_6g_summary.json").read_text())
for r_, row in zip(X6["X3_min_rate"], rows("XVI")):
    tx = 1e3 * 0.12e6 / (RHO * 10e9)
    def need(L0, rho_, Rt):
        if Rt < r_["reliability"]: return None                                       # reliability gate
        sl = r_["Lmax_ms"] - L0 - tx; return None if sl <= 0 else 1e3 * 4.6 * (1 + md1_wait_quantile(rho_, r_["reliability"])) / sl
    a_, f_ = need(0.1, 0.3, 0.9999999), need(L["T4"], RHO_MAX, R["T4"]); fm = lambda v: "Not reachable" if v is None else f"{v / 1000:,.1f}"
    rec("Table XVIII", f"required rate at {r_['Lmax_ms']} ms, reliability {r_['reliability']}", fm(f_) == row[2] and fm(a_) == row[3], f"far edge {fm(f_)}, AI-RAN {fm(a_)} TFLOP/s; printed {row[2]}, {row[3]}")

df = pd.DataFrame(out); df.to_csv(ROOT / "results/v2/equation_verification.csv", index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 150); pd.set_option("display.max_rows", 200)
print(df.to_string(index=False)); print(); print(f"{int(df.ok.sum())}/{len(df)} checks passed")
