#!/usr/bin/env python3
"""Checks added in response to the final review (comments A-E). Output: results/v2/review_checks.json and CSV files.

A  Joint factorial over benchmark basis, relative T2 efficiency, path energy, payload and regional carbon spread.
B  Latency-bound benchmark basis (MLPerf Server and SingleStream runs of the two systems behind the reference efficiencies),
   server-only and device-only efficiency derating, and the per-request rate.
C  Throughput factor for the quantized variant V3 applied to execution time and capacity as well as energy.
D  Queueing consistency: mixed-variant tiers, pooled against random dispatch, and the conservative mixed-variant gate.
E  Capacity-constrained placements as the load grows from 5% to 100% of the peak arrival coefficients.
"""
from __future__ import annotations
import io, contextlib, itertools, json
from pathlib import Path
import numpy as np
import pandas as pd
with contextlib.redirect_stdout(io.StringIO()):
    import ease6g_v2 as m
import mlperf_anchor
from ease6g_queue import md1_quantile

OUT = m.OUT; RC = {}
A = mlperf_anchor.main(); RC["mlperf"] = A
EE_SRV_LB, EE_DEV_LB = A["server_server"]["GFLOP_per_J"], A["device_singlestream"]["GFLOP_per_J"]
KS, KD = A["server_latency_bound_factor"], A["device_latency_bound_factor"]
WINS = list(m.WIN)


def brief(r):
    return dict(served=r["served"], EASE=r["placements"], Emin=r["Emin_placements"], Oracle=r["Oracle_placements"], red=float(r["static_red_vs_Emin"]), dE=float(r["static_dE_vs_Emin"]),
                oracle_red=float(r["static_oracle_red_vs_Emin"]), seasonal={w: float(v["red_vs_Emin"]) for w, v in r["seasonal"].items()},
                seasonal_oracle={w: float(v["oracle_red_vs_Emin"]) for w, v in r["seasonal"].items()})


def ee_(ks=1.0, kd=1.0): return np.r_[m.EE[:4] * ks, m.EE[4] * kd]


def tier(pl, u): return pl.get(u, "UNSERVED").split("-")[0]


def disagree(b, u="UC4"): return tier(b["Emin"], u) != tier(b["Oracle"], u)

# ================================================================= B  benchmark basis
# B1  server-only and device-only efficiency factors (kappa_s on T1-T4, kappa_d on T5)
ks_grid = [round(x, 2) for x in np.arange(0.50, 1.0001, 0.01)]
sweep = {str(k): brief(m.scenario(ee=ee_(k, 1.0))) for k in ks_grid}
pd.DataFrame([dict(kappa_s=float(k), red=v["red"], dE=v["dE"], oracle_red=v["oracle_red"], UC4_Emin=tier(v["Emin"], "UC4"), UC4_EASE=tier(v["EASE"], "UC4"), UC4_Oracle=tier(v["Oracle"], "UC4"),
                   UC5_Emin=tier(v["Emin"], "UC5"), UC5_EASE=tier(v["EASE"], "UC5")) for k, v in sweep.items()]).to_csv(OUT / "review_server_only_derating.csv", index=False)


def bisect(pred, lo, hi, it=50):
    """Largest x in [lo, hi] with pred(x) true when pred holds at lo and fails at hi."""
    for _ in range(it):
        mid = 0.5 * (lo + hi)
        if pred(mid): lo = mid
        else: hi = mid
    return lo


chi = m.CHI_UC4; a3 = m.PUE[2] / m.EE[2]; b3 = m.b_(2)
def ks_star(kd): return (a3 * chi) / (chi / (m.EE[4] * kd) - m.eacc - b3)          # server factor at which the metro tier and the device need equal energy for UC4 (closed form)
ks_num = bisect(lambda k: tier(m.scenario(ee=ee_(k, 1.0))["Emin_placements"], "UC4") == "T5", 0.5, 1.0)
ks_ease = bisect(lambda k: tier(m.scenario(ee=ee_(k, 1.0))["placements"], "UC4") == "T5", 0.5, 1.0)
k_T2T3 = chi / m.chi_E(1, 2)                                                        # joint factor at which chi_E(T2,T3) reaches UC4's intensity
grid2 = []
for kd in (1.0, 0.8, 0.6, round(KD, 3), 0.4):
    for ks in (1.0, 0.95, 0.9, round(KS, 3), 0.8, 0.7, 0.6, 0.5):
        b = brief(m.scenario(ee=ee_(ks, kd)))
        grid2.append(dict(kappa_s=ks, kappa_d=kd, red=b["red"], dE=b["dE"], oracle_red=b["oracle_red"], UC4_Emin=tier(b["Emin"], "UC4"), UC4_EASE=tier(b["EASE"], "UC4"), UC4_Oracle=tier(b["Oracle"], "UC4"),
                          predicted_headline=bool(ks >= ks_star(kd) and ks >= k_T2T3)))
g2 = pd.DataFrame(grid2); g2.to_csv(OUT / "review_efficiency_basis_grid.csv", index=False)
RC["B_derating"] = dict(
    sweep={k: dict(red=v["red"], dE=v["dE"], oracle_red=v["oracle_red"], UC4=[tier(v["Emin"], "UC4"), tier(v["EASE"], "UC4"), tier(v["Oracle"], "UC4")]) for k, v in sweep.items() if k in ("1.0", "0.95", "0.92", "0.91", "0.9", "0.85", "0.8", "0.7", "0.6", "0.5")},
    ks_star_closed=float(ks_star(1.0)), ks_star_numeric=float(ks_num), ks_ease_moves=float(ks_ease), k_T2T3=float(k_T2T3), ks_star_at_measured_kd=float(ks_star(KD)),
    ks_required_at_measured_kd=float(max(ks_star(KD), k_T2T3)), grid=grid2,
    grid_prediction_matches=int(sum((r["UC4_Emin"] == "T3" and r["UC4_EASE"] == "T2") == r["predicted_headline"] for r in grid2)), grid_cells=len(grid2),
    headline_red_range=[float(min(r["red"] for r in grid2 if r["predicted_headline"])), float(max(r["red"] for r in grid2 if r["predicted_headline"]))],
    other_red_max=float(max(r["red"] for r in grid2 if not r["predicted_headline"])), table={k: sweep[k] for k in ("0.9", "0.85")},
    device_optimum_red_range=[float(min(v["red"] for k, v in sweep.items() if ks_ease < float(k) < ks_num)), float(max(v["red"] for k, v in sweep.items() if ks_ease < float(k) < ks_num))],
    both_device_red_range=[float(min(v["red"] for k, v in sweep.items() if float(k) < ks_ease)), float(max(v["red"] for k, v in sweep.items() if float(k) < ks_ease))],
    oracle_keeps_T2_down_to=float(min(float(k) for k, v in sweep.items() if tier(v["Oracle"], "UC4") == "T2")))

# B2  latency-bound basis: server efficiency from the Server-scenario run, device efficiency from the SingleStream run
lb_eff = brief(m.scenario(ee=np.r_[np.full(4, EE_SRV_LB), EE_DEV_LB]))                  # efficiencies only; assumed per-request rate kept
srv = A["server_server"]; q999, qmax = srv["latency_p999_ms"], srv["latency_max_ms"]
def exq_measured(uc):
    """Execution-plus-queueing latency of the measured server under Poisson load, scaled by work per inference: the 99.9th percentile for
    R_min <= 0.999 and the largest of the 4.7e7 observed latencies for stricter reliabilities. The device keeps its SingleStream execution time."""
    q = q999 if float(uc.Rmin) <= 0.999 + 1e-12 else qmax
    x = np.tile((q * m.F / mlperf_anchor.GFLOP_PER_IMAGE)[None, :], (m.NT, 1)); x[4] = 1000.0 * m.F / m.RATE[4]; return x
lb_full = brief(m.scenario(ee=np.r_[np.full(4, EE_SRV_LB), EE_DEV_LB], exq=exq_measured))
lb_feas = {u: sorted({m.TIER[j // m.NV] for j in np.flatnonzero(m.build(u, ee=np.r_[np.full(4, EE_SRV_LB), EE_DEV_LB], exq=exq_measured)["mask"].ravel())}) for u in m.SERV_ALL}
lb_leff = {u: {m.TIER[t]: float(m.build(u, exq=exq_measured)["leff"][t, m.VAR.index("V4" if u == "UC4" else "V2")]) for t in range(m.NT)} for u in m.SERV_ALL}
ee_lb = np.r_[np.full(4, EE_SRV_LB), EE_DEV_LB]
RC["B_latency_bound"] = dict(EE_server=EE_SRV_LB, EE_device=EE_DEV_LB, kappa_s=KS, kappa_d=KD, efficiencies_only=lb_eff, with_measured_latency=lb_full, feasible_tiers_measured_latency=lb_feas,
                             L_eff_measured_ms=lb_leff, chi_E_T2_T3=float(m.chi_E(1, 2, ee_lb)), chi_C_T2_T3=float(m.chi_C(1, 2, m.CS[0], ee_lb)),
                             band_holds=bool(m.chi_C(1, 2, m.CS[0], ee_lb) < chi < m.chi_E(1, 2, ee_lb)))
# B3  per-request rate: the headline when the network servers are no faster per request than the device, and at the reference efficiencies
rate_rows = {}
for lab, r_ in (("40000 (reference)", 40000.0), ("10000", 10000.0), ("2890 (device SingleStream rate)", m.RATE[4]), ("2000", 2000.0), ("1000", 1000.0)):
    b = brief(m.scenario(rate=np.r_[np.full(4, r_), m.RATE[4]])); rate_rows[lab] = dict(served=b["served"], red=b["red"], dE=b["dE"], UC4=[tier(b["Emin"], "UC4"), tier(b["EASE"], "UC4")], UC5=[tier(b["Emin"], "UC5"), tier(b["EASE"], "UC5")])
RC["B_rate"] = dict(assumed_exec_ms_per_4p1_GFLOP=float(1000 * mlperf_anchor.GFLOP_PER_IMAGE / m.RATE[0]), measured_mean_over_assumed=float(srv["latency_mean_ms"] / (1000 * mlperf_anchor.GFLOP_PER_IMAGE / m.RATE[0])), rows=rate_rows, min_rate_GFLOPs=m.S["sensitivity"]["min_rate_GFLOPs_for_reference_placement"])

# ================================================================= A  joint factorial
allw = pd.concat(m.WIN.values()); regs = m.REGIONS
def spread(g):
    win = {}
    for w, h in m.WIN.items():
        mh = h[regs].to_numpy(float).mean(1); win[w] = h.assign(**{r_: np.maximum(mh + g * (h[r_].to_numpy(float) - mh), m.CI_FLOOR) for r_ in regs})
    al = pd.concat(win.values()); return win, np.array([[float(al[m.REFMAP[t]].mean()) / 1000 for t in m.TIER]])
SPREAD = {g: spread(g) for g in (1.0, 0.5)}
BASIS = {"Offline (730/461)": (m.EE.copy(), None), "Latency-bound (603/212)": (ee_lb.copy(), None)}
fac = []
for (bn, (eb, _)), f, mm, kb, g in itertools.product(BASIS.items(), (0.90, 0.95, 1.00, 1.05, 1.10), (0.5, 1.0, 2.0), (10, 15, 20), (1.0, 0.5)):
    e = eb.copy(); e[1] *= f; win, cs = SPREAD[g]
    b = brief(m.scenario(ee=e, transport_scale=mm, payload_scale=kb * 8e-3 / m.PAYLOAD_MBIT, win=win, ci_static_=cs))
    fac.append(dict(basis=bn, T2_efficiency_factor=f, path_scale=mm, payload_kB=kb, spread=g, red=b["red"], dE=b["dE"], oracle_red=b["oracle_red"], UC4_Emin=tier(b["Emin"], "UC4"), UC4_EASE=tier(b["EASE"], "UC4"),
                    UC4_Oracle=tier(b["Oracle"], "UC4"), disagree=disagree(b), ease_is_oracle=bool(b["EASE"] == b["Oracle"]), red_min_season=min(b["seasonal"].values()), red_max_season=max(b["seasonal"].values())))
fac = pd.DataFrame(fac); fac.to_csv(OUT / "review_joint_factorial.csv", index=False)
def fsum(g_):
    d, a = g_[g_.disagree], g_[~g_.disagree]
    return dict(cells=int(len(g_)), disagree=int(len(d)), red_dis_min=float(d.red.min()) if len(d) else None, red_dis_max=float(d.red.max()) if len(d) else None, red_dis_median=float(d.red.median()) if len(d) else None,
                red_agr_min=float(a.red.min()) if len(a) else None, red_agr_max=float(a.red.max()) if len(a) else None, ge10=int((g_.red >= 10).sum()), ge5=int((g_.red >= 5).sum()), negative=int((g_.red < -1e-9).sum()),
                dE_max=float(g_.dE.max()), ease_is_oracle=int(g_.ease_is_oracle.sum()))
RC["A_factorial"] = dict(all=fsum(fac), by_basis={k: fsum(g_) for k, g_ in fac.groupby("basis")}, by_T2_factor={str(k): fsum(g_) for k, g_ in fac.groupby("T2_efficiency_factor")},
                         by_path={str(k): fsum(g_) for k, g_ in fac.groupby("path_scale")}, by_payload={str(k): fsum(g_) for k, g_ in fac.groupby("payload_kB")}, by_spread={str(k): fsum(g_) for k, g_ in fac.groupby("spread")},
                         equal_efficiency=fsum(fac[fac.T2_efficiency_factor == 1.0]), within_band=fsum(fac[fac.T2_efficiency_factor.isin([0.95, 1.0])]),
                         disagree_but_small=int((fac.disagree & (fac.red < 5)).sum()))

# ================================================================= C  throughput factor for the quantized variant
iV3 = m.VAR.index("V3"); F0, D0 = float(m.F[iV3]), float(m.DELTA[iV3]); crows = {}; F_REF, DELTA_REF = m.F, m.DELTA
for lab, s in (("1 (reference: energy only)", 1.0), ("1/delta = 2.22", 1.0 / D0), ("4", 4.0), ("8", 8.0)):
    m.F = F_REF.copy(); m.DELTA = DELTA_REF.copy(); m.F[iV3] = F0 / s; m.DELTA[iV3] = D0 * s   # execution time and capacity use F/s; energy F*delta is unchanged
    try:
        r = m.scenario(); bb = {u: m.build(u) for u in m.SERV}; b3 = {u: m.lab(int(m.decide(bb[u], m.CS)["B3"]["i"][0])) for u in m.SERV}
        sv = m.svc_list(m.STRESS, blds=bb); ms, _, _ = m.solve(sv, m.CAPV, np.ones(m.NT, bool), allow_unserved=False)
        crows[lab] = dict(throughput_factor=float(s), EASE=r["placements"], Emin=r["Emin_placements"], Oracle=r["Oracle_placements"], B3=b3, red=float(r["static_red_vs_Emin"]), stress_MILP={u: m.lab(i) for u, i in zip(m.SERV, ms)},
                          V3_selected=bool(any("V3" in v for d_ in (r["placements"], r["Emin_placements"], r["Oracle_placements"], b3) for v in d_.values()) or any(m.VAR[i % m.NV] == "V3" for i in ms)))
    finally:
        m.F, m.DELTA = F_REF, DELTA_REF
iV2 = m.VAR.index("V2")
RC["C_V3_throughput"] = dict(rows=crows, time_parity_factor=float(F0 / m.F[iV2]), energy_parity_delta=float(m.F[iV2] / F0), delta=float(D0))

# ================================================================= D  queueing consistency
rng_seeds = (11, 23, 37, 51, 67); N = 20_000_000; CH = 5_000_000; WARM = 100_000; PS = (1 - 1e-3, 1 - 1e-4, 1 - 1e-5); RHO = m.RHO_MAX


def lindley(seed, draw_s, draw_a):
    """Waiting times of a FCFS single server (Lindley's recursion); draw_s(rng, n) service times, draw_a(rng, n) interarrival times."""
    rng = np.random.default_rng(seed); out = []; s_last = 0.0; run_min = 0.0
    for _ in range(N // CH):
        S = s_last + np.cumsum(draw_s(rng, CH) - draw_a(rng, CH)); mn = np.minimum(np.minimum.accumulate(S), run_min)
        out.append((S - mn).astype(np.float32)); s_last, run_min = S[-1], mn[-1]
    return np.concatenate(out)[WARM:]


def qtab(draw_s, draw_a):
    q = np.array([[float(np.quantile(w, p)) for p in PS] for w in (lindley(s, draw_s, draw_a) for s in rng_seeds)])
    return {str(p): dict(mean=float(q[:, j].mean()), min=float(q[:, j].min()), max=float(q[:, j].max())) for j, p in enumerate(PS)}


ANALYTIC = {str(p): md1_quantile(RHO, p) for p in PS}
# D1  pooled first-come-first-served dispatch: an M/D/c queue with a shared buffer equals c interleaved E_c/D/1 queues (customer n starts when customer n-c leaves)
pooled = {}
for c in (2, 15):
    pooled[str(c)] = qtab(lambda rng, n: 1.0, lambda rng, n, c=c: rng.gamma(c, 1.0 / (c * RHO), n))
# D2  two variants on one tier: Poisson arrivals, two-point service time (V4 with probability p, V2 otherwise), utilisation at the ceiling
sV4, sV2 = m.F[m.VAR.index("V4")] / m.RATE[0] * 1000, m.F[iV2] / m.RATE[0] * 1000                # service times in ms at the reference rate
mixed = {}
for p4 in (0.10, 0.50, 0.90, 0.95, 0.99):                                             # the simulation's mixed tier-hours have a V4 share of 0.91 to 0.98
    es = p4 * sV4 + (1 - p4) * sV2
    mixed[str(p4)] = dict(mean_service_ms=float(es), quantiles_ms=qtab(lambda rng, n, p4=p4: np.where(rng.random(n) < p4, sV4, sV2), lambda rng, n, es=es: rng.exponential(es / RHO, n)))
    mixed[str(p4)]["bound_longest_ms"] = {k: v * sV2 for k, v in ANALYTIC.items()}; mixed[str(p4)]["own_V4_ms"] = {k: v * sV4 for k, v in ANALYTIC.items()}
    mixed[str(p4)]["within_bound"] = bool(all(mixed[str(p4)]["quantiles_ms"][k]["mean"] <= ANALYTIC[k] * sV2 for k in ANALYTIC))       # five-seed mean against the M/D/1 quantile with the longest service time
    mixed[str(p4)]["above_own"] = bool(all(mixed[str(p4)]["quantiles_ms"][k]["mean"] >= ANALYTIC[k] * sV4 for k in ANALYTIC))
# D3  which tier-hours of the capacity-and-outage simulation carry two variants, and the gate with the longest service time on the tier in the queueing term
def cons_latency(u, t, v, fmax):
    uc = m.ucrow(u); ttx = 1000.0 * float(uc.payload_Mbit) * 1e6 / (m.RHO * float(uc.access_bandwidth_Gbps) * 1e9)
    return m.LAT[t] + ttx + 1000 * m.F[v] / m.RATE[t] + md1_quantile(RHO, float(uc.Rmin)) * 1000 * fmax / m.RATE[t]
mix_rows = []; viol = 0; checked = 0; tier_hours = {p: 0 for p in ("EASE", "Emin", "Oracle-KA")}; mixed_hours = {p: 0 for p in tier_hours}; worst = {}; occ = {p: {t: 0 for t in m.TIER[:4]} for p in tier_hours}
for s in m.SEEDS:
    rt = m.R_full[s]
    for h in range(24, 192):
        ah = h - 24; outage = ah in set(range(48, 51)) | set(range(120, 124)); av = np.ones(m.NT, bool); av[3] = not outage
        rates_h = rt.iloc[h].to_dict(); svs_h = m.svc_list(rates_h)
        for pol, obj in (("EASE", "score"), ("Emin", "energy"), ("Oracle-KA", "carbon")):
            sel, _, _ = m.solve(svs_h, m.CAPV, av, allow_unserved=True, objective=obj)
            for t in range(4):
                on = [(u, i % m.NV) for u, i in zip(m.SERV, sel) if i is not None and i // m.NV == t]
                if not on: continue
                tier_hours[pol] += 1; occ[pol][m.TIER[t]] += 1; vs = {v for _, v in on}; fmax = max(m.F[v] for v in vs)
                if len(vs) > 1:
                    mixed_hours[pol] += 1; lam = {v: sum(rates_h[u] for u, v_ in on if v_ == v) for v in vs}
                    mix_rows.append(dict(policy=pol, seed=s, hour=ah, tier=m.TIER[t], services="+".join(u for u, _ in on), variants="+".join(sorted(m.VAR[v] for v in vs)), share_V4=float(lam.get(m.VAR.index("V4"), 0.0) / sum(lam.values())),
                                         utilisation_of_admission=float(sum(rates_h[u] * m.F[v] for u, v in on) / m.CAPV[t])))
                for u, v in on:
                    lc = cons_latency(u, t, v, fmax); checked += 1; viol += int(lc > float(m.ucrow(u).Lmax_ms) + 1e-9)
                    if len(vs) > 1:
                        k_ = f"{u}@{m.TIER[t]}"; slack = float(m.ucrow(u).Lmax_ms) - lc
                        if k_ not in worst or slack < worst[k_]["slack_ms"]: worst[k_] = dict(L_conservative_ms=float(lc), Lmax_ms=float(m.ucrow(u).Lmax_ms), slack_ms=float(slack), L_gate_ms=float(m.B[u]["leff"][t, v]))
mx = pd.DataFrame(mix_rows); mx.to_csv(OUT / "review_mixed_variant_tier_hours.csv", index=False)
RC["D_queue"] = dict(rho=RHO, analytic_service_times=ANALYTIC, samples_per_seed=N, seeds=list(rng_seeds), pooled_dispatch=pooled, mixed_two_point=mixed, service_ms=dict(V4=float(sV4), V2=float(sV2)),
                     sim_tier_hours=tier_hours, sim_tier_hours_by_tier=occ, sim_mixed_tier_hours=mixed_hours, sim_mixed_by_tier={p: mx[mx.policy == p].groupby("tier").size().to_dict() for p in tier_hours} if len(mx) else {},
                     sim_mixed_share_V4=dict(min=float(mx.share_V4.min()), max=float(mx.share_V4.max())) if len(mx) else None,
                     sim_mixed_max_utilisation_of_admission=float(mx.utilisation_of_admission.max()) if len(mx) else None,
                     conservative_gate=dict(service_tier_hours_checked=int(checked), violations=int(viol), tightest=worst),
                     static_reference_single_variant=bool(all(len({pl.split("-")[1] for u, pl in ((r["uc"], r["placement"]) for r in m.S["static"]) if pl.startswith(t)}) <= 1 for t in ("T1", "T2", "T3", "T4"))))

# ================================================================= E  capacity-constrained placements against load
CS = m.CS; erows = []
def static_load(pol_idx, mult):
    ld = np.zeros(m.NT)
    for u, i in pol_idx.items(): ld[i // m.NV] += mult * m.PEAK[u] * m.F[i % m.NV]
    return ld
ind = {p: {u: int(m.decide(m.B[u], CS)[p]["i"][0]) for u in m.SERV} for p in ("EASE", "Emin", "Oracle-KA")}
feas_mult = {p: float(min(m.CAPV[t] / static_load(ind[p], 1.0)[t] for t in range(4) if static_load(ind[p], 1.0)[t] > 0)) for p in ind}
bind_tier = {p: m.TIER[int(np.argmin([m.CAPV[t] / static_load(ind[p], 1.0)[t] if static_load(ind[p], 1.0)[t] > 0 else np.inf for t in range(4)]))] for p in ind}
for mult in [round(x, 2) for x in np.arange(0.05, 1.0001, 0.05)]:
    rates = {u: mult * m.PEAK[u] for u in m.SERV}; sv = m.svc_list(rates); row = dict(load=mult); tot = {}
    for pol, obj in (("EASE", "score"), ("Emin", "energy"), ("Oracle-KA", "carbon")):
        sel, _, _ = m.solve(sv, m.CAPV, np.ones(m.NT, bool), allow_unserved=True, objective=obj)
        e = sum(rates[u] * m.B[u]["E"].ravel()[i] for u, i in zip(m.SERV, sel) if i is not None); c = sum(rates[u] * m.carbon(m.B[u], [i], CS)[0, 0] for u, i in zip(m.SERV, sel) if i is not None)
        tot[pol] = (e, c); row[pol] = {u: ("UNSERVED" if i is None else m.lab(i)) for u, i in zip(m.SERV, sel)}; row[pol + "_unserved"] = [u for u, i in zip(m.SERV, sel) if i is None]
        row[pol + "_static_feasible"] = bool((static_load(ind[pol], mult)[:4] <= m.CAPV[:4] + 1e-6).all())
    same = row["EASE_unserved"] == row["Emin_unserved"] == row["Oracle-KA_unserved"]
    row.update(same_served=bool(same), red=float(100 * (1 - tot["EASE"][1] / tot["Emin"][1])), dE=float(100 * (tot["EASE"][0] / tot["Emin"][0] - 1)), gap_oracle=float(100 * (tot["EASE"][1] / tot["Oracle-KA"][1] - 1)))
    erows.append(row)
pd.DataFrame([dict(load=r["load"], red=r["red"], dE=r["dE"], gap_oracle=r["gap_oracle"], same_served=r["same_served"], **{f"{p}_{u}": r[p][u] for p in ("EASE", "Emin", "Oracle-KA") for u in m.SERV}) for r in erows]).to_csv(OUT / "review_capacity_load_sweep.csv", index=False)
def _cap_red(mult):
    rates = {u: mult * m.PEAK[u] for u in m.SERV}; sv = m.svc_list(rates); c = {}
    for pol, obj in (("EASE", "score"), ("Emin", "energy")):
        sel, _, _ = m.solve(sv, m.CAPV, np.ones(m.NT, bool), allow_unserved=True, objective=obj); c[pol] = sum(rates[u] * m.carbon(m.B[u], [i], CS)[0, 0] for u, i in zip(m.SERV, sel) if i is not None)
    return 100 * (1 - c["EASE"] / c["Emin"])
load_star = bisect(lambda x: _cap_red(x) > 10.0, 0.05, 1.0, it=30)                      # largest load at which the capacity-constrained saving stays above 10%
iV4 = m.VAR.index("V4"); metro_full = float(m.CAPV[2] / (m.PEAK["UC4"] * m.F[iV4] + m.PEAK["UC3"] * m.F[iV2]))   # load at which UC4 (V4) and UC3 (V2) together fill the metro tier
sim_peak = float(max(m.R_full[s][u].iloc[24:].max() / m.PEAK[u] for s in m.SEEDS for u in m.SERV))
RC["E_capacity"] = dict(static_feasible_up_to_load=feas_mult, binding_tier=bind_tier, peak_static_load={p: dict(zip(m.TIER[:4], static_load(ind[p], 1.0)[:4].tolist())) for p in ind}, admission=dict(zip(m.TIER[:4], m.CAPV[:4].tolist())),
                        sweep=erows, load_star=float(load_star), metro_full_load=metro_full, red_below=[float(min(r["red"] for r in erows if r["load"] <= load_star)), float(max(r["red"] for r in erows if r["load"] <= load_star))],
                        red_above=[float(min(r["red"] for r in erows if r["load"] > load_star)), float(max(r["red"] for r in erows if r["load"] > load_star))], red_at_peak=float(erows[-1]["red"]), dE_at_peak=float(erows[-1]["dE"]),
                        Emin_UC4_at_peak=erows[-1]["Emin"]["UC4"], peak_differs=[u for u in m.SERV if erows[-1]["EASE"][u] != erows[-1]["Emin"][u]], EASE_UC4_at_peak=erows[-1]["EASE"]["UC4"], gap_oracle_max=float(max(abs(r["gap_oracle"]) for r in erows)), all_served=bool(all(not r["EASE_unserved"] and not r["Emin_unserved"] for r in erows)),
                        daily_profile_mean_load=float(np.mean([m.base.daily_load_fraction(h) for h in range(24)])), simulation_peak_load_fraction=sim_peak, simulation=m.S["controlled_sim_policies"]["EASE_vs_Emin"], trace_peak_utilisation=m.S["trace_capacity"]["utilisation"])

(OUT / "review_checks.json").write_text(json.dumps(RC, indent=1, default=float))
print("done", OUT / "review_checks.json")
