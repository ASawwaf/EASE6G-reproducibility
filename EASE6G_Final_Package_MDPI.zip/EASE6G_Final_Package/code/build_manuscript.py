#!/usr/bin/env python3
"""Assemble the revised manuscript: template + retained source text + generated tables/numbers -> Markdown -> DOCX (two-column sections restored)."""
import copy, json, math, re, shutil, subprocess, sys, zipfile
from pathlib import Path
import numpy as np, pandas as pd, scipy, matplotlib
from docx import Document
from lxml import etree
ROOT = Path(__file__).resolve().parent.parent; BUILD = ROOT / "build"
ORIG = Path(sys.argv[1]); SRC_MD = Path(sys.argv[2]); OUT = Path(sys.argv[3])
V = json.loads((BUILD / "numbers.json").read_text()); T = json.loads((BUILD / "tables.json").read_text())
src = SRC_MD.read_text(encoding="utf8").split("\n")
WINS = ["Winter 2026", "Spring 2026", "Summer 2026"]
def sea(w, k, scope="all"): return next(r[k] for r in V["seasonal"] if r["window"] == w and r["scope"] == scope)
def th(w, u, k): return next(r[k] for r in V["tier_hours"] if r["window"] == w and r["uc"] == u)
def wc(u, p): return next((r["count"] for r in V["weight_counts"] if r["uc"] == u and r["placement"] == p), 0)
def capuc(u, k): return next(r[k] for r in V["capacity"]["per_uc"] if r["uc"] == u)
def simh(u, t): return next((r["mean"] for r in V["sim"] if r["uc"] == u and r["tier"] == t), 0.0)
def md(scope, col, k): return V["mapdist"][scope][col][k]
def commv(u, k): return next(r[k] for r in V["comm"] if r["uc"] == u)
def envstat(chi, k): return next(r[k] for r in V["env_static"] if abs(r["chi"] - chi) < 1e-9)
def milp(n, k): return next(r[k] for r in V["milp"] if r["services"] == n)
def ceil1(v): return f"{math.ceil(v * 10) / 10:.1f}"
X = V["sixg"]
def x2(s, w, k): return next(r[k] for r in X["X2"] if r["scenario"] == s and r["window"] == w)
def chiS(k, key): return next(r[key] for r in X["X1_chi_by_split_V2_T1"] if r["k"] == k)
def splits(rate, bits, w, k): return next(r[k] for r in X["X1_seasonal"] if r["device_rate"] == rate and str(r["feature_bits"]) == bits and r["window"] == w)
_ee = pd.read_csv(ROOT / "results/v2_6g/X1_device_efficiency_sweep.csv")
def ees(ee, feat, k): return _ee[(_ee.device_EE == ee) & (_ee.feat.astype(str) == feat)][k].iloc[0]
def zero_hours(w):
    f = {"Winter 2026": "winter", "Spring 2026": "spring", "Summer 2026": "summer"}[w]; h = pd.read_csv(ROOT / f"data/neso_regional_{f}_2026.csv")
    x = h["North Scotland"].to_numpy(float); x = x[: len(x) // 2 * 2].reshape(-1, 2).mean(1); return int((x == 0).sum())
PUE = [1.2, 1.3, 1.35, 1.4]; EE = [730, 730, 730, 730]; EPS = [12.66, 6.48, 3.39, 0.30]
def pairx(i, j): return (EPS[j] - EPS[i]) * 1e-3 / (PUE[i] / EE[i] - PUE[j] / EE[j])
xs = [c["chi_E"] for c in V["xrange"]["cases"] if c["chi_E"] is not None and c["case"] not in ("Reference (one server value)", "Previous profile")]; xr_min, xr_max = min(xs), max(xs)   # published server/module pairs only
def byu(u, k): return next(g[k] for g in V["by_user"] if g["user"] == u)
def xb(s_, k): return X["X2b"][s_][k]
_envt = pd.read_csv(ROOT / "results/v2/intensity_envelope.csv")
def envh(w, chi, k): return float(_envt[(_envt.window == w) & ((_envt.chi - chi).abs() < 1e-6)][k].iloc[0])
def accts(name, w, k): return V["sens"]["carbon_accounting"][name]["seasonal"][w][k]
def acct(name): return next(v["static_weighted_red_vs_B3"] for k_, v in V["sens"]["carbon_accounting"].items() if k_ == name)
CHI_UC4 = 2.9 / 0.12; CI_FLOOR = 11.0
def pe(u, p_): return V["energy_by_method"][u][p_]
def pc_(u, p_): return V["carbon_by_method"][u][p_]
def fr(wc, k): return next(r[k] for r in V["frontier"] if abs(r["w_C"] - wc) < 1e-9)
def simsd(u, t): return next((r["std"] for r in V["sim"] if r["uc"] == u and r["tier"] == t), 0.0)
def th_(w, u, t): return json.loads(_th[(_th.window == w) & (_th.uc == u)]["EASE_tier_hours"].iloc[0]).get(t, 0)
def var_(name, k): return V["sens"]["variants"][name][k]
def varsea(name, w, k): return V["sens"]["variants"][name]["seasonal"][w][k]
def accts_s(name): return V["sens"]["carbon_accounting"][name]["static_red_vs_B5"]
def x3(scn, u, k): return next(r[k] for r in X["X3"] if r["scenario"] == scn and r["uc"] == u)
def x3r(L, R): return next(r["airan_GFLOPs"] for r in X["X3_min_rate"] if abs(r["Lmax_ms"] - L) < 1e-9 and abs(r["reliability"] - R) < 1e-12) / 1000
def split_static(rate, bits, k): return next(r[k] for r in X["X1_static"] if r["device_rate"] == rate and str(r["feature_bits"]) == bits)
_th = pd.read_csv(ROOT / "results/v2/reference_trace_tier_hours.csv")
def oth(w, u, t): return json.loads(_th[(_th.window == w) & (_th.uc == u)]["Oracle-KA_tier_hours"].iloc[0]).get(t, 0)
def envs(chi, k): return next(r[k] for r in V["env_static"] if abs(r["chi"] - chi) < 1e-3)
def wd(n): return ["no", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"][int(n)] if 0 <= int(n) <= 10 else f"{int(n):,}"
pyver = sys.version.split()[0]; npver, pdver, spver, mplver = np.__version__, pd.__version__, scipy.__version__, matplotlib.__version__
# consistency assertions behind prose claims
refpl = {u: V["static"][u]["placement"] for u in V["static"]}; REF = {"UC1": "INFEASIBLE", **refpl}
assert V["served"] == ["UC2", "UC3", "UC4", "UC5"] and V["unserved"] == ["UC1"]
assert refpl == {"UC2": "T4-V2", "UC3": "T4-V2", "UC4": "T2-V4", "UC5": "T1-V2"}
assert all(V["placements"][u]["EASE"] == V["placements"][u]["Oracle-KA"] for u in refpl) and V["placements"]["UC4"]["B5"] == "T3-V4" and V["placements"]["UC5"]["B5"] == "T4-V2"
assert V["placements"]["UC4"]["B3"] == "T5-V4" and V["placements"]["UC5"]["B3"] == "T5-V2" and V["placements"]["UC4"]["B4"] == "T5-V4" and V["placements"]["UC5"]["B4"] == "T4-V2"
assert all(V["placements"][u][p_] == refpl[u] for u in ("UC2", "UC3") for p_ in ("B3", "B4", "B5"))
assert V["static_red_B5"] > 0 and V["static_dE_B5"] > 0 and V["static_red_B3"] > 0 and V["static_dE_B3"] < 0 and abs(V["static_weighted"]["EASE"]["red_vs_Oracle-KA"]) < 1e-9
assert pe("UC4", "B5") < pe("UC4", "EASE") and pc_("UC4", "EASE") < pc_("UC4", "B5") and pe("UC5", "B5") < pe("UC5", "EASE") and pc_("UC5", "EASE") < pc_("UC5", "B5")
assert V["mapw"]["red_vs_B5"]["positive"] == 24 and V["mapw"]["red_vs_B3"]["positive"] == 24 and V["mapw"]["dE_vs_B3"]["positive"] == 0 and V["mapw"]["dE_vs_B5"]["negative"] == 0
assert all(V["mapstatic"][u]["ease_equals_oracle"] == 24 for u in refpl) and md("all", "red_vs_B5", "positive") == 72 and V["seasonal_b5"]["neg"] == 0 and md("all", "red_vs_B3", "negative") == 0
assert all(sea(w, "red_vs_B5") > 0 and sea(w, "dE_vs_B5") > 0 and sea(w, "red_vs_B3") > 0 and sea(w, "dE_vs_B3") < 0 for w in WINS)
assert fr(0.0, "mappings_differ") == 0 and fr(0.1, "mappings_differ") == 24 and all(abs(fr(w, "red_median") - fr(0.4, "red_median")) < 1e-6 for w in (0.15, 0.2, 0.6, 0.8)) and V["oracle24"]["differ"] == 24
assert abs(V["env"]["chi_E_T2_T3"] - 45.114) < 1e-3 and abs(pairx(2, 3) - V["env"]["chi_E_T2_T3"]) < 1e-6 and abs(pairx(0, 1) - V["env"]["chi_E_T2_T3"]) < 1e-6
assert V["env"]["chi_C_T2_T3_mean"] < V["static"]["UC4"]["chi_GFLOP_per_Mbit"] < V["static"]["UC5"]["chi_GFLOP_per_Mbit"] < V["env"]["chi_E_T2_T3"] and V["chi_dev"]["T2_730"] < V["static"]["UC4"]["chi_GFLOP_per_Mbit"]
assert V["env"]["Emin_negative"] == 0 and V["env"]["negative"] == 0 and sorted(round(r["chi"], 1) for r in V["env_static"] if abs(r["reduction_vs_Emin_percent"]) > 1e-9) == [10.0, round(CHI_UC4, 1), 30.0]
assert V["capacity"]["independent"]["load"]["T4"] > V["capacity"]["capacity"]["T4"] and capuc("UC3", "stress") == "T3-V2" and abs(V["capacity"]["milp_vs_oracle_carbon_percent"]) < 1e-9 and all(capuc(u, "stress") == refpl[u] for u in ("UC2", "UC4", "UC5"))
assert simh("UC2", "UNSERVED") == 7 and simh("UC4", "T2") == 168 and simh("UC5", "T1") == 168 and simh("UC3", "T3") + simh("UC3", "T4") == 168
sn = V["sens"]
assert all(v == REF for v in sn["T4_transport_nJ_per_bit"].values()) and all(sn["per_request_rate_scale"][k] == REF for k in ("0.5", "1", "2", "4")) and sn["per_request_rate_scale"]["0.25"] == {**REF, "UC2": "INFEASIBLE"}
assert all(sn["device_rate_GFLOPs"][k] == REF for k in sn["device_rate_GFLOPs"]) and all(sn["device_EE_GFLOP_per_J"][k] == REF for k in ("100", "200", "300", "461")) and sn["device_EE_GFLOP_per_J"]["730"] == {**REF, "UC4": "T5-V4"}
assert all(v == REF for v in sn["efficiency_level_x_path"].values()) and all(sn["rho_max"][k] == REF for k in ("0.3", "0.5", "0.7")) and sn["rho_max"]["0.9"] == {**REF, "UC2": "INFEASIBLE"}
assert all(sn["headroom_cap"][k] == REF for k in ("1.5", "2.0", "3.0", "5.0")) and sn["headroom_cap"]["1000000000.0"] == {**REF, "UC4": "T5-V4"}
assert all(v["placements"] == refpl for v in sn["carbon_accounting"].values()) and var_("mean-delay latency gate", "placements")["UC1"] == "T4-V2" and var_("uncompressed payload (1.2 Mbit)", "static_red_vs_B5") < 0.1
assert commv("UC2", "stable") == 81 and commv("UC3", "stable") == 81 and commv("UC2", "matches_oracle") == 81 and commv("UC3", "matches_oracle") == 81
assert all(milp(n_, "runs_with_unserved") == 0 for n_ in (5, 50, 250, 1000)) and milp(1000, "solve_s_max") < 1 and milp(1000, "hit_time_limit") == 0
assert x3("5G-class far edge (reference)", "UC1", "EASE") == "INFEASIBLE" and x3("AI-RAN far edge", "UC1", "EASE") == "T4-V2" and x3("AI-RAN far edge", "UC1", "latency_ms") <= 1.0
assert all(x3("AI-RAN far edge", u, "EASE") == refpl[u] for u in refpl)
assert all(splits(r_, "8", w, "hours_split") == 168 for r_ in (58.1, 230, 2890) for w in WINS) and all(splits(r_, "native", w, "hours_split") == 0 for r_ in (4, 58.1, 230, 2890) for w in WINS)
assert xb("2030, no regional spread", "cells_positive") == 0 and xb("2030 uniform", "static_positive") == 24 and xb("2030, spread halved", "static_max") < xb("2030 uniform", "static_max")
# ---- round-5 claims: E-min as primary comparator, conditions for the headline, generalized disagreement set
assert all(V["placements"][u]["B5"] == V["placements"][u]["Emin"] for u in refpl) and abs(V["static_red_Emin"] - V["static_red_B5"]) < 1e-9 and V["static_red_Emin"] > 0 and V["static_dE_Emin"] > 0
assert all(pc_(u, "EASE") == pc_(u, "Emin") for u in ("UC2", "UC3")) and pc_("UC4", "EASE") < pc_("UC4", "Emin") and pc_("UC5", "EASE") < pc_("UC5", "Emin")
assert all(V["b5w"][k]["B5_placements"]["UC4"] == "T3-V4" for k in ("0.1", "0.15", "0.2")) and all(V["b5w"][k]["B5_placements"]["UC4"] == "T2-V4" for k in ("0.22", "0.25", "0.3333", "0.4"))
assert all(V["sens"]["payload_kB_savings"][k]["B5_placements"]["UC4"] == "T2-V4" for k in ("10", "12", "14", "14.4")) and all(V["sens"]["payload_kB_savings"][k]["B5_placements"]["UC4"] == "T3-V4" for k in ("15", "16", "18", "20"))
assert all(v_["Emin_placements"]["UC4"] == "T3-V4" and v_["placements"]["UC4"] == "T2-V4" for v_ in V["sens"]["payload_kB_savings"].values())
ab = {a["configuration"]: a for a in V["ablation"]}
assert ab["No carbon"]["UC4"] == "T2-V4" and ab["No carbon"]["UC5"] == "T4-V2" and all(ab[c][u] == refpl[u] for c in ("No KPI score", "No energy") for u in refpl) and ab["No accuracy gate"]["accuracy_invalid"] == 3
assert fr(0.05, "mappings_differ_Emin") == 18 and fr(0.1, "mappings_differ_Emin") == 24 and fr(0.1, "oracle_match") == 18 and all(fr(w, "oracle_match") == 20 for w in (0.15, 0.2, 0.25)) and all(fr(w, "oracle_match") == 24 for w in np.arange(0.3, 0.801, 0.05))
assert all(abs(fr(w, "redE_min") - fr(0.1, "redE_min")) < 1e-9 for w in (0.15, 0.2, 0.25)) and all(abs(fr(w, "gap_max")) < 1e-9 for w in np.arange(0.3, 0.801, 0.05)) and max(fr(w, "gap_max") for w in (0.1, 0.15, 0.2, 0.25)) == fr(0.2, "gap_max")
assert V["oracleEmin24"]["differ"] == 24 and V["mapw"]["red_vs_Emin"]["positive"] == 24 and V["mapw"]["dE_vs_Emin"]["negative"] == 0 and md("all", "red_vs_Emin", "positive") == 72 and V["seasonal_emin"]["neg"] == 0
assert byu("North Scotland", "em_max") == max(g["em_max"] for g in V["by_user"]) and V["no_floor_maps"]["max"] > V["mapw"]["red_vs_Emin"]["max"] and V["no_floor_maps"]["median"] > V["mapw"]["red_vs_Emin"]["median"]
assert var_("no carbon floor", "static_red_vs_Emin") > V["static_red_Emin"] and all(varsea("no carbon floor", w, "red_vs_Emin") > sea(w, "red_vs_Emin") for w in WINS)
assert all(sea(w, "red_vs_Emin") > 0 and sea(w, "dE_vs_Emin") > 0 for w in WINS) and th_("Summer 2026", "UC3", "T3") > 0 and V["placements"]["UC3"]["EASE"] == V["placements"]["UC3"]["Emin"]
xw = V["xwin"]; assert xw["Summer 2026"]["window_mean_opposite"] and not xw["Winter 2026"]["window_mean_opposite"] and not xw["Spring 2026"]["window_mean_opposite"] and xw["Summer 2026"]["mean_CI_T2"] > xw["Summer 2026"]["mean_CI_T3"]
ev = V["env"]; assert ev["Emin_pos_without_disagreement"] == 0 and ev["Emin_negative"] == 0 and ev["Emin_pos_outside_mean_interval"] == 9 and ev["departed_outside_hours"] > 0 and ev["disagreement_without_saving"] == 5
assert all(envh("Spring 2026", c, "reduction_vs_Emin_percent") > 0 for c in (0.3, 0.5, 1.0, 3.0)) and envh("Summer 2026", 100, "reduction_vs_Emin_percent") > 0
assert V["env_maxdE_row"]["energy_change_vs_Emin_percent"] == V["env_pos_dE_max"] and V["env_max_row"]["window"] == "Spring 2026" and V["env_maxdE_row"]["window"] == "Spring 2026"
v35 = V["variants35"]; assert v35["n"] == 35 and v35["n_dis"] + v35["n_agr"] == 35 and v35["dis_min"] > 10 and v35["agr_max"] < 2.5
kmv = [v for k_, v in V["km"].items() if float(k_.split("|")[0]) * float(k_.split("|")[1]) <= 0.5 + 1e-9]; assert len(kmv) == 9 and max(kmv) < 1.0
ep = V["sens"]["efficiency_profiles_savings"]; assert all(ep[k]["placements"]["UC4"] == "T5-V4" and ep[k]["Emin_placements"]["UC4"] == "T5-V4" for k in ("server low all (471)", "server mid / module mid (730/730, T5 613)"))
assert any(v["Emin_placements"]["UC4"] != "T3-V4" for v in V["sens"]["efficiency_level_x_path_savings"].values()) and all(v["placements"] == refpl for v in V["sens"]["efficiency_level_x_path_savings"].values())
assert abs(var_("uniform intensity in every region (marginal-unit proxy)", "static_red_vs_Emin")) < 1e-9 and abs(V["b5w"]["0.2"]["red_vs_B5"] - V["static_red_B5"]) < 1e-9
assert abs(pairx(0, 3) - V["env"]["chi_E_T2_T3"]) < 1e-6 and V["static"]["UC5"]["chi_GFLOP_per_Mbit"] < pairx(0, 3) and V["band"]["reference_T2_lead"] < V["band"]["T2_lead_max"]
assert split_static(2890, "8", "EASE") == "T4-V2-k1" and split_static(2890, "8", "Oracle") == "T1-V2-k1" and split_static(2890, "8", "gap_vs_oracle_percent") > 20
assert x3r(1.0, 0.9999999) > 0 and next(r["far_edge_GFLOPs"] for r in X["X3_min_rate"] if r["Lmax_ms"] == 1.0 and r["reliability"] > 0.999999) is None
tc = V["trace_cap"]; assert not tc["binding"] and max(tc["utilisation"].values()) < 0.5
sp = V["simpol"]; assert sp["EASE"]["unserved_service_hours"] == sp["Emin"]["unserved_service_hours"] == sp["Oracle-KA"]["unserved_service_hours"] == 7 and sp["EASE"]["tier_hours"] == sp["Oracle-KA"]["tier_hours"]
assert sp["Emin"]["tier_hours"]["UC3"] == sp["EASE"]["tier_hours"]["UC3"] and sp["Emin"]["tier_hours"]["UC4"] == {"T3": 168.0} and abs(sp["EASE_vs_Emin"]["gap_oracle"]) < 1e-9 and sp["EASE_vs_Emin"]["red"] > 0
_sp = pd.read_csv(ROOT / "results/v2/controlled_simulation_policies.csv"); _ix = ["seed", "hour", "uc"]
assert (_sp[_sp.policy == "EASE"].set_index(_ix).tier == _sp[_sp.policy == "Oracle-KA"].set_index(_ix).tier).all()
_ex = json.loads((ROOT / "results/v2/v2_summary.json").read_text())["controlled_sim_policies_Emin_UC5_explained"]; assert _ex["hours"] > 0 and _ex["explained"] == _ex["hours"]
# ---- review-6 claims
rb = V["rob"]; fl = rb["floor"]; base_uf = fl["11 g/kWh in score only"]
assert max(v["differ"] for v in rb["floor_decisions_differing"].values()) <= 10 and rb["floor_decisions_differing"]["11 g/kWh in score only"]["differ"] == 0
for k_ in ("5 g/kWh in score only", "1 g/kWh in score only", "no floor, zero-safe score (offset 1 g/kWh)", "no floor, zero-safe score (offset 0.1 g/kWh)"):
    v_ = fl[k_]; assert abs(v_["static_red_vs_Emin"] - base_uf["static_red_vs_Emin"]) < 0.01 and all(abs(v_["seasonal"][w]["red_vs_Emin"] - base_uf["seasonal"][w]["red_vs_Emin"]) < 0.01 for w in WINS)
    assert all(abs(v_["mappings"][q] - base_uf["mappings"][q]) < 0.01 for q in ("min", "median", "max"))
assert base_uf["static_red_vs_Emin"] > V["static_red_Emin"] and base_uf["mappings"]["max"] > V["mapw"]["red_vs_Emin"]["max"] and abs(fl["11 g/kWh in signal (reference)"]["static_red_vs_Emin"] - V["static_red_Emin"]) < 1e-9
mb = rb["marginal_blend"]; assert abs(mb["0.0"]["static_red_vs_Emin"]) < 1e-9 and mb["0.25"]["static_red_vs_Emin"] < 0 and mb["0.25"]["placements"]["UC4"] == "T2-V4"
assert all(mb[k_]["static_red_vs_Emin"] < V["static_red_Emin"] for k_ in ("0.75", "0.5", "0.25", "0.0")) and mb["0.75"]["static_red_vs_Emin"] > mb["0.5"]["static_red_vs_Emin"] > 0
fe = rb["forecast_error"]; assert all(fe["0.1"][w]["red_vs_Emin"] > 0 for w in WINS) and fe["0.25"]["Summer 2026"]["red_vs_Emin"] < 0
vm = rb["volume_mix"]; assert vm["UC4 75%"]["red_vs_Emin"] > vm["UC4 50%"]["red_vs_Emin"] > vm["UC4 25%"]["red_vs_Emin"] > vm["UC4 10%"]["red_vs_Emin"] > vm["UC4 0%"]["red_vs_Emin"] > 0
qv = V["qv"]; assert all(abs(qv["poisson"][p_]["mean"] / qv["analytic"][p_] - 1) < 0.05 for p_ in qv["analytic"]) and all(qv["bursty_h2_scv4"][p_]["mean"] > 2.5 * qv["analytic"][p_] for p_ in qv["analytic"])
fb = qv["reference_placements_under_bursty_arrivals"]; assert not fb["UC2"]["feasible_bursty"] and all(fb[u]["feasible_bursty"] for u in ("UC3", "UC4", "UC5")) and qv["UC2_bursty"]["by_rho"]["0.6"]["feasible"]
assert 0.5 < V["k_star"] < 0.55 and all(V["km"][k_] < 1.0 for k_ in V["km"] if float(k_.split("|")[0]) * float(k_.split("|")[1]) <= V["k_star"])
assert abs(V["sens"]["UC4_B5_margin"]["weight_at_tie"] - 0.212) < 0.002 and V["sens"]["UC4_B5_margin"]["weight_at_tie"] < 0.22
# ---- final-review claims (comments A-E; results/v2/review_checks.json)
RC = V["rc"]; MLP = RC["mlperf"]; LB = RC["B_latency_bound"]; BD = RC["B_derating"]; AF = RC["A_factorial"]; DQ = RC["D_queue"]; EC = RC["E_capacity"]; C3 = RC["C_V3_throughput"]
assert all(MLP[k_]["valid"] for k_ in ("server_offline", "server_server", "device_offline", "device_singlestream"))
assert abs(MLP["server_offline"]["GFLOP_per_J"] - 730) < 1 and abs(MLP["device_offline"]["GFLOP_per_J"] - 461) < 1 and abs(MLP["device_singlestream_rate_GFLOP_per_s"] - 2890) < 1   # the logs reproduce the reference inputs
assert MLP["device_latency_bound_factor"] < MLP["server_latency_bound_factor"] < 1
lbe, lbm = LB["efficiencies_only"], LB["with_measured_latency"]
assert lbe["EASE"] == refpl and lbe["red"] > 10 and LB["band_holds"] and lbe["Emin"]["UC5"] == lbe["EASE"]["UC5"] == "T1-V2" and lbe["Emin"]["UC3"] == "T3-V2" and lbe["Emin"]["UC4"] == "T3-V4"
assert lbm["served"] == ["UC4", "UC5"] and lbm["EASE"] == {"UC4": "T2-V4", "UC5": "T2-V2"} and lbm["Emin"]["UC4"] == "T3-V4" and LB["L_eff_measured_ms"]["UC5"]["T1"] > 100 and lbm["red"] > 10
assert LB["feasible_tiers_measured_latency"]["UC2"] == [] and LB["feasible_tiers_measured_latency"]["UC3"] == []
rr_ = RC["B_rate"]["rows"]["2890 (device SingleStream rate)"]; assert rr_["served"] == ["UC4", "UC5"] and rr_["UC4"] == ["T3", "T2"] and rr_["UC5"] == ["T4", "T1"]
assert V["sens"]["min_rate_GFLOPs_for_reference_placement"]["UC4"] < V["sens"]["min_rate_GFLOPs_for_reference_placement"]["UC5"] < MLP["device_singlestream_rate_GFLOP_per_s"]
assert abs(BD["ks_star_closed"] - BD["ks_star_numeric"]) < 1e-6 and BD["ks_ease_moves"] < BD["ks_star_closed"] and BD["grid_prediction_matches"] == BD["grid_cells"]
assert LB["kappa_s"] > max(BD["ks_star_at_measured_kd"], BD["k_T2T3"]) and abs(BD["k_T2T3"] - V["k_star"]) < 1e-9 and BD["headline_red_range"][0] > 15 > BD["other_red_max"]
assert 8 < BD["device_optimum_red_range"][0] < BD["device_optimum_red_range"][1] < BD["headline_red_range"][0] and BD["both_device_red_range"][1] < 3 and BD["sweep"]["0.9"]["UC4"] == ["T5", "T2", "T2"] and BD["sweep"]["0.85"]["UC4"][:2] == ["T5", "T5"]
fa = AF["all"]; assert fa["cells"] == 180 and fa["negative"] == 0 and 2 * fa["disagree"] > fa["cells"] and fa["red_agr_max"] < 2.5 and AF["by_spread"]["1.0"]["ge10"] > AF["by_spread"]["0.5"]["ge10"]
assert AF["within_band"]["disagree"] / AF["within_band"]["cells"] > 0.75 and fa["red_dis_median"] < V["static_red_Emin"] and abs(fa["red_agr_max"] - V["variants35"]["agr_max"]) < 0.05
c3r = C3["rows"]; assert not c3r["1/delta = 2.22"]["V3_selected"] and all(c3r[k_][p_] == c3r["1 (reference: energy only)"][p_] for k_ in c3r for p_ in ("EASE", "Emin", "Oracle", "stress_MILP"))
assert all(abs(c3r[k_]["red"] - V["static_red_Emin"]) < 1e-9 for k_ in c3r) and c3r["1/delta = 2.22"]["B3"] == c3r["1 (reference: energy only)"]["B3"] and any("V3" in v for v in c3r["4"]["B3"].values())
assert DQ["static_reference_single_variant"] and DQ["sim_mixed_tier_hours"]["EASE"] == 0 and DQ["sim_mixed_tier_hours"]["Oracle-KA"] == 0 and set(DQ["sim_mixed_by_tier"]["Emin"]) == {"T3"}
assert DQ["sim_tier_hours_by_tier"]["Emin"]["T3"] == 168 * 5 and DQ["conservative_gate"]["violations"] == 0 and all(v["within_bound"] and v["above_own"] for v in DQ["mixed_two_point"].values())
assert all(DQ["pooled_dispatch"][c_][p_]["max"] < DQ["analytic_service_times"][p_] for c_ in DQ["pooled_dispatch"] for p_ in DQ["analytic_service_times"]) and DQ["pooled_dispatch"]["2"]["0.99999"]["mean"] < 0.5 * DQ["analytic_service_times"]["0.99999"]
assert V["qv"]["poisson"]["0.99999"]["min"] < V["qv"]["analytic"]["0.99999"] < V["qv"]["poisson"]["0.99999"]["max"]
assert EC["simulation_peak_load_fraction"] < EC["load_star"] and abs(EC["load_star"] - EC["metro_full_load"]) < 1e-4 and EC["red_below"][0] > 15 and EC["red_above"][1] < 3 and EC["all_served"] and EC["gap_oracle_max"] < 1e-9
assert EC["Emin_UC4_at_peak"] == "T2-V4" and EC["peak_differs"] == ["UC5"] and EC["binding_tier"]["EASE"] == EC["binding_tier"]["Emin"] == "T4" and EC["static_feasible_up_to_load"]["Emin"] < EC["static_feasible_up_to_load"]["EASE"] < EC["load_star"]
assert abs(EC["red_at_peak"]) <= V["variants35"]["agr_max"] + 0.05 and max(m_ for m_ in (0.10, 0.30, 0.50)) * 1.25 <= EC["load_star"]
_sw = {round(r_["load"], 2): r_["red"] for r_ in EC["sweep"]}; assert _sw[0.6] > 15 and _sw[0.65] < 3 and 0.60 < EC["metro_full_load"] < 0.65       # the 5% grid brackets the calculated threshold
assert abs(EC["metro_full_load"] - EC["admission"]["T3"] / (V["rates"]["peak"]["UC4"] * 2.9 + V["rates"]["peak"]["UC3"] * 4.6)) < 1e-9
assert lbm["Emin"]["UC5"] == lbm["EASE"]["UC5"] == "T2-V2" and all(V["placements"][u]["EASE"] == V["placements"][u]["Emin"] for u in ("UC2", "UC3"))
assert not V["qv"]["reference_placements_under_bursty_arrivals"]["UC2"]["feasible_bursty"]
tpl = (BUILD / "manuscript_template.md").read_text(encoding="utf8")
tpl = re.sub(r"\{\{(.+?)\}\}", lambda mo: eval("f'{" + mo.group(1) + "}'"), tpl)
tpl = re.sub(r"@@TABLE (\w+)@@", lambda mo: T[mo.group(1)], tpl)
FIX = []
def keep(mo):
    a, b = int(mo.group(1)), int(mo.group(2)); chunk = "\n".join(src[a - 1:b])
    for o, n in FIX: chunk = chunk.replace(o, n)
    return chunk
tpl = re.sub(r"@@KEEP (\d+)-(\d+)@@", keep, tpl)
d0 = Document(str(ORIG)); auth = [p.text for p in d0.paragraphs if p.style.name == "Author"]
esc = lambda s: s.replace("[", "\\[").replace("]", "\\]").replace("@", "\\@")
title = "EASE-6G: A Regime Analysis of Carbon-Aware AI Inference Placement Across the Edge--Cloud Continuum With Implications for 6G"
tpl = tpl.replace("@@TITLE@@", '::: {custom-style="Title"}\n' + title + "\n:::")
tpl = tpl.replace("@@AUTHORS@@", "\n\n".join('::: {custom-style="Author"}\n' + (esc(a) if a.strip() else " ") + "\n:::" for a in auth))
assert "@@" not in tpl and "{{" not in tpl

# ---- audit corrections to passages carried over from the source manuscript
for _a, _b in [('\\[46\\] OpenAI, "[GPT-5.6: Frontier intelligence that scales with your\nambition,](https://openai.com/index/gpt-5-6/)" Jul. 9, 2026. \\[Online\\].\nAvailable: https://openai.com/index/gpt-5-6/. Accessed: Sep. 18, 2026.',
                '\\[46\\] T. Sukprasert, A. Souza, N. Bashir, D. Irwin, and P. Shenoy, "On the limitations of carbon-aware temporal and spatial workload shifting in the cloud," in Proc. 19th Eur. Conf. Comput. Syst. (EuroSys), Athens, Greece, Apr. 2024, doi: 10.1145/3627703.3650079.'),
               ('\\[26\\] Y. G. Kim, U. Gupta, A. McCrabb, Y. Son, V. Bertacco, D. Brooks,\nand C.-J. Wu, "GreenScale: Carbon-aware systems for edge computing,"\narXiv:2304.00404, 2023.', '\\[26\\] Y. Son, U. Gupta, A. McCrabb, Y. G. Kim, V. Bertacco, D. Brooks, and C.-J. Wu, "GreenScale: Carbon optimization for edge computing," IEEE Internet Things J., vol. 12, no. 16, pp. 32379--32393, 2025, doi: 10.1109/JIOT.2025.3555153.'),
               ("Generative AI was used as an assistive tool for language editing, code\nreview, and organization of the manuscript \\[46\\]. The authors\nindependently verified the technical content, equations, calculations,\ncitations, and conclusions and take full responsibility for the article.", "Generative AI was used in preparing this article. GPT-5.6 (OpenAI) was used for language editing, code review, and organization of the manuscript. Claude (Anthropic; Claude Fable 5.2 and Claude Opus 5.5) was used to revise the analysis code and rerun the experiments reported in Sections V--VII, to verify equations, numerical results, and references, and to draft and edit text in all sections. The authors reviewed and verified the technical content, equations, calculations, citations, and conclusions and take full responsibility for the article."),
               ("\\[29\\]. CarbonEdge extends", "\\[29\\]. CarbonEdge by Zhang et al. extends"),
               ("Low-rank adaptation (LoRA) reduces\ntrainable parameters during adaptation but is not an\ninference-compression technique \\[37\\]; it is therefore not used as a\nlower-FLOP variant. ", ""),
               ('\\[37\\] E. J. Hu et al., "LoRA: Low-rank adaptation of large language\nmodels," in Proc. ICLR, 2022.',
                '\\[37\\] J. Baliga, R. W. A. Ayre, K. Hinton, and R. S. Tucker, "Green cloud computing: Balancing energy in processing, storage, and transport," Proc. IEEE, vol. 99, no. 1, pp. 149--167, Jan. 2011, doi: 10.1109/JPROC.2010.2060451.'),
               ("efficiency of machine learning systems from Watts to MWatts for", "efficiency of machine learning systems from μWatts to MWatts for"),
               ("0.45; deployment-specific calibration remains necessary.", "0.45; deployment-specific calibration remains necessary. The factor scales energy only: execution time and capacity use the nominal work of V3, as if quantization saved energy without raising throughput. Section VI-I applies a matching throughput factor and finds no decision changed."),
               ("MEC and edge-computing studies establish computation offloading", "Early energy analyses of offloading showed that moving work off a device saves energy only when the computation is large relative to the data transferred \\[52\\]. MEC and edge-computing studies establish computation offloading")]:
    assert tpl.count(_a) == 1, ("audit correction target not found", _a[:60]); tpl = tpl.replace(_a, _b)

# ---- typography pass 1: equation fixes, inline symbols as math (same style as the display equations)
tpl = tpl.replace(r"\rho_{B}B_{\text{access,uc,}}$$", r"\rho_{B}\,B_{\text{access,uc}},$$")
GREEK = {"χ": r"\chi", "ρ": r"\rho", "δ": r"\delta", "α": r"\alpha", "β": r"\beta", "ε": r"\varepsilon", "η": r"\eta", "κ": r"\kappa", "λ": r"\lambda"}
def _base(x): return GREEK.get(x, x if len(x) == 1 else r"\text{" + x + "}")
def _args(a): return ",".join(x if x in ("t", "v", "h", "u", "d", "i", "j") else r"\text{" + x + "}" for x in a.split(","))
def _sub(mo):
    b, sub, arg = mo.group(1), mo.group(2), mo.group(3)
    sb = sub if len(sub) == 1 else r"\text{" + sub + "}"
    return "$" + _base(b) + "_{" + sb + "}" + ("(" + _args(arg) + ")" if arg else "") + "$"
def _fn(mo): return "$" + _base(mo.group(1)) + "(" + _args(mo.group(2)) + ")$"
def symbols(text):
    text = text.replace("χ = Fδ/D", r"$\chi = F\delta/D$")
    text = text.replace("executes k/12 of", "executes $k/12$ of")
    text = re.sub(r"([A-Za-zχρδαβεηκλ]+)~([^~\n]+)~(?:\(([A-Za-z0-9,]{1,8})\))?", _sub, text)
    text = re.sub(r"(?<![A-Za-z$\\{}_])(EE|PUE|CI|F|L|B|R|J|A|a|b|r|δ|α|β)\((t|v|uc|u|d|t,h|v,uc|V3)\)", _fn, text)
    text = text.replace("εₜ", r"$\varepsilon_{t}$")
    text = re.sub(r"(?<![A-Za-z$\\{}_])([χδ])(?![A-Za-z~(])", lambda mo: "$" + GREEK[mo.group(1)] + "$", text)
    text = re.sub(r"\b(tier|variant|hour|block) ([tvhk])\b", lambda mo: mo.group(1) + " $" + mo.group(2) + "$", text)
    text = re.sub(r"(?<![A-Za-z$\\{}_\-])\b(r)(?= (?:=|≥) |\.(?:\s|$))|\b(M)(?= (?:= \d|an unserved))|\b(y)(?= is fixed)|(?<=payload )(D)\b|(?<=from payload )(D)\b", lambda mo: "$" + mo.group(0) + "$", text)
    return text
_head, _refs = tpl.split("# REFERENCES", 1); _lines = []
for _ln in _head.split("\n"):
    if _ln.startswith(("|", "#", "$$", "**TABLE", "!", ":::")) or "custom-style" in _ln: _lines.append(_ln); continue
    _parts = re.split(r"(\$[^$\n]+\$)", _ln)                      # keep existing inline math untouched
    _lines.append("".join(x if k % 2 else symbols(x) for k, x in enumerate(_parts)).replace("$$", r"\,"))   # adjacent symbols form one expression
_head = "\n".join(_lines)
TMATH = {r"$\text{CAP}_{\text{AI}}$": "CAP~AI~", r"$L_{\text{max}}$": "*L*~max~", r"$B_{\text{min}}$": "*B*~min~", r"$R_{\text{min}}$": "*R*~min~",
         r"$J_{\text{max}}$": "*J*~max~", r"$\text{Acc}_{\text{min}}$": "Acc~min~"}
def _tsym(ln):                                                 # table cells: symbols as italic text with true subscripts at the table's font size
    for k_, v_ in TMATH.items(): ln = ln.replace(k_, v_)
    ln = ln.replace("χE", "*χ*~E~").replace("χC", "*χ*~C~").replace("εₜ", "*ε*~t~")
    ln = re.sub(r"(?<![*])χ(?![*~])", "*χ*", ln)
    ln = re.sub(r"\*\*([LBRJr]) \(", r"***\1* (", ln); ln = ln.replace("| **R** |", "| ***R*** |")   # tier-profile symbols L(t), B(t), R(t), J(t), r(t)
    return ln
_head = "\n".join(_tsym(l) if l.startswith("|") else l for l in _head.split("\n"))
assert not re.search(r"[A-Za-zχρ]~[^~\n]+~", "\n".join(l for l in _head.split("\n") if not l.startswith("|"))), "text-style subscript left in prose"

_head = _head.replace("factor** $\\delta(v)$", "factor *δ*(*v*)**")
_head, _nd = re.subn(r"analytical \$\\delta\$( *\n *)= 0\.45", r"analytical\1*δ* = 0.45", _head); assert _nd == 1 and "factor *δ*(*v*)**" in _head
# ---- typography pass 2: citations numbered in order of first appearance; en-dash ranges
_head = re.sub(r"\\\]\s*-{1,2}\s*\\\[(?=\d)", r"\\]--\\[", _head)
_order = []
for mo in re.finditer(r"\\\[(\d+)\\\](?:--\\\[(\d+)\\\])?", _head):
    a_, b_ = int(mo.group(1)), int(mo.group(2) or mo.group(1))
    for n_ in range(a_, b_ + 1):
        if n_ not in _order: _order.append(n_)
_blocks = re.split(r"\n(?=\\\[\d+\\\] )", _refs.split("# AUTHOR BIOGRAPHIES")[0].strip("\n")); _tail = "# AUTHOR BIOGRAPHIES" + _refs.split("# AUTHOR BIOGRAPHIES", 1)[1]
_ids = [int(re.match(r"\\\[(\d+)\\\]", b_).group(1)) for b_ in _blocks]
assert sorted(_ids) == list(range(1, len(_ids) + 1)) and sorted(_order) == sorted(_ids), ("uncited or undefined references", sorted(set(_ids) ^ set(_order)))
REMAP = {old: new for new, old in enumerate(_order, 1)}
def _cite(mo):
    a_, b_ = int(mo.group(1)), mo.group(2)
    if b_ is None: return rf"\[{REMAP[a_]}\]"
    assert REMAP[int(b_)] - REMAP[a_] == int(b_) - a_, ("citation range broken by renumbering", a_, b_)
    return rf"\[{REMAP[a_]}\]--\[{REMAP[int(b_)]}\]"
_head = re.sub(r"\\\[(\d+)\\\](?:--\\\[(\d+)\\\])?", _cite, _head)
def _rng(mo):                                                 # three consecutive citations are written as a range
    a_, b_, c_ = int(mo.group(1)), int(mo.group(2)), int(mo.group(3))
    return rf"\[{a_}\]--\[{c_}\]" if (b_, c_) == (a_ + 1, a_ + 2) else mo.group(0)
_head = re.sub(r"\\\[(\d+)\\\], \\\[(\d+)\\\], \\\[(\d+)\\\]", _rng, _head)
_blocks = sorted((re.sub(r"^\\\[(\d+)\\\]", lambda mo: rf"\[{REMAP[int(mo.group(1))]}\]", b_.strip("\n")) for b_ in _blocks), key=lambda b_: int(re.match(r"\\\[(\d+)\\\]", b_).group(1)))
tpl = _head + "# REFERENCES\n\n" + "\n\n".join(_blocks) + "\n\n" + _tail
(BUILD / "citation_renumbering.json").write_text(json.dumps({str(k): v for k, v in sorted(REMAP.items())}, indent=0))
md_path = BUILD / "EASE6G_revised.md"; md_path.write_text(tpl, encoding="utf8")
media = BUILD / "media"; media.mkdir(exist_ok=True)
with zipfile.ZipFile(ORIG) as z:
    for n in ("word/media/image1.png", "word/media/image2.png"): (media / Path(n).name).write_bytes(z.read(n))
for f in (ROOT / "figures_v2").glob("*.png"): shutil.copy(f, media / f.name)
tmp = BUILD / "pandoc_out.docx"
subprocess.run(["pandoc", str(md_path), "-f", "markdown", "-o", str(tmp), "--reference-doc", str(ORIG), "--resource-path", str(BUILD)], check=True)

# ---- restore single/two-column sections
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"; q = lambda t: f"{{{W}}}{t}"
work = BUILD / "x"; shutil.rmtree(work, ignore_errors=True)
with zipfile.ZipFile(tmp) as z: z.extractall(work)
dp = work / "word/document.xml"; tree = etree.parse(str(dp)); body = tree.getroot().find(q("body")); final = body.find(q("sectPr"))
def style(p):
    s = p.find(f"{q('pPr')}/{q('pStyle')}"); return s.get(q("val")) if s is not None else ""
def text(p): return "".join(p.itertext())

M = "http://schemas.openxmlformats.org/officeDocument/2006/math"; R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PORDER = ["pStyle", "keepNext", "keepLines", "pageBreakBefore", "framePr", "widowControl", "numPr", "suppressLineNumbers", "pBdr", "shd", "tabs", "suppressAutoHyphens", "kinsoku", "wordWrap", "overflowPunct", "topLinePunct", "autoSpaceDE", "autoSpaceDN", "bidi", "adjustRightInd", "snapToGrid", "spacing", "ind", "contextualSpacing", "mirrorIndents", "suppressOverlap", "jc", "textDirection", "textAlignment", "textboxTightWrap", "outlineLvl", "divId", "cnfStyle", "rPr", "sectPr", "pPrChange"]
RORDER = ["rStyle", "rFonts", "b", "bCs", "i", "iCs", "caps", "smallCaps", "strike", "dstrike", "outline", "shadow", "emboss", "imprint", "noProof", "snapToGrid", "vanish", "webHidden", "color", "spacing", "w", "kern", "position", "sz", "szCs", "highlight", "u", "effect", "bdr", "shd", "fitText", "vertAlign", "rtl", "cs", "em", "lang", "eastAsianLayout", "specVanish", "oMath"]
SORDER = ["headerReference", "footerReference", "footnotePr", "endnotePr", "type", "pgSz", "pgMar", "paperSrc", "pgBorders", "lnNumType", "pgNumType", "cols", "formProt", "vAlign", "noEndnote", "titlePg", "textDirection", "bidi", "rtlGutter", "docGrid"]
def loc(e): return etree.QName(e).localname
def resort(parent, order):
    ch = list(parent); ch.sort(key=lambda c: order.index(loc(c)) if loc(c) in order else len(order))
    for c in ch: parent.remove(c)
    for c in ch: parent.append(c)
def setp(p, **kw):
    """Set paragraph properties: spacing=(before, after), jc, keepNext, tabs."""
    ppr = p.find(q("pPr"))
    if ppr is None: ppr = etree.Element(q("pPr")); p.insert(0, ppr)
    def put(tag, attrs=None, children=None):
        for o in ppr.findall(q(tag)): ppr.remove(o)
        e = etree.SubElement(ppr, q(tag))
        for k_, v_ in (attrs or {}).items(): e.set(q(k_), str(v_))
        for c in children or []: e.append(c)
    if "spacing" in kw:
        b, a_ = kw["spacing"]; put("spacing", {k_: v_ for k_, v_ in (("before", b), ("after", a_)) if v_ is not None})
    if "jc" in kw: put("jc", {"val": kw["jc"]})
    if kw.get("keepNext"): put("keepNext")
    if "tabs" in kw:
        ts = []
        for val, pos in kw["tabs"]:
            t = etree.Element(q("tab")); t.set(q("val"), val); t.set(q("pos"), str(pos)); ts.append(t)
        put("tabs", children=ts)
    resort(ppr, PORDER); return ppr
def setr(p, font=None, sz=None, bold=None):
    for r in p.iter(q("r")):
        rpr = r.find(q("rPr"))
        if rpr is None: rpr = etree.Element(q("rPr")); r.insert(0, rpr)
        if font:
            for o in rpr.findall(q("rFonts")): rpr.remove(o)
            f = etree.SubElement(rpr, q("rFonts"))
            for a_ in ("ascii", "eastAsia", "hAnsi", "cs"): f.set(q(a_), font)
        if sz:
            for tg in ("sz", "szCs"):
                for o in rpr.findall(q(tg)): rpr.remove(o)
            e = etree.SubElement(rpr, q("sz")); e.set(q("val"), str(sz))
        if bold and rpr.find(q("b")) is None: etree.SubElement(rpr, q("b"))
        resort(rpr, RORDER)
def mkrun(text=None, tab=False):
    r = etree.Element(q("r"))
    if tab: etree.SubElement(r, q("tab"))
    else:
        rp = etree.SubElement(r, q("rPr")); f = etree.SubElement(rp, q("rFonts")); f.set(q("ascii"), "Times New Roman"); f.set(q("hAnsi"), "Times New Roman")
        t = etree.SubElement(r, q("t")); t.text = text
    return r
kids = [k for k in body if k.tag in (q("p"), q("tbl"))]
# ---- equations: centre tab + right-aligned number, as in the source document
for k in list(kids):
    if k.tag != q("p") or k.find(f"{{{M}}}oMathPara") is None: continue
    omp = k.find(f"{{{M}}}oMathPara"); num = None
    trailing = "".join(t.text or "" for r in k.findall(q("r")) for t in r.findall(q("t"))).strip()
    if re.fullmatch(r"\(\d+\)", trailing): num = trailing
    else:
        nx = k.getnext()
        if nx is not None and nx.tag == q("p") and re.fullmatch(r"\(\d+\)", "".join(nx.itertext()).strip()): num = "".join(nx.itertext()).strip(); body.remove(nx)
    for r in k.findall(q("r")): k.remove(r)
    omp.addprevious(mkrun(tab=True))
    if num: omp.addnext(mkrun(num)); omp.addnext(mkrun(tab=True))
    setp(k, spacing=(40, 40), jc="left", tabs=[("center", 2550), ("right", 5020)])
    k.find(q("pPr")).find(q("pStyle")).set(q("val"), "BodyText")   # one paragraph style for every display equation
kids = [k for k in body if k.tag in (q("p"), q("tbl"))]

# ---- direct formatting transferred from the source document's conventions
for k in kids:
    if k.tag == q("tbl"):
        tp = k.find(q("tblPr"))
        for tg in ("tblW", "jc", "tblCellMar", "tblLayout"):
            for o in tp.findall(q(tg)): tp.remove(o)
        st_ = tp.find(q("tblStyle")); pos = (list(tp).index(st_) + 1) if st_ is not None else 0
        tw = etree.Element(q("tblW")); tw.set(q("w"), "5000"); tw.set(q("type"), "pct"); jc = etree.Element(q("jc")); jc.set(q("val"), "center")
        mar = etree.Element(q("tblCellMar"))
        for side in ("top", "left", "bottom", "right"):
            e = etree.SubElement(mar, q(side)); e.set(q("w"), "45"); e.set(q("type"), "dxa")
        look = tp.find(q("tblLook"))
        for e in (tw, jc, mar):
            if look is not None: look.addprevious(e)
            else: tp.append(e)
        fs = 14                                                        # one table text size (7 pt) throughout
        for ri, tr in enumerate(k.findall(q("tr"))):
            trp = tr.find(q("trPr"))
            if trp is None: trp = etree.Element(q("trPr")); tr.insert(0, trp)
            if trp.find(q("cantSplit")) is None: trp.insert(0 if trp.find(q("cnfStyle")) is None else 1, etree.Element(q("cantSplit")))
            for tc in tr.findall(q("tc")):
                tcp = tc.find(q("tcPr"))
                if tcp is None: tcp = etree.Element(q("tcPr")); tc.insert(0, tcp)
                for tg in ("shd", "vAlign"):
                    for o in tcp.findall(q(tg)): tcp.remove(o)
                if ri == 0:
                    sh = etree.SubElement(tcp, q("shd")); sh.set(q("val"), "clear"); sh.set(q("color"), "auto"); sh.set(q("fill"), "D9E2F3")
                va = etree.SubElement(tcp, q("vAlign")); va.set(q("val"), "center")
                for p in tc.findall(q("p")):
                    if ri == 0: setp(p, spacing=(0, 0), jc="center", keepNext=True)
                    else: setp(p, spacing=(0, 0), keepNext=True)
                    setr(p, sz=fs, bold=(ri == 0))
                    for mr in p.iter(f"{{{M}}}r"):                 # math runs in table cells: same size as the cell text
                        wr = mr.find(q("rPr"))
                        if wr is None:
                            wr = etree.Element(q("rPr")); mrp = mr.find(f"{{{M}}}rPr"); mr.insert(1 if mrp is not None else 0, wr)
                        for o in wr.findall(q("sz")) + wr.findall(q("szCs")): wr.remove(o)
                        z = etree.SubElement(wr, q("sz")); z.set(q("val"), str(fs)); z = etree.SubElement(wr, q("szCs")); z.set(q("val"), str(fs))
        continue
    st = style(k); tx = text(k).strip()
    _fs = {"Abstract": 20, "ImageCaption": 16, "Author": 16}.get(st, 18)
    for mr in k.iter(f"{{{M}}}r"):
        wr = mr.find(q("rPr"))
        if wr is None:
            wr = etree.Element(q("rPr")); mrp = mr.find(f"{{{M}}}rPr"); mr.insert(1 if mrp is not None else 0, wr)
        for o_ in wr.findall(q("sz")) + wr.findall(q("szCs")): wr.remove(o_)
        z = etree.SubElement(wr, q("sz")); z.set(q("val"), str(_fs)); z = etree.SubElement(wr, q("szCs")); z.set(q("val"), str(_fs)); resort(wr, RORDER)
    if k.find(f"{{{M}}}oMathPara") is not None: continue
    if st == "Title": setp(k, spacing=(None, 60)); setr(k, font="Times New Roman")
    elif st == "Author": setp(k, spacing=(None, 0)); setr(k, sz=16)
    elif st == "Heading1": setp(k, spacing=(80, 40), jc="center"); setr(k, font="Times New Roman", sz=22)
    elif st == "Heading2": setp(k, spacing=(60, 20)); setr(k, font="Times New Roman", sz=20)
    elif st == "ImageCaption": setp(k, spacing=(None, 40), jc="center")
    elif k.find(f".//{q('drawing')}") is not None: setp(k, spacing=(40, 0), jc="center")
    elif tx.startswith("TABLE "): setp(k, spacing=(40, 20), jc="center", keepNext=True)
    elif st in ("BodyText", "FirstParagraph", "Compact"): setp(k, spacing=(0, 0), jc="both")
for ppr in body.iter(q("pPr")): resort(ppr, PORDER)
MORD = {"dPr": ["begChr", "sepChr", "endChr", "grow", "shp", "ctrlPr"], "rPr": ["lit", "nor", "scr", "sty", "brk", "aln"]}
for rp_ in body.iter(f"{{{M}}}rPr"):
    if rp_.find(f"{{{M}}}nor") is not None:
        for o in rp_.findall(f"{{{M}}}sty"): rp_.remove(o)
for tag, order in MORD.items():
    for e in body.iter(f"{{{M}}}{tag}"): resort(e, order)
seen_h1 = False; flags = []
for k in kids:
    if k.tag == q("tbl"): flags.append(True); continue
    st = style(k)
    if st == "Heading1": seen_h1 = True
    wide = (not seen_h1) or st in ("ImageCaption", "CaptionedFigure") or k.find(f".//{q('drawing')}") is not None or text(k).strip().startswith("TABLE ")
    flags.append(wide)
def sect(wide):
    s = etree.Element(q("sectPr")); t = etree.SubElement(s, q("type")); t.set(q("val"), "continuous")
    for c in final:
        if c.tag in (q("cols"), q("type")): continue
        s.append(copy.deepcopy(c))
    cols = etree.SubElement(s, q("cols")); cols.set(q("space"), "331")
    if not wide: cols.set(q("num"), "2")
    resort(s, SORDER); return s
i = 0
while i < len(kids):
    j = i
    while j + 1 < len(kids) and flags[j + 1] == flags[i]: j += 1
    if j < len(kids) - 1:
        last = kids[j]
        if last.tag == q("tbl"):
            np_ = etree.Element(q("p")); last.addnext(np_); last = np_
        ppr = last.find(q("pPr"))
        if ppr is None: ppr = etree.Element(q("pPr")); last.insert(0, ppr)
        ppr.append(sect(flags[i])); resort(ppr, PORDER)
    else:
        for c in list(final):
            if c.tag in (q("cols"), q("type")): final.remove(c)
        t = etree.Element(q("type")); t.set(q("val"), "continuous"); final.insert(0, t)
        cols = etree.SubElement(final, q("cols")); cols.set(q("space"), "331")
        if not flags[i]: cols.set(q("num"), "2")
        resort(final, SORDER)
    i = j + 1
tree.write(str(dp), xml_declaration=True, encoding="UTF-8", standalone=True)
# ---- schema hygiene for parts written by the converter
nump = work / "word/numbering.xml"
if nump.exists(): nump.write_text(re.sub(r'(<w:nsid w:val=")([0-9A-Fa-f]{1,7})(")', lambda mo: mo.group(1) + mo.group(2).rjust(8, "0") + mo.group(3), nump.read_text(encoding="utf8")), encoding="utf8")
setp_ = work / "word/settings.xml"; setp_.write_text(re.sub(r"<w:savePreviewPicture\s*/>", "", setp_.read_text(encoding="utf8")), encoding="utf8")
with zipfile.ZipFile(ORIG) as z: setp_.write_bytes(z.read("word/settings.xml"))   # the converter reorders settings; keep the source file's
# ---- package hygiene: drop media carried over from the reference file but not referenced; declare png
rels = (work / "word/_rels/document.xml.rels").read_text(encoding="utf8")
for f in (work / "word/media").glob("*"):
    if f"media/{f.name}" not in rels: f.unlink()
ct = work / "[Content_Types].xml"; c = ct.read_text(encoding="utf8")
if 'Extension="png"' not in c: ct.write_text(c.replace("<Default ", '<Default Extension="png" ContentType="image/png"/><Default ', 1), encoding="utf8")
OUT.unlink(missing_ok=True)
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(work.rglob("*")):
        if f.is_file(): z.write(f, f.relative_to(work).as_posix())
words = len(re.sub(r"\$\$.*?\$\$", " ", tpl, flags=re.S).split()); ab = tpl.split("Abstract---")[1].split("**Index Terms")[0]
print("built", OUT, "| words ~", words, "| abstract words", len(ab.split()))
