#!/usr/bin/env python3
"""Discrete-event validation of the M/D/1 waiting-time quantile used in the tail-latency gate (Eq. 9).

Each shared-tier server is simulated with Lindley's recursion W_n = max(0, W_{n-1} + D - A_n), solved in vectorized form as
W_n = S_n - min_{k<=n} S_k with S_n the cumulative sum of D - A_k. Service time D = 1 (results are in service times), utilization 0.7.
Arrivals: Poisson (the model's assumption) and a bursty renewal process with hyperexponential interarrival times (squared coefficient
of variation 4, balanced means). The bursty quantiles are then inserted into Eq. (9) to test whether the reference placements stay feasible.
Output: results/v2/queue_validation.json
"""
import json
from pathlib import Path
import numpy as np
import ease6g_v2 as m
from ease6g_queue import md1_quantile

OUT = Path(__file__).resolve().parent.parent / "results" / "v2"
RHO = m.RHO_MAX; N_PER_SEED = 20_000_000; CHUNK = 5_000_000; SEEDS = (11, 23, 37, 51, 67); WARM = 100_000
PS = (1 - 1e-3, 1 - 1e-4, 1 - 1e-5)


def interarrivals(rng, n, kind, scv=4.0, rho=RHO):
    if kind == "poisson": return rng.exponential(1 / rho, n)
    p1 = 0.5 * (1 + np.sqrt((scv - 1) / (scv + 1)))                      # balanced-means H2
    lam1, lam2 = 2 * p1 * rho, 2 * (1 - p1) * rho
    pick = rng.random(n) < p1
    return np.where(pick, rng.exponential(1 / lam1, n), rng.exponential(1 / lam2, n))


def waits(seed, kind, rho=RHO):
    rng = np.random.default_rng(seed); out = []; s_last = 0.0; run_min = 0.0
    for _ in range(N_PER_SEED // CHUNK):
        S = s_last + np.cumsum(1.0 - interarrivals(rng, CHUNK, kind, rho=rho))
        mn = np.minimum(np.minimum.accumulate(S), run_min)
        out.append((S - mn).astype(np.float32)); s_last, run_min = S[-1], mn[-1]
    return np.concatenate(out)[WARM:]


res = {"rho": RHO, "samples_per_seed": N_PER_SEED, "seeds": list(SEEDS), "analytic": {str(p): md1_quantile(RHO, p) for p in PS}}
for kind in ("poisson", "bursty_h2_scv4"):
    q = np.array([[float(np.quantile(w, p)) for p in PS] for w in (waits(s, "poisson" if kind == "poisson" else "h2") for s in SEEDS)])
    res[kind] = {str(p): dict(mean=float(q[:, j].mean()), min=float(q[:, j].min()), max=float(q[:, j].max())) for j, p in enumerate(PS)}
# feasibility of the reference placements when the bursty quantile replaces the analytic one in Eq. (9)
xb = {p: res["bursty_h2_scv4"][str(p)]["mean"] for p in PS}
feas = {}
for u in m.SERV:
    pl = next(r for r in m.S["static"] if r["uc"] == u)["placement"]; t, v = m.TIER.index(pl.split("-")[0]), m.VAR.index(pl.split("-")[1])
    if t == 4: continue
    rmin = float(m.ucrow(u).Rmin); p = min(PS, key=lambda x: abs(x - rmin))
    svc = 1000 * m.F[v] / m.RATE[t]; ttx = 1000 * float(m.ucrow(u).payload_Mbit) * 1e6 / (m.RHO * float(m.ucrow(u).access_bandwidth_Gbps) * 1e9)
    l_an = m.LAT[t] + ttx + (1 + md1_quantile(RHO, rmin)) * svc; l_b = m.LAT[t] + ttx + (1 + xb[p]) * svc
    feas[u] = dict(placement=pl, Lmax_ms=float(m.ucrow(u).Lmax_ms), L_eff_analytic_ms=float(l_an), L_eff_bursty_ms=float(l_b), feasible_bursty=bool(l_b <= float(m.ucrow(u).Lmax_ms)))
res["reference_placements_under_bursty_arrivals"] = feas
# admission ceiling that restores UC2 at the far edge under bursty arrivals
u2 = m.ucrow("UC2"); svc2 = 1000 * m.F[m.VAR.index("V2")] / m.RATE[3]; ttx2 = 1000 * float(u2.payload_Mbit) * 1e6 / (m.RHO * float(u2.access_bandwidth_Gbps) * 1e9)
x_allow = (float(u2.Lmax_ms) - m.LAT[3] - ttx2) / svc2 - 1; res["UC2_bursty"] = dict(x_allowed=float(x_allow), by_rho={})
for r_ in (0.6, 0.5):
    qb = [float(np.quantile(waits(s, "h2", rho=r_), 1 - 1e-5)) for s in SEEDS]
    res["UC2_bursty"]["by_rho"][str(r_)] = dict(x_mean=float(np.mean(qb)), x_max=float(np.max(qb)), feasible=bool(np.max(qb) <= x_allow))
(OUT / "queue_validation.json").write_text(json.dumps(res, indent=1))
print(json.dumps(res, indent=1))
