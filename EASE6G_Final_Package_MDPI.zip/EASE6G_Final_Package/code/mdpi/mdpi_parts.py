#!/usr/bin/env python3
"""Styles, numbering, page header/footer parts, settings, content types and properties for the MDPI build,
taken from MDPI's official Future Internet Word template."""
import re, sys, os
from lxml import etree
OUT = sys.argv[1]
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NSDECL = ('xmlns:w="%s" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
          'xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math"' % W)
import zipfile
# Every style, the numbering, theme, fonts, page headers and footers come from MDPI's official Future Internet
# Word template (template/futureinternet-template.dot), unchanged except the year and volume in the running heads.
TPL = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'template', 'futureinternet-template.dot')
YEAR, VOL = '2026', '18'
tz = zipfile.ZipFile(TPL)
def tread(n): return tz.read(n).decode('utf8')
def wpart(n, text): 
    path = os.path.join(OUT, n); os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w', encoding='utf8').write(text); etree.parse(path)

for n in ('word/styles.xml', 'word/numbering.xml', 'word/theme/theme1.xml', 'word/fontTable.xml'):
    assert os.path.exists(os.path.join(OUT, n)), n
    wpart(n, tread(n))

# ---------------- headers / footers (template parts) ----------------
for old in ('header1.xml', 'header2.xml', 'header3.xml', 'footer1.xml', 'footer2.xml', 'footer3.xml'):
    fp = os.path.join(OUT, 'word', old)
    if os.path.exists(fp): os.remove(fp)
HF = {'header1.xml': 'header', 'header2.xml': 'header', 'header3.xml': 'header', 'footer1.xml': 'footer', 'footer2.xml': 'footer'}
for n in HF:
    x = tread('word/' + n)
    if n in ('header2.xml', 'footer2.xml'):
        assert x.count('>2025<') == 1 and x.count('> 17<') == 1, n
        x = x.replace('>2025<', '>%s<' % YEAR).replace('> 17<', '> %s<' % VOL)
    wpart('word/' + n, x)
# first-page header: journal and MDPI logos
hr = tread('word/_rels/header3.xml.rels')
for src, dst in (('media/image3.png', 'media/mdpi_tpl_journal_logo.png'), ('media/image4.png', 'media/mdpi_tpl_mdpi_logo.png')):
    assert src in hr; hr = hr.replace(src, dst)
    open(os.path.join(OUT, 'word', dst), 'wb').write(tz.read('word/' + src))
wpart('word/_rels/header3.xml.rels', hr)

rp = os.path.join(OUT, 'word/_rels/document.xml.rels')
rels = open(rp, encoding='utf8').read()
rels = re.sub(r'<Relationship [^>]*Target="(?:header|footer)\d\.xml"[^>]*/>', '', rels)
HF_IDS = [('rIdTplHdrEven', 'header', 'header1.xml'), ('rIdTplHdrDef', 'header', 'header2.xml'), ('rIdTplHdrFirst', 'header', 'header3.xml'),
          ('rIdTplFtrDef', 'footer', 'footer1.xml'), ('rIdTplFtrFirst', 'footer', 'footer2.xml')]
rels = rels.replace('</Relationships>', ''.join(
    '<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/%s" Target="%s"/>' % x
    for x in HF_IDS) + '</Relationships>')
open(rp, 'w', encoding='utf8').write(rels)

# ---------------- content types ----------------
cp = os.path.join(OUT, '[Content_Types].xml')
ct = open(cp, encoding='utf8').read()
ct = re.sub(r'<Override PartName="/word/media/image\d+\.png"[^>]*/>', '', ct)
ct = re.sub(r'<Override PartName="/word/(?:header|footer)\d\.xml"[^>]*/>', '', ct)
assert '<Default Extension="png"' in ct
H = 'application/vnd.openxmlformats-officedocument.wordprocessingml.header+xml'
Fo = 'application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml'
ct = ct.replace('</Types>', ''.join('<Override PartName="/word/%s" ContentType="%s"/>' % (n, H if k == 'header' else Fo)
                                    for n, k in HF.items()) + '</Types>')
open(cp, 'w', encoding='utf8').write(ct)

# ---------------- settings: template compatibility options, tab stop and punctuation spacing ----------------
stp = os.path.join(OUT, 'word/settings.xml')
st = open(stp, encoding='utf8').read(); ts = tread('word/settings.xml')
st = re.sub(r'<w:compat>.*?</w:compat>', re.search(r'<w:compat>.*?</w:compat>', ts, re.S).group(0), st, flags=re.S)
st = re.sub(r'<w:defaultTabStop [^>]*/>', '<w:defaultTabStop w:val="510"/>', st)
st = re.sub(r'<w:characterSpacingControl [^>]*/>', '<w:characterSpacingControl w:val="compressPunctuation"/>', st)
if '<w:autoHyphenation' not in st:
    st = re.sub(r'(<w:defaultTabStop [^>]*/>)', r'\1<w:autoHyphenation/>', st)
open(stp, 'w', encoding='utf8').write(st); etree.parse(stp)

# ---------------- core properties ----------------
cpp = os.path.join(OUT, 'docProps/core.xml')
c = open(cpp, encoding='utf8').read()
c = c.replace('<dc:title></dc:title>', '<dc:title>When Does Carbon-Aware AI Inference Placement Pay? A Closed-Form Regime Analysis across the Edge–Cloud Continuum and Design Rules for 6G Compute Placement</dc:title>')
c = c.replace('<cp:keywords></cp:keywords>', '<cp:keywords>AI inference placement; carbon-aware computing; edge–cloud continuum; 6G</cp:keywords>')
open(cpp, 'w', encoding='utf8').write(c)
print('post ok')
