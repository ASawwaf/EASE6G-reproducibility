#!/usr/bin/env python3
"""Convert the IEEE-layout manuscript written by build_manuscript.py into the MDPI
(Future Internet) submission file.

    python3 convert_to_mdpi.py <ieee_manuscript.docx> <figures_dir> <output_mdpi.docx>

What it does (and nothing else):
  1. merges adjacent identically formatted runs so cross-references can be found;
  2. mdpi_layout.py: MDPI page layout and styles, MDPI front matter, numbered
     headings (1., 1.1.), Arabic table numbers and captions, "Figure n",
     "Equation (n)", MDPI citation format [1,2] / [3-9], MDPI back matter,
     MDPI reference list (mdpi_refs.py), the 200-word abstract (mdpi_abstract.txt)
     and the abbreviation definitions at first use;
  3. mdpi_parts.py: styles, numbering, header/footer, settings and content types from MDPI's official template;
  3b. mdpi_template.py: front matter, equations, tables, references and back matter in the template's form;
  4. mdpi_edition.py (run inside step 2): MDPI edition structure - appendices A-E for supporting evidence, the regime
     map (Figure 6), the design-rules table (Table 12), the new title, and citations re-ordered by first appearance;
  5. replaces the eight figures with the 600-dpi RGB files from <figures_dir> (fig1_tiers.png, ..., fig7_crossover.png).
Equations (OMML) are carried over unchanged (asserted); the edition moves some inline symbols to the appendices,
so inline math is compared as a set and display equations in order.
"""
import io, os, re, shutil, subprocess, sys, tempfile, zipfile
from lxml import etree
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
A_ = 'http://schemas.openxmlformats.org/drawingml/2006/main'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
REMOVED_INLINE = 2   # the two inline symbols of the former Section 7.2 prose, F(v)delta(v) and D, replaced by the design-rules table
FIGS = ['fig1_tiers.png', 'fig2_pipeline.png', 'fig3_static_carbon.png', 'fig4_weight_frontier.png',
        'fig5_mappings.png', 'fig_regime_map.png', 'fig6_envelope.png', 'fig7_crossover.png']   # document order of the MDPI edition


def safe_extract(docx, dest):
    with zipfile.ZipFile(docx) as z:
        for n in z.namelist():
            if n.startswith('/') or '..' in n.split('/'):
                raise SystemExit('unsafe path in docx: ' + n)
        z.extractall(dest)


def merge_runs(doc_xml):
    """Merge adjacent <w:r> siblings that carry identical <w:rPr> and only <w:t> text."""
    t = etree.parse(doc_xml)
    for pe in list(t.iter('{%s}proofErr' % W)):
        pe.getparent().remove(pe)
    n = 0
    for parent in {r.getparent() for r in t.iter('{%s}r' % W)}:
        kids = list(parent)
        i = 0
        while i < len(kids) - 1:
            a, b = kids[i], kids[i + 1]
            if all(etree.QName(x).localname == 'r' and etree.QName(x).namespace == W for x in (a, b)):
                def parts(r):
                    rpr = r.find('{%s}rPr' % W)
                    rest = [c for c in r if c is not rpr]
                    return rpr, rest
                ra, xa = parts(a); rb, xb = parts(b)
                same = (etree.tostring(ra) if ra is not None else b'') == (etree.tostring(rb) if rb is not None else b'')
                only_t = all(etree.QName(c).localname == 't' for c in xa + xb) and xa and xb
                if same and only_t:
                    ta = xa[-1]
                    ta.text = (ta.text or '') + ''.join(c.text or '' for c in xb)
                    ta.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
                    for extra in xa[:-1]:
                        ta.text = (extra.text or '') + ta.text; a.remove(extra)
                    parent.remove(b); kids.pop(i + 1); n += 1
                    continue
            i += 1
    t.write(doc_xml, xml_declaration=True, encoding='UTF-8', standalone=True)
    return n


def math_signature(doc_xml):
    root = etree.parse(doc_xml).getroot()
    sig = []
    for m in root.iter('{%s}oMath' % M):
        m = etree.fromstring(etree.tostring(m))
        for rpr in list(m.iter('{%s}rPr' % W)):
            for ch in list(rpr):
                if etree.QName(ch).localname in ('sz', 'szCs', 'rFonts'): rpr.remove(ch)
            if len(rpr) == 0: rpr.getparent().remove(rpr)
        for c in m.iter('{%s}ctrlPr' % M):
            for ch in list(c): c.remove(ch)
        sig.append(etree.tostring(m, method='c14n'))
    disp = [s_ for s_, m in zip(sig, root.iter('{%s}oMath' % M)) if etree.QName(m.getparent()).localname == 'oMathPara']
    return sig, disp


def replace_figures(out_dir, fig_dir):
    doc = etree.parse(os.path.join(out_dir, 'word/document.xml')).getroot()
    rels = etree.parse(os.path.join(out_dir, 'word/_rels/document.xml.rels')).getroot()
    target = {r.get('Id'): r.get('Target') for r in rels}
    blips = [b.get('{%s}embed' % R) for b in doc.iter('{%s}blip' % A_)]
    assert len(blips) == len(FIGS), blips
    for rid, name in zip(blips, FIGS):
        im = Image.open(os.path.join(fig_dir, name))
        if im.mode in ('RGBA', 'LA', 'P'):
            im = im.convert('RGBA'); bg = Image.new('RGB', im.size, (255, 255, 255)); bg.paste(im, mask=im.split()[3]); im = bg
        im.convert('RGB').save(os.path.join(out_dir, 'word', target[rid]), format='PNG', dpi=(600, 600), optimize=True)


def main(ieee_docx, fig_dir, out_docx):
    tmp = tempfile.mkdtemp(prefix='mdpi_')
    try:
        src, out = os.path.join(tmp, 'src'), os.path.join(tmp, 'out')
        safe_extract(ieee_docx, src)
        merge_runs(os.path.join(src, 'word/document.xml'))
        before = math_signature(os.path.join(src, 'word/document.xml'))
        subprocess.run([sys.executable, os.path.join(HERE, 'mdpi_layout.py'), src, out, fig_dir], check=True)
        subprocess.run([sys.executable, os.path.join(HERE, 'mdpi_parts.py'), out], check=True)
        subprocess.run([sys.executable, os.path.join(HERE, 'mdpi_template.py'), out], check=True)
        replace_figures(out, fig_dir)
        after = math_signature(os.path.join(out, 'word/document.xml'))
        from collections import Counter
        added = Counter(after[0]) - Counter(before[0]); removed = Counter(before[0]) - Counter(after[0])
        assert not added and before[1] == after[1], 'equations changed during conversion'
        assert sum(removed.values()) == REMOVED_INLINE, ('unexpected inline math removed', sum(removed.values()))
        os.makedirs(os.path.dirname(os.path.abspath(out_docx)), exist_ok=True)
        with zipfile.ZipFile(out_docx, 'w', zipfile.ZIP_DEFLATED) as z:
            z.write(os.path.join(out, '[Content_Types].xml'), '[Content_Types].xml')
            for base, _, files in sorted(os.walk(out)):
                for f in sorted(files):
                    p = os.path.join(base, f); rel = os.path.relpath(p, out)
                    if rel != '[Content_Types].xml': z.write(p, rel)
        print('MDPI manuscript written:', out_docx, '| equations unchanged:', len(after[0]), '| display equations in order:', len(after[1]))
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == '__main__':
    if len(sys.argv) != 4:
        raise SystemExit(__doc__)
    main(*sys.argv[1:])
