#!/usr/bin/env python3
"""Brings the body of the MDPI build in line with MDPI's official Future Internet Word template
(template/futureinternet-template.dot). Runs after mdpi_parts.py, which installs the template's styles,
numbering, headers and footers.

  - Style names as in the template (MDPI_6.2_back_matter, MDPI_8.1_references, ...).
  - Front matter as in the template: the left-column box (Academic Editor, history, Citation, Copyright) as the
    template's floating table after the author line, "Abstract" as its own line, and the rule after the keywords.
  - Display equations in the template's two-cell table: equation centred, number right (MDPI_3.9 / MDPI_3.a).
  - Tables with the template's three-line borders (1-mm side margins kept for left-aligned text columns);
    narrow tables sit in the text column, as in the template; wide tables span the page.
  - References numbered automatically with the template's list (MDPI_8.1_references), titles not hyperlinked.
  - Back matter in the template's order; the two "Not applicable" statements, which the template does not
    list, are omitted; an Abbreviations section and the Publisher's Note are added.
  - Page setup (margins, header and footer distances, line numbering) as in the template.
Every change is asserted; the text of the paper is otherwise unchanged.
Usage: python3 mdpi_template.py <unpacked_docx_dir>"""
import copy, os, re, sys, zipfile
from lxml import etree

OUT = sys.argv[1]
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
q = lambda t: '{%s}%s' % (W, t)
TPL = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'template', 'futureinternet-template.dot')
YEAR = '2026'
COL, TEXT_W = 2608, 10466
NS = 'xmlns:w="%s" xmlns:r="%s" xmlns:m="%s"' % (W, R, M)

dp = os.path.join(OUT, 'word/document.xml')
tree = etree.parse(dp); root = tree.getroot(); body = root.find(q('body'))
tdoc = etree.fromstring(zipfile.ZipFile(TPL).read('word/document.xml'))
tbody = tdoc.find(q('body'))

def text(el): return ''.join(t.text or '' for t in el.iter(q('t')))
def pstyle(p):
    s = p.find('%s/%s' % (q('pPr'), q('pStyle'))); return s.get(q('val')) if s is not None else ''
def set_style(p, sid):
    ppr = p.find(q('pPr'))
    if ppr is None: ppr = etree.SubElement(p, q('pPr')); p.remove(ppr); p.insert(0, ppr)
    s = ppr.find(q('pStyle'))
    if s is None: s = etree.Element(q('pStyle')); ppr.insert(0, s)
    s.set(q('val'), sid)
def X(xml): return etree.fromstring('<w:root %s>%s</w:root>' % (NS, xml))[0]
def strip_rsid(el):
    for e in el.iter():
        for a in list(e.attrib):
            if 'rsid' in a or a.startswith('{http://schemas.microsoft.com/office/word/2010/wordml}'): del e.attrib[a]
    return el
PPR_ORDER = ['pStyle', 'keepNext', 'keepLines', 'pageBreakBefore', 'framePr', 'widowControl', 'numPr', 'suppressLineNumbers',
             'pBdr', 'shd', 'tabs', 'suppressAutoHyphens', 'kinsoku', 'wordWrap', 'overflowPunct', 'topLinePunct', 'autoSpaceDE',
             'autoSpaceDN', 'bidi', 'adjustRightInd', 'snapToGrid', 'spacing', 'ind', 'contextualSpacing', 'mirrorIndents',
             'suppressOverlap', 'jc', 'textDirection', 'textAlignment', 'textboxTightWrap', 'outlineLvl', 'divId', 'cnfStyle',
             'rPr', 'sectPr', 'pPrChange']
def order_ppr(ppr):
    kids = sorted(list(ppr), key=lambda c: PPR_ORDER.index(etree.QName(c).localname))
    for c in kids: ppr.remove(c)
    for c in kids: ppr.append(c)

els = list(body)
changes = {}
def done(key, n=1): changes[key] = changes.get(key, 0) + n

# ---------------- 1. style names of the template ----------------
RENAME = {'MDPI62BackMatter': 'MDPI62backmatter', 'MDPI81References': 'MDPI81references', 'MDPI71Referencesheading': 'MDPI21heading1'}
styles_xml = open(os.path.join(OUT, 'word/styles.xml'), encoding='utf8').read()
for p in root.iter(q('p')):
    s = pstyle(p)
    if s in RENAME: set_style(p, RENAME[s]); done('style renamed')
used = {pstyle(p) for p in root.iter(q('p'))} - {'', 'MDPI61Sidebar'}
missing = [s for s in used if 'w:styleId="%s"' % s not in styles_xml]
assert not missing, missing

# ---------------- 2. front matter ----------------
def first(style):
    hit = [e for e in body if etree.QName(e).localname == 'p' and pstyle(e) == style]
    assert hit, style; return hit[0]
authors = first('MDPI13authornames')
side = [e for e in body if etree.QName(e).localname == 'p' and pstyle(e) == 'MDPI61Sidebar']
assert [text(e).split(':')[0] for e in side] == ['Citation', 'Academic Editor', 'Received', 'Revised', 'Accepted', 'Published', 'Copyright'], [text(e) for e in side]
for e in side: body.remove(e)
ttbl = [e for e in tbody if etree.QName(e).localname == 'tbl'][0]
assert ttbl.find('%s/%s' % (q('tblPr'), q('tblpPr'))) is not None and 'Academic Editor' in text(ttbl)
box = strip_rsid(copy.deepcopy(ttbl))
cr = [t for t in box.iter(q('t')) if '2025 by the authors' in (t.text or '')]
assert len(cr) == 1; cr[0].text = cr[0].text.replace('2025', YEAR)
authors.addnext(box); done('left-column box from template')

# affiliations: correspondence marker as in the template (bold asterisk, then a tab)
corr = [e for e in body if etree.QName(e).localname == 'p' and pstyle(e) == 'MDPI16affiliation' and 'Correspondence:' in text(e)]
assert len(corr) == 1
r0 = corr[0].find(q('r')); assert text(r0) == '*'
r0rpr = r0.find(q('rPr'))
if r0rpr is not None: r0.remove(r0rpr)
r0.insert(0, X('<w:rPr><w:b/></w:rPr>'))

# abstract: "Abstract" on its own line, then the abstract text
ab = first('MDPI17abstract')
runs = ab.findall(q('r'))
assert text(runs[0]) == 'Abstract:' and text(runs[1]).startswith(' '), [text(r) for r in runs[:2]]
ab.remove(runs[0])
if text(runs[1]) == ' ': ab.remove(runs[1])
else: runs[1].find(q('t')).text = runs[1].find(q('t')).text[1:]
ppr = ab.find(q('pPr')); ppr.append(X('<w:spacing w:before="0" w:after="0"/>')); order_ppr(ppr)
tabs_head = [e for e in tbody if etree.QName(e).localname == 'p' and pstyle(e) == 'MDPI17abstract' and text(e) == 'Abstract']
assert len(tabs_head) == 1
ab.addprevious(strip_rsid(copy.deepcopy(tabs_head[0]))); done('abstract heading line')
kw = first('MDPI18keywords')
kr = kw.findall(q('r')); assert text(kr[0]) == 'Keywords:' and text(kr[1]).startswith(' '), [text(r) for r in kr[:2]]
kr[0].find(q('t')).text = 'Keywords: '
if text(kr[1]) == ' ': kw.remove(kr[1])
else: kr[1].find(q('t')).text = kr[1].find(q('t')).text[1:]
kw.addnext(X('<w:p><w:pPr><w:pStyle w:val="MDPI19line"/></w:pPr></w:p>')); done('rule after keywords')

# ---------------- 3. contributions list: template list and text-before-list style ----------------
items = [p for p in body.iter(q('p')) if pstyle(p) == 'MDPI37itemize']
assert len(items) == 4
for p in items:
    ppr = p.find(q('pPr'))
    for tag in ('numPr', 'ind'):
        e = ppr.find(q(tag)); assert e is not None; ppr.remove(e)
before = items[0].getprevious(); assert pstyle(before) == 'MDPI31text'
set_style(before, 'MDPI35textbeforelist'); done('list uses template numbering', 4)

# ---------------- 4. display equations in the template's two-cell table ----------------
teq = [e for e in tbody if etree.QName(e).localname == 'tbl' and 'MDPI3aequationnumber' in etree.tostring(e).decode()][0]
eq_tblpr = strip_rsid(copy.deepcopy(teq.find(q('tblPr')))); eq_grid = copy.deepcopy(teq.find(q('tblGrid')))
w_eq, w_no = [int(g.get(q('w'))) for g in eq_grid]
neq = nnum = 0
for p in [e for e in body if etree.QName(e).localname == 'p' and pstyle(e) == 'MDPI39equation']:
    maths = p.findall('{%s}oMathPara' % M)
    assert len(maths) == 1, text(p)
    m = re.fullmatch(r'\s*\((\d+)\)\s*', text(p)); assert m or not text(p).strip(), repr(text(p))   # a few are unnumbered
    tbl = etree.Element(q('tbl')); tbl.append(copy.deepcopy(eq_tblpr)); tbl.append(copy.deepcopy(eq_grid))
    tr = etree.SubElement(tbl, q('tr'))
    tc1 = etree.SubElement(tr, q('tc')); tc1.append(X('<w:tcPr><w:tcW w:w="%d" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>' % w_eq))
    pe = X('<w:p><w:pPr><w:pStyle w:val="MDPI39equation"/></w:pPr></w:p>'); pe.append(maths[0]); tc1.append(pe)
    tc2 = etree.SubElement(tr, q('tc')); tc2.append(X('<w:tcPr><w:tcW w:w="%d" w:type="dxa"/><w:vAlign w:val="center"/></w:tcPr>' % w_no))
    tc2.append(X('<w:p><w:pPr><w:pStyle w:val="MDPI3aequationnumber"/></w:pPr>%s</w:p>'
                 % ('<w:r><w:t>(%s)</w:t></w:r>' % m.group(1) if m else '')))
    p.addprevious(tbl); body.remove(p); neq += 1
    if m: nnum += 1; assert int(m.group(1)) == nnum, (m.group(1), nnum)
assert neq == 26 and nnum == 24, (neq, nnum); done('equations in template table', neq)

# ---------------- 5. tables: template borders and margins; narrow tables in the text column ----------------
TEXT_COL = {'Table 8.', 'Table 9.', 'Table 11.', 'Table 13.'}
eq_tbls = set()
ntab = 0
for tbl in [e for e in body if etree.QName(e).localname == 'tbl']:
    if tbl.find('%s/%s' % (q('tblPr'), q('tblpPr'))) is not None: continue           # left-column box
    if 'MDPI3aequationnumber' in etree.tostring(tbl).decode(): continue               # equation
    cap = tbl.getprevious(); assert pstyle(cap) == 'MDPI41tablecaption', text(cap)
    label = text(cap).split(' ')[0] + ' ' + text(cap).split(' ')[1]
    tp = tbl.find(q('tblPr'))
    for tag in ('tblW', 'jc', 'tblInd', 'tblBorders', 'tblCellMar', 'tblLook', 'tblLayout'):
        e = tp.find(q(tag))
        if e is not None: tp.remove(e)
    narrow = label in TEXT_COL
    width = TEXT_W - COL if narrow else TEXT_W
    for x in ('<w:tblW w:w="%d" w:type="dxa"/>' % (width - 1 if narrow else width),
              '<w:tblInd w:w="%d" w:type="dxa"/>' % (COL if narrow else 0),
              '<w:tblBorders><w:top w:val="single" w:sz="8" w:space="0" w:color="auto"/>'
              '<w:bottom w:val="single" w:sz="8" w:space="0" w:color="auto"/></w:tblBorders>',
              '<w:tblLayout w:type="fixed"/>',
              # the template's tables have zero side margins; 1 mm is kept here because several tables have
              # left-aligned text columns that would otherwise run into each other
              '<w:tblCellMar><w:left w:w="57" w:type="dxa"/><w:right w:w="57" w:type="dxa"/></w:tblCellMar>',
              '<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="1" w:lastColumn="0" w:noHBand="0" w:noVBand="1"/>'):
        tp.append(X(x))
    TBLPR_ORDER = ['tblStyle', 'tblpPr', 'tblOverlap', 'bidiVisual', 'tblStyleRowBandSize', 'tblStyleColBandSize', 'tblW', 'jc',
                   'tblCellSpacing', 'tblInd', 'tblBorders', 'shd', 'tblLayout', 'tblCellMar', 'tblLook']
    kids = sorted(list(tp), key=lambda c: TBLPR_ORDER.index(etree.QName(c).localname))
    for c in kids: tp.remove(c)
    for c in kids: tp.append(c)
    grid = tbl.find(q('tblGrid')); old = [int(g.get(q('w'))) for g in grid]
    total = sum(old); target = width - 1 if narrow else width
    new = [int(round(w * target / total)) for w in old]; new[-1] += target - sum(new)
    for g, w in zip(grid, new): g.set(q('w'), str(w))
    for tr in tbl.findall(q('tr')):
        ci = 0
        for tc in tr.findall(q('tc')):
            tcpr = tc.find(q('tcPr')); span = tcpr.find(q('gridSpan')) if tcpr is not None else None
            k = int(span.get(q('val'))) if span is not None else 1
            tcw = tcpr.find(q('tcW')) if tcpr is not None else None
            if tcw is not None: tcw.set(q('w'), str(sum(new[ci:ci + k]))); tcw.set(q('type'), 'dxa')
            for b in tc.iter(q('top'), q('bottom')):
                if b.getparent().tag == q('tcBorders') and b.get(q('color')) == '000000': b.set(q('color'), 'auto')
            ci += k
            # table text stays at its current size (9 pt, or 8 pt in the widest tables) rather than the style's 10 pt
            for p in tc.iter(q('p')):
                for r in p.iter(q('r')):
                    rpr = r.find(q('rPr'))
                    if rpr is None: rpr = etree.Element(q('rPr')); r.insert(0, rpr)
                    if rpr.find(q('sz')) is None:
                        rpr.append(X('<w:sz w:val="18"/>')); rpr.append(X('<w:szCs w:val="18"/>'))
                        RPR_ORDER = ['rStyle', 'rFonts', 'b', 'bCs', 'i', 'iCs', 'caps', 'smallCaps', 'strike', 'dstrike', 'outline',
                                     'shadow', 'emboss', 'imprint', 'noProof', 'snapToGrid', 'vanish', 'webHidden', 'color', 'spacing',
                                     'w', 'kern', 'position', 'sz', 'szCs', 'highlight', 'u', 'effect', 'bdr', 'shd', 'fitText',
                                     'vertAlign', 'rtl', 'cs', 'em', 'lang', 'eastAsianLayout', 'specVanish', 'oMath']
                        kids = sorted(list(rpr), key=lambda c: RPR_ORDER.index(etree.QName(c).localname))
                        for c in kids: rpr.remove(c)
                        for c in kids: rpr.append(c)
    ntab += 1
assert ntab == 19, ntab; done('tables to template format', ntab)

# ---------------- 6. back matter in the template's order ----------------
bm = [e for e in body if etree.QName(e).localname == 'p' and pstyle(e) == 'MDPI62backmatter']
labels = [text(e).split(':')[0] for e in bm]
assert labels == ['Supplementary Materials', 'Author Contributions', 'Funding', 'Institutional Review Board Statement',
                  'Informed Consent Statement', 'Data Availability Statement', 'Acknowledgments', 'Conflicts of Interest'], labels
for e in bm[3:5]:
    assert text(e).endswith(': Not applicable.'), text(e)
    body.remove(e); done('omitted not-applicable statement')
sp = bm[0].find('%s/%s' % (q('pPr'), q('spacing'))); sp.attrib.clear(); sp.set(q('before'), '240')

# Abbreviations section, as in the template (heading, sentence, borderless two-column table)
ABBR = [('3GPP', '3rd Generation Partnership Project'), ('5G', 'Fifth generation'), ('6G', 'Sixth generation'),
        ('AI', 'Artificial intelligence'), ('AI-RAN', 'Artificial intelligence–radio access network'), ('CI', 'Carbon intensity'),
        ('DNN', 'Deep neural network'), ('EASE-6G', 'Energy-Aware Sustainable Edge for 6G'), ('EE', 'Energy efficiency'),
        ('FP32', '32-bit floating point'), ('GPU', 'Graphics processing unit'),
        ('IMT-2030', 'International Mobile Telecommunications-2030'), ('KPI', 'Key performance indicator'),
        ('MEC', 'Multi-access edge computing'), ('MILP', 'Mixed-integer linear program'), ('ML', 'Machine learning'),
        ('NESO', 'National Energy System Operator'), ('PTQ', 'Post-training quantization'), ('PUE', 'Power usage effectiveness'),
        ('RAN', 'Radio access network'), ('SLO', 'Service-level objective'), ('SMO', 'Service Management and Orchestration')]
full = ' '.join(text(p) for p in body.iter(q('p')))
for ab_, _ in ABBR:
    assert re.search(r'\(%s\)|%s denotes' % (re.escape(ab_), re.escape(ab_)), full) or ab_ == 'GPU', ab_   # every entry is defined in the text
assert '(GPUs)' in full
tab_tbl = [e for e in tbody if etree.QName(e).localname == 'tbl' and 'Multidisciplinary Digital Publishing Institute' in text(e)][0]
tab_tbl = strip_rsid(copy.deepcopy(tab_tbl))
row_tpl = tab_tbl.findall(q('tr'))[0]
for tr in tab_tbl.findall(q('tr')): tab_tbl.remove(tr)
for ab_, full_ in ABBR:
    tr = copy.deepcopy(row_tpl); ts = [t for t in tr.iter(q('t'))]; assert len(ts) == 2
    ts[0].text, ts[1].text = ab_, full_; tab_tbl.append(tr)
head = [e for e in tbody if etree.QName(e).localname == 'p' and pstyle(e) == 'MDPI21heading1' and text(e) == 'Abbreviations'][0]
intro = [e for e in tbody if etree.QName(e).localname == 'p' and text(e).startswith('The following abbreviations')][0]
head = strip_rsid(copy.deepcopy(head))
for b in head.findall(q('bookmarkStart')): head.remove(b)
coi = [e for e in body if etree.QName(e).localname == 'p' and text(e).startswith('Conflicts of Interest:')][0]
coi.addnext(tab_tbl); coi.addnext(strip_rsid(copy.deepcopy(intro))); coi.addnext(head)
done('abbreviations section', len(ABBR))

# ---------------- 7. references: template numbering, no hyperlinked titles; Publisher's Note ----------------
refs = [p for p in body.iter(q('p')) if pstyle(p) == 'MDPI81references']
assert len(refs) == 66
for k, p in enumerate(refs, 1):
    rs = p.findall(q('r'))
    assert text(rs[0]) == '%d.' % k and text(rs[1]) == '\t', (k, text(rs[0]), text(rs[1]))
    p.remove(rs[0]); p.remove(rs[1])
    ppr = p.find(q('pPr'))
    ppr.append(X('<w:numPr><w:ilvl w:val="0"/><w:numId w:val="23"/></w:numPr>')); ppr.append(X('<w:ind w:left="425" w:hanging="425"/>'))
    order_ppr(ppr)
    for h in p.findall(q('hyperlink')):
        if not text(h).startswith('http'):
            for r in h.findall(q('r')):
                rs_ = r.find('%s/%s' % (q('rPr'), q('rStyle')))
                if rs_ is not None: rs_.getparent().remove(rs_)
                h.addprevious(r)
            p.remove(h); done('reference title unlinked')
rh = [p for p in body.iter(q('p')) if pstyle(p) == 'MDPI21heading1' and text(p) == 'References']
assert len(rh) == 1
rppr = rh[0].find(q('pPr')); rppr.append(X('<w:ind w:left="0"/>')); order_ppr(rppr)
note = [e for e in tbody if etree.QName(e).localname == 'p' and pstyle(e) == 'MDPI63notes'][0]
refs[-1].addnext(strip_rsid(copy.deepcopy(note))); done('publisher note')

# ---------------- 8. page setup as in the template ----------------
sect = body.find(q('sectPr')); tsect = tbody.find(q('sectPr'))
new = etree.Element(q('sectPr'))
for t_, rid in (('even', 'rIdTplHdrEven'), ('default', 'rIdTplHdrDef')):
    new.append(X('<w:headerReference w:type="%s" r:id="%s"/>' % (t_, rid)))
new.append(X('<w:footerReference w:type="default" r:id="rIdTplFtrDef"/>'))
new.append(X('<w:headerReference w:type="first" r:id="rIdTplHdrFirst"/>'))
new.append(X('<w:footerReference w:type="first" r:id="rIdTplFtrFirst"/>'))
for tag in ('type', 'pgSz', 'pgMar', 'lnNumType', 'pgNumType', 'cols', 'titlePg', 'docGrid'):
    e = tsect.find(q(tag)); assert e is not None, tag
    new.append(strip_rsid(copy.deepcopy(e)))
body.replace(sect, new); done('page setup from template')

tree.write(dp, xml_declaration=True, encoding='UTF-8', standalone=True)
print('template ok | ' + ' | '.join('%s: %d' % kv for kv in changes.items()))
