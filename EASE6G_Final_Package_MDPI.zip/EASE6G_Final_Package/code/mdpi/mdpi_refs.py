# MDPI-style reference list for EASE-6G (converted from the IEEE-style list; numbering unchanged).
# Markup: *italic*  **bold**  {{title, hyperlinked to the URL the original title linked to}}
#         ~sub~ (subscript)  [[placeholder, highlighted]]  bare URLs become hyperlinks.
ACC = 'accessed on 19 November 2026'

REFS = [
 # 1
 "ITU-R M.2160-0. *{{Framework and overall objectives of the future development of IMT for 2030 and beyond}}*; International Telecommunication Union: Geneva, Switzerland, 2023.",
 # 2
 "Saad, W.; Bennis, M.; Chen, M. {{A vision of 6G wireless systems: Applications, trends, technologies, and open research problems}}. *IEEE Netw.* **2020**, *34*, 134–142. https://doi.org/10.1109/mnet.001.1900287.",
 # 3
 "3GPP TS 22.261 V18.19.0. *{{Service requirements for the 5G system}}*; Release 18; 3rd Generation Partnership Project, February 2026.",
 # 4
 "3GPP TS 28.554 V18.9.0. *{{Management and orchestration; 5G end-to-end key performance indicators}}*; Release 18; 3rd Generation Partnership Project, February 2026.",
 # 5
 "ETSI GS MEC 003 V4.1.1. *{{Multi-access Edge Computing (MEC); Framework and Reference Architecture}}*; European Telecommunications Standards Institute, May 2025.",
 # 6
 "Xu, D.; et al. {{Edge intelligence: Empowering intelligence to the edge of network}}. *Proc. IEEE* **2021**, *109*, 1778–1837. https://doi.org/10.1109/jproc.2021.3119950.",
 # 7
 "Shi, Y.; et al. {{Communication-efficient edge AI: Algorithms and systems}}. *IEEE Commun. Surv. Tutor.* **2020**, *22*, 2167–2191. https://doi.org/10.1109/comst.2020.3007787.",
 # 8
 "Calvanese Strinati, E.; et al. {{6G: The next frontier: From holographic messaging to artificial intelligence using subterahertz and visible light communication}}. *IEEE Veh. Technol. Mag.* **2019**, *14*, 42–50. https://doi.org/10.1109/mvt.2019.2921162.",
 # 9
 "Nguyen, D.C.; et al. {{6G Internet of Things: A comprehensive survey}}. *IEEE Internet Things J.* **2022**, *9*, 359–383. https://doi.org/10.1109/jiot.2021.3103320.",
 # 10
 "Patterson, D.; et al. {{Carbon emissions and large neural network training}}. *arXiv* **2021**, arXiv:2104.10350.",
 # 11
 "Strubell, E.; Ganesh, A.; McCallum, A. {{Energy and policy considerations for deep learning in NLP}}. In Proceedings of the 57th Annual Meeting of the Association for Computational Linguistics, 2019; pp. 3645–3650. https://doi.org/10.18653/v1/P19-1355.",
 # 12
 "Schwartz, R.; Dodge, J.; Smith, N.A.; Etzioni, O. {{Green AI}}. *Commun. ACM* **2020**, *63*, 54–63. https://doi.org/10.1145/3381831.",
 # 13
 "The Green Grid. *{{Green Grid data center power efficiency metrics: PUE and DCiE}}*; White Paper 6; The Green Grid, 2008.",
 # 14
 "Masanet, E.; et al. {{Recalibrating global data center energy-use estimates}}. *Science* **2020**, *367*, 984–986. https://doi.org/10.1126/science.aba3758.",
 # 15
 "Dodge, J.; et al. {{Measuring the carbon intensity of AI in cloud instances}}. In Proceedings of the ACM Conference on Fairness, Accountability, and Transparency (FAccT), 2022; pp. 1877–1894. https://doi.org/10.1145/3531146.3533234.",
 # 16
 "Lannelongue, L.; Grealey, J.; Inouye, M. {{Green algorithms: Quantifying the carbon footprint of computation}}. *Adv. Sci.* **2021**, *8*, 2100707. https://doi.org/10.1002/advs.202100707.",
 # 17
 "The Green Grid. *{{PUE: A comprehensive examination of the metric}}*; White Paper 49; The Green Grid, 2012.",
 # 18
 "Jacob, B.; et al. {{Quantization and training of neural networks for efficient integer-arithmetic-only inference}}. In Proceedings of the IEEE/CVF Conference on Computer Vision and Pattern Recognition (CVPR), 2018. https://doi.org/10.1109/cvpr.2018.00286.",
 # 19
 "Zhu, M.; Gupta, S. {{To prune, or not to prune: Exploring the efficacy of pruning for model compression}}. In Proceedings of the International Conference on Learning Representations (ICLR) Workshop, 2018.",
 # 20
 "Touvron, H.; Cord, M.; Douze, M.; Massa, F.; Sablayrolles, A.; Jégou, H. {{Training data-efficient image transformers & distillation through attention}}. In Proceedings of the 38th International Conference on Machine Learning, 2021; PMLR Volume 139, pp. 10347–10357.",
 # 21
 "Rao, Y.; Zhao, W.; Liu, B.; Lu, J.; Zhou, J.; Hsieh, C.-J. DynamicViT: Efficient vision transformers with dynamic token sparsification. In *Advances in Neural Information Processing Systems*; 2021; Volume 34, pp. 13937–13949.",
 # 22
 "Liu, Z.; Wang, Y.; Han, K.; Zhang, W.; Ma, S.; Gao, W. {{Post-training quantization for vision transformer}}. In *Advances in Neural Information Processing Systems*; 2021; Volume 34, pp. 28092–28103.",
 # 23
 "Sukprasert, T.; Souza, A.; Bashir, N.; Irwin, D.; Shenoy, P. On the limitations of carbon-aware temporal and spatial workload shifting in the cloud. In Proceedings of the 19th European Conference on Computer Systems (EuroSys), Athens, Greece, April 2024. https://doi.org/10.1145/3627703.3650079.",
 # 24
 "Hanafy, W.A.; Bostandoost, R.; Bashir, N.; Irwin, D.; Hajiesmaili, M.; Shenoy, P. The war of the efficiencies: Understanding the tension between carbon and energy optimization. In Proceedings of the 2nd Workshop on Sustainable Computer Systems (HotCarbon), Boston, MA, USA, July 2023. https://doi.org/10.1145/3604930.3605709.",
 # 25
 "Kumar, K.; Lu, Y.-H. Cloud computing for mobile users: Can offloading computation save energy? *Computer* **2010**, *43*, 51–56. https://doi.org/10.1109/MC.2010.98.",
 # 26
 "Baliga, J.; Ayre, R.W.A.; Hinton, K.; Tucker, R.S. Green cloud computing: Balancing energy in processing, storage, and transport. *Proc. IEEE* **2011**, *99*, 149–167. https://doi.org/10.1109/JPROC.2010.2060451.",
 # 27
 "Jalali, F.; Hinton, K.; Ayre, R.; Alpcan, T.; Tucker, R.S. Fog computing may help to save energy in cloud computing. *IEEE J. Sel. Areas Commun.* **2016**, *34*, 1728–1739. https://doi.org/10.1109/JSAC.2016.2545559.",
 # 28
 "Williams, S.; Waterman, A.; Patterson, D. Roofline: An insightful visual performance model for multicore architectures. *Commun. ACM* **2009**, *52*, 65–76. https://doi.org/10.1145/1498765.1498785.",
 # 29
 "Hawkes, A.D. Estimating marginal CO~2~ emissions rates for national electricity systems. *Energy Policy* **2010**, *38*, 5977–5987. https://doi.org/10.1016/j.enpol.2010.05.053.",
 # 30
 "Sukprasert, T.; Bashir, N.; Souza, A.; Irwin, D.; Shenoy, P. On the implications of choosing average versus marginal carbon intensity signals on carbon-aware optimizations. In Proceedings of the 15th ACM International Conference on Future and Sustainable Energy Systems (e-Energy), Singapore, June 2024; pp. 422–427. https://doi.org/10.1145/3632775.3661953.",
 # 31
 "Gorka, J.; Rhodes, N.; Roald, L. ElectricityEmissions.jl: A framework for the comparison of carbon intensity signals. In Proceedings of the 16th ACM International Conference on Future and Sustainable Energy Systems (e-Energy), June 2025; pp. 19–30.",
 # 32
 "Mach, P.; Becvar, Z. {{Mobile edge computing: A survey on architecture and computation offloading}}. *IEEE Commun. Surv. Tutor.* **2017**, *19*, 1628–1656. https://doi.org/10.1109/comst.2017.2682318.",
 # 33
 "Asheralieva, A.; Niyato, D. {{Hierarchical game-theoretic and reinforcement learning framework for computational offloading in UAV-enabled mobile edge computing networks with multiple service providers}}. *IEEE Internet Things J.* **2019**, *6*, 8753–8769. https://doi.org/10.1109/JIOT.2019.2923702.",
 # 34
 "Chen, X.; et al. {{Optimized computation offloading performance in virtual edge computing systems via deep reinforcement learning}}. *IEEE Internet Things J.* **2019**, *6*, 4005–4018. https://doi.org/10.1109/jiot.2018.2876279.",
 # 35
 "Son, Y.; Gupta, U.; McCrabb, A.; Kim, Y.G.; Bertacco, V.; Brooks, D.; Wu, C.-J. GreenScale: Carbon optimization for edge computing. *IEEE Internet Things J.* **2025**, *12*, 32379–32393. https://doi.org/10.1109/JIOT.2025.3555153.",
 # 36
 "Ke, H.; Jin, W.; Wang, H. CarbonCP: Carbon-aware DNN partitioning with conformal prediction for sustainable edge intelligence. *arXiv* **2024**, arXiv:2404.16970.",
 # 37
 "Nabavinejad, S.M.; Jia, W.; Taneja, S.; Guo, T. {{CARBONDIS: Carbon-aware DNN inference scheduling on heterogeneous GPUs}}. In Proceedings of the 25th IEEE/ACM International Symposium on Cluster, Cloud and Internet Computing (CCGrid), 2025; pp. 315–324. https://doi.org/10.1109/CCGRID64434.2025.00032.",
 # 38
 "Li, Y.; Hu, Z.; Choukse, E.; Fonseca, R.; Suh, G.E.; Gupta, U. EcoServe: Designing carbon-aware AI inference systems. *arXiv* **2025**, arXiv:2502.05043.",
 # 39
 "Zhang, G.; Guo, W.; Tan, Z.; Sun, C.; Jiang, H. CarbonEdge: Carbon-aware deep learning inference framework for sustainable edge computing. In Proceedings of the 2026 International Wireless Communications and Mobile Computing Conference (IWCMC), Wuzhou, China, 2026; pp. 445–450. https://doi.org/10.1109/IWCMC69287.2026.11580067.",
 # 40
 "Li, B.; Samsi, S.; Gadepally, V.; Tiwari, D. Clover: Toward sustainable AI with carbon-aware machine learning inference service. In Proceedings of the International Conference for High Performance Computing, Networking, Storage and Analysis (SC), Denver, CO, USA, 2023; Article 20. https://doi.org/10.1145/3581784.3607034.",
 # 41
 "Wu, L.; Hanafy, W.A.; Souza, A.; Nguyen, K.; Harkes, J.; Irwin, D.; Satyanarayanan, M.; Shenoy, P. CarbonEdge: Leveraging mesoscale spatial carbon-intensity variations for low carbon edge computing. In Proceedings of the 34th ACM International Symposium on High-Performance Parallel and Distributed Computing (HPDC), 2025; pp. 1–13. https://doi.org/10.1145/3731545.3731576.",
 # 42 (added)
 "Zhu, S.; Hurley, N.; Tabatabaee Malazi, H. Does energy-efficiency mean carbon-awareness? A critical evaluation of sustainable serverless edge scheduling. In Proceedings of the 18th IEEE/ACM International Conference on Utility and Cloud Computing (UCC), Nantes, France, December 2025; pp. 1–6. https://doi.org/10.1145/3773274.3774929.",
 # 43 (added)
 "Kribaa, W.; Välisuo, P.; Elmusrati, M. Carbon-aware resource scheduling for geo-distributed cloud–edge systems under SLA and capacity constraints. *Future Gener. Comput. Syst.* **2027**, *188*, 108898. https://doi.org/10.1016/j.future.2026.108898.",
 # 44
 "Rajashekar, K.; Sharghivand, N.; Prodan, R.; Farahani, R. Toward sustainability-aware LLM inference on edge clusters. In Proceedings of the 1st International Workshop on Intelligent and Scalable Systems across the Computing Continuum (ScaleSys); *IoT Workshop Proceedings*, 2025; Volume 1, pp. 57–60. https://doi.org/10.34749/3061-1008.2025.9.",
 # 45
 "Marler, R.T.; Arora, J.S. {{Survey of multi-objective optimization methods for engineering}}. *Struct. Multidiscip. Optim.* **2004**, *26*, 369–395. https://doi.org/10.1007/s00158-003-0368-6.",
 # 46
 "Marler, R.T.; Arora, J.S. {{The weighted sum method for multi-objective optimization: new insights}}. *Struct. Multidiscip. Optim.* **2010**, *41*, 853–862. https://doi.org/10.1007/s00158-009-0460-7.",
 # 47
 "Sze, V.; Chen, Y.-H.; Yang, T.-J.; Emer, J.S. {{Efficient processing of deep neural networks: A tutorial and survey}}. *Proc. IEEE* **2017**, *105*, 2295–2329. https://doi.org/10.1109/jproc.2017.2761740.",
 # 48
 "Howard, A.G.; et al. MobileNets: Efficient convolutional neural networks for mobile vision applications. *arXiv* **2017**, arXiv:1704.04861.",
 # 49
 "Vaswani, A.; et al. {{Attention is all you need}}. In *Advances in Neural Information Processing Systems*; 2017; Volume 30, pp. 5998–6008.",
 # 50
 "Reddi, V.J.; et al. MLPerf inference benchmark. In Proceedings of the ACM/IEEE 47th Annual International Symposium on Computer Architecture, 2020; pp. 446–459. https://doi.org/10.1109/ISCA45697.2020.00045.",
 # 51
 "Tschand, A.; et al. MLPerf Power: Benchmarking the energy efficiency of machine learning systems from μWatts to MWatts for sustainable AI. In Proceedings of the 31st IEEE International Symposium on High-Performance Computer Architecture (HPCA), 2025; pp. 1201–1216. https://doi.org/10.1109/HPCA61900.2025.00092.",
 # 52
 "Kopras, B.; Idzikowski, F.; Bossy, B.; Kryszkiewicz, P.; Bogucka, H. {{Communication and computing task allocation for energy-efficient fog networks}}. *Sensors* **2023**, *23*, 997. https://doi.org/10.3390/s23020997.",
 # 53
 "Gross, D.; Shortle, J.F.; Thompson, J.M.; Harris, C.M. *Fundamentals of Queueing Theory*, 4th ed.; Wiley: Hoboken, NJ, USA, 2008.",
 # 54
 "Dolan, S.L.; Heath, G.A. Life cycle greenhouse gas emissions of utility-scale wind power: Systematic review and harmonization. *J. Ind. Ecol.* **2012**, *16*, S136–S154. https://doi.org/10.1111/j.1530-9290.2012.00464.x.",
 # 55
 "MLCommons. MLPerf Inference results, closed division, ResNet-50 Offline with power measurement: Gigabyte R282-Z93 5x QAIC100 (Datacenter v1.0, Offline and Server), Foxconn Gloria Highend (Edge v2.1), NVIDIA Jetson AGX Orin MaxQ (Edge v3.0 and v3.1), and NVIDIA Orin NX MaxQ (Edge v3.1, Offline and SingleStream), 2021–2023. Available online: https://github.com/mlcommons/inference_results_v3.1 and the corresponding v1.0, v2.1, and v3.0 repositories (" + ACC + ").",
 # 56
 "NVIDIA. Jetson benchmarks: MLPerf Inference results. Available online: https://developer.nvidia.com/embedded/jetson-benchmarks (" + ACC + ").",
 # 57
 "Wu, P.-S.; Lin, Y.-C.; Yang, C.-H. {{A 99.2 TOPS/W Transformer learning processor with approximated attention score gradient computation and ternary vector-based speculation}}. In Proceedings of the 2024 IEEE Symposium on VLSI Technology and Circuits, Honolulu, HI, USA, 2024; pp. 1–2. https://doi.org/10.1109/VLSITechnologyandCir46783.2024.10631391.",
 # 58
 "Rey, L.; Bernardos, A.M.; Dobrzycki, A.D.; Carramiñana, D.; Bergesio, L.; Besada, J.A.; Casar, J.R. {{A performance analysis of You Only Look Once models for deployment on constrained computational edge devices in drone applications}}. *Electronics* **2025**, *14*, 638. https://doi.org/10.3390/electronics14030638.",
 # 59
 "3GPP TR 32.972 V18.0.0. *{{Study on system and functional aspects of energy efficiency in 5G networks}}*; Release 18; 3rd Generation Partnership Project, May 2024.",
 # 60
 "National Energy System Operator. {{Regional Carbon Intensity Forecast}}. NESO Data Portal, Dataset. Available online: https://www.neso.energy/data-portal/regional-carbon-intensity-forecast (accessed on 16 July 2026).",
 # 61
 "Bruce, A.R.W.; Ruff, L.; Kelloway, J.; MacMillan, F.; Rogers, A. *{{Carbon Intensity Regional Forecast Methodology}}*; National Energy System Operator, May 2024. Available online: https://api.neso.energy/dataset/bf3d723b-b4ae-4ec7-9fc9-e584c651a9da/resource/1d817f4c-a126-45c8-baf0-218bf57d37be/download/neso-ci-regional-methodology_v2.pdf (" + ACC + ").",
 # 62
 "UK Department for Energy Security and Net Zero. *Clean Power 2030 Action Plan: A new era of clean electricity*; December 2024. Available online: https://www.gov.uk/government/publications/clean-power-2030-action-plan (" + ACC + ").",
 # 63
 "Matsubara, Y.; Levorato, M.; Restuccia, F. Split computing and early exiting for deep learning applications: Survey and research challenges. *ACM Comput. Surv.* **2022**, *55*, 90. https://doi.org/10.1145/3527155.",
 # 64
 "Kang, Y.; Hauswald, J.; Gao, C.; Rovinski, A.; Mudge, T.; Mars, J.; Tang, L. Neurosurgeon: Collaborative intelligence between the cloud and mobile edge. In Proceedings of the 22nd International Conference on Architectural Support for Programming Languages and Operating Systems (ASPLOS), Xi’an, China, April 2017; pp. 615–629. https://doi.org/10.1145/3037697.3037698.",
 # 65
 "3GPP TR 22.874 V18.2.0. *5G System (5GS); Study on traffic characteristics and performance requirements for AI/ML model transfer*; Release 18; 3rd Generation Partnership Project, December 2021.",
 # 66
 "Gupta, U.; Kim, Y.G.; Lee, S.; Tse, J.; Lee, H.-H.S.; Wei, G.-Y.; Brooks, D.; Wu, C.-J. Chasing carbon: The elusive environmental footprint of computing. In Proceedings of the IEEE International Symposium on High-Performance Computer Architecture (HPCA), 2021; pp. 854–867. https://doi.org/10.1109/HPCA51647.2021.00076.",
]
assert len(REFS) == 66
