# MDPI edition structure, run inside mdpi_layout.py (exec in its namespace) after the body has been converted.
#  1. Moves supporting evidence to appendices, ordered by first mention: the sensitivity and robustness checks of
#     Section 6.9 with the benchmark-scenario detail of Section 5.1 and the check design of Section 5.3 (Appendix A),
#     the capacity-and-outage simulation (Appendix B), the trace-driven intensity envelope and the published-efficiency
#     crossovers (Appendix C), the table of all 24 tier-to-grid mappings (Appendix D), and the 2030 grid
#     scenarios and split inference of Section 7 (Appendix E). Each move leaves a short summary in the main text.
#  2. Adds the regime map (new Figure 6) to Section 6.8.
#  3. Rewrites Section 7.2 as a table of design rules for a 6G compute-placement function and merges the former
#     Section 7.6 (inputs a placement function needs) into it.
#  4. Renumbers tables, figures, sections and citations, and re-orders the reference list by first citation.
# Every number in the text written here must already occur in the generated manuscript text (asserted below), so
# the edition adds no number that the pipeline did not produce.
from PIL import Image

NEW_TITLE = ('When Does Carbon-Aware AI Inference Placement Pay? A Closed-Form Regime Analysis across the '
             'Edge–Cloud Continuum and Design Rules for 6G Compute Placement')
SOURCE_TEXT = ' '.join(x.text or '' for el in els for x in el.iter(q('w:t'), q('m:t')))   # generated manuscript text (IEEE build)
NEW_TEXTS = []

def P(t_, style='MDPI31text'):
    NEW_TEXTS.append(t_)
    return para(style, rich(t_))

def rich(t_):
    """Plain text with **run-in head** spans, set in italics like the run-in heads of the converted text."""
    out = []
    for k, part in enumerate(re.split(r'\*\*(.+?)\*\*', t_)):
        if part: out.append(run(part, i=(k % 2 == 1)))
    return out

def htext(el):
    return wtext(el).strip() if etree.QName(el).localname == 'p' else ''

def find_heading(prefix):
    hits_ = [k for k, el in enumerate(new_body) if pstyle(el) in ('MDPI21heading1', 'MDPI22heading2') and htext(el).startswith(prefix)]
    assert len(hits_) == 1, (prefix, hits_)
    return hits_[0]

def set_heading(el, new_text):
    ts = list(el.iter(q('w:t'))); ts[0].text = new_text
    for t_ in ts[1:]: t_.text = ''

# ---------- 1. renumber references to tables, figures and sections in the existing text (single pass) ----------
TAB_MAP = {11: 'D1', 12: 'C1', 13: 'C2', 14: 'A1', 15: 'A2', 16: '11', 17: 'E1', 18: '13'}   # new Table 12 (design rules) inserted below
FIG_MAP = {6: 'C1', 7: 'C2'}                                       # new Figure 6 (regime map) is inserted below
SEC_MAP = {'7.3': ('Appendix', 'E.1'), '7.4': ('Section', '7.3'), '7.5': ('Appendix', 'E.2'), '7.6': ('Section', '7.2')}

def _remap_list(kind, nums, seps):
    mp = TAB_MAP if kind.startswith('Table') else FIG_MAP
    new = [mp.get(int(n), n) for n in nums]
    if any(not x.isdigit() for x in new) and len(new) > 1:          # mixed main/appendix list: name each one
        singular = 'Table' if kind.startswith('Table') else 'Figure'
        return ''.join((singular + ' ' + x) + (s or '') for x, s in zip(new, seps + ['']))
    return kind + ' ' + ''.join(x + (s or '') for x, s in zip(new, seps + ['']))

def remap_refs(s):
    def tf(mo):
        kind = mo.group(1); body_ = mo.group(2)
        nums = re.findall(r'\d+', body_); seps = re.findall(r'(?:–|, and |, | and )', body_)
        return _remap_list(kind, nums, seps)
    s = re.sub(r'\b(Tables?|Figures?) (\d+(?:(?:–|, and |, | and )\d+)*)\b', tf, s)
    def sf(mo):
        items = re.findall(r'\d+(?:\.\d+)?', mo.group(2)); seps = re.findall(r'(?:–|, and |, | and )', mo.group(2))
        mapped = [SEC_MAP.get(x, ('Section', x)) for x in items]
        if all(k_ == 'Section' for k_, _ in mapped):
            return ('Sections ' if len(items) > 1 else 'Section ') + ''.join(v + (s_ or '') for (_, v), s_ in zip(mapped, seps + ['']))
        return ''.join((k_ + ' ' + v) + (s_ or '') for (k_, v), s_ in zip(mapped, seps + ['']))
    s = re.sub(r'\b(Sections?) (\d+(?:\.\d+)?(?:(?:–|, and |, | and )\d+(?:\.\d+)?)*)(?![\d.]*\d)', sf, s)
    return s

# Cross-references whose target moved to Appendix A (from Section 6.9, or from Section 5.1 for the efficiency bound);
# each must fire exactly once.
# References to the efficiency band, the 35 variants, scaling and the uniform-intensity case stay with Section 6.9.
TO_APPB = [
    ('Section 6.9 removes the floor', 'Appendix A removes the floor'),
    ('arbitrary arrival processes (Section 6.9)', 'arbitrary arrival processes (Appendix A)'),
    ('Section 6.9 tests the last two', 'Appendix A tests the last two'),
    ('barely affects the decisions (Section 6.9)', 'barely affects the decisions (Appendix A)'),
    ('Section 6.9 reruns the headline', 'Appendix A reruns the headline'),
    ('saving falls below 1% (Section 6.9)', 'saving falls below 1% (Appendix A)'),
    ('Sections 6.8 and 6.9 report the other', 'Section 6.8 and Appendix A report the other'),
    ('Section 6.9 varies', 'Appendix A varies'),
    ('analytical unless stated otherwise (Section 6.9)', 'analytical unless stated otherwise (Appendix A)'),
    ('Section 6.9 applies a matching', 'Appendix A applies a matching'),
    ('Section 6.9 states which', 'Appendix A states which'),
    ('admitted at T4 (Section 6.9)', 'admitted at T4 (Appendix A)'),
    ('then to about 2% (Section 6.9)', 'then to about 2% (Appendix A)'),
    ('changes no decision (Section 6.9)', 'changes no decision (Appendix A)'),
    ('median saving of 9.8% (Section 6.9)', 'median saving of 9.8% (Appendix A)'),
    ('have no feasible tier (Section 6.9)', 'have no feasible tier (Appendix A)'),
    ('placements unchanged (Section 6.9)', 'placements unchanged (Appendix A)'),
    ('Section 6.9 scales the access', 'Appendix A scales the access'),
    ('when all tiers lose efficiency together (Section 5.1)', 'when all tiers lose efficiency together (Appendix A)'),
]
# The hourly evaluation of Equation (24) moved from Section 6.8 to Appendix C (Section 6.8 keeps a summary).
TO_APPB += [
    ('so does the set; Section 6.8 evaluates Equation (24) hour by hour', 'so does the set; Appendix C evaluates Equation (24) hour by hour'),
    ('UC4 stays there in 129 hours (Section 6.8)', 'UC4 stays there in 129 hours (Appendix C)'),
]
_appb_hits = {a: 0 for a, _ in TO_APPB}
for el in new_body:
    for t_ in el.iter(q('w:t')):
        if t_.text:
            for a, b in TO_APPB:
                if a in t_.text:
                    _appb_hits[a] += t_.text.count(a); t_.text = t_.text.replace(a, b)
            t_.text = remap_refs(t_.text)
assert all(v == 1 for v in _appb_hits.values()), {k: v for k, v in _appb_hits.items() if v != 1}
data_body = remap_refs(data_body).replace('in Sections 6 and 7 is generated', 'in Sections 6 and 7 and Appendices A–E is generated')
assert 'Appendices A–E' in data_body

# ---------- 2. locate the blocks ----------
i65, i66 = find_heading('6.5. '), find_heading('6.6. ')
i68, i69, i610 = find_heading('6.8. '), find_heading('6.9. '), find_heading('6.10. ')
i72, i73, i74, i75, i76 = (find_heading('7.%d. ' % k) for k in (2, 3, 4, 5, 6))
i8 = find_heading('8. ')
i67 = find_heading('6.7. ')
sec65 = new_body[i65 + 1:i66]; sec69 = new_body[i69 + 1:i610]
sec72 = new_body[i72 + 1:i73]; sec73 = new_body[i73 + 1:i74]; sec74 = new_body[i74 + 1:i75]
sec75 = new_body[i75 + 1:i76]; sec76 = new_body[i76 + 1:i8]
assert len(sec65) == 2 and htext(sec65[0]).startswith('The far edge is unavailable') and htext(sec65[1]).startswith('Capacity against load.')
assert htext(sec69[0]).startswith('Conditions for the headline saving.') and htext(sec69[1]).startswith('Benchmark basis.')
assert len(sec72) == 1 and htext(sec72[0]).startswith('Four rules follow') and len(sec76) == 1 and len(sec75) == 1
sec67 = new_body[i67 + 1:i68]; sec68 = new_body[i68 + 1:i69]
def _kind(el):
    if etree.QName(el).localname == 'tbl': return 'tbl'
    if has_img(el): return 'img'
    return pstyle(el) + ':' + htext(el)[:12]
assert [_kind(e)[:24] for e in sec67] == ['MDPI41tablecaption:Table', 'tbl', 'img', 'MDPI51figurecaption:Figu',
                                         'MDPI31text:Table D1 gro'], [_kind(e) for e in sec67]
assert htext(sec67[0]).startswith('Table D1. All 24') and htext(sec67[3]).startswith('Figure 5.')
assert [_kind(e)[:24] for e in sec68] == ['MDPI41tablecaption:Table', 'tbl', 'img', 'MDPI51figurecaption:Figu',
        'MDPI31text:With one ser', 'MDPI31text:Under mean c', 'MDPI31text:Hourly, the ', 'MDPI31text:Table C1 and',
        'MDPI31text:Of the 1,246', 'MDPI41tablecaption:Table', 'tbl', 'img', 'MDPI51figurecaption:Figu', 'MDPI31text:Table C2 rep'], \
    [_kind(e)[:24] for e in sec68]
tab_map = sec67[0:2]; keep67 = sec67[2:]
tab_env1, fig_env1 = sec68[0:2], sec68[2:4]; keep68a = sec68[4:6]; move68 = sec68[6:9]
tab_env2, fig_env2 = sec68[9:11], sec68[11:13]; keep68b = sec68[13:]
assert htext(tab_env1[0]).startswith('Table C1.') and htext(fig_env1[1]).startswith('Figure C1.')
assert htext(tab_env2[0]).startswith('Table C2.') and htext(fig_env2[1]).startswith('Figure C2.')

def _one(prefix):
    hits_ = [el for el in new_body if htext(el).startswith(prefix)]
    assert len(hits_) == 1, (prefix, len(hits_)); return hits_[0]
p_eff = _one('Efficiency inputs and their anchoring.')
p_cos = _one('Capacity-and-outage simulation. A 192-hour run')
p_sen = _one('Sensitivity and scaling. The headline saving')

def _locate(p_, marker):
    kids = [c for c in p_ if etree.QName(c).localname != 'pPr']
    for ci, c in enumerate(kids):
        ts = list(c.iter(q('w:t')))
        for t_ in ts:
            if t_.text and marker in t_.text:
                assert len(ts) == 1, ('marker run holds several w:t', marker)
                return kids, ci, t_, t_.text.index(marker)
    raise AssertionError(('marker not found', marker))

def _set(t_, txt):
    t_.text = txt; t_.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')

def split_out(p_, start, end, lead, pointer):
    """Move the text from `start` to the end of `end` (or to the paragraph end if end is None) into a new paragraph with
    italic run-in `lead`; leave `pointer` in its place in p_. Inline math inside the moved span moves with it."""
    mv = copy.deepcopy(p_)
    kids, si, ts_, so = _locate(mv, start)
    if end is None: ei, te_, eo = len(kids) - 1, None, None
    else:
        _, ei, te_, eo = _locate(mv, end); eo += len(end)
    for c in kids[:si] + kids[ei + 1:]: mv.remove(c)
    if end is not None and si == ei: _set(ts_, ts_.text[so:eo])
    else:
        _set(ts_, ts_.text[so:])
        if te_ is not None: _set(te_, te_.text[:eo])
    pPr_ = mv.find('w:pPr', ns)
    mv.insert(1 if pPr_ is not None else 0, run(lead + ' ', i=True))   # italic run-in head, as elsewhere
    kids, si, ts_, so = _locate(p_, start)
    if end is None: ei, te_, eo = len(kids) - 1, None, None
    else:
        _, ei, te_, eo = _locate(p_, end); eo += len(end)
    if end is not None and si == ei:
        _set(ts_, ts_.text[:so] + pointer + (' ' + ts_.text[eo:].lstrip() if ts_.text[eo:].strip() else ''))
    else:
        _set(ts_, ts_.text[:so] + pointer + ('' if te_ is None or not te_.text[eo:].strip() else ' '))
        if te_ is not None: _set(te_, te_.text[eo:].lstrip())
        for c in kids[si + 1:(ei if te_ is not None else ei + 1)]: p_.remove(c)
    NEW_TEXTS.extend([lead, pointer])
    return mv

EFF_PTR = ('Appendix A gives the benchmark scenarios behind these values, a latency-bound basis, and the factors by which '
           'the efficiencies may scale.')
mv_eff = split_out(p_eff, 'The reference efficiencies are Offline (throughput) power results',
                   '(500, 350, 275, and 200 GFLOP/J at T1–T4).', 'Benchmark scenarios.', EFF_PTR)
for a_, b_ in [('Appendix A reruns the headline on this basis', 'The benchmark-basis check below reruns the headline on this basis'),
               ('the saving falls below 1% (Appendix A)', 'the saving falls below 1% (see below)'),
               ('Section 6.8 and Appendix A report the other published pairings', 'Section 6.8 and the input variants below report the other published pairings')]:
    hit_ = [t_ for t_ in mv_eff.iter(q('w:t')) if t_.text and a_ in t_.text]
    assert len(hit_) == 1, a_; _set(hit_[0], hit_[0].text.replace(a_, b_)); NEW_TEXTS.append(b_)
assert wtext(p_eff).rstrip().endswith('so applying PUE in Equation (1) is consistent.') and EFF_PTR in wtext(p_eff)

SEN_PTR = 'Appendix A describes the further input variants, sweeps, and checks of the benchmark basis and model structure.'
mv_sen = split_out(p_sen, 'Five further input variants are rerun', None, 'Design of the checks.', SEN_PTR)
hit_ = [t_ for t_ in mv_sen.iter(q('w:t')) if t_.text and 'latency-bound basis of Section 5.1' in t_.text]
assert len(hit_) == 1; _set(hit_[0], hit_[0].text.replace('latency-bound basis of Section 5.1', 'latency-bound basis above'))
assert wtext(p_sen).rstrip().endswith(SEN_PTR)

COS_PTR = ('Capacity-and-outage simulation. A 168-hour simulation with far-edge outages and load noise is run for five seeds; '
           'Appendix B gives its design.')
cos_ptr = P(COS_PTR.replace('Capacity-and-outage simulation.', '**Capacity-and-outage simulation.**'))
rich_check = wtext(cos_ptr); assert rich_check == COS_PTR, rich_check

for blk in (sec65[:1], sec69[1:], sec73, sec75, tab_map, tab_env1, fig_env1, move68, tab_env2, fig_env2, [mv_eff, mv_sen, p_cos]):                  # no numbered equation moves to an appendix
    assert all(el.find('.//m:oMathPara', ns) is None for el in blk)

# ---------- 3. new main-text pieces ----------
lead65 = P('A 168-hour capacity-and-outage simulation with far-edge outages and load noise (Appendix B) confirms the static '
           'result: over the week EASE-6G emits 17.0% less carbon than E-min for 2.6% more energy and makes the same decisions '
           'as the capacity-constrained Oracle-KA in every hour.')
sum69 = P('Appendix A reports the remaining checks. On a latency-bound benchmark basis the saving is 16.9% for 1.6% more energy, '
          'and with measured server latency only UC4, the dominant service, keeps its reference placement. In a factorial of 180 '
          'combinations around the reference, UC4’s energy-optimal and carbon-optimal tiers differ in 103, with a median saving of '
          '9.8% there and at most 2.3% elsewhere. Blending in a uniform marginal emission factor shrinks the saving toward zero, and '
          'forecast errors of 10% per hour and region change the weekly savings from 14.7%, 50.2%, and 4.8% to 13.7%, 50.0%, and 3.0%. '
          'The discrete-event simulation reproduces the analytic queueing quantiles for Poisson arrivals, whereas bursty arrivals roughly '
          'triple them (Tables A1 and A2).')
# regime map: intro paragraph, figure, caption
intro68 = P('Figure 6 maps where energy-optimal and carbon-optimal placement of the regional and metro tiers disagree, Equation (24), '
            'over work per transported bit and the facility-adjusted efficiency of the two tiers. Carbon awareness can change the '
            'decision only inside the shaded set, which lies between the carbon crossover of Equation (23) and the energy crossover of '
            'Equation (21). UC4 sits inside it at the reference inputs, which is why it carries the 17.0% saving. With uncompressed '
            'inputs it moves below the carbon crossover, and outside the efficiency band derived in Section 6.9 the energy-optimal and '
            'carbon-optimal tiers coincide. The rest of this section gives the boundaries at the reference inputs and under '
            'published efficiencies; Appendix C tests them on the hourly traces.')
sum68 = P('On the hourly traces the carbon crossover moves with the grid intensities, so the disagreement set changes from hour to '
          'hour (Appendix C). Across the 33 window–intensity cells of Table C1 and Figure C1, carbon is below that of E-min in 18 and '
          'never above it, every cell with a saving has hours in the disagreement set, and the largest reduction is 56.5%, at '
          '30 GFLOP/Mbit in spring, for 1.7% more energy.')
fig_tpl = None
for k, el in enumerate(new_body):
    if pstyle(el) == 'MDPI51figurecaption' and htext(el).startswith('Figure C1.'):
        fig_tpl = new_body[k - 1]; break
assert fig_tpl is not None and has_img(fig_tpl)
fig_p = copy.deepcopy(fig_tpl)
IMG = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/image'
rid_new = new_rel(IMG, 'media/fig_regime_map.png')
A_NS = 'http://schemas.openxmlformats.org/drawingml/2006/main'
WP = 'http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing'
PIC = 'http://schemas.openxmlformats.org/drawingml/2006/picture'
fig_p.find('.//{%s}blip' % A_NS).set(q('r:embed'), rid_new)
w_px, h_px = Image.open(os.path.join(FIG_DIR, 'fig_regime_map.png')).size
cx = int(fig_p.find('.//{%s}extent' % WP).get('cx')); cy = int(round(cx * h_px / w_px))
fig_p.find('.//{%s}extent' % WP).set('cy', str(cy))
for ext in fig_p.iter('{%s}ext' % A_NS):
    if ext.get('cx') is not None: ext.set('cx', str(cx)); ext.set('cy', str(cy))
max_id = max(int(e.get('id')) for el in new_body for e in el.iter('{%s}docPr' % WP))
fig_p.find('.//{%s}docPr' % WP).set('id', str(max_id + 1)); fig_p.find('.//{%s}docPr' % WP).set('name', 'Figure regime map')
cnv = fig_p.find('.//{%s}cNvPr' % PIC)
if cnv is not None: cnv.set('id', '0'); cnv.set('name', 'fig_regime_map.png')
cap6_text = ('Regime map for the regional (T2) and metro (T3) tiers, with the access link of UC4 and the mean carbon intensity of the '
             'reference mapping. Shaded: work per transported bit and efficiency ratios at which energy-optimal and carbon-optimal '
             'placement choose different tiers, Equation (24), bounded by the energy crossover, Equation (21), and the carbon crossover, '
             'Equation (23). Moving up from the reference point the regional tier gains efficiency, moving down the metro tier does, one '
             'tier at a time; published efficiency pairs that change both tiers are evaluated in Section 6.8 and Appendix C.')
NEW_TEXTS.append(cap6_text)
cap6 = para('MDPI51figurecaption', caption_runs('Figure 6.', cap6_text))

# Section 7.2: design rules table
lead72 = P('Table 12 condenses the results into rules for a 6G compute-placement function. Each rule states the condition under which '
           'it applies, the threshold found in this study, and the input the function needs to apply it.')
RULES = [
 ('Rule', 'Condition', 'Threshold in this study', 'Input the function needs'),
 ('1. Work per transported bit sets the regime', 'Below the crossovers transport decides and the nearest feasible tier uses the least energy; above them compute decides', 'Energy crossover of 45.1 GFLOP/Mbit for the regional and metro tiers at equal server efficiency; UC4 at 24.2 GFLOP/Mbit (Figure 6)', 'Per service: work per inference and payload'),
 ('2. Upstream tiers win on energy only if they are more efficient', 'An upstream tier needs less facility energy per unit of work, PUE/EE, than the downstream tier, Equation (22)', 'Reference: regional tier ahead by 3.8%, from PUE alone', 'Per tier: EE and PUE'),
 ('3. Carbon awareness pays only inside the disagreement set', 'Near-equal facility-adjusted efficiency of the competing tiers and a regional spread in grid carbon, Equation (24)', '17.0% inside the band (cleaner tier at most 7.4% more efficient, or dirtier tier at most 19.1% more efficient); at most 2.3% outside; zero without regional spread (Table E1)', 'Per tier: grid carbon-intensity forecast; the user’s grid'),
 ('4. Compress inputs before placing', 'Raw tensors cut work per transported bit tenfold and move a service below the carbon crossover', 'UC4: 24.2 GFLOP/Mbit compressed, 2.4 uncompressed; saving 0.0%', 'Per service: payload as sent'),
 ('5. Keep headroom at the energy-optimal tier', 'Once that tier is full, capacity alone moves an energy minimizer to the carbon-preferred tier', 'Saving holds up to 63% of peak load; 2.2% at peak (Section 6.5)', 'Per tier: capacity and current load'),
 ('6. Very tight latency targets need compute at the RAN', 'At 1 ms and below, service latency and execution, not transport, use the budget', '1 ms at 1 − 10⁻⁵: 169.7 TFLOP/s at a 5G-class far edge, 32.7 TFLOP/s co-located with the RAN; 0.5 ms not reachable at the far edge (Table 13)', 'Per tier: service latency and per-request compute rate'),
 ('7. Forecast quality matters where the spread is small', 'Decisions taken on a noisy carbon signal', 'Errors of 10% per hour and region: weekly savings of 13.7%, 50.0%, and 3.0% instead of 14.7%, 50.2%, and 4.8% (Appendix A)', 'Grid carbon-intensity forecasts with their error'),
]
for row in RULES: NEW_TEXTS.extend(row)
def mk_table(rows, widths):
    tb = E('w:tbl', None, E('w:tblPr'), E('w:tblGrid', None, *[E('w:gridCol', {'w:w': w_}) for w_ in widths]))
    for ri, row in enumerate(rows):
        tr = E('w:tr', None, E('w:trPr', None, E('w:cantSplit'), *( [E('w:tblHeader')] if ri == 0 else [] )))
        for cell in row:
            tr.append(E('w:tc', None, E('w:p', None, run(cell, b=(ri == 0)))))
        tb.append(tr)
    return tb
tbl15 = mk_table(RULES, [2000, 2700, 3300, 2466])
fmt_table(tbl15)
for tr in tbl15.findall('w:tr', ns):                                # text-heavy table: left-align the body cells
    if tr.find('w:trPr/w:tblHeader', ns) is not None: continue
    for p_ in tr.iter(q('w:p')):
        jc_ = p_.find('w:pPr/w:jc', ns); jc_.set(WV, 'left')
cap15_text = 'Design rules for a 6G compute-placement function derived from this study.'
NEW_TEXTS.append(cap15_text)
cap15 = para('MDPI41tablecaption', caption_runs('Table 12.', cap15_text))
# former Section 7.6 (inputs to expose) follows the table
inputs_p = sec76[0]
for t_ in inputs_p.iter(q('w:t')):
    if t_.text:
        t_.text = t_.text.replace('Section 6.9 indicates that errors', 'Appendix A indicates that errors')
assert 'Appendix A indicates' in wtext(inputs_p) and 'Section 6.7 and Appendix E.1 show' in wtext(inputs_p), wtext(inputs_p)
scope72 = P('The rules give the sustainability capability of IMT-2030 (Table 11) a quantitative test: from measured inputs, a placement '
            'function can tell whether a carbon signal will change its decisions before it acts on one. They come from an end-to-end '
            'model without an air interface, with the IMT-2030 latency targets applied end to end (Section 7.1), so they are inputs to '
            '6G architecture work, not a specification.')
sum7c = P('Appendix E adds two forward-looking checks. Uniform decarbonization to the Clean Power 2030 target for Great Britain [62] '
          'keeps the carbon-aware saving in every mapping; compressing the regional spread shrinks it, and without spread it disappears '
          '(Table E1). Device–network split inference pays only for uncompressed inputs, where it saves 2.9% of UC5 energy and carbon, '
          'and there the policy emits 26.2% more carbon than Oracle-KA statically (Appendix E.2).')

# ---------- 4. appendices ----------
appA_lead = P('This appendix reports the checks summarized in Section 6.9; Tables A1 and A2 collect them.')
app_map_lead = P('Table D1 lists the static (weighted) and seasonal results for all 24 tier-to-grid mappings summarized in Section 6.7.')
app_env_lead = P('This appendix gives the trace-driven envelope for the regional–metro pair (Table C1 and Figure C1) and the crossovers '
              'under published efficiency values discussed in Section 6.8 (Table C2 and Figure C2).')
H1 = lambda s_: (NEW_TEXTS.append(s_), para('MDPI21heading1', [run(s_)]))[1]
H2 = lambda s_: (NEW_TEXTS.append(s_), para('MDPI22heading2', [run(s_)]))[1]
appendices = ([H1('Appendix A. Sensitivity and Robustness Checks'), appA_lead, mv_sen, mv_eff] + sec69[1:]
              + [H1('Appendix B. Capacity-and-Outage Simulation'), p_cos, sec65[0]]
              + [H1('Appendix C. Intensity Envelope on the Traces and Published Efficiencies'), app_env_lead] + tab_env1 + fig_env1
              + move68 + tab_env2 + fig_env2
              + [H1('Appendix D. Tier-to-Grid Mappings'), app_map_lead] + tab_map
              + [H1('Appendix E. Forward-Looking 6G Analyses'), H2('Appendix E.1. Grid Scenarios for 2030')] + sec73
              + [H2('Appendix E.2. Device–Network Split Inference')] + sec75)
for el in appendices:                                               # appendix paragraphs keep MDPI body styles
    if etree.QName(el).localname == 'p' and pstyle(el) == 'MDPI32textnoindent': pass

# ---------- 5. assemble the main text ----------
set_heading(new_body[i74], '7.3. Inference Co-Located with the Radio Access Network')
new_body[new_body.index(p_cos)] = cos_ptr
main = (new_body[:i65 + 1] + [lead65, sec65[1]] + new_body[i66:i67 + 1] + keep67 + [new_body[i68], intro68, fig_p, cap6]
        + keep68a + [sum68] + keep68b + [new_body[i69]]
        + [sec69[0], sum69] + new_body[i610:i72 + 1] + [lead72, cap15, tbl15, inputs_p, scope72]
        + [new_body[i74]] + sec74 + [sum7c] + new_body[i8:])
new_body = main
# the paragraph after a moved table needs its spacing; the paragraph after the new table gets it too
inputs_p.find('w:pPr', ns).insert(1, E('w:spacing', {'w:before': 240}))

# ---------- 5b. contribution 4, conclusions and back matter follow the new structure ----------
c4 = [el for el in new_body if htext(el).startswith('A 6G outlook.')]
assert len(c4) == 1, len(c4)
C4_OLD_HEAD, C4_NEW_HEAD = 'A 6G outlook.', 'Design rules for 6G compute placement.'
C4_OLD = 'The model is mapped to the IMT-2030 capabilities, and three forward-looking analyses are added: '
C4_NEW = ('The model is mapped to the IMT-2030 capabilities, the results are condensed into seven design rules for a '
          'compute-placement function (Section 7.2), and three forward-looking analyses are added (Section 7): ')
NEW_TEXTS.extend([C4_NEW_HEAD, C4_NEW])
_c4_done = 0
for t_ in c4[0].iter(q('w:t')):
    if t_.text and C4_OLD_HEAD in t_.text: t_.text = t_.text.replace(C4_OLD_HEAD, C4_NEW_HEAD); _c4_done += 1
    if t_.text and C4_OLD in t_.text: t_.text = t_.text.replace(C4_OLD, C4_NEW); _c4_done += 1
assert _c4_done == 2, _c4_done
concl_rules = P('Table 12 turns these conditions into design rules for a 6G compute-placement function and lists the inputs '
                'that function needs; Appendices A–E give the supporting robustness checks, simulation, mapping and trace results, '
                'and forward-looking analyses.')
assert htext(new_body[-1]).endswith('evaluate that dependence from measured inputs.'), htext(new_body[-1])[-80:]
new_body.append(concl_rules)
ack_mdpi = ack_mdpi.replace('experiments reported in Sections 5–7,', 'experiments reported in Sections 5–7 and Appendices A–E,')
assert 'Appendices A–E,' in ack_mdpi
for k_, el in enumerate(back):
    lab = wtext(el)
    if lab.startswith('Data Availability Statement:'): back[k_] = bm('Data Availability Statement:', [run(data_body)])
    if lab.startswith('Acknowledgments:'): back[k_] = bm('Acknowledgments:', [run(ack_mdpi)])
assert sum('Appendices A–E' in wtext(el) for el in back) == 2

# ---------- 6. citations renumbered by first appearance (main text, then appendices) ----------
CIT = re.compile(r'\[(\d+(?:[,–]\d+)*)\]')
def _expand(g):
    out = []
    for part in g.split(','):
        if '–' in part:
            a_, b_ = map(int, part.split('–')); out += list(range(a_, b_ + 1))
        else: out.append(int(part))
    return out
order = []
for el in new_body + appendices:
    for t_ in el.iter(q('w:t')):
        for mo in CIT.finditer(t_.text or ''):
            for n_ in _expand(mo.group(1)):
                if n_ not in order: order.append(n_)
assert sorted(order) == list(range(1, len(REFS) + 1)), sorted(set(range(1, len(REFS) + 1)) ^ set(order))
CMAP = {old: new for new, old in enumerate(order, 1)}
def _compress(nums):
    nums = sorted(set(nums)); out = []; k = 0
    while k < len(nums):
        j = k
        while j + 1 < len(nums) and nums[j + 1] == nums[j] + 1: j += 1
        if j - k >= 2: out.append('%d–%d' % (nums[k], nums[j]))
        else: out += [str(x) for x in nums[k:j + 1]]
        k = j + 1
    return '[' + ','.join(out) + ']'
for el in new_body + appendices:
    for t_ in el.iter(q('w:t')):
        if t_.text and CIT.search(t_.text):
            t_.text = CIT.sub(lambda mo: _compress([CMAP[n_] for n_ in _expand(mo.group(1))]), t_.text)
REFS_NEW = [None] * len(REFS)
for old, new in CMAP.items(): REFS_NEW[new - 1] = REFS[old - 1]
ref_title_url = {CMAP[o]: u for o, u in ref_title_url.items()}
REFS = REFS_NEW
refs = [para('MDPI71Referencesheading', [run('References')])]
for n, s in enumerate(REFS, 1):
    refs.append(para('MDPI81References', [run('%d.' % n), run('\t')] + ref_runs(n, s)))
back = back + appendices

# ---------- 7. title ----------
tp = para('MDPI12title', [run(NEW_TITLE)])
front[1] = tp

# ---------- 8. guard: every number written here occurs in the generated manuscript text ----------
def _nums(s):
    s = re.sub(r'\b(?:Tables?|Figures?|Sections?|Equations?|Appendix|Appendices) [A-E]?\(?\d*[\d.]*\)?', ' ', s)
    s = re.sub(r'\[\d+(?:[,–]\d+)*\]', ' ', s)
    return set(re.findall(r'\d+(?:\.\d+)?', s))
src_nums = set(re.findall(r'\d+(?:\.\d+)?', SOURCE_TEXT.replace(',', '')))
missing = sorted(n for t_ in NEW_TEXTS for n in _nums(t_.replace(',', '')) if n not in src_nums)
assert not missing, ('numbers not in the generated manuscript', missing)
print('edition ok: refs renumbered', sum(1 for o, n in CMAP.items() if o != n), '| appendix elements', len(appendices))
