#!/usr/bin/env python3
"""Convert the IEEE-formatted EASE-6G manuscript (unpacked, runs merged)
into MDPI (Future Internet) house layout. Text, equations, tables and figures are
carried over; only layout, numbering conventions, captions, citations-format,
front matter and back matter are changed."""
import re, sys, copy, os, shutil
from lxml import etree
sys.path.insert(0, os.path.dirname(__file__))
from mdpi_refs import REFS

SRC = sys.argv[1]           # unpacked merged docx dir (read)
OUT = sys.argv[2]           # output unpacked dir (written)
FIG_DIR = sys.argv[3] if len(sys.argv) > 3 else None   # figures_v2 (regime map size for the MDPI edition)
if os.path.exists(OUT): shutil.rmtree(OUT)
shutil.copytree(SRC, OUT)

W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
PR = 'http://schemas.openxmlformats.org/package/2006/relationships'
ns = {'w': W, 'm': M, 'r': R}
def q(t): p, n = t.split(':'); return '{%s}%s' % ({'w': W, 'm': M, 'r': R}[p], n)
WV = q('w:val')

# ---------------- geometry (twips) ----------------
PAGE_W, PAGE_H = 11906, 16838          # A4
ML = MR = 720                          # 1.27 cm
MT, MB, HDR, FTR = 1417, 1077, 1020, 567
TEXT_W = PAGE_W - ML - MR              # 10466
COL = 2608                             # 4.6 cm left column (MDPI)
COL_W = TEXT_W - COL                   # 7858
EQ_CENTER = COL + COL_W // 2           # 6537
FONT = 'Palatino Linotype'

doc = etree.parse(os.path.join(SRC, 'word/document.xml'))
root = doc.getroot()
body = root.find('w:body', ns)
els = list(body)

def text(e):
    return ''.join(x.text or '' for x in e.iter(q('w:t'), q('m:t')))
def wtext(e):
    return ''.join(x.text or '' for x in e.iter(q('w:t')))

def E(tag, attrs=None, *children):
    el = etree.Element(q(tag))
    for k, v in (attrs or {}).items():
        el.set(q(k) if ':' in k else k, str(v))
    for c in children: el.append(c)
    return el

def run(t, b=False, i=False, sup=False, sub=False, hl=None, size=None):
    rpr = E('w:rPr')
    if b: rpr.append(E('w:b')); rpr.append(E('w:bCs'))
    if i: rpr.append(E('w:i')); rpr.append(E('w:iCs'))
    if size: rpr.append(E('w:sz', {'w:val': size})); rpr.append(E('w:szCs', {'w:val': size}))
    if hl: rpr.append(E('w:highlight', {'w:val': hl}))
    if sup: rpr.append(E('w:vertAlign', {'w:val': 'superscript'}))
    if sub: rpr.append(E('w:vertAlign', {'w:val': 'subscript'}))
    r = E('w:r')
    if len(rpr): r.append(rpr)
    tt = E('w:t'); tt.text = t
    tt.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
    r.append(tt)
    return r

def para(style, runs=(), extra_ppr=()):
    p = E('w:p')
    ppr = E('w:pPr', None, E('w:pStyle', {'w:val': style}))
    for x in extra_ppr: ppr.append(x)
    p.append(ppr)
    for r in runs: p.append(r)
    return p

# ---------------- hyperlink relationships ----------------
rels_path = os.path.join(OUT, 'word/_rels/document.xml.rels')
rels = etree.parse(rels_path); rroot = rels.getroot()
rid_target = {r.get('Id'): r.get('Target') for r in rroot}
_rid_n = [500]
def new_rel(rtype, target, external=False):
    _rid_n[0] += 1
    rid = 'rIdM%d' % _rid_n[0]
    el = etree.SubElement(rroot, '{%s}Relationship' % PR)
    el.set('Id', rid); el.set('Type', rtype); el.set('Target', target)
    if external: el.set('TargetMode', 'External')
    return rid
HL = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink'
def hyperlink(runs, url):
    h = E('w:hyperlink'); h.set(q('r:id'), new_rel(HL, url, True))
    for r in runs:
        rpr = r.find('w:rPr', ns)
        if rpr is None: rpr = E('w:rPr'); r.insert(0, rpr)
        rpr.insert(0, E('w:rStyle', {'w:val': 'Hyperlink'}))
        h.append(r)
    return h

# ---------------- cross-reference & citation conversion ----------------
ROMAN = {'I':1,'II':2,'III':3,'IV':4,'V':5,'VI':6,'VII':7,'VIII':8,'IX':9,'X':10,
         'XI':11,'XII':12,'XIII':13,'XIV':14,'XV':15,'XVI':16,'XVII':17,'XVIII':18}
LET = {c: i + 1 for i, c in enumerate('ABCDEFGHIJ')}
RN = r'(?:XVIII|XVII|XVI|XIV|XV|XIII|XII|XI|X|IX|VIII|VII|VI|IV|V|III|II|I)'
SEC1 = RN + r'(?:-[A-J])?'

def sec_conv(s):
    def one(tok):
        if '-' in tok:
            a, b = tok.split('-'); return '%d.%d' % (ROMAN[a], LET[b])
        return str(ROMAN[tok])
    return re.sub(SEC1, lambda m: one(m.group(0)), s)

def convert_text(s):
    # citations: "[1], [2]" -> "[1,2]"; "[3]–[9]" -> "[3–9]"; mixed lists
    def cit(m):
        g = m.group(0)
        return '[' + re.sub(r'\]\s*,\s*\[', ',', re.sub(r'\]–\[', '–', g))[1:]
    s = re.sub(r'\[\d+\](?:(?:,\s|–)\[\d+\])+', cit, s)
    # Tables
    s = re.sub(r'\bTables (' + RN + r')((?:(?:–|, | and |, and | to )' + RN + r')+)\b',
               lambda m: 'Tables ' + re.sub(RN, lambda k: str(ROMAN[k.group(0)]), m.group(1) + m.group(2)), s)
    s = re.sub(r'\bTable (' + RN + r')\b', lambda m: 'Table %d' % ROMAN[m.group(1)], s)
    # Sections
    s = re.sub(r'\bSections (' + SEC1 + r')((?:(?:–|, | and |, and | to )' + SEC1 + r')+)(?![\w-])',
               lambda m: 'Sections ' + sec_conv(m.group(1) + m.group(2)), s)
    s = re.sub(r'\bSection (' + SEC1 + r')(?![\w-])', lambda m: 'Section ' + sec_conv(m.group(1)), s)
    # Figures
    s = re.sub(r'\bFigs\. (\d+)', r'Figures \1', s)
    s = re.sub(r'\bFig\. (\d+)\(([a-z])\)', r'Figure \1\2', s)
    s = re.sub(r'\bFig\. (\d+)', r'Figure \1', s)
    # Equations
    s = re.sub(r'\bEqs\. \(', 'Equations (', s)
    s = re.sub(r'\bEq\. \(', 'Equation (', s)
    return s

def convert_wt_in(el):
    for t in el.iter(q('w:t')):
        if t.text: t.text = convert_text(t.text)

# ---------------- run / paragraph cleaning ----------------
STRIP_RPR = {'rFonts', 'sz', 'szCs', 'color', 'lang'}
def clean_runs(el):
    for rpr in el.iter(q('w:rPr')):
        par = rpr.getparent()
        if etree.QName(par).localname == 'pPr':      # paragraph-mark props
            par.remove(rpr); continue
        for ch in list(rpr):
            if etree.QName(ch).localname in STRIP_RPR:
                rpr.remove(ch)
        if len(rpr) == 0: par.remove(rpr)

def set_ppr(p, style, keep_num=False, ind=None, jc=None, keep_next=False):
    old = p.find('w:pPr', ns)
    num = old.find('w:numPr', ns) if old is not None else None
    ppr = E('w:pPr', None, E('w:pStyle', {'w:val': style}))
    if keep_next: ppr.append(E('w:keepNext'))
    if keep_num and num is not None: ppr.append(copy.deepcopy(num))
    if ind: ppr.append(E('w:ind', ind))
    if jc: ppr.append(E('w:jc', {'w:val': jc}))
    if old is not None: p.replace(old, ppr)
    else: p.insert(0, ppr)

def is_eq(p): return p.find('.//m:oMathPara', ns) is not None
def has_img(p): return p.find('.//w:drawing', ns) is not None
def pstyle(p):
    s = p.find('w:pPr/w:pStyle', ns)
    return s.get(WV) if s is not None else None

# ---------------- locate structural landmarks ----------------
idx = {}
for i, el in enumerate(els):
    if etree.QName(el).localname != 'p': continue
    t = wtext(el)
    if pstyle(el) == 'Title': idx['title'] = i
    if t.startswith('Abstract—'): idx['abstract'] = i
    if t.startswith('Index Terms—'): idx['keywords'] = i
    if t.startswith('Code and Data Availability—'): idx['dataavail'] = i
    if pstyle(el) == 'Heading1' and t.strip() == 'ACKNOWLEDGMENT': idx['ack'] = i
    if pstyle(el) == 'Heading1' and t.strip() == 'REFERENCES': idx['refs'] = i
    if pstyle(el) == 'Heading1' and t.strip() == 'AUTHOR BIOGRAPHIES': idx['bios'] = i
for k in ('title', 'abstract', 'keywords', 'dataavail', 'ack', 'refs', 'bios'):
    assert k in idx, k
ack_text = wtext(els[idx['ack'] + 1])
data_text = wtext(els[idx['dataavail']])
assert ack_text.startswith('Generative AI was used')

# map reference number -> URL of the hyperlink on its title (to preserve it)
ref_title_url = {}
for i in range(idx['refs'] + 1, idx['bios']):
    el = els[i]
    m = re.match(r'\[(\d+)\]', wtext(el))
    if not m: continue
    h = el.find('.//w:hyperlink', ns)
    if h is not None:
        ref_title_url[int(m.group(1))] = rid_target[h.get(q('r:id'))]
assert len([i for i in range(idx['refs'] + 1, idx['bios']) if re.match(r'\[\d+\]', wtext(els[i]))]) == 66

# ---------------- captions ----------------
TABLE_CAPS = {
 1: 'Direct related-work comparison.',
 2: 'Crossover analyses in prior work and in this paper.',
 3: 'Five-tier reference configuration.',
 4: 'Literature-grounded model-variant reference profiles.',
 5: 'Analytical service-profile requirements.',
 6: 'Static EASE-6G placements and per-inference metrics.',
 7: 'Primary operational comparison, static, weighted by request volume.',
 8: 'Operational and diagnostic oracle gaps.',
 9: 'Component ablation.',
 10: '2026 seasonal results, reference mapping, served services (per week).',
 11: 'All 24 tier-to-grid mappings, grouped by the user’s grid: static (weighted) and seasonal results.',
 12: 'T2/T3 envelope under UC4 conditions: carbon reduction vs the energy minimizer E-min (hours with a different tier / hours in the disagreement set; energy change).',
 13: 'T2/T3 crossovers under published efficiency values.',
 14: 'Conditions for the headline saving: static, volume-weighted carbon saving against E-min.',
 15: 'Robustness of the saving against E-min to the carbon signal, request volumes, shared capacity, and the V3 throughput factor (reference mapping unless stated).',
 16: 'IMT-2030 capabilities and their treatment in this study.',
 17: '2030 grid scenarios: carbon-aware saving against the energy minimizer E-min.',
 18: 'Per-request compute rate needed to meet end-to-end tail-latency targets with the distilled variant (4.6 GFLOP).',
}
def caption_runs(label, rest):
    runs = [run(label, b=True), run(' ')]
    # bold panel letters: (a) -> (**a**)
    pos = 0
    for m in re.finditer(r'\(([a-z])\)', rest):
        if m.start() > pos: runs.append(run(rest[pos:m.start()]))
        runs += [run('('), run(m.group(1), b=True), run(')')]
        pos = m.end()
    if pos < len(rest): runs.append(run(rest[pos:]))
    return runs

# ---------------- tables ----------------
TABLE_FONT = {}
def fmt_table(tbl, ncols_hint=None):
    tblpr = tbl.find('w:tblPr', ns)
    grid = [int(g.get(q('w:w'))) for g in tbl.findall('w:tblGrid/w:gridCol', ns)]
    tot = sum(grid)
    rows0 = tbl.findall('w:tr', ns)
    # minimum column width = longest unbreakable word (header words may hyphenate badly otherwise)
    longest = [0] * len(grid)
    for tr in rows0:
        for ci, tc in enumerate(tr.findall('w:tc', ns)):
            for w in re.split(r'\s+', text(tc)):
                longest[ci] = max(longest[ci], len(w))
    def layout(cw):
        mins = [min(int(L * cw) + 130, TEXT_W // 2) for L in longest]
        new = [g * TEXT_W / tot for g in grid]
        for _ in range(20):
            short = [i for i in range(len(new)) if new[i] < mins[i]]
            if not short: break
            for i in short: new[i] = mins[i]
            free = [i for i in range(len(new)) if new[i] > mins[i]]
            excess = sum(new) - TEXT_W
            fsum = sum(new[i] - mins[i] for i in free)
            if fsum <= 0: break
            for i in free: new[i] -= excess * (new[i] - mins[i]) / fsum
        ok = all(new[i] >= mins[i] - 1 for i in range(len(new))) and abs(sum(new) - TEXT_W) < 2
        if not ok:
            if sum(mins) >= TEXT_W:
                new = [m * TEXT_W / sum(mins) for m in mins]
            else:
                new = [max(x, 300) for x in new]; k = TEXT_W / sum(new); new = [x * k for x in new]
        return [int(round(x)) for x in new], ok
    font = 18
    new, ok = layout(132)          # ~9 pt Palatino average glyph width in twips
    if not ok:
        font = 16
        new, ok = layout(118)
    new[-1] += TEXT_W - sum(new)
    TABLE_FONT[id(tbl)] = font
    for g, w in zip(tbl.findall('w:tblGrid/w:gridCol', ns), new): g.set(q('w:w'), str(w))
    look = tblpr.find('w:tblLook', ns)
    npr = E('w:tblPr', None,
            E('w:tblW', {'w:w': TEXT_W, 'w:type': 'dxa'}),
            E('w:jc', {'w:val': 'left'}),
            E('w:tblInd', {'w:w': 0, 'w:type': 'dxa'}),
            E('w:tblBorders', None,
              E('w:top', {'w:val': 'single', 'w:sz': 8, 'w:space': 0, 'w:color': '000000'}),
              E('w:left', {'w:val': 'nil'}),
              E('w:bottom', {'w:val': 'single', 'w:sz': 8, 'w:space': 0, 'w:color': '000000'}),
              E('w:right', {'w:val': 'nil'}),
              E('w:insideH', {'w:val': 'nil'}),
              E('w:insideV', {'w:val': 'nil'})),
            E('w:tblLayout', {'w:type': 'fixed'}),
            E('w:tblCellMar', None,
              E('w:top', {'w:w': 28, 'w:type': 'dxa'}), E('w:left', {'w:w': 57, 'w:type': 'dxa'}),
              E('w:bottom', {'w:w': 28, 'w:type': 'dxa'}), E('w:right', {'w:w': 57, 'w:type': 'dxa'})))
    if look is not None: npr.append(copy.deepcopy(look))
    tbl.replace(tblpr, npr)
    rows = tbl.findall('w:tr', ns)
    # column alignment: centre short-content columns, left-align long-text columns
    ncol = len(grid)
    colchars = [[] for _ in range(ncol)]
    for tr in rows[1:]:
        for ci, tc in enumerate(tr.findall('w:tc', ns)):
            colchars[ci].append(len(text(tc)))
    avg = [sum(c) / max(len(c), 1) for c in colchars]
    nhdr = sum(1 for tr in rows if tr.find('w:trPr/w:tblHeader', ns) is not None) or 1
    for ri, tr in enumerate(rows):
        for ci, tc in enumerate(tr.findall('w:tc', ns)):
            tcpr = tc.find('w:tcPr', ns)
            if tcpr is None: tcpr = E('w:tcPr'); tc.insert(0, tcpr)
            for ch in list(tcpr):
                if etree.QName(ch).localname in ('shd', 'tcBorders', 'tcW'): tcpr.remove(ch)
            tcpr.insert(0, E('w:tcW', {'w:w': new[ci], 'w:type': 'dxa'}))
            if ri == nhdr - 1:
                b = E('w:tcBorders', None, E('w:bottom', {'w:val': 'single', 'w:sz': 4, 'w:space': 0, 'w:color': '000000'}))
                # tcBorders must follow tcW/gridSpan/vMerge and precede shd/vAlign
                tcpr.insert(1, b)
            for p in tc.findall('w:p', ns):
                jc = 'center' if (ri < nhdr or avg[ci] <= 22) else 'left'
                long_tbl = len(rows) > 14
                kn = (ri < nhdr + 2) if long_tbl else (ri < len(rows) - 1)
                set_ppr(p, 'MDPI42tablebody', jc=jc, keep_next=kn)
            clean_runs(tc)
            if TABLE_FONT[id(tbl)] != 18:
                for r_ in tc.iter(q('w:r')):
                    rpr = r_.find('w:rPr', ns)
                    if rpr is None: rpr = E('w:rPr'); r_.insert(0, rpr)
                    pos = len([c for c in rpr if etree.QName(c).localname in ('rStyle','rFonts','b','bCs','i','iCs')])
                    rpr.insert(pos, E('w:szCs', {'w:val': 16})); rpr.insert(pos, E('w:sz', {'w:val': 16}))
                for m_ in tc.iter(q('m:r')):
                    rpr = m_.find('w:rPr', ns)
                    if rpr is None:
                        rpr = E('w:rPr'); mr = m_.find('m:rPr', ns)
                        m_.insert(1 if mr is not None else 0, rpr)
                    rpr.append(E('w:sz', {'w:val': 16})); rpr.append(E('w:szCs', {'w:val': 16}))

# ---------------- walk body ----------------
new_body = []
tcount = 0; fcount = 0
prev_eq = False
pending_table_caption = None
i = 0
end = idx['ack']
while i < len(els):
    el = els[i]
    tag = etree.QName(el).localname
    if tag == 'sectPr':
        i += 1; continue
    if i >= idx['ack'] or i == idx['dataavail']:
        # back matter, references and biographies are rebuilt below
        i += 1; continue
    if tag in ('bookmarkStart', 'bookmarkEnd'):
        i += 1; continue
    if i < idx['abstract']:
        i += 1; continue          # title/author block rebuilt below
    if i in (idx['abstract'], idx['keywords']):
        i += 1; continue          # rebuilt below
    if tag == 'tbl':
        fmt_table(el)
        convert_wt_in(el)
        new_body.append(el); prev_eq = False
        i += 1; continue
    if tag != 'p':
        new_body.append(el); i += 1; continue
    p = el
    st = pstyle(p)
    t = wtext(p)
    # drop empty spacer paragraphs (section-break carriers after tables)
    if not t.strip() and not has_img(p) and p.find('.//m:oMath', ns) is None:
        i += 1; continue
    if st == 'Heading1':
        m = re.match(r'(' + RN + r')\.\s+(.*)', t.strip())
        assert m, t
        H1 = {'INTRODUCTION': 'Introduction', 'RELATED WORK': 'Related Work',
              'PROBLEM DEFINITION AND SYSTEM MODEL': 'Problem Definition and System Model',
              'EASE-6G FRAMEWORK': 'EASE-6G Framework', 'EVALUATION METHODOLOGY': 'Evaluation Methodology',
              'RESULTS AND DISCUSSION': 'Results and Discussion',
              'IMPLICATIONS FOR 6G ARCHITECTURE': 'Implications for 6G Architecture',
              'LIMITATIONS AND FUTURE WORK': 'Limitations and Future Work',
              'CONCLUSION': 'Conclusions'}
        n1 = ROMAN[m.group(1)]
        new_body.append(para('MDPI21heading1', [run('%d. %s' % (n1, H1[m.group(2)]))]))
        prev_eq = False; i += 1; continue
    if st == 'Heading2':
        m = re.match(r'([A-J])\.\s+(.*)', t.strip()); assert m, t
        new_body.append(para('MDPI22heading2', [run('%d.%d. %s' % (n1, LET[m.group(1)], convert_text(m.group(2))))]))
        prev_eq = False; i += 1; continue
    mt = re.match(r'TABLE (' + RN + r')\. ', t)
    if mt:
        tcount += 1; n = ROMAN[mt.group(1)]; assert n == tcount, (n, tcount)
        assert p.find('.//m:oMath', ns) is None
        new_body.append(para('MDPI41tablecaption', caption_runs('Table %d.' % n, TABLE_CAPS[n])))
        prev_eq = False; i += 1; continue
    mf = re.match(r'Fig\. (\d+)\. (.*)', t)
    if st == 'ImageCaption' and mf:
        fcount += 1; n = int(mf.group(1)); assert n == fcount
        assert p.find('.//m:oMath', ns) is None and p.find('.//w:vertAlign', ns) is None
        new_body.append(para('MDPI51figurecaption', caption_runs('Figure %d.' % n, convert_text(mf.group(2)))))
        prev_eq = False; i += 1; continue
    if has_img(p):
        set_ppr(p, 'MDPI52figure', keep_next=True); clean_runs(p)
        new_body.append(p); prev_eq = False; i += 1; continue
    if is_eq(p):
        set_ppr(p, 'MDPI39equation'); clean_runs(p)
        new_body.append(p); prev_eq = True; i += 1; continue
    if p.find('w:pPr/w:numPr', ns) is not None:
        set_ppr(p, 'MDPI37itemize', keep_num=True, ind={'w:left': COL + 425, 'w:hanging': 425})
        clean_runs(p); convert_wt_in(p)
        new_body.append(p); prev_eq = False; i += 1; continue
    # body text
    first = t.lstrip()[:1]
    style = 'MDPI32textnoindent' if (prev_eq and first.islower()) else 'MDPI31text'
    set_ppr(p, style); clean_runs(p); convert_wt_in(p)
    if new_body and etree.QName(new_body[-1]).localname == 'tbl':
        p.find('w:pPr', ns).insert(1, E('w:spacing', {'w:before': 240}))
    new_body.append(p); prev_eq = False; i += 1

assert tcount == 18 and fcount == 7, (tcount, fcount)

# ---------------- front matter ----------------
title_p = els[idx['title']]
title_runs = [copy.deepcopy(r) for r in title_p.findall('w:r', ns)]
assert wtext(title_p).startswith('EASE-6G: A Regime Analysis')
for r in title_runs:
    for t in r.iter(q('w:t')):
        t.text = t.text.replace('Continuum With Implications', 'Continuum with Implications')
tp = para('MDPI12title', title_runs); clean_runs(tp)

front = []
front.append(para('MDPI11articletype', [run('Article')]))
front.append(tp)
A = [('Ahmed Mostafa Saleh ElSawaf', '1,*'), ('Nour Eldeen M. Khalifa', '1,2'),
     ('Mohamed Hamed N. Taha', '1'), ('Shaimaa M. Mohamed', '1')]
ar = []
for k, (nm, sup) in enumerate(A):
    if k == len(A) - 1: ar.append(run(' and '))
    elif k > 0: ar.append(run(', '))
    ar.append(run(nm)); ar.append(run(sup, sup=True))
front.append(para('MDPI13authornames', ar))
front.append(para('MDPI16affiliation', [run('1', sup=True), run('\t'),
    run('Information Technology Department, Faculty of Computers and Artificial Intelligence, Cairo University, Giza 12613, Egypt; mnasrtaha@cu.edu.eg (M.H.N.T.); s.mosaad@fci-cu.edu.eg (S.M.M.)')]))
front.append(para('MDPI16affiliation', [run('2', sup=True), run('\t'),
    run('Electrical Engineering and Computer Science Program, College of Engineering (CoE), A’Sharqiyah University (ASU), Ibra 400, Oman; nourmahmoud@asu.edu.om')]))
front.append(para('MDPI16affiliation', [run('*', b=False), run('\t'), run('Correspondence: ahmed.sawaf@gmail.com')]))

# abstract: shortened to <=200 words (approved by the author); superscripts marked ^...^
abs_txt = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mdpi_abstract.txt'), encoding='utf8').read().strip()
ab_runs = []
for k, part in enumerate(abs_txt.split('^')):
    if part: ab_runs.append(run(part, sup=(k % 2 == 1)))
abp = para('MDPI17abstract', [run('Abstract:', b=True), run(' ')] + ab_runs)
assert len(abs_txt.replace('^', '').split()) <= 200

kw_text = wtext(els[idx['keywords']]).split('—', 1)[1].strip().rstrip('.')
kws = [k.strip() for k in kw_text.split(',')]
assert 3 <= len(kws) <= 10
kwp = para('MDPI18keywords', [run('Keywords:', b=True), run(' ' + '; '.join(kws))])

# left-column information box (MDPI first page), anchored as a frame in the left column
def side(runs, first=False):
    fp = E('w:framePr', {'w:w': COL - 284, 'w:hSpace': 284, 'w:wrap': 'around',
                         'w:vAnchor': 'text', 'w:hAnchor': 'margin', 'w:x': 0, 'w:y': 0})
    return para('MDPI61Sidebar', runs, extra_ppr=[fp])
sidebar = [
    side([run('Citation:', b=True), run(' To be added by editorial staff during production.')]),
    side([run('Academic Editor:', b=True), run(' Firstname Lastname')]),
    side([run('Received:', b=True), run(' date')]),
    side([run('Revised:', b=True), run(' date')]),
    side([run('Accepted:', b=True), run(' date')]),
    side([run('Published:', b=True), run(' date')]),
    side([run('Copyright:', b=True), run(' © 2026 by the authors. Submitted for possible open access publication under the terms and conditions of the Creative Commons Attribution (CC BY) license (https://creativecommons.org/licenses/by/4.0/).')]),
]
front += sidebar + [abp, kwp]

# ---------------- back matter ----------------
def bm(label, body_text_runs):
    return para('MDPI62BackMatter', [run(label, b=True), run(' ')] + body_text_runs)
def bm_first(label, rs):
    p = bm(label, rs); p.find('w:pPr', ns).append(E('w:spacing', {'w:before': 240, 'w:after': 120})); return p
ack_mdpi = ('During the preparation of this manuscript, the authors used GPT-5.6 (OpenAI) for language editing, '
            'code review, and organization of the manuscript, and Claude (Anthropic; Claude Fable 5.2 and Claude Opus 5.5) '
            'to revise the analysis code and rerun the experiments reported in Sections 5–7, to verify equations, numerical '
            'results, and references, and to draft and edit text in all sections. The authors have reviewed and edited the '
            'output and take full responsibility for the content of this publication.')
data_body = convert_text(data_text.split('—', 1)[1].strip())
back = [
 bm_first('Supplementary Materials:', [run('The following supporting information can be downloaded at: https://www.mdpi.com/article/doi/s1, File S1: Reproducibility package (Python implementation, solver configurations, parameter tables, 2026 NESO regional carbon-intensity traces, MLPerf logs, numerical results, and figure-generation scripts).')]),
 bm('Author Contributions:', [run('Conceptualization, A.M.S.E. and N.E.M.K.; methodology, A.M.S.E.; software, A.M.S.E.; validation, A.M.S.E., M.H.N.T. and S.M.M.; formal analysis, A.M.S.E.; investigation, A.M.S.E.; data curation, A.M.S.E.; writing—original draft preparation, A.M.S.E.; writing—review and editing, N.E.M.K., M.H.N.T. and S.M.M.; visualization, A.M.S.E.; supervision, N.E.M.K., M.H.N.T. and S.M.M.; project administration, N.E.M.K. All authors have read and agreed to the published version of the manuscript.')]),
 bm('Funding:', [run('This research received no external funding.')]),
 bm('Institutional Review Board Statement:', [run('Not applicable.')]),
 bm('Informed Consent Statement:', [run('Not applicable.')]),
 bm('Data Availability Statement:', [run(data_body)]),
 bm('Acknowledgments:', [run(ack_mdpi)]),
 bm('Conflicts of Interest:', [run('The authors declare no conflicts of interest.')]),
]

# ---------------- references ----------------
TOK = re.compile(r'(\*\*.+?\*\*|\*\{\{.+?\}\}\*|\{\{.+?\}\}|\*.+?\*|~.+?~|\[\[.+?\]\]|https?://[^\s]+)')
def ref_runs(n, s):
    out = []
    for part in TOK.split(s):
        if not part: continue
        if part.startswith('**'): out.append(run(part[2:-2], b=True))
        elif part.startswith('*{{'):
            out.append(hyperlink([run(part[3:-3], i=True)], ref_title_url[n]))
        elif part.startswith('{{'):
            out.append(hyperlink([run(part[2:-2])], ref_title_url[n]))
        elif part.startswith('*'): out.append(run(part[1:-1], i=True))
        elif part.startswith('~'): out.append(run(part[1:-1], sub=True))
        elif part.startswith('[['): out.append(run(part[2:-2], hl='yellow'))
        elif part.startswith('http'):
            url = part; tail = ''
            while url[-1] in '.,;)': tail = url[-1] + tail; url = url[:-1]
            out.append(hyperlink([run(url)], url))
            if tail: out.append(run(tail))
        else: out.append(run(part))
    return out
linked = {n for n, s in enumerate(REFS, 1) if '{{' in s}
assert linked == set(ref_title_url), (linked ^ set(ref_title_url))
refs = [para('MDPI71Referencesheading', [run('References')])]
for n, s in enumerate(REFS, 1):
    refs.append(para('MDPI81References', [run('%d.' % n), run('\t')] + ref_runs(n, s)))

# ---------------- abbreviation definitions at first use (approved by the author) ----------------
ABBR_EDITS = [
 ('facility energy per unit of work, PUE/EE, than the downstream tier.',
  'facility energy per unit of work than the downstream tier, measured by PUE/EE, the ratio of power usage effectiveness (PUE) to accelerator energy efficiency (EE).'),
 ('hard latency and service-KPI enforcement', 'hard latency and service key performance indicator (KPI) enforcement'),
 ('inference requests on heterogeneous GPUs', 'inference requests on heterogeneous graphics processing units (GPUs)'),
 ('mostly FP32 transformers', 'mostly 32-bit floating-point (FP32) transformers'),
 ('an 8-bit post-training-quantized network (V3)', 'an 8-bit post-training-quantized (PTQ) network (V3)'),
 ('inference co-located with the radio access network, with the compute rates', 'inference co-located with the radio access network (RAN), with the compute rates'),
 ('AI-RAN proposals place inference accelerators at the radio access network', 'Artificial intelligence–radio access network (AI-RAN) proposals place inference accelerators at the RAN'),
 ('The reference profiles are 5G-class', 'The reference profiles are fifth-generation (5G)-class'),
 ('The IMT-2030 framework lists', 'The International Mobile Telecommunications-2030 (IMT-2030) framework lists'),
 ('The dimensions follow 3GPP service requirements', 'The dimensions follow 3rd Generation Partnership Project (3GPP) service requirements'),
 ('split AI/ML operation', 'split AI/machine learning (ML) operation'),
 ('that a 5G-class far edge cannot.', 'that a fifth-generation (5G)-class far edge cannot.'),
]
hits = {k: 0 for k, _ in ABBR_EDITS}
for el in [abp] + new_body:
    for t in el.iter(q('w:t')):
        if not t.text: continue
        for old, new in ABBR_EDITS:
            if old in t.text:
                hits[old] += t.text.count(old); t.text = t.text.replace(old, new)
bad = {k: v for k, v in hits.items() if v != 1}
assert not bad, bad
# Table 11: spell out the shortened region names in the user-grid column
tbl11 = [el for el in new_body if etree.QName(el).localname == 'tbl'][10]
nfix = 0
for tc in tbl11.iter(q('w:tc')):
    full = text(tc).strip()
    if full in ('SE England', 'E England'):
        ts = list(tc.iter(q('w:t'))); assert len(ts) == 1
        ts[0].text = {'SE England': 'South East England', 'E England': 'East England'}[full]; nfix += 1
assert nfix == 2, nfix

# ---------------- MDPI edition: appendices, regime map, design rules, title, citation order ----------------
exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mdpi_edition.py'), encoding='utf8').read(), globals())

# ---------------- section properties ----------------
def mk_sect():
    s = E('w:sectPr')
    s.append(E('w:headerReference', {'w:type': 'default', 'r:id': 'rIdHdrDef'}))
    s.append(E('w:headerReference', {'w:type': 'first', 'r:id': 'rIdHdrFirst'}))
    s.append(E('w:footerReference', {'w:type': 'default', 'r:id': 'rIdFtrDef'}))
    s.append(E('w:footerReference', {'w:type': 'first', 'r:id': 'rIdFtrFirst'}))
    s.append(E('w:pgSz', {'w:w': PAGE_W, 'w:h': PAGE_H, 'w:code': 9}))
    s.append(E('w:pgMar', {'w:top': MT, 'w:right': MR, 'w:bottom': MB, 'w:left': ML,
                           'w:header': HDR, 'w:footer': FTR, 'w:gutter': 0}))
    s.append(E('w:lnNumType', {'w:countBy': 1, 'w:distance': 113, 'w:restart': 'continuous'}))
    s.append(E('w:cols', {'w:space': 720}))
    s.append(E('w:titlePg'))
    s.append(E('w:docGrid', {'w:linePitch': 360}))
    return s

for ch in list(body): body.remove(ch)
for el in front + new_body + back + refs: body.append(el)
body.append(mk_sect())

# fix hyperlink-run style: E() created rStyle inside rPr at position 0 already
doc.write(os.path.join(OUT, 'word/document.xml'), xml_declaration=True, encoding='UTF-8', standalone=True)
rels.write(rels_path, xml_declaration=True, encoding='UTF-8', standalone=True)
print('ok: tables', tcount, 'figures', fcount, 'paragraphs', len(new_body))
