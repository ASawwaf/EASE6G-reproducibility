#!/usr/bin/env python3
"""Efficiency and latency anchors computed from the published MLPerf Inference logs frozen in data/mlperf/.

For each run, the average power is the mean of the power-analyzer samples (spl.txt) between the power_begin and power_end
timestamps of the LoadGen detail log, and the efficiency is throughput x 4.1 GFLOP per ResNet-50 image / average power.
The Offline values reproduce the reference inputs of the manuscript (730 and 461 GFLOP/J). The Server and SingleStream runs of
the same two systems give the latency-bound basis used in ease6g_review_checks.py.
Output: results/v2/mlperf_anchor.json
"""
import datetime as dt, json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent; SRC = ROOT / "data" / "mlperf"; OUT = ROOT / "results" / "v2"
GFLOP_PER_IMAGE = 4.1
RUNS = {"server_offline": "r282_z93_q5_offline", "server_server": "r282_z93_q5_server", "device_offline": "orin_nx_maxq_offline", "device_singlestream": "orin_nx_maxq_singlestream"}


def _t(s): return dt.datetime.strptime(s, "%m-%d-%Y %H:%M:%S.%f")


def _key(detail, k): return re.search(r'"key": "%s", "value": "?([^",}]*)"?' % k, detail).group(1)


def run(prefix):
    summ = (SRC / f"{prefix}_mlperf_log_summary.txt").read_text(); det = (SRC / f"{prefix}_mlperf_log_detail.txt").read_text()
    b, e = _t(_key(det, "power_begin")), _t(_key(det, "power_end")); w = []; idle = None
    for ln in (SRC / f"{prefix}_spl.txt").read_text().splitlines():
        p = ln.split(",")
        if p[0] != "Time": continue
        if idle is None: idle = float(p[3])                               # first analyzer sample, before the load starts
        if b <= _t(p[1]) <= e: w.append(float(p[3]))
    f = lambda pat: (lambda mo: float(mo.group(1)) if mo else None)(re.search(pat, summ))
    scen = re.search(r"Scenario : (\w+)", summ).group(1)
    qps = {"Offline": f(r"Samples per second: ([\d.]+)"), "Server": f(r"Scheduled samples per second : ([\d.]+)"), "SingleStream": f(r"QPS w/ loadgen overhead\s*: ([\d.]+)")}[scen]
    P = sum(w) / len(w)
    out = dict(scenario=scen, valid="Result is : VALID" in summ, samples_per_s=qps, avg_power_W=P, power_samples=len(w), first_sample_W=idle, GFLOP_per_J=GFLOP_PER_IMAGE * qps / P,
               throughput_GFLOP_per_s=GFLOP_PER_IMAGE * qps)
    for lab, pat in (("mean", r"Mean latency \(ns\)\s*: (\d+)"), ("min", r"Min latency \(ns\)\s*: (\d+)"), ("max", r"Max latency \(ns\)\s*: (\d+)"), ("p50", r"50\.00 percentile latency \(ns\)\s*: (\d+)"),
                     ("p90", r"90\.00 percentile latency \(ns\)\s*: (\d+)"), ("p99", r"99\.00 percentile latency \(ns\)\s*: (\d+)"), ("p999", r"99\.90 percentile latency \(ns\)\s*: (\d+)")):
        v = f(pat)
        if v is not None and scen != "Offline": out[f"latency_{lab}_ms"] = v / 1e6
    if scen == "Server": out["target_latency_ms"] = f(r"target_latency \(ns\): (\d+)") / 1e6
    return out


def main():
    A = {k: run(p) for k, p in RUNS.items()}
    A["server_latency_bound_factor"] = A["server_server"]["GFLOP_per_J"] / A["server_offline"]["GFLOP_per_J"]
    A["device_latency_bound_factor"] = A["device_singlestream"]["GFLOP_per_J"] / A["device_offline"]["GFLOP_per_J"]
    A["server_load_fraction_of_offline"] = A["server_server"]["samples_per_s"] / A["server_offline"]["samples_per_s"]
    A["server_idle_fraction_of_offline_power"] = A["server_server"]["first_sample_W"] / A["server_offline"]["avg_power_W"]
    A["device_singlestream_rate_GFLOP_per_s"] = GFLOP_PER_IMAGE / (A["device_singlestream"]["latency_p90_ms"] / 1000)
    A["device_singlestream_mJ_per_inference"] = 1000 * A["device_singlestream"]["avg_power_W"] / A["device_singlestream"]["samples_per_s"]
    A["sources"] = {"server": "mlcommons/inference_results_v1.0, closed/Qualcomm/results/r282_z93_q5-qaic-v1.3.14-aic100/resnet50/{offline,server}/performance/run_1",
                    "device": "mlcommons/inference_results_v3.1, closed/NVIDIA/results/Orin_NX_TRT_MaxQ/resnet50/{Offline,SingleStream}/performance/run_1"}
    OUT.mkdir(parents=True, exist_ok=True); (OUT / "mlperf_anchor.json").write_text(json.dumps(A, indent=1)); return A


if __name__ == "__main__":
    print(json.dumps(main(), indent=1))
