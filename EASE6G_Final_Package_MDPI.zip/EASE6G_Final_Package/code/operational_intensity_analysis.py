#!/usr/bin/env python3
"""Decision-boundary and seasonal analysis over effective operational intensity.

The analysis holds the UC4 service gates and access profile fixed, restricts the
choice to its feasible T2/T3 tiers, and varies effective model work per payload:

    chi = F * delta / D  [GFLOP/Mbit].

This exposes, rather than hides, the regime in which path transport dominates
and the regime in which carbon-aware placement can change the decision.
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
RESULTS.mkdir(exist_ok=True)
FIGURES.mkdir(exist_ok=True)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ease6g_revision_model as model

TIERS = ("T2", "T3")
CHI_GRID = np.unique(
    np.concatenate(
        ([0.01, 0.03, 0.03625, 0.1, 0.23, 0.3, 1.0, 3.0, 10.0, 30.0, 100.0],
         np.logspace(-2, 2, 241))
    )
)
REPORT_GRID = np.array([0.01, 0.03, 0.03625, 0.1, 0.23, 0.3, 1.0, 3.0, 10.0, 30.0, 100.0])


def tier_row(tier: str) -> pd.Series:
    return model.TIERS[model.TIERS.tier == tier].iloc[0]


def uc4() -> pd.Series:
    return model.USE_CASES[model.USE_CASES.uc == "UC4"].iloc[0]


def kpi_norms() -> dict[str, float]:
    u = uc4()
    raw = {}
    for tier in TIERS:
        t = tier_row(tier)
        raw[tier] = (
            u.Lmax_ms / t.service_latency_ms
            + t.bandwidth_Gbps / u.Bmin_Gbps
            + t.reliability / u.Rmin
            + u.Jmax_ms / t.jitter_ms
        )
    maximum = max(raw.values())
    return {tier: value / maximum for tier, value in raw.items()}


def energy_per_mbit(tier: str, chi: float) -> float:
    """Total energy for one Mbit at effective intensity chi."""
    t = tier_row(tier)
    u = uc4()
    compute = float(t.PUE) / float(t.accelerator_EE_GFLOPS_per_W) * float(chi)
    access = float(u.access_tx_power_W) / (model.RHO_B * float(u.access_bandwidth_Gbps)) * 1e-3
    transport = float(t.transport_energy_nJ_per_bit) * 1e-3
    return compute + access + transport


def carbon_per_mbit(tier: str, chi: float, ci: dict[str, float]) -> float:
    return energy_per_mbit(tier, chi) * float(ci[tier]) / 3.6


def normalize_eff(values: dict[str, float]) -> dict[str, float]:
    lo, hi = min(values.values()), max(values.values())
    if hi == lo:
        return {tier: 1.0 for tier in values}
    return {tier: 1.0 - (value - lo) / (hi - lo) for tier, value in values.items()}


def select(chi: float, ci: dict[str, float]) -> dict[str, str]:
    energy = {tier: energy_per_mbit(tier, chi) for tier in TIERS}
    carbon = {tier: carbon_per_mbit(tier, chi, ci) for tier in TIERS}
    eta = normalize_eff(energy)
    carbon_eff = normalize_eff(carbon)
    kpi = kpi_norms()
    ease_score = {
        tier: 0.4 * eta[tier] + 0.4 * carbon_eff[tier] + 0.2 * kpi[tier]
        for tier in TIERS
    }
    b5_score = {tier: (2 / 3) * eta[tier] + (1 / 3) * kpi[tier] for tier in TIERS}

    def winner(score: dict[str, float]) -> str:
        return sorted(TIERS, key=lambda t: (-score[t], carbon[t], energy[t], t))[0]

    return {
        "EASE-6G": winner(ease_score),
        "B5": winner(b5_score),
        "Oracle-KA": sorted(TIERS, key=lambda t: (carbon[t], energy[t], t))[0],
    }


def crossover(ci: dict[str, float] | None = None) -> tuple[float, float | None]:
    t2, t3 = tier_row("T2"), tier_row("T3")
    u = uc4()
    access = float(u.access_tx_power_W) / (model.RHO_B * float(u.access_bandwidth_Gbps)) * 1e-3
    b2 = access + float(t2.transport_energy_nJ_per_bit) * 1e-3
    b3 = access + float(t3.transport_energy_nJ_per_bit) * 1e-3
    g2 = float(t2.PUE) / float(t2.accelerator_EE_GFLOPS_per_W)
    g3 = float(t3.PUE) / float(t3.accelerator_EE_GFLOPS_per_W)
    chi_e = (b2 - b3) / (g3 - g2)
    if ci is None:
        return chi_e, None
    denominator = float(ci["T2"]) * g2 - float(ci["T3"]) * g3
    chi_c = (float(ci["T3"]) * b3 - float(ci["T2"]) * b2) / denominator
    return chi_e, chi_c if chi_c > 0 else None


def mean_ci() -> dict[str, float]:
    return {tier: float(tier_row(tier).CI_kg_per_kWh) for tier in TIERS}


def static_analysis() -> pd.DataFrame:
    ci = mean_ci()
    rows = []
    for chi in CHI_GRID:
        choices = select(float(chi), ci)
        energies = {tier: energy_per_mbit(tier, float(chi)) for tier in TIERS}
        carbons = {tier: carbon_per_mbit(tier, float(chi), ci) for tier in TIERS}
        b5, ease, oracle = choices["B5"], choices["EASE-6G"], choices["Oracle-KA"]
        rows.append(
            {
                "chi_GFLOP_per_Mbit": chi,
                "B5_tier": b5,
                "EASE_tier": ease,
                "Oracle_KA_tier": oracle,
                "B5_energy_J_per_Mbit": energies[b5],
                "EASE_energy_J_per_Mbit": energies[ease],
                "B5_carbon_mg_per_Mbit": carbons[b5],
                "EASE_carbon_mg_per_Mbit": carbons[ease],
                "carbon_reduction_vs_B5_percent": 100 * (carbons[b5] - carbons[ease]) / carbons[b5],
            }
        )
    return pd.DataFrame(rows)


def seasonal_analysis() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    seed_rows = []
    hour_rows = []
    for window, hourly in model.load_carbon_trace_windows().items():
        ci_hours = [
            {tier: float(row[model.TIER_REGION_NAMES[tier]]) / 1000.0 for tier in TIERS}
            for _, row in hourly.iterrows()
        ]
        for chi in REPORT_GRID:
            decisions = [select(float(chi), ci) for ci in ci_hours]
            for h, (ci, decision) in enumerate(zip(ci_hours, decisions)):
                b5, ease = decision["B5"], decision["EASE-6G"]
                hour_rows.append(
                    {
                        "window": window,
                        "hour": h,
                        "chi_GFLOP_per_Mbit": chi,
                        "B5_tier": b5,
                        "EASE_tier": ease,
                        "Oracle_KA_tier": decision["Oracle-KA"],
                        "different_from_B5": ease != b5,
                        "T2_CI_g_per_kWh": ci["T2"] * 1000,
                        "T3_CI_g_per_kWh": ci["T3"] * 1000,
                    }
                )
            for seed in model.RNG_SEEDS:
                rng = np.random.default_rng(seed)
                b5_total = ease_total = oracle_total = 0.0
                for h, (ci, decision) in enumerate(zip(ci_hours, decisions)):
                    rate = model.rates_for_hour(h, rng, scale=0.25)["UC4"]
                    factor = rate * 3600.0
                    b5_total += carbon_per_mbit(decision["B5"], float(chi), ci) * factor
                    ease_total += carbon_per_mbit(decision["EASE-6G"], float(chi), ci) * factor
                    oracle_total += carbon_per_mbit(decision["Oracle-KA"], float(chi), ci) * factor
                seed_rows.append(
                    {
                        "window": window,
                        "seed": seed,
                        "chi_GFLOP_per_Mbit": chi,
                        "B5_carbon_index": b5_total,
                        "EASE_carbon_index": ease_total,
                        "Oracle_KA_carbon_index": oracle_total,
                        "reduction_vs_B5_percent": 100 * (b5_total - ease_total) / b5_total,
                        "gap_vs_Oracle_KA_percent": 100 * (ease_total - oracle_total) / oracle_total,
                    }
                )
    seeds = pd.DataFrame(seed_rows)
    hours = pd.DataFrame(hour_rows)
    windows = (
        seeds.groupby(["window", "chi_GFLOP_per_Mbit"])
        .agg(
            reduction_mean_percent=("reduction_vs_B5_percent", "mean"),
            reduction_sd_percent=("reduction_vs_B5_percent", "std"),
            oracle_gap_mean_percent=("gap_vs_Oracle_KA_percent", "mean"),
        )
        .reset_index()
    )
    differing = (
        hours.groupby(["window", "chi_GFLOP_per_Mbit"])
        .different_from_B5.sum()
        .reset_index(name="hours_different_from_B5")
    )
    windows = windows.merge(differing, on=["window", "chi_GFLOP_per_Mbit"])
    return seeds, hours, windows


def make_figures(static: pd.DataFrame, seasonal: pd.DataFrame, chi_e: float, chi_c: float) -> None:
    palette = {"T2": "#005AFF", "T3": "#23ABB6"}
    tier_code = {"T2": 0, "T3": 1}
    x = static.chi_GFLOP_per_Mbit.to_numpy()

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(8.4, 6.0), sharex=True, gridspec_kw={"height_ratios": [1, 1.35]})
    for method, marker, yoff in [("B5", "o", -0.08), ("EASE", "s", 0.0), ("Oracle_KA", "^", 0.08)]:
        col = f"{method}_tier"
        y = np.array([tier_code[t] for t in static[col]]) + yoff
        ax1.plot(x, y, linewidth=1.6, label=method.replace("_", "-"), marker=marker, markevery=30, markersize=3)
    ax1.set_xscale("log")
    ax1.set_yticks([0, 1], ["T2", "T3"])
    ax1.set_ylabel("Selected tier")
    ax1.legend(ncol=3, fontsize=8, loc="lower left")
    ax1.grid(True, which="both", alpha=0.2)

    ax2.plot(x, static.carbon_reduction_vs_B5_percent, color="#7D33F2", linewidth=2.2)
    ax2.axhline(0, color="black", linewidth=0.8)
    ax2.set_xscale("log")
    ax2.set_xlabel(r"Effective operational intensity $\chi$ (GFLOP/Mbit)")
    ax2.set_ylabel("Carbon reduction vs B5 (%)")
    ax2.grid(True, which="both", alpha=0.2)
    for axis in (ax1, ax2):
        axis.axvline(chi_e, color="#F7B737", linestyle="--", linewidth=1.4)
        axis.axvline(chi_c, color="#E23B3B", linestyle="--", linewidth=1.4)
        axis.axvline(0.03625, color="#666666", linestyle=":", linewidth=1.2)
    ax1.set_title("UC4 feasibility envelope: the decision changes across operational intensity")
    ax2.text(chi_e, ax2.get_ylim()[1] * 0.90, "energy crossover", rotation=90, va="top", ha="right", fontsize=8)
    ax2.text(chi_c, ax2.get_ylim()[1] * 0.90, "mean-carbon crossover", rotation=90, va="top", ha="right", fontsize=8)
    ax2.text(0.03625, ax2.get_ylim()[1] * 0.90, "reference UC4", rotation=90, va="top", ha="right", fontsize=8)
    fig.tight_layout()
    phase_path = FIGURES / "fig_operational_intensity_phase.png"
    phase_tmp = FIGURES / "fig_operational_intensity_phase.tmp.png"
    fig.savefig(phase_tmp, dpi=240, bbox_inches="tight")
    plt.close(fig)
    os.replace(phase_tmp, phase_path)

    order = [x[0] for x in model.TRACE_WINDOWS]
    fig, ax = plt.subplots(figsize=(8.2, 4.7))
    colors = ["#005AFF", "#23ABB6", "#7D33F2"]
    for window, color in zip(order, colors):
        d = seasonal[seasonal.window == window]
        ax.plot(d.chi_GFLOP_per_Mbit, d.reduction_mean_percent, marker="o", linewidth=2, label=window, color=color)
    ax.axhline(0, color="black", linewidth=0.8)
    ax.axvline(0.03625, color="#666666", linestyle=":", linewidth=1.2, label="Reference UC4")
    ax.set_xscale("log")
    ax.set_xlabel(r"Effective operational intensity $\chi$ (GFLOP/Mbit)")
    ax.set_ylabel("Seasonal carbon reduction vs B5 (%)")
    ax.set_title("Trace-driven benefit is conditional, not universal")
    ax.grid(True, which="both", alpha=0.2)
    ax.legend(fontsize=8)
    fig.tight_layout()
    seasonal_path = FIGURES / "fig_seasonal_operational_intensity.png"
    seasonal_tmp = FIGURES / "fig_seasonal_operational_intensity.tmp.png"
    fig.savefig(seasonal_tmp, dpi=240, bbox_inches="tight")
    plt.close(fig)
    os.replace(seasonal_tmp, seasonal_path)


def main() -> None:
    ci = mean_ci()
    chi_e, chi_c = crossover(ci)
    assert chi_c is not None
    static = static_analysis()
    seeds, hours, seasonal = seasonal_analysis()
    static.to_csv(RESULTS / "operational_intensity_static_grid.csv", index=False)
    report_mask = np.logical_or.reduce(
        [np.isclose(static.chi_GFLOP_per_Mbit.to_numpy(), value) for value in REPORT_GRID]
    )
    report_grid = static.loc[report_mask].copy()
    report_grid.to_csv(RESULTS / "operational_intensity_report_grid.csv", index=False)
    seeds.to_csv(RESULTS / "seasonal_operational_intensity_seed_results.csv", index=False)
    hours.to_csv(RESULTS / "seasonal_operational_intensity_hourly_decisions.csv", index=False)
    seasonal.to_csv(RESULTS / "seasonal_operational_intensity_window_summary.csv", index=False)
    crossover_rows = [
        {"quantity": "T2-T3 energy crossover", "value_GFLOP_per_Mbit": chi_e},
        {"quantity": "T2-T3 mean-carbon crossover", "value_GFLOP_per_Mbit": chi_c},
        {"quantity": "Reference UC3 effective intensity", "value_GFLOP_per_Mbit": 4.6 / 20.0},
        {"quantity": "Reference UC4 effective intensity", "value_GFLOP_per_Mbit": 2.9 / 80.0},
    ]
    pd.DataFrame(crossover_rows).to_csv(RESULTS / "operational_intensity_crossovers.csv", index=False)
    make_figures(static, seasonal, chi_e, chi_c)
    positive = seasonal[seasonal.reduction_mean_percent > 1e-9]
    summary = {
        "energy_crossover_GFLOP_per_Mbit": chi_e,
        "mean_carbon_crossover_GFLOP_per_Mbit": chi_c,
        "reference_UC3_chi": 4.6 / 20.0,
        "reference_UC4_chi": 2.9 / 80.0,
        "seasonal_cells": int(len(seasonal)),
        "seasonal_cells_with_positive_reduction": int(len(positive)),
        "maximum_seasonal_reduction_percent": float(seasonal.reduction_mean_percent.max()),
        "maximum_predeclared_static_reduction_percent": float(report_grid.carbon_reduction_vs_B5_percent.max()),
        "maximum_dense_visualization_reduction_percent": float(static.carbon_reduction_vs_B5_percent.max()),
    }
    (RESULTS / "operational_intensity_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
