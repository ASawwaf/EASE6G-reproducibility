"""Waiting-time quantiles of the M/D/1 queue (Erlang's formula in 60-digit arithmetic), used by the tail-latency gate."""
import functools
import mpmath as mp
mp.mp.dps = 60


def md1_cdf(x, rho):
    """P(W <= x D) for an M/D/1 queue at load rho; x in service times."""
    x = mp.mpf(x); rho = mp.mpf(rho); s = mp.mpf(0)
    for k in range(int(mp.floor(x)) + 1):
        a = rho * (k - x); s += a ** k / mp.factorial(k) * mp.e ** (-a)
    return (1 - rho) * s


@functools.lru_cache(maxsize=None)
def md1_quantile(rho, p):
    """Smallest x (in service times) with P(W <= x D) >= p."""
    rho = float(rho); p = float(p)
    if p <= 1 - rho: return 0.0
    lo, hi = 0.0, 1.0
    while md1_cdf(hi, rho) < p: hi *= 2
    for _ in range(50):
        mid = 0.5 * (lo + hi)
        if md1_cdf(mid, rho) < p: lo = mid
        else: hi = mid
    return float(hi)
