#!/usr/bin/env python3
from __future__ import annotations
import itertools, json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import ease6g_revision_model as model

ROOT=Path(__file__).resolve().parent.parent; R=ROOT/'results'; F=ROOT/'figures'
REGIONS=['London','South East England','East England','North Scotland']
REFERENCE={'T1':'London','T2':'South East England','T3':'East England','T4':'North Scotland'}

# Base candidate structure. Energy, KPI, eta, and gates do not depend on CI.
base=model.candidates().copy()
base['idx']=np.arange(len(base))
# B5 selection independent of CI.
b5_idx={}
for uc in model.USE_CASES.uc:
    d=base[(base.uc==uc)&(base.K==1)&(base.A==1)].copy(); d['b5']=(2/3)*d.eta+(1/3)*d.KPI_norm
    b5_idx[uc]=int(d.sort_values(['b5','E_total_J'],ascending=[False,True]).iloc[0]['idx'])

uc_all_indices={uc:base.index[base.uc==uc].to_numpy() for uc in model.USE_CASES.uc}
uc_feasible_indices={uc:base.index[(base.uc==uc)&(base.K==1)&(base.A==1)].to_numpy() for uc in model.USE_CASES.uc}
tier_arr=base.tier.to_numpy(); var_arr=base.variant.to_numpy(); energy=base.E_total_J.to_numpy(); eta=base.eta.to_numpy(); kpi=base.KPI_norm.to_numpy()


def decisions(ci_by_tier):
    ci_vec=np.array([ci_by_tier[t] for t in tier_arr])
    carbon=energy*ci_vec/3.6
    ease={}; oracle={}
    for uc,inds in uc_feasible_indices.items():
        cfeasible=carbon[inds]; cmin=cfeasible.min(); cmax=cfeasible.max()
        c=carbon[inds]
        ce=np.ones_like(c) if cmax==cmin else 1-(c-cmin)/(cmax-cmin)
        score=0.4*eta[inds]+0.4*ce+0.2*kpi[inds]
        # deterministic tie breaks: highest score, lowest carbon, lowest energy
        order=np.lexsort((energy[inds],c,-score)); ei=inds[order[0]]
        oi=inds[np.lexsort((energy[inds],c))[0]]
        ease[uc]=ei; oracle[uc]=oi
    return carbon,ease,oracle


def main():
    windows=model.load_carbon_trace_windows(); combined=pd.concat(windows.values()); means={r:float(combined[r].mean())/1000 for r in REGIONS}
    # Pre-generate workload rates by window/seed/hour.
    rate_cache={}
    for w in windows:
        for seed in model.RNG_SEEDS:
            rng=np.random.default_rng(seed)
            rate_cache[(w,seed)]=[model.rates_for_hour(h,rng,scale=0.25) for h in range(168)]
    map_defs=[]; static_rows=[]; dyn_rows=[]
    for mid,perm in enumerate(itertools.permutations(REGIONS),1):
        mapping=dict(zip(['T1','T2','T3','T4'],perm)); mapping['T5']=mapping['T4']; ref=all(mapping[k]==REFERENCE[k] for k in REFERENCE)
        map_defs.append({'mapping_id':mid,'is_reference':ref,**mapping})
        ci={t:means[r] for t,r in mapping.items()}; carbon,ease,oracle=decisions(ci)
        ec=np.mean([carbon[ease[uc]] for uc in model.USE_CASES.uc]); bc=np.mean([carbon[b5_idx[uc]] for uc in model.USE_CASES.uc]); oc=np.mean([carbon[oracle[uc]] for uc in model.USE_CASES.uc])
        static_rows.append({'mapping_id':mid,'is_reference':ref,'EASE_mean_carbon_mg':ec,'B5_mean_carbon_mg':bc,'Oracle_KA_mean_carbon_mg':oc,'reduction_vs_B5_percent':100*(bc-ec)/bc,'gap_vs_Oracle_KA_percent':100*(ec-oc)/oc,'EASE_placements':'; '.join(f'{uc}:{tier_arr[ease[uc]]}-{var_arr[ease[uc]]}' for uc in model.USE_CASES.uc)})
        for w,hourly in windows.items():
            hdec=[]
            for _,row in hourly.iterrows():
                cih={t:float(row[r])/1000 for t,r in mapping.items()}; hdec.append(decisions(cih))
            for seed in model.RNG_SEEDS:
                ec=bc=oc=0.0
                rates=rate_cache[(w,seed)]
                for h,(carbon,ease,oracle) in enumerate(hdec):
                    for uc in model.USE_CASES.uc:
                        rate=rates[h][uc]; ec+=carbon[ease[uc]]*rate*3600; bc+=carbon[b5_idx[uc]]*rate*3600; oc+=carbon[oracle[uc]]*rate*3600
                dyn_rows.append({'mapping_id':mid,'is_reference':ref,'window':w,'seed':seed,'reduction_vs_B5_percent':100*(bc-ec)/bc,'gap_vs_Oracle_KA_percent':100*(ec-oc)/oc})
    maps=pd.DataFrame(map_defs); static=pd.DataFrame(static_rows); dyn=pd.DataFrame(dyn_rows)
    maps.to_csv(R/'mapping_definitions.csv',index=False); static.to_csv(R/'mapping_static_results.csv',index=False); dyn.to_csv(R/'mapping_trace_seed_results.csv',index=False)
    win=dyn.groupby(['mapping_id','is_reference','window']).agg(reduction_mean_percent=('reduction_vs_B5_percent','mean'),reduction_sd_percent=('reduction_vs_B5_percent','std'),oracle_gap_mean_percent=('gap_vs_Oracle_KA_percent','mean')).reset_index(); win.to_csv(R/'mapping_trace_window_results.csv',index=False)
    summary={'mapping_count':24,'static_positive_mappings':int((static.reduction_vs_B5_percent>0).sum()),'static_median_reduction_percent':float(static.reduction_vs_B5_percent.median()),'static_min_reduction_percent':float(static.reduction_vs_B5_percent.min()),'static_max_reduction_percent':float(static.reduction_vs_B5_percent.max()),'dynamic_by_window':{}}
    for w,g in win.groupby('window'):
        summary['dynamic_by_window'][w]={'positive_mappings':int((g.reduction_mean_percent>0).sum()),'median_reduction_percent':float(g.reduction_mean_percent.median()),'min_reduction_percent':float(g.reduction_mean_percent.min()),'max_reduction_percent':float(g.reduction_mean_percent.max())}
    (R/'mapping_robustness_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    order=[x[0] for x in model.TRACE_WINDOWS]; fig,ax=plt.subplots(figsize=(8.2,4.4)); data=[win[win.window==w].reduction_mean_percent.values for w in order]
    ax.boxplot(data,tick_labels=[w.replace(' 2026','') for w in order]); ax.axhline(0,linewidth=1); ax.set_ylabel('Carbon reduction vs B5 across 24 mappings (%)'); ax.set_title('Regional mapping robustness'); fig.tight_layout(); fig.savefig(F/'fig7_mapping_robustness.png',dpi=220,bbox_inches='tight'); plt.close(fig)
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
