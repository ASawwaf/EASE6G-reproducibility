"""Sweep the declared UC4 envelope; keep B5 fixed and preserve exact tie breaks."""
import json
from pathlib import Path
import numpy as np
import pandas as pd
import operational_intensity_analysis as a

OUT = a.RESULTS / 'positive_regime_weights'
OUT.mkdir(exist_ok=True)
weights = [(i/20, j/20, (20-i-j)/20) for i in range(21) for j in range(21-i)]
default_id = weights.index((0.4, 0.4, 0.2))
kpi = a.kpi_norms()
rows, static_rows, seed_rows = [], [], []
checks = 0

def choices(chi, ci):
    e = {t:a.energy_per_mbit(t, chi) for t in a.TIERS}
    c = {t:a.carbon_per_mbit(t, chi, ci) for t in a.TIERS}
    ne, nc = a.normalize_eff(e), a.normalize_eff(c)
    chosen = []
    for we, wc, wk in weights:
        scores = {t:we*ne[t]+wc*nc[t]+wk*kpi[t] for t in a.TIERS}
        chosen.append(sorted(a.TIERS,key=lambda t:(-scores[t],c[t],e[t],t))[0])
    reference = a.select(chi,ci)
    assert chosen[default_id] == reference['EASE-6G']
    return np.array(chosen), c, reference

for chi in a.REPORT_GRID:
    selected,c,ref = choices(float(chi),a.mean_ci())
    for wi,(we,wc,wk) in enumerate(weights):
        static_rows.append(dict(chi=chi,wE=we,wC=wc,wK=wk,tier=selected[wi],default_tier=ref['EASE-6G'],changed=selected[wi]!=ref['EASE-6G'],reduction_percent=100*(c[ref['B5']]-c[selected[wi]])/c[ref['B5']]))

for window, hourly in a.model.load_carbon_trace_windows().items():
    selected_hours, carbon_hours, baseline_hours, oracle_hours = [], [], [], []
    rates=[]
    for seed in a.model.RNG_SEEDS:
        rng=np.random.default_rng(seed)
        rates.append([a.model.rates_for_hour(h,rng,scale=0.25)['UC4']*3600 for h in range(len(hourly))])
    rates=np.array(rates)
    for chi in a.REPORT_GRID:
        selected_hours,carbon_hours,baseline_hours,oracle_hours=[],[],[],[]
        for _,hour in hourly.iterrows():
            ci={t:float(hour[a.model.TIER_REGION_NAMES[t]])/1000 for t in a.TIERS}
            selected,c,ref=choices(float(chi),ci)
            checks+=1
            selected_hours.append(selected)
            carbon_hours.append([c[t] for t in selected])
            baseline_hours.append(c[ref['B5']])
            oracle_hours.append(c[ref['Oracle-KA']])
        selected_hours=np.array(selected_hours)
        totals=rates @ np.array(carbon_hours)
        base=rates @ np.array(baseline_hours)
        oracle=rates @ np.array(oracle_hours)
        reductions=100*(base[:,None]-totals)/base[:,None]
        for wi,(we,wc,wk) in enumerate(weights):
            rows.append(dict(window=window,chi=chi,wE=we,wC=wc,wK=wk,hours=len(hourly),T2_hours=int((selected_hours[:,wi]=='T2').sum()),T3_hours=int((selected_hours[:,wi]=='T3').sum()),changed_hours=int((selected_hours[:,wi]!=selected_hours[:,default_id]).sum()),reduction_mean_percent=reductions[:,wi].mean(),reduction_sd_percent=reductions[:,wi].std(ddof=1)))
            for si,seed in enumerate(a.model.RNG_SEEDS):
                seed_rows.append(dict(window=window,chi=chi,wE=we,wC=wc,wK=wk,seed=seed,EASE_carbon_index=totals[si,wi],B5_carbon_index=base[si],Oracle_carbon_index=oracle[si],reduction_percent=reductions[si,wi]))

df=pd.DataFrame(rows)
st=pd.DataFrame(static_rows)
defaults=df[(df.wE==.4)&(df.wC==.4)&(df.wK==.2)]
existing=pd.read_csv(a.RESULTS/'seasonal_operational_intensity_window_summary.csv')
merged=defaults.merge(existing,left_on=['window','chi'],right_on=['window','chi_GFLOP_per_Mbit'])
assert len(merged)==33
assert np.allclose(merged.reduction_mean_percent_x,merged.reduction_mean_percent_y,rtol=0,atol=1e-10)
cells=df.groupby(['window','chi']).agg(changing_weight_vectors=('changed_hours',lambda s:int((s>0).sum())),positive_weight_vectors=('reduction_mean_percent',lambda s:int((s>1e-9).sum())),min_reduction_percent=('reduction_mean_percent','min'),max_reduction_percent=('reduction_mean_percent','max')).reset_index()
byweight=df.groupby(['wE','wC','wK']).agg(changed_hours=('changed_hours','sum'),positive_cells=('reduction_mean_percent',lambda s:int((s>1e-9).sum()))).reset_index()
summary=dict(weight_vectors=len(weights),window_intensity_weight_cells=len(df),hourly_decisions=int(df.hours.sum()),default_hourly_checks=checks,default_seasonal_cells_verified=len(merged),weight_vectors_matching_default_all_hours=int((byweight.changed_hours==0).sum()),cells_with_any_changed_hour=int((df.changed_hours>0).sum()),changed_hourly_decisions=int(df.changed_hours.sum()),positive_cells=int((df.reduction_mean_percent>1e-9).sum()),negative_cells=int((df.reduction_mean_percent < -1e-9).sum()),minimum_seasonal_reduction=float(df.reduction_mean_percent.min()),maximum_seasonal_reduction=float(df.reduction_mean_percent.max()),kpi_norms=kpi)
for name,frame in [('seasonal_weights',df),('static_weights',st),('seasonal_seeds',pd.DataFrame(seed_rows)),('cell_summary',cells),('weight_summary',byweight)]:
    frame.to_csv(OUT/(name+'.csv'),index=False)
(OUT/'summary.json').write_text(json.dumps(summary,indent=2))
print(json.dumps(summary,indent=2))
print(cells.to_string(index=False))
