"""Generate the seven manuscript figures from the frozen numerical outputs."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
import ease6g_revision_model as model
import operational_intensity_analysis as intensity

ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'results'; F=ROOT/'figures'
plt.rcParams.update({'font.family':'serif','font.serif':['Nimbus Roman','Times New Roman','DejaVu Serif'],'mathtext.fontset':'stix','font.size':11,'axes.titlesize':12,'savefig.dpi':300})
def save(fig,n):
 fig.tight_layout();fig.savefig(F/f'fig{n}_submission.png',dpi=300,bbox_inches='tight');plt.close(fig)

fig,ax=plt.subplots(figsize=(12,2.35));ax.set(xlim=(0,5),ylim=(0,1));ax.axis('off')
for i,row in model.TIERS.iterrows():
 x=i+.06
 ax.add_patch(FancyBboxPatch((x,.06),.87,.88,boxstyle='round,pad=0.02',facecolor='white',edgecolor='#005AFF',linewidth=1.5))
 name={'T1':'Remote cloud','T2':'Regional edge','T3':'Metro edge','T4':'Far edge','T5':'On-device'}[row.tier]
 ax.text(x+.435,.81,f'{row.tier}  {name}',ha='center',fontweight='bold',fontsize=12,color='#005AFF')
 vals=[rf'$\mathrm{{CAP}}_{{\mathrm{{AI}}}}$: {row.CAP_AI_GFLOPS_per_s:,.0f} GFLOP/s',rf'$\mathrm{{EE}}$: {row.accelerator_EE_GFLOPS_per_W:g} GFLOP/(s W)',rf'$\mathrm{{CI}}$: {row.CI_kg_per_kWh:.3f} kg CO$_2$/kWh',row.region_name.replace('South East England','South East\nEngland')]
 for y,v in zip([.64,.48,.32,.14],vals):ax.text(x+.435,y,v,ha='center',va='center',fontsize=10.5)
 if i<4:ax.annotate('',xy=(i+1.035,.5),xytext=(x+.89,.5),arrowprops={'arrowstyle':'<->','lw':1})
save(fig,1)

fig,ax=plt.subplots(figsize=(10,2.8));ax.set(xlim=(0,3),ylim=(0,2));ax.axis('off')
labels=['Service and model\nrequirements','Tier efficiency, carbon,\naccess and path profiles','Hard service and\naccuracy gates','Routing policy','Capacity and availability\nconstrained MILP','Feasible energy, carbon\nand KPI scoring']
pos=[(.5,1.5),(1.5,1.5),(2.5,1.5),(.5,.5),(1.5,.5),(2.5,.5)]
for (x,y),label in zip(pos,labels):ax.text(x,y,label,ha='center',va='center',bbox={'boxstyle':'round,pad=.45','fc':'white','ec':'#005AFF'},fontsize=11)
for a,b in [((.89,1.5),(1.10,1.5)),((1.93,1.5),(2.10,1.5)),((2.5,1.19),(2.5,.81)),((2.09,.5),(1.94,.5)),((1.05,.5),(.85,.5))]:ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','lw':1.2})
save(fig,2)

b=pd.read_csv(R/'baseline_results.csv');o=pd.read_csv(R/'oracle_static_results.csv')
b=pd.concat([b[b.method.isin(['B3','B4','B5','EASE-6G'])],o[o.method=='Oracle-KA']])
p=b.pivot(index='uc',columns='method',values='carbon_mg')[['B3','B4','B5','EASE-6G','Oracle-KA']]
ax=p.plot.bar(figsize=(8.2,4.2),rot=0,color=['#005AFF','#23ABB6','#37CC73','#7D33F2','#F7B737'])
ax.set(xlabel='Service profile',ylabel='Carbon (mg CO$_2$/inference)');ax.legend(ncol=3,fontsize=9);save(ax.figure,3)

d=pd.read_csv(R/'trace_simulation_paths.csv');d['ec']=d.ease_carbon_mg_per_inf*d.rate_inf_per_s*3600;d['bc']=d.b5_carbon_mg_per_inf*d.rate_inf_per_s*3600
s=d.groupby(['window','seed'])[['ec','bc']].sum();s['r']=100*(s.bc-s.ec)/s.bc
order=[w[0] for w in model.TRACE_WINDOWS];vals=s.groupby('window').r.mean().reindex(order)
fig,ax=plt.subplots(figsize=(8.2,3.6));ax.scatter(range(3),vals,color='#005AFF',s=65,zorder=3);ax.axhline(0,color='#888888',lw=.8)
ax.set(xticks=range(3),xticklabels=[x.replace(' 2026','') for x in order],xlim=(-.45,2.45),ylim=(-.5,1.1),ylabel='Carbon reduction versus B5 (%)')
for i,v in enumerate(vals):ax.text(i,v+.10,f'{v:.2f}%\nUC3 and UC4:\n0 different-tier hours',ha='center',fontsize=9)
save(fig,4)

seasonal=pd.read_csv(R/'seasonal_operational_intensity_window_summary.csv')
fig,ax=plt.subplots(figsize=(8.2,4.3))
for w,c in zip(order,['#005AFF','#23ABB6','#7D33F2']):
 d=seasonal[seasonal.window==w];ax.plot(d.chi_GFLOP_per_Mbit,d.reduction_mean_percent,'o-',label=w,color=c,lw=1.6)
ax.axvline(.03625,color='#777777',ls=':',label='Reference UC4');ax.set(xscale='log',xlabel=r'Effective operational intensity $\chi$ (GFLOP/Mbit)',ylabel='Seasonal carbon reduction versus B5 (%)');ax.grid(alpha=.2);ax.legend(fontsize=9);save(fig,5)

static=pd.read_csv(R/'operational_intensity_static_grid.csv');ce,cc=intensity.crossover(intensity.mean_ci())
fig,(a,b)=plt.subplots(2,1,figsize=(8.4,5.8),sharex=True,gridspec_kw={'height_ratios':[1,1.35]})
x=static.chi_GFLOP_per_Mbit
for col,label,offset,marker in [('B5','B5',-.08,'o'),('EASE','EASE-6G',0,'s'),('Oracle_KA','Oracle-KA',.08,'^')]:
 a.plot(x,static[col+'_tier'].map({'T2':0,'T3':1})+offset,label=label,marker=marker,markevery=30,markersize=3,lw=1.3)
a.set(yticks=[0,1],yticklabels=['T2','T3'],ylabel='Selected tier');a.legend(ncol=3,fontsize=9,loc='lower left')
b.plot(x,static.carbon_reduction_vs_B5_percent,color='#7D33F2',lw=2);b.set(xlabel=r'Effective operational intensity $\chi$ (GFLOP/Mbit)',ylabel='Carbon reduction versus B5 (%)')
for ax in [a,b]:
 ax.set_xscale('log');ax.axvline(ce,color='#F7B737',ls='--');ax.axvline(cc,color='#E23B3B',ls='--');ax.axvline(.03625,color='#777777',ls=':');ax.grid(alpha=.2)
for v,label in [(ce,'Energy crossover'),(cc,'Carbon crossover'),(.03625,'Reference UC4')]:b.text(v,19,label,rotation=90,ha='right',va='top',fontsize=9)
save(fig,6)

d=pd.read_csv(R/'communication_transport_sensitivity_81_scenarios_detail.csv')
ref={'payload_scale':1.,'rho_B':.6,'tx_power_scale':1.,'transport_scale':1.}
settings=[('payload_scale','(a) Payload','Payload multiplier'),('rho_B','(b) Effective access bandwidth',r'Effective-rate factor $\rho_B$'),('tx_power_scale','(c) Access transmission power','Power multiplier'),('transport_scale','(d) Transport energy per bit','Transport-intensity multiplier')]
base=d[np.logical_and.reduce([np.isclose(d[k],v) for k,v in ref.items()])].set_index('uc').EASE_comm_energy_J_per_inf
assert len(base)==4
fig,axes=plt.subplots(2,2,figsize=(8.2,4.2),sharey=True)
records=[]
for ax,(key,title,xlabel) in zip(axes.flat,settings):
 s=d[np.logical_and.reduce([np.isclose(d[k],v) for k,v in ref.items() if k!=key])].copy()
 assert len(s)==12
 curves={}
 for uc in ['UC1','UC2','UC3','UC4']:
  g=s[s.uc==uc].sort_values(key);assert len(g)==3
  x=g[key].to_numpy();y=100*(g.EASE_comm_energy_J_per_inf.to_numpy()/base[uc]-1);curves[uc]=(x,y)
  for xv,yv in zip(x,y):records.append({'parameter':key,'value':xv,'uc':uc,'communication_energy_change_percent':yv})
 assert np.allclose(curves['UC1'][1],curves['UC2'][1]) and np.allclose(curves['UC1'][1],curves['UC3'][1])
 for uc,label,color,marker,style in [('UC1','UC1–UC3','#005AFF','o','-'),('UC4','UC4','#E23B3B','s','--')]:
  x,y=curves[uc];ax.plot(x,y,label=label,color=color,marker=marker,ls=style,lw=1.4,markersize=5,markerfacecolor='none' if uc=='UC4' else color)
 ax.set_title(title,fontsize=10);ax.set_xlabel(xlabel,fontsize=9);ax.set_xticks(x);ax.axhline(0,color='#999999',lw=.6);ax.grid(alpha=.18);ax.tick_params(labelsize=9)
for ax in axes[:,0]:ax.set_ylabel('Communication energy change (%)',fontsize=9)
handles,labels=axes.flat[0].get_legend_handles_labels();fig.legend(handles,labels,loc='upper center',ncol=2,frameon=False,bbox_to_anchor=(.5,1.02),fontsize=10)
fig.tight_layout(rect=(0,0,1,.95));fig.savefig(F/'fig7_submission.png',dpi=300,bbox_inches='tight');plt.close(fig)
pd.DataFrame(records).to_csv(R/'figure7_one_parameter_slices.csv',index=False)
print('Generated seven figures from rerun CSV outputs.')
