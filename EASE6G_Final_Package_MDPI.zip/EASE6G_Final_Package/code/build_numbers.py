#!/usr/bin/env python3
"""Collect every number, table and figure used by the revised manuscript into build/numbers.json and figures_v2/."""
import io, contextlib, itertools, json
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
with contextlib.redirect_stdout(io.StringIO()):
    import ease6g_v2 as m
    import ease6g_6g_extensions as x
ROOT = Path(__file__).resolve().parent.parent; BUILD = ROOT / "build"; FIG = ROOT / "figures_v2"
S = json.loads((ROOT / "results/v2/v2_summary.json").read_text()); X = json.loads((ROOT / "results/v2_6g/v2_6g_summary.json").read_text())
V = {}; T = {}
POL = ["EASE", "B3", "B4", "B5", "Emin", "Oracle-KA"]

# ---- static
st = pd.DataFrame(S["static"]).set_index("uc"); V["static"] = st.to_dict("index")
bl = pd.read_csv(ROOT / "results/v2/baselines.csv")
means = bl.groupby("method")[["E_total_J", "carbon_mg"]].mean(); V["means"] = means.to_dict("index")
SW = S["static_weighted"]; V["static_weighted"] = SW; V["volume_share"] = S["volume_share"]
for b in ("B3", "B4", "B5", "Emin"):
    V[f"static_red_{b}"] = SW["EASE"]["red_vs_" + b]; V[f"static_dE_{b}"] = SW["EASE"]["dE_vs_" + b]                       # volume-weighted (headline)
    V[f"unw_red_{b}"] = 100 * (1 - means.loc["EASE", "carbon_mg"] / means.loc[b, "carbon_mg"]); V[f"unw_dE_{b}"] = 100 * (means.loc["EASE", "E_total_J"] / means.loc[b, "E_total_J"] - 1)
V["placements"] = bl.pivot(index="uc", columns="method", values="placement").to_dict("index")
V["acc_gap"] = S["accuracy_enforcement_gap_percent"]
piv = bl.pivot(index="uc", columns="method", values="carbon_mg"); V["carbon_by_method"] = piv.to_dict("index")
V["uc5_red_B3"] = 100 * (1 - piv.loc["UC5", "EASE"] / piv.loc["UC5", "B3"]); V["uc5_red_B5"] = 100 * (1 - piv.loc["UC5", "EASE"] / piv.loc["UC5", "B5"]); V["uc5_red_Emin"] = 100 * (1 - piv.loc["UC5", "EASE"] / piv.loc["UC5", "Emin"])
V["uc4_red_Emin"] = 100 * (1 - piv.loc["UC4", "EASE"] / piv.loc["UC4", "Emin"]); _wn = {u: V["volume_share"][u] for u in m.SERV if u != "UC5"}
V["static_red_Emin_noUC5"] = 100 * (1 - sum(_wn[u] * piv.loc[u, "EASE"] for u in _wn) / sum(_wn[u] * piv.loc[u, "Emin"] for u in _wn))
V["abs_ug_EASE"] = 1000 * SW["EASE"]["carbon_mg"]; V["abs_ug_Emin"] = 1000 * SW["Emin"]["carbon_mg"]
pe = bl.pivot(index="uc", columns="method", values="E_total_J"); V["energy_by_method"] = pe.to_dict("index"); V["uc5_dE_B3"] = 100 * (pe.loc["UC5", "EASE"] / pe.loc["UC5", "B3"] - 1); V["uc5_dE_B5"] = 100 * (pe.loc["UC5", "EASE"] / pe.loc["UC5", "B5"] - 1)
V["ablation"] = S["ablation"]; V["weight_counts"] = S["weight_sweep_static_counts"]; V["capacity"] = S["capacity"]; V["sim"] = S["controlled_sim_tier_hours_mean_sd"]
V["CI"] = S["settings"]["reference_CI_kg_per_kWh"]; V["sens"] = S["sensitivity"]; V["milp"] = S["milp_scaling"]; V["comm"] = S["comm_sensitivity"]
# ---- seasonal reference
sr = pd.DataFrame(S["seasonal_reference"]); V["seasonal"] = sr.to_dict("records"); V["tier_hours"] = S["seasonal_reference_tier_hours"]
# ---- mappings
cells = pd.read_csv(ROOT / "results/v2/mapping_trace_cells.csv"); mst = pd.read_csv(ROOT / "results/v2/mapping_static.csv")
V["mapdist"] = S["mapping_distribution"]; V["mapstatic"] = S["mapping_static"]; V["uc3_worst"] = S["UC3_worst_mapping"]; V["mapw"] = S["mapping_static_weighted"]
mw = pd.read_csv(ROOT / "results/v2/mapping_static_weighted.csv")
perms = list(itertools.permutations(m.REGIONS)); mapping_of = {i + 1: dict(zip(m.TIER[:4], p)) for i, p in enumerate(perms)}
rule_ids = [i for i, mp in mapping_of.items() if mp["T1"] == "North Scotland"]; old_id = [i for i, mp in mapping_of.items() if all(mp[t] == m.OLDMAP[t] for t in m.TIER[:4])][0]
ref_id = [i for i, mp in mapping_of.items() if all(mp[t] == m.REFMAP[t] for t in m.TIER[:4])][0]
def static_red(mid, b):
    g = mst[mst.mapping_id == mid]; return 100 * (1 - g.C_EASE.mean() / g["C_" + b].mean()), 100 * (g.E_EASE.mean() / g["E_" + b].mean() - 1), 100 * (g.C_EASE.mean() / g["C_Oracle-KA"].mean() - 1)
rr = []
for i in rule_ids:
    a = static_red(i, "B3"); c5 = cells[(cells.mapping_id == i) & (cells.scope == "all")].set_index("window")
    rr.append(dict(mapping_id=i, T4=mapping_of[i]["T4"], T3=mapping_of[i]["T3"], T2=mapping_of[i]["T2"], static_red_B3=a[0], static_dE_B3=a[1], static_gap=a[2], static_red_B5=static_red(i, "B5")[0],
                   winter=c5.loc["Winter 2026", "red_vs_B3"], spring=c5.loc["Spring 2026", "red_vs_B3"], summer=c5.loc["Summer 2026", "red_vs_B3"], spring_dE=c5.loc["Spring 2026", "dE_vs_B3"], max_gap=c5.gap_vs_oracle.max()))
V["rule6"] = rr; rd = pd.DataFrame(rr)
mw["user"] = [mapping_of[i]["T4"] for i in mw.mapping_id]; cw = cells[cells.scope == "all"].copy(); cw["user"] = [mapping_of[i]["T4"] for i in cw.mapping_id]
grp = []
for ug in ["London", "South East England", "East England", "North Scotland", "All"]:
    g = mw if ug == "All" else mw[mw.user == ug]; c = cw if ug == "All" else cw[cw.user == ug]
    grp.append(dict(user=ug, n=len(g), b3_min=g.red_vs_B3.min(), b3_max=g.red_vs_B3.max(), b5_pos=int((g.red_vs_B5 > 1e-9).sum()), b5_max=g.red_vs_B5.max(),
                    em_pos=int((g.red_vs_Emin > 1e-9).sum()), em_min=float(g.red_vs_Emin.min()), em_max=float(g.red_vs_Emin.max()), dEm_max=float(g.dE_vs_Emin.max()),
                    sea_em_pos=int((c.C_Emin - c.C_EASE > 1e-9).sum()), sea_kg_em=float((c.C_Emin - c.C_EASE).mean()), sea_kg_em_max=float((c.C_Emin - c.C_EASE).max()), b5_min_pos=float(g.red_vs_B5[g.red_vs_B5 > 1e-9].min()) if (g.red_vs_B5 > 1e-9).any() else 0.0, b3_median=float(g.red_vs_B3.median()), dE5_max=g.dE_vs_B5.max(), gap_max=g.gap_vs_oracle.max(),
                    sea_b5_pos=int((c.C_B5 - c.C_EASE > 1e-9).sum()), sea_cells=len(c), sea_kg_b5=float((c.C_B5 - c.C_EASE).mean()), sea_dE5_max=float(c.dE_vs_B5.max())))
V["by_user"] = grp
ows = mw.loc[mw.gap_vs_oracle.idxmax()]; V["oracle_worst_static"] = dict(mapping=mapping_of[int(ows.mapping_id)], gap=float(ows.gap_vs_oracle), oracle_dE=float(100 * (ows["E_Oracle-KA"] / ows.E_EASE - 1)))
z = cw[(cw.C_EASE < 1e-3)]; V["zero_cells"] = dict(n=int(len(z)), users=sorted(set(z.user)), windows=sorted(set(z.window)), kg_b5_min=float((z.C_B5 - z.C_EASE).min()) if len(z) else 0.0, kg_b5_max=float((z.C_B5 - z.C_EASE).max()) if len(z) else 0.0)
V["seasonal_emin"] = dict(pos=int((cw.C_Emin - cw.C_EASE > 1e-9).sum()), neg=int((cw.C_Emin - cw.C_EASE < -1e-9).sum()), kg_mean=float((cw.C_Emin - cw.C_EASE).mean()), kg_max=float((cw.C_Emin - cw.C_EASE).max()))
V["seasonal_b5"] = dict(pos=int((cw.C_B5 - cw.C_EASE > 1e-9).sum()), neg=int((cw.C_B5 - cw.C_EASE < -1e-9).sum()), kg_mean=float((cw.C_B5 - cw.C_EASE).mean()), kg_max=float((cw.C_B5 - cw.C_EASE).max()))
V["rule6_static_min"], V["rule6_static_max"] = rd.static_red_B3.min(), rd.static_red_B3.max(); V["rule6_static_dE"] = rd.static_dE_B3.mean()
V["rule6_ws_min"], V["rule6_ws_max"] = rd[["winter", "summer"]].min().min(), rd[["winter", "summer"]].max().max(); V["rule6_spring"] = sorted(rd.spring.tolist())
o = static_red(old_id, "B3"); oc = cells[(cells.mapping_id == old_id) & (cells.scope == "all")]
V["old_map"] = dict(static_red_B3=o[0], static_red_B5=static_red(old_id, "B5")[0], seasonal_red_B3=oc.red_vs_B3.tolist(), seasonal_red_B5=oc.red_vs_B5.tolist())
allst = [static_red(i, "B3") for i in mapping_of]; V["all24_static_red_B3"] = dict(min=min(a[0] for a in allst), max=max(a[0] for a in allst), median=float(np.median([a[0] for a in allst])), positive=int(sum(a[0] > 1e-9 for a in allst)), negative=int(sum(a[0] < -1e-9 for a in allst)), max_gap=max(a[2] for a in allst))
# UC3: weight ratio closing the worst-mapping gap
mp = dict(mapping_of[int(V["uc3_worst"]["mapping_id"])]); mp["T5"] = mp["T4"]; cs = m.ci_static(mp); flip = None
for wc in np.arange(0.40, 0.8001, 0.001):
    d = m.decide(m.B["UC3"], cs, (0.8 - wc, wc, 0.2))
    if d["EASE"]["i"][0] == d["Oracle-KA"]["i"][0]: flip = wc; break
V["uc3_flip_wC"] = flip; V["uc3_flip_ratio"] = None if flip is None else flip / (0.8 - flip)
# ---- envelope and crossover
env = pd.DataFrame(S["envelope"]["table"]); V["env"] = {k: v for k, v in S["envelope"].items() if k != "table"}; V["xrange"] = S["crossover_range"]
se = env[env.window != "static mean"]; V["env_max_row"] = se.loc[se.reduction_vs_Emin_percent.idxmax()].to_dict(); pos = se[se.reduction_vs_Emin_percent > 1e-9]
V["env_pos_dE_min"], V["env_pos_dE_max"] = float(pos.energy_change_vs_Emin_percent.min()), float(pos.energy_change_vs_Emin_percent.max()); V["env_gap_max"] = float(se.gap_vs_oracle_percent.max())
V["env_static"] = env[env.window == "static mean"][["chi", "EASE", "B5", "Emin", "oracle", "reduction_vs_B5_percent", "reduction_vs_Emin_percent", "energy_change_vs_Emin_percent", "gap_vs_oracle_percent"]].to_dict("records")
V["env_b5_summer_uc4"] = float(env[(env.window == "Summer 2026") & ((env.chi - m.CHI_UC4).abs() < 1e-3)].reduction_vs_B5_percent.iloc[0])
V["sixg"] = X
(BUILD / "numbers.json").write_text(json.dumps(V, indent=1, default=float))

# ================= markdown tables
def grid(header, rows, widths):
    hd = lambda h: h if h.startswith("$") else "**" + h + "**"
    return "\n".join(["| " + " | ".join(hd(h) for h in header) + " |", "|" + "|".join("-" * max(3, w) for w in widths) + "|"] + ["| " + " | ".join(str(c) for c in r) + " |" for r in rows])
def _grid_old(header, rows, widths):
    """pandoc multiline table."""
    def cell(s, w): return str(s).ljust(w)
    line = "  " + "-" * (sum(widths) + len(widths) - 1); sep = "  " + " ".join("-" * w for w in widths)
    out = [line, "  " + " ".join(cell("**" + h + "**" if not h.startswith("$") else h, w) for h, w in zip(header, widths)), sep]
    for r in rows: out += ["  " + " ".join(cell(c, w) for c, w in zip(r, widths)), ""]
    out[-1] = line; return "\n".join(out)
f6 = lambda v: f"{v:.6f}"; pc = lambda v, d=2: f"{v:.{d}f}%"; sg = lambda v, d=2: f"{v:+.{d}f}%"
mj = lambda v: f"{1000 * v:.3f}"; ug = lambda v: f"{1000 * v:.3f}"
_v5 = {u: [u, r.placement, f"{r.chi_GFLOP_per_Mbit:.2f}", mj(r.E_compute_J), mj(r.E_comm_J), mj(r.E_total_J), ug(r.carbon_mg), r.feasible_tiers.replace(",", ", "), f"{100 * V['volume_share'][u]:.1f}%"] for u, r in st.iterrows()}
for u in S["unserved"]: _v5[u] = [u, "None", "--", "--", "--", "--", "--", "None", "Unserved"]
T["V"] = grid(["UC", "Placement", "χ (GFLOP/Mbit)", "Compute E (mJ)", "Comm. E (mJ)", "Total E (mJ)", "Carbon (µg CO₂)", "Feasible tiers", "Share of requests"],
              [_v5[u] for u in m.SERV_ALL], [6, 12, 16, 15, 13, 13, 17, 16, 18])
interp = {"B3": "Latency-first: lowest effective latency", "B4": "Latency--energy minimizer", "B5": "Carbon-unaware weighted counterpart (0.80/0.20)", "Emin": "Minimum energy under all gates (primary comparator)", "EASE": "Weighted energy--carbon--KPI policy", "Oracle-KA": "Myopic minimum carbon under all gates"}
T["VI"] = grid(["Method", "E (mJ/inf.)", "Carbon (µg CO₂/inf.)", "EASE-6G carbon saving", "UC4", "UC5", "Interpretation"],
               [["EASE-6G" if p == "EASE" else ("E-min" if p == "Emin" else p), mj(SW[p]["E_J"]), ug(SW[p]["carbon_mg"]), "--" if p == "EASE" else pc(100 * (1 - SW["EASE"]["carbon_mg"] / SW[p]["carbon_mg"]), 1),
                 V["placements"]["UC4"][p], V["placements"]["UC5"][p], interp[p]] for p in ("B3", "B4", "B5", "Emin", "EASE", "Oracle-KA")], [11, 12, 20, 18, 8, 8, 38])
T["VII"] = grid(["UC", "EASE-6G", "Oracle-KA", "EASE-KA gap", "Oracle-K", "Accuracy-enforcement gap"],
                [[u, V["placements"][u]["EASE"], V["placements"][u]["Oracle-KA"], pc(100 * (piv.loc[u, "EASE"] / piv.loc[u, "Oracle-KA"] - 1)), V["placements"][u]["Oracle-K"], pc(V["acc_gap"][u])] for u in m.SERV], [6, 10, 11, 13, 10, 26])
T["VIII"] = grid(["Configuration", "Placements (UC2--UC5)", "Accuracy-invalid selections"],
                 [[a["configuration"], ", ".join(a[u] for u in m.SERV), a["accuracy_invalid"]] for a in V["ablation"]], [18, 38, 28])
s5 = sr[sr.scope == "all"].set_index("window"); th = pd.read_csv(ROOT / "results/v2/reference_trace_tier_hours.csv").set_index(["window", "uc"])
def ohrs(w, u): return ", ".join(f"{k}:{v}" for k, v in sorted(json.loads(th.loc[(w, u), "Oracle-KA_tier_hours"]).items()))
def hrs(w, u): return ", ".join(f"{k}:{v}" for k, v in sorted(json.loads(th.loc[(w, u), "EASE_tier_hours"]).items()))
T["IX"] = grid(["Window", "UC4 tier-hours", "UC5 tier-hours", "EASE-6G (kg CO₂)", "Saved vs E-min (kg CO₂)", "Carbon saved vs E-min", "Energy vs E-min", "Carbon saved vs B3", "Energy vs B3", "Gap to Oracle-KA"],
               [[w.split()[0], hrs(w, "UC4"), hrs(w, "UC5"), f"{s5.loc[w, 'C_EASE']:.2f}", f"{s5.loc[w, 'C_Emin'] - s5.loc[w, 'C_EASE']:.2f}", pc(s5.loc[w, "red_vs_Emin"], 1), sg(s5.loc[w, "dE_vs_Emin"], 1), pc(s5.loc[w, "red_vs_B3"], 1), sg(s5.loc[w, "dE_vs_B3"], 1), pc(s5.loc[w, "gap_vs_oracle"])] for w in ("Winter 2026", "Spring 2026", "Summer 2026")], [8, 15, 22, 16, 18, 9, 14, 8, 13, 16])
sh = lambda r: r.replace("South East England", "SE England").replace("East England", "E England")
T["X"] = grid(["User grid (T4, T5)", "Mappings", "Static vs B3", "Static vs E-min", "Energy vs E-min (max)", "Static gap to Oracle-KA (max)", "Trace cells below E-min", "Weekly saving vs E-min, mean (max) (kg CO₂)"],
              [[sh(g["user"]) if g["user"] != "All" else "All mappings", g["n"], f"{g['b3_min']:.1f} to {g['b3_max']:.1f}%", f"{g['em_min']:.1f} to {g['em_max']:.1f}%", sg(g["dEm_max"], 1),
                f"{g['gap_max']:.1f}%", f"{g['sea_em_pos']} of {g['sea_cells']}", f"{g['sea_kg_em']:.2f} ({g['sea_kg_em_max']:.2f})"] for g in grp], [20, 12, 14, 18, 18, 24, 18, 30])
def envcell(w, chi):
    r = env[(env.window == w) & (env.chi == chi)].iloc[0]
    if w == "static mean": return f"{r.reduction_vs_Emin_percent:.2f}% ({'disagree' if r.hours_in_disagreement else 'agree'}; {r.energy_change_vs_Emin_percent:+.1f}% E)"
    return f"{r.reduction_vs_Emin_percent:.2f}% ({int(r.hours_differ_Emin)}/{int(r.hours_in_disagreement)} h; {r.energy_change_vs_Emin_percent:+.1f}% E)"
xE, xC = V["env"]["chi_E_T2_T3"], V["env"]["chi_C_T2_T3_mean"]
def regime(chi): return "Below both" if chi < min(xE, xC) else ("Between crossovers" if chi < max(xE, xC) else "Above both")
T["XI"] = grid(["χ (GFLOP/Mbit)", "Mean intensity", "Winter", "Spring", "Summer"],
               [[(f"{c:.2f} (UC4)" if abs(c - m.CHI_UC4) < 1e-3 else f"{c:g}"), envcell("static mean", c), envcell("Winter 2026", c), envcell("Spring 2026", c), envcell("Summer 2026", c)] for c in sorted(env.chi.unique())], [16, 26, 27, 27, 27])
def fx(v): return "None" if v is None else f"{v:.2f}"
def chi_dev(ee_n, t=1):                                     # energy crossover of network tier t against the device (UC4 access); access does not cancel here
    d = m.PUE[4] / m.EE[4] - m.PUE[t] / ee_n; return (m.eacc + m.EPS[t] * 1e-3) / d if d > 0 else None
for c in V["xrange"]["cases"]: c["chi_dev_T2"] = chi_dev(c["EE_T2"], 1)
V["chi_dev"] = {f"T{t + 1}_{ee}": chi_dev(ee, t) for t in (0, 1) for ee in (471, 730, 1274)}
T["XII"] = grid(["Efficiency case (basis)", "EE(T2)", "EE(T3)", "EE ratio", "Energy crossover χE", "Mean-carbon crossover χC", "T2 vs device crossover"],
                [[c["case"], c["EE_T2"], c["EE_T3"], f"{c['ratio']:.3f}", fx(c["chi_E"]), fx(c["chi_C_mean"]), fx(c["chi_dev_T2"])] for c in V["xrange"]["cases"]], [26, 8, 8, 10, 20, 26, 22])
x2 = pd.DataFrame(X["X2"])
xb = X["X2b"]
T["XV"] = grid(["Scenario", "Reference mapping, spring vs E-min", "Mappings with static saving vs E-min (of 24)", "Static saving vs E-min, median (max)", "Trace cells below E-min (of 72)", "Mean saving vs E-min (kg CO₂/week)", "Largest energy cost vs E-min"],
                [[s_, pc(x2[(x2.scenario == s_) & (x2.window == "Spring 2026")].red_vs_Emin_percent.iloc[0], 1), xb[s_]["static_positive_Emin"], f"{xb[s_]['static_median_Emin']:.1f}% ({xb[s_]['static_max_Emin']:.1f}%)", xb[s_]["cells_positive_Emin"], f"{xb[s_]['kg_saved_mean_Emin']:.3f}", sg(xb[s_]["dE_max_Emin"], 1)] for s_ in x2.scenario.unique()],
                [26, 18, 22, 22, 16, 20, 18])
# ---- Table XIII: conditions for the headline saving (static, volume-weighted, against E-min)
sn_ = S["sensitivity"]; _ci = m.CS[0]; _cu = _ci[m.USER]
def _cx(ee=None, mscale=1.0, uniform=False):
    ee = m.EE if ee is None else np.asarray(ee, float); a = m.PUE / ee; b = m.EPS * 1e-3 * mscale; ci = np.full(m.NT, 0.394) if uniform else _ci; cu = ci[m.USER]
    xe = (b[1] - b[2]) / (a[2] - a[1]) if a[2] > a[1] else None
    al = ci * a; be = cu * m.eacc + b * (m.PHI * ci + (1 - m.PHI) * cu); xc = (be[2] - be[1]) / (al[1] - al[2]) if al[1] != al[2] else None
    return xe, (xc if xc is not None and xc > 0 else None)
_rows13 = []
def _r13(label, v, chi, ee=None, mscale=1.0, uniform=False, kind="Emin"):
    xe, xc = _cx(ee, mscale, uniform); sea_ = v["seasonal_red_vs_Emin"]
    _rows13.append([label, f"{chi:.1f}", "--" if xc is None else f"{xc:.1f}", "None" if xe is None else f"{xe:.1f}", f"{v['Emin_placements']['UC4'].split('-')[0]} / {v['placements']['UC4'].split('-')[0]}",
                    pc(v["static_red_vs_Emin"], 1), sg(v["static_dE_vs_Emin"], 1), f"{min(sea_.values()):.1f} to {max(sea_.values()):.1f}%"])
ep_, st_, km_, pl_ = sn_["efficiency_profiles_savings"], sn_["single_tier_efficiency_savings"], sn_["efficiency_level_x_path_savings"], sn_["payload_kB_savings"]
_r13("Reference (730 GFLOP/J at T1--T4; 15 kB)", ep_["reference (730 all servers)"], m.CHI_UC4)
for kb in ("10", "20"): _r13(f"Payload {kb} kB", pl_[kb], 2.9 / (float(kb) * 8e-3))
for t_, f_ in (("T2", "0.9"), ("T2", "1.05"), ("T3", "0.95"), ("T3", "1.1")):
    ee_ = m.EE.copy(); ee_[int(t_[1]) - 1] *= float(f_); _r13(f"{t_} efficiency ×{f_}", st_[f"{t_} x{f_}"], m.CHI_UC4, ee_)
for lab_, key_, v_ in (("T1--T2 1,274, T3--T4 471 GFLOP/J", "server high T1-T2 / low T3-T4 (1274/471)", (1274, 471, 461)), ("T1--T2 471, T3--T4 1,274 GFLOP/J", "server low T1-T2 / high T3-T4 (471/1274)", (471, 1274, 461)),
                       ("All servers 1,274 GFLOP/J", "server high all (1274)", (1274, 1274, 461)), ("All servers 471 GFLOP/J", "server low all (471)", (471, 471, 461)), ("Device 613 GFLOP/J", "server mid / module mid (730/730, T5 613)", (730, 730, 613))):
    _r13(lab_, ep_[key_], m.CHI_UC4, np.r_[v_[0], v_[0], v_[1], v_[1], v_[2]])
_r13("Previous profile (500/350/275/200)", ep_["previous profile (500/350/275/200)"], m.CHI_UC4, np.r_[500.0, 350.0, 275.0, 200.0, m.EE[4]])
for km in ("0.5|1.0", "1.0|2.0"):
    k_, mm_ = map(float, km.split("|")); _r13(f"Efficiency ×{k_:g}, path energy ×{mm_:g}", km_[km], m.CHI_UC4, m.EE * k_, mm_)
# ---- review checks (final review, comments A-E): benchmark basis and server-only efficiency rows
RC = json.loads((ROOT / "results/v2/review_checks.json").read_text()); V["rc"] = RC
def _adapt(b): return dict(seasonal_red_vs_Emin=b["seasonal"], Emin_placements=b["Emin"], placements=b["EASE"], static_red_vs_Emin=b["red"], static_dE_vs_Emin=b["dE"])
_lb = RC["B_latency_bound"]; _ee_lb = np.r_[np.full(4, _lb["EE_server"]), _lb["EE_device"]]
_r13(f"Latency-bound basis ({_lb['EE_server']:.0f} GFLOP/J at T1--T4, {_lb['EE_device']:.0f} at T5)", _adapt(_lb["efficiencies_only"]), m.CHI_UC4, _ee_lb)
_r13("Latency-bound basis with measured server latency (UC4, UC5 served)", _adapt(_lb["with_measured_latency"]), m.CHI_UC4, _ee_lb)
for k_ in ("0.9", "0.85"): _r13(f"T1--T4 efficiency ×{k_}, device unchanged", _adapt(RC["B_derating"]["table"][k_]), m.CHI_UC4, np.r_[m.EE[:4] * float(k_), m.EE[4]])
_r13("Uncompressed payload (1.2 Mbit)", {**sn_["variants"]["uncompressed payload (1.2 Mbit)"], "seasonal_red_vs_Emin": {k_: v_["red_vs_Emin"] for k_, v_ in sn_["variants"]["uncompressed payload (1.2 Mbit)"]["seasonal"].items()}}, 2.9 / 1.2)
_r13("Uniform intensity in every region", {**sn_["variants"]["uniform intensity in every region (marginal-unit proxy)"], "seasonal_red_vs_Emin": {k_: v_["red_vs_Emin"] for k_, v_ in sn_["variants"]["uniform intensity in every region (marginal-unit proxy)"]["seasonal"].items()}}, m.CHI_UC4, uniform=True)
T["XIII"] = grid(["Variant", "χ (UC4)", "χC (T2/T3)", "χE (T2/T3)", "UC4: E-min / EASE-6G", "Static saving vs E-min", "Energy vs E-min", "Weekly saving vs E-min (three windows)"], _rows13, [36, 8, 10, 10, 16, 18, 14, 22])
_all35 = [(k_, v_) for blk_ in ("efficiency_profiles_savings", "single_tier_efficiency_savings", "efficiency_level_x_path_savings", "payload_kB_savings") for k_, v_ in sn_[blk_].items()]
_dis = [v_["static_red_vs_Emin"] for k_, v_ in _all35 if v_["Emin_placements"]["UC4"].split("-")[0] != v_["Oracle_placements"]["UC4"].split("-")[0]]
_agr = [v_["static_red_vs_Emin"] for k_, v_ in _all35 if v_["Emin_placements"]["UC4"].split("-")[0] == v_["Oracle_placements"]["UC4"].split("-")[0]]
V["variants35"] = dict(n=len(_all35), n_dis=len(_dis), dis_min=min(_dis), dis_max=max(_dis), n_agr=len(_agr), agr_min=min(_agr), agr_max=max(_agr))
V["band"] = S["disagreement_band_UC4"]; V["xwin"] = S["crossover_by_window"]; V["oracleEmin24"] = S["oracle_vs_Emin_24"]
V["b5w"] = sn_["B5_headroom_weight"]; V["b5margin"] = sn_["UC4_B5_margin"]; V["no_floor_maps"] = S["no_floor_mappings"]; V["floor"] = S["floor_stats"]
V["env_maxdE_row"] = pos.loc[pos.energy_change_vs_Emin_percent.idxmax()].to_dict(); _ns = se[(se.reduction_vs_Emin_percent <= 1e-9) & (se.hours_in_disagreement > 0)]; V["env_nosave_maxD"] = int(_ns.hours_in_disagreement.max())
V["sw_Emin_pl"] = {u: V["placements"][u]["Emin"] for u in m.SERV}
V["km"] = {k_: v_["static_red_vs_Emin"] for k_, v_ in km_.items()}; V["payload_range"] = [min(v_["static_red_vs_Emin"] for v_ in pl_.values()), max(v_["static_red_vs_Emin"] for v_ in pl_.values())]
V["payload_b5"] = {k_: v_["static_red_vs_B5"] for k_, v_ in pl_.items()}
reg = m.REFMAP
T["II"] = grid(["Tier", "Name", "PUE", "Grid region", "CI (kg CO₂/kWh)", "L (ms)", "B (Gbit/s)", "R", "J (ms)", "EE (GFLOP/J)", "r (GFLOP/s)", "$\\text{CAP}_{\\text{AI}}$ **(GFLOP/s)**", "εₜ (nJ/bit)"],
               [[t, n, f"{m.PUE[i]:.2f}", reg[t], f"{V['CI'][t]:.4f}", f"{m.LAT[i]:g}", f"{m.BW[i]:g}", f"{m.REL[i]:.5f}", f"{m.JIT[i]:g}", f"{m.EE[i]:g}", f"{m.RATE[i]:,.0f}", "Per device" if not np.isfinite(m.CAPV[i]) else f"{m.CAPV[i]:,.0f}", f"{m.EPS[i]:g}"] for i, (t, n) in enumerate(zip(m.TIER, ["Remote Cloud", "Regional Edge", "Metro Edge", "Far Edge", "On-Device"]))], [7, 13, 7, 16, 14, 7, 10, 12, 7, 12, 12, 16, 11])
names = {"UC1": "Ultra-low-latency control (manufacturing example)", "UC2": "Mobility-critical service (vehicle example)", "UC3": "High-reliability interactive service (clinical example)", "UC4": "High-throughput video-analytics service", "UC5": "Interactive visual recognition"}
T["IV"] = grid(["UC", "Name", "$L_{\\text{max}}$ **(ms)**", "$B_{\\text{min}}$ **(Gbit/s)**", "$R_{\\text{min}}$", "$J_{\\text{max}}$ **(ms)**", "$\\text{Acc}_{\\text{min}}$", "Payload (Mbit/inf.)", "Access (Gbit/s; W)"],
               [[r.uc, names[r.uc], f"{r.Lmax_ms:g}", f"{r.Bmin_Gbps:g}", f"{r.Rmin:.5f}", f"{r.Jmax_ms:g}", "None" if pd.isna(r.Accmin_percent) else f"{r.Accmin_percent:g}%", f"{r.payload_Mbit:g}", f"{r.access_bandwidth_Gbps:g}; {r.access_tx_power_W:g}"] for r in m.UC.itertuples()], [9, 66, 26, 30, 18, 26, 28, 21, 20])
V["rates"] = dict(peak=m.PEAK, stress=m.STRESS); V["served"] = S["served"]; V["unserved"] = S["unserved"]
V["frontier"] = S["weight_frontier"]; V["oracle24"] = S["oracle_vs_B5_24"]; V["trace_cap"] = S["trace_capacity"]; V["simpol"] = S["controlled_sim_policies"]
V["rob"] = S["robustness_review"]; V["qv"] = json.loads((ROOT / "results/v2/queue_validation.json").read_text())
V["k_star"] = m.CHI_UC4 / S["envelope"]["chi_E_T2_T3"]                                   # efficiency level (x path energy) at which chi_E reaches UC4's intensity
_rb = S["robustness_review"]; _W3 = ("Winter 2026", "Spring 2026", "Summer 2026")
def _sea3(d): return " / ".join(f"{d[w]['red_vs_Emin']:.1f}" for w in _W3)
_rr = []
for k_, lab_ in (("11 g/kWh in signal (reference)", "Floor 11 g CO₂/kWh in signal (reference)"), ("11 g/kWh in score only", "Floor 11 g CO₂/kWh in score only; unfloored accounting"),
                 ("1 g/kWh in score only", "Floor 1 g CO₂/kWh in score only; unfloored accounting"), ("no floor, zero-safe score (offset 1 g/kWh)", "No floor; zero-safe score")):
    v_ = _rb["floor"][k_]; dd = _rb["floor_decisions_differing"][k_]
    _rr.append([lab_, pc(v_["static_red_vs_Emin"], 1), _sea3(v_["seasonal"]), f"{v_['mappings']['min']:.1f} to {v_['mappings']['max']:.1f}%", f"{dd['differ']} of {dd['total']:,} decisions differ"])
for lam in ("0.75", "0.5", "0.25", "0.0"):
    v_ = _rb["marginal_blend"][lam]
    _rr.append([f"{int(float(lam) * 100)}% regional average, {100 - int(float(lam) * 100)}% marginal 0.69 kg/kWh", pc(v_["static_red_vs_Emin"], 1), _sea3(v_["seasonal"]), f"{v_['mappings']['min']:.1f} to {v_['mappings']['max']:.1f}%",
                "UC4 decided by headroom" if float(lam) == 0.25 else ("Carbon proportional to energy" if float(lam) == 0.0 else "Attribution bound")])
for sg_ in ("0.1", "0.25", "0.5"):
    v_ = _rb["forecast_error"][sg_]; _rr.append([f"Forecast error {int(float(sg_) * 100)}% (decisions on noisy signal)", "--", _sea3(v_), "--", f"Gap to Oracle-KA up to {max(x['gap_vs_oracle'] for x in v_.values()):.1f}%"])
for k_ in ("UC4 50%", "UC4 10%", "UC4 0%", "equal weights"):
    v_ = _rb["volume_mix"][k_]; _rr.append([("Equal request volumes" if k_ == "equal weights" else f"Request volume: {k_} share"), pc(v_["red_vs_Emin"], 1), "--", "--", f"Energy {v_['dE_vs_Emin']:+.1f}%"])
_ec = RC["E_capacity"]; _sw = {round(r_["load"], 2): r_ for r_ in _ec["sweep"]}
for ld_ in (0.5, 1.0):
    _rr.append([f"Shared capacity enforced, load {int(100 * ld_)}% of peak", pc(_sw[ld_]["red"], 1), "--", "--", f"Energy {_sw[ld_]['dE']:+.1f}%; E-min runs UC4 at {_sw[ld_]['Emin']['UC4'].split('-')[0]}"])
_c3 = RC["C_V3_throughput"]["rows"]["1/delta = 2.22"]
_rr.append(["V3 throughput factor 2.2 on execution time and capacity", pc(_c3["red"], 1), "--", "--", "No decision changes" if not _c3["V3_selected"] else "V3 selected"])
T["ROB"] = grid(["Check", "Static saving vs E-min", "Weekly saving vs E-min, winter / spring / summer (%)", "Mappings (static)", "Note"], _rr, [44, 14, 30, 16, 30])
_sim = pd.read_csv(ROOT / "results/v2/controlled_simulation_paths.csv"); _u3 = _sim[(_sim.uc == "UC3") & (_sim.tier == "T3")].groupby("seed").size()
V["sim_uc3_T3_range"] = [int(_u3.min()), int(_u3.max())]
V["peak_T4_load"] = float(sum(m.PEAK[u] * m.F[m.VAR.index(V["placements"][u]["EASE"].split("-")[1])] for u in m.SERV if V["placements"][u]["EASE"].startswith("T4")))
x3 = pd.DataFrame(X["X3"]); xm = pd.DataFrame(X["X3_min_rate"])
fmt_r = lambda v: "Not reachable" if (v is None or (isinstance(v, float) and np.isnan(v))) else f"{v / 1000:,.1f}"
T["XVI"] = grid(["Latency limit (ms)", "Reliability", "5G-class far edge: required rate (TFLOP/s)", "AI-RAN tier: required rate (TFLOP/s)"],
               [[f"{r.Lmax_ms:g}", "1 − 10⁻⁵" if r.reliability < 0.999999 else "1 − 10⁻⁷", fmt_r(r.far_edge_GFLOPs), fmt_r(r.airan_GFLOPs)] for r in xm.itertuples()], [18, 14, 40, 36])
(BUILD / "numbers.json").write_text(json.dumps(V, indent=1, default=float))
(BUILD / "tables.json").write_text(json.dumps(T, indent=1, ensure_ascii=False))

# ================= figures
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]; INK = "#2b2b28"; MUTED = "#6f6e68"
plt.rcParams.update({"font.family": "serif", "font.serif": ["Liberation Serif", "TeX Gyre Termes", "Times New Roman"], "mathtext.fontset": "stix", "font.size": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": INK, "ytick.color": INK, "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True, "grid.color": "#e4e3de", "grid.linewidth": 0.6, "axes.axisbelow": True, "legend.frameon": False, "savefig.dpi": 600, "savefig.bbox": "tight"})
# Fig 3: static carbon per service and method
fig, ax = plt.subplots(figsize=(7.0, 2.7)); meth = ["B3", "B4", "B5", "EASE", "Oracle-KA"]; w = 0.15
for k, p in enumerate(meth):
    ax.bar(np.arange(len(m.SERV)) + (k - 2) * (w + 0.012), [1000 * piv.loc[u, p] for u in m.SERV], w, color=C[k], label="EASE-6G" if p == "EASE" else ("B3 (latency-first)" if p == "B3" else ("B5 = E-min" if p == "B5" else p)))
ax.set_xticks(range(len(m.SERV))); ax.set_xticklabels(m.SERV); ax.set_ylabel("Carbon (µg CO$_2$/inference)"); ax.grid(axis="x", visible=False); ax.legend(ncol=5, loc="upper center", bbox_to_anchor=(0.5, 1.16), fontsize=8)
fig.savefig(FIG / "fig3_static_carbon.png"); plt.close(fig)
# Fig 2: decision pipeline with the equations that implement each stage (same style as Fig. 1)
from matplotlib.patches import FancyBboxPatch
fig, ax = plt.subplots(figsize=(7.2, 2.25)); ax.set(xlim=(0, 4), ylim=(0, 2)); ax.axis("off")
BL = "#3B6DB3"
def _box(x, y, title, sub, dashed=False, w=0.86, h=0.62):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.015,rounding_size=0.04", fc="#F4F7FC" if not dashed else "white", ec=BL, lw=1.3, ls="--" if dashed else "-"))
    ax.text(x, y + 0.11, title, ha="center", va="center", fontsize=8.2, color="#1A2B4C", fontweight="bold")
    ax.text(x, y - 0.15, sub, ha="center", va="center", fontsize=7.4, color="#333333", style="italic")
def _arr(a, b, dashed=False): ax.annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="-|>", lw=1.1, color="#1A2B4C", ls="--" if dashed else "-", shrinkA=0, shrinkB=0))
_box(0.5, 1.5, "Service and model\nrequirements", "Tables 4 and 5")
_box(1.5, 1.5, "Tier, access, and\npath profiles", "Eqs. (1)–(5), (7); Table 3")
_box(2.5, 1.5, "Hard service and\naccuracy gates", "Eqs. (9)–(11)")
_box(3.5, 1.5, "Ratio scores on\nfeasible candidates", "Eqs. (6), (8), (12)–(15)")
_box(3.5, 0.5, "MILP with capacity\nand availability", "Eqs. (16)–(19)")
_box(2.5, 0.5, "Placement decision", "tier and variant per\nservice and hour")
_box(1.0, 0.5, "Regime analysis", r"Eqs. (20)–(24): $\chi_E$, $\chi_C$, disagreement set", dashed=True, w=1.5)
for a, b in (((0.93, 1.5), (1.07, 1.5)), ((1.93, 1.5), (2.07, 1.5)), ((2.93, 1.5), (3.07, 1.5)), ((3.5, 1.19), (3.5, 0.81)), ((3.07, 0.5), (2.93, 0.5))): _arr(a, b)
_arr((1.5, 1.19), (1.3, 0.81), dashed=True)
fig.savefig(FIG / "fig2_pipeline.png"); plt.close(fig)
# Fig 6: envelope, (a) reduction against E-min, (b) hours in which the energy and carbon orderings of T2 and T3 disagree (Eq. 24)
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.9)); mk = {"Winter 2026": "o", "Spring 2026": "s", "Summer 2026": "^"}
for k, wn in enumerate(mk):
    g = env[env.window == wn]
    axs[0].plot(g.chi, g.reduction_vs_Emin_percent, mk[wn], color=C[k], ms=6.0, mec="white", mew=0.8, label=wn.split()[0], ls="none")
    axs[1].plot(g.chi, g.hours_in_disagreement, mk[wn], color=C[k], ms=6.0, mec="white", mew=0.8, ls="-", lw=0.8, alpha=0.9)
for pi_, a_ in enumerate(axs):
    for xv, lb in ((xE, f"$\\chi_E$ = {xE:.1f}"), (m.CHI_UC4, "UC4 (V4)")):
        a_.axvline(xv, color=MUTED, lw=0.9, ls=":" if "UC4" in lb else "--")
        a_.text(xv * (0.93 if "UC4" in lb else 1.07), 0.62 if pi_ == 0 else (0.30 if "UC4" in lb else 0.03), lb, rotation=90, va="top" if pi_ == 0 else "bottom",   # panel (b): the UC4 label sits in the gap between the summer and winter curves
                ha="right" if "UC4" in lb else "left", fontsize=7.5, color=MUTED, transform=a_.get_xaxis_transform())
    a_.set_xscale("log"); a_.set_xlabel(r"Effective operational intensity $\chi$ (GFLOP/Mbit)")
axs[0].set_ylabel("Carbon reduction vs E-min (%)"); axs[0].set_ylim(-3, 62); axs[0].legend(loc="upper left", fontsize=8); axs[0].set_title("(a) Reduction against the energy minimizer", fontsize=9, loc="left")
axs[1].set_ylabel("Hours in disagreement (of 168)"); axs[1].set_ylim(-5, 175); axs[1].set_title("(b) Hours in which energy and carbon disagree", fontsize=9, loc="left"); fig.tight_layout()
fig.savefig(FIG / "fig6_envelope.png"); plt.close(fig)
# Fig 7: energy and carbon ratio T2/T3, with efficiency cases
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.9)); chi = np.logspace(-2, 2, 4001); curves = []
cases = [c for c in V["xrange"]["cases"] if c["case"] in ("Reference (one server value)", "Server high / module low", "Server mid / module mid", "Previous profile")]; lss = ["-", "--", "-.", ":"]
for k, c in enumerate(cases):
    ee = m.EE.copy(); ee[1], ee[2] = c["EE_T2"], c["EE_T3"]; e2 = np.array([m.epm(1, v, ee) for v in chi]); e3 = np.array([m.epm(2, v, ee) for v in chi])
    axs[0].plot(chi, e2 / e3, color=C[k], lw=1.8, ls=lss[k], label=f"{c['case']}: {c['EE_T2']}/{c['EE_T3']} GFLOP/J"); cu_ = m.CS[0][m.USER]; cpm = lambda t, ee_: (m.PUE[t] / ee_[t] * chi * m.CS[0][t] + m.eacc * cu_ + m.EPS[t] * 1e-3 * (m.PHI * m.CS[0][t] + (1 - m.PHI) * cu_))   # Eq. (7) per Mbit
    axs[1].plot(chi, cpm(1, ee) / cpm(2, ee), color=C[k], lw=1.8, ls=lss[k])
    curves.append(pd.DataFrame(dict(case=c["case"], chi=chi, energy_ratio=e2 / e3, carbon_ratio=cpm(1, ee) / cpm(2, ee))))
for a, t in zip(axs, ("(a) Energy ratio T2/T3", "(b) Mean-carbon ratio T2/T3")):
    a.axhline(1, color=INK, lw=0.8); a.set_xscale("log"); a.set_xlabel(r"$\chi$ (GFLOP/Mbit)"); a.set_title(t, fontsize=9, loc="left")
axs[0].set_ylabel("Ratio (T2 / T3)"); fig.legend(*axs[0].get_legend_handles_labels(), ncol=2, loc="upper center", bbox_to_anchor=(0.5, 1.12), fontsize=7.5); fig.tight_layout()
fig.savefig(FIG / "fig7_crossover.png"); plt.close(fig); pd.concat(curves).to_csv(ROOT / "results/v2/fig7_crossover_curves.csv", index=False)   # data behind Fig. 7, checked by verify_equations.py
# Regime map (MDPI edition): where energy-optimal and carbon-optimal placement of the regional (T2) / metro (T3) pair disagree,
# Eq. (24), over work per transported bit and the facility-adjusted efficiency of T2 relative to T3 (UC4 access link, mean carbon intensity)
_ci = m.CS[0]; _cu = _ci[m.USER]; _A2 = m.PUE[1] / m.EE[1]; _A3 = m.PUE[2] / m.EE[2]; L_REF = _A3 / _A2
def _coef(L):                         # one tier improves at a time, as in the band of Section 6.9: above the reference T2 gains, below it T3 gains
    return (_A3 / L, _A3) if L >= L_REF else (_A2, _A2 * L)
def _beta(t): return _cu * m.eacc + m.b_(t) * (m.PHI * _ci[t] + (1 - m.PHI) * _cu)
def _chiE(L): a2, a3 = _coef(L); return (m.b_(1) - m.b_(2)) / (a3 - a2) if a3 > a2 else np.nan        # Eq. (21); exists only if Eq. (22) holds
def _chiC(L): a2, a3 = _coef(L); d = _ci[1] * a2 - _ci[2] * a3; x = (_beta(2) - _beta(1)) / d if d != 0 else np.nan; return x if x > 0 else np.nan   # Eq. (23)
def _disagree(L, x):
    a2, a3 = _coef(L); de = (a2 - a3) * x + m.b_(1) - m.b_(2); dc = (_ci[1] * a2 - _ci[2] * a3) * x + _beta(1) - _beta(2); return de * dc < 0   # Eq. (24)
assert abs(_chiE(L_REF) - m.chi_E(1, 2)) < 1e-9 and abs(_chiC(L_REF) - m.chi_C(1, 2, m.CS[0])) < 1e-9
_band = S["disagreement_band_UC4"]; L_HI = 1 + _band["T2_lead_max"]; L_LO = 1 / (1 + _band["T3_lead_max"])
assert _disagree(L_REF, m.CHI_UC4) and _disagree(L_HI * 0.999, m.CHI_UC4) and not _disagree(L_HI * 1.001, m.CHI_UC4)
assert _disagree(L_LO * 1.001, m.CHI_UC4) and not _disagree(L_LO * 0.999, m.CHI_UC4)
_Lg = np.logspace(np.log10(0.6), np.log10(1.8), 721); _Xg = np.logspace(-1, 3, 961)
_D = np.array([[_disagree(L, x) for x in _Xg] for L in _Lg])
pd.DataFrame([(L, x, bool(d)) for L, row in zip(_Lg, _D) for x, d in zip(_Xg, row)], columns=["L_T2_over_T3", "chi_GFLOP_per_Mbit", "disagree"]).to_csv(ROOT / "results/v2/regime_map_grid.csv", index=False)
fig, ax = plt.subplots(figsize=(7.0, 3.4))
ax.contourf(_Xg, _Lg, _D.astype(float), levels=[0.5, 1.5], colors=[C[0]], alpha=0.16)
ax.plot([_chiE(L) for L in _Lg], _Lg, color=INK, lw=1.4, ls="--", label=r"Energy crossover $\chi_E$, Eq. (21)")
ax.plot([_chiC(L) for L in _Lg], _Lg, color=C[1], lw=1.4, ls=":", label=r"Carbon crossover $\chi_C$ (mean intensity), Eq. (23)")
ax.axhline(1.0, color=MUTED, lw=0.6)
_xr = [m.CHI_UC4 * 15 / 20, m.CHI_UC4 * 15 / 10]
ax.plot(_xr, [L_REF, L_REF], color=C[2], lw=3, solid_capstyle="butt", alpha=0.8, label="UC4, payload 10–20 kB")
ax.plot([m.CHI_UC4, m.CHI_UC4], [L_LO, L_HI], color=C[0], lw=1.1); ax.plot([m.CHI_UC4] * 2, [L_LO, L_HI], ls="none", marker="_", ms=9, color=C[0])
ax.annotate("UC4 stays in the band while T2 is at most %.1f%%\nor T3 at most %.1f%% more efficient" % (100 * _band["T2_lead_max"], 100 * _band["T3_lead_max"]), xy=(m.CHI_UC4, L_LO), xytext=(m.CHI_UC4 * 0.5, 0.68),
            fontsize=7.5, color=C[0], ha="center", arrowprops=dict(arrowstyle="-", color=C[0], lw=0.7))
ax.plot(m.CHI_UC4, L_REF, marker="*", ms=12, color=C[3], mec=INK, mew=0.6, ls="none", label="UC4, reference (17.0% saving)")
_chi_raw = m.CHI_UC4 * 0.12 / 1.2
ax.plot(_chi_raw, L_REF, marker="o", ms=6, color="white", mec=INK, mew=0.9, ls="none", label="UC4, uncompressed input (0.0%)")
ax.text(400, 0.68, "Agree", fontsize=8, color=MUTED, ha="center"); ax.text(0.3, 1.12, "Agree", fontsize=8, color=MUTED, ha="center")
ax.text(170, 0.875, "Disagree: carbon awareness\nchanges the tier", fontsize=8, color=C[0], ha="center")
ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(0.1, 1000); ax.set_ylim(0.6, 1.8)
ax.set_yticks([0.6, 0.8, 1.0, 1.2, 1.5, 1.8]); ax.set_yticklabels(["0.6", "0.8", "1.0", "1.2", "1.5", "1.8"]); ax.minorticks_off()
ax.set_xlabel(r"Effective operational intensity $\chi$ (GFLOP/Mbit)"); ax.set_ylabel("Facility-adjusted efficiency,\nregional (T2) / metro (T3)")
ax.legend(fontsize=7, loc="upper right", frameon=True, framealpha=0.95, edgecolor="#e4e3de"); fig.tight_layout()
fig.savefig(FIG / "fig_regime_map.png"); plt.close(fig)
V["regime_map"] = dict(L_ref=float(L_REF), L_hi=float(L_HI), L_lo=float(L_LO), chi_E_ref=float(_chiE(L_REF)), chi_C_ref=float(_chiC(L_REF)), chi_uc4=float(m.CHI_UC4), chi_uc4_raw=float(_chi_raw))
(BUILD / "numbers.json").write_text(json.dumps(V, indent=1, default=float))   # adds the regime-map values
# Fig 4: energy-carbon weight frontier over the 24 mappings, against E-min
frd = pd.read_csv(ROOT / "results/v2/weight_frontier_24_mappings.csv"); gq = frd.groupby("w_C")
fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.7))
for a_, col, yl in ((axs[0], "red_vs_Emin", "Carbon reduction vs E-min (%)"), (axs[1], "dE_vs_Emin", "Energy change vs E-min (%)")):
    a_.fill_between(gq[col].min().index, gq[col].min(), gq[col].max(), color=C[0], alpha=0.18, lw=0, label="Range over 24 mappings")
    a_.plot(gq[col].median().index, gq[col].median(), "-o", color=C[0], ms=3.5, lw=1.6, label="Median")
    a_.axvline(m.W[1], color=MUTED, ls="--", lw=0.9); a_.set_xlabel("Carbon weight $w_C$ (headroom weight 0.20)"); a_.set_ylabel(yl)
om = gq.matches_oracle.sum(); ax2 = axs[0].twinx(); ax2.step(om.index, om.values, where="mid", color=C[1], lw=1.2, label="Mappings matching Oracle-KA"); ax2.set_ylim(0, 25); ax2.set_ylabel("Mappings matching Oracle-KA", color=C[1], fontsize=8); ax2.tick_params(axis="y", colors=C[1]); ax2.grid(False); ax2.spines["right"].set_visible(True)
h1, l1 = axs[0].get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
axs[0].set_title("(a) Carbon saving", fontsize=9, loc="left"); axs[1].set_title("(b) Energy cost", fontsize=9, loc="left"); axs[0].legend(h1 + h2, l1 + l2, fontsize=7, loc="lower right"); fig.tight_layout()
fig.savefig(FIG / "fig4_weight_frontier.png"); plt.close(fig)
# Fig 5: mapping distribution, served services: (a) against latency-first B3, (b) against the energy minimizer E-min, by the user's grid
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.0)); ugs = ["London", "South East England", "East England", "North Scotland"]; mks = ["o", "s", "^", "D"]
for k, ug in enumerate(ugs):
    g = cw[cw.user == ug]
    axs[0].plot(g.red_vs_B3, g.dE_vs_B3, mks[k], color=C[k], ms=6, mec="white", mew=0.8, ls="none", alpha=0.85, label=f"User grid: {sh(ug)}")
    axs[1].plot(g.C_Emin - g.C_EASE, g.dE_vs_Emin, mks[k], color=C[k], ms=6, mec="white", mew=0.8, ls="none", alpha=0.85)
for a in axs: a.axhline(0, color=INK, lw=0.8)
axs[0].set_xlabel("Carbon reduction vs B3 (%)"); axs[0].set_ylabel("Energy change (%)"); axs[0].set_title("(a) Against latency-first B3", fontsize=9, loc="left")
axs[1].set_xlabel("Carbon saved vs E-min (kg CO$_2$/week)"); axs[1].set_title("(b) Against the energy minimizer E-min", fontsize=9, loc="left")
fig.legend(*axs[0].get_legend_handles_labels(), ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.08), fontsize=7.5); fig.tight_layout()
fig.savefig(FIG / "fig5_mappings.png"); plt.close(fig)
print(json.dumps({k: V[k] for k in ("static_red_B3", "static_dE_B3", "static_red_B4", "static_red_B5", "static_dE_B5", "uc5_red_B3", "uc5_red_B5", "uc5_dE_B3", "uc5_dE_B5", "rule6_static_min", "rule6_static_max", "rule6_static_dE", "rule6_ws_min", "rule6_ws_max", "rule6_spring", "old_map", "all24_static_red_B3", "uc3_worst", "uc3_flip_wC", "uc3_flip_ratio", "env", "env_max_row", "env_pos_dE_min", "env_pos_dE_max", "env_gap_max", "env_static", "weight_counts", "sim", "milp", "CI", "acc_gap")}, indent=0, default=float))
for k in T: print("TABLE", k); print(T[k])
print("mapdist", json.dumps(V["mapdist"], default=float)); print("mapstatic", V["mapstatic"]); print("cap", json.dumps(V["capacity"], default=float)); print("means", V["means"]); print("abl", V["ablation"]); print("comm", V["comm"]); print("ids", ref_id, old_id, rule_ids)

# ================= parameter tables exactly as used by the revised model (match Tables II-IV)
PV = ROOT / "parameters" / "v2"; PV.mkdir(parents=True, exist_ok=True)
pd.DataFrame(dict(tier=m.TIER, name=["Remote Cloud", "Regional Edge", "Metro Edge", "Far Edge", "On-Device"], PUE=m.PUE, grid_region=[m.REFMAP[t] for t in m.TIER],
                  CI_mean_kg_per_kWh=[V["CI"][t] for t in m.TIER], service_latency_ms=m.LAT, bandwidth_Gbps=m.BW, reliability=m.REL, jitter_ms=m.JIT, EE_GFLOP_per_J=m.EE,
                  per_request_rate_GFLOP_per_s=m.RATE, CAP_AI_admission_GFLOP_per_s=["per device" if not np.isfinite(c) else c for c in m.CAPV], path_energy_nJ_per_bit=m.EPS)).to_csv(PV / "table_III_tiers.csv", index=False)
pd.DataFrame(dict(variant=m.VAR, GFLOP_per_inference=m.F, top1_accuracy_percent=m.ACC, precision_energy_factor=m.DELTA)).to_csv(PV / "table_IV_variants.csv", index=False)
u_ = m.UC.assign(name=[names[x] for x in m.UC.uc])[["uc", "name", "Lmax_ms", "Bmin_Gbps", "Rmin", "Jmax_ms", "Accmin_percent", "payload_Mbit", "access_bandwidth_Gbps", "access_tx_power_W"]].copy()
u_["peak_arrival_per_s"] = [m.PEAK[u] for u in u_.uc]; u_["stress_arrival_per_s"] = [m.STRESS[u] for u in u_.uc]; u_.to_csv(PV / "table_V_use_cases.csv", index=False)
pd.DataFrame([dict(parameter=k, value=v) for k, v in (("rho_B_effective_rate_factor", m.RHO), ("rho_max_admission_utilisation", m.RHO_MAX), ("path_share_phi_destination", m.PHI), ("access_energy_on_user_grid", m.ACC_AT_USER),
              ("headroom_cap_s_cap", m.CAP_RATIO), ("carbon_floor_g_per_kWh", m.CI_FLOOR), ("latency_gate", "R_min-quantile of M/D/1 waiting time at rho_max"), ("weights_energy_carbon_KPI", "0.40/0.40/0.20"), ("user_grid", "T4 and T5 share the user grid"))]).to_csv(PV / "model_settings.csv", index=False)
