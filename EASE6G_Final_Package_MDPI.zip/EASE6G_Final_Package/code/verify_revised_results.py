#!/usr/bin/env python3
"""Invariant-based verification for the corrected EASE-6G evaluation."""
from __future__ import annotations

import json
import math
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
R = ROOT / "results"
checks: list[dict] = []


def check(name: str, condition: bool, actual=None, expected=None) -> None:
    checks.append({"name": name, "pass": bool(condition), "actual": actual, "expected": expected})


cand = pd.read_csv(R / "all_candidates.csv")
static = pd.read_csv(R / "static_placements.csv")
baselines = pd.read_csv(R / "baseline_results.csv")
ablation = pd.read_csv(R / "ablation_results.csv")
variants = pd.read_csv(ROOT / "parameters/table_III_variants.csv").set_index("variant")

v3_break_even = float(variants.loc["V2", "GFLOPs_per_inference"]) / float(
    variants.loc["V3", "GFLOPs_per_inference"]
)
check(
    "V3 analytical break-even below assumed precision factor",
    v3_break_even < float(variants.loc["V3", "precision_energy_factor"]),
    v3_break_even,
    "<0.45 (analytical assumption)",
)

# Eq. (3): access time/rate are destination independent for every offloaded UC.
for uc, group in cand[cand.tier != "T5"].groupby("uc"):
    check(f"{uc} one offload transmission time", group.tx_time_ms.nunique() == 1, group.tx_time_ms.unique().tolist(), "one value")
    check(f"{uc} one offload effective rate", group.effective_rate_Gbps.nunique() == 1, group.effective_rate_Gbps.unique().tolist(), "one value")
    check(f"{uc} one offload access energy", group.E_access_J.nunique() == 1, group.E_access_J.unique().tolist(), "one value")

# Path transport remains ordered by distance/stage count.
eps = cand[cand.uc == "UC4"].drop_duplicates("tier").set_index("tier").transport_energy_nJ_per_bit
check("transport ordering", eps.T1 > eps.T2 > eps.T3 > eps.T4 == 0, eps.to_dict(), "T1>T2>T3>T4=0")

# Normalization is defined by hard-feasible candidates only.
for uc, group in cand.groupby("uc"):
    feasible = group[(group.K == 1) & (group.A == 1)]
    check(f"{uc} feasible eta range", feasible.eta.between(-1e-12, 1 + 1e-12).all(), [feasible.eta.min(), feasible.eta.max()], "[0,1]")
    check(f"{uc} feasible carbon range", feasible.carbon_eff.between(-1e-12, 1 + 1e-12).all(), [feasible.carbon_eff.min(), feasible.carbon_eff.max()], "[0,1]")

# B5 is exactly the renormalized no-carbon ablation.
b5 = baselines[baselines.method == "B5"].set_index("uc")
no_c = ablation[ablation.ablation == "No carbon"].set_index("uc")
for uc in b5.index:
    b5_place = f"{b5.loc[uc, 'tier']}-{b5.loc[uc, 'variant']}"
    no_c_place = f"{no_c.loc[uc, 'tier']}-{no_c.loc[uc, 'variant']}"
    check(f"{uc} B5 equals no-carbon ablation", b5_place == no_c_place, b5_place, no_c_place)

# Every reported EASE placement satisfies both hard gates.
for _, row in static.iterrows():
    c = cand[(cand.uc == row.uc) & (cand.tier == row.tier) & (cand.variant == row.variant)].iloc[0]
    check(f"{row.uc} selected gates", c.K == 1 and c.A == 1, [int(c.K), int(c.A)], [1, 1])

weights = pd.read_csv(R / "weight_sweep.csv")
check("weight simplex size", weights[["wE", "wC", "wK"]].drop_duplicates().shape[0] == 231, weights[["wE", "wC", "wK"]].drop_duplicates().shape[0], 231)

capacity = pd.read_csv(R / "capacity_system_metrics.csv")
check("capacity solution feasible", bool(capacity.iloc[-1].capacity_feasible), bool(capacity.iloc[-1].capacity_feasible), True)

cross = pd.read_csv(R / "operational_intensity_crossovers.csv").set_index("quantity").value_GFLOP_per_Mbit
chi_e = float(cross["T2-T3 energy crossover"])
chi_c = float(cross["T2-T3 mean-carbon crossover"])
check("positive ordered crossovers", 0 < chi_e < chi_c, [chi_e, chi_c], "0 < energy < carbon")
check("reference UC3 below crossover", float(cross["Reference UC3 effective intensity"]) < chi_e, float(cross["Reference UC3 effective intensity"]), f"<{chi_e}")
check("reference UC4 below crossover", float(cross["Reference UC4 effective intensity"]) < chi_e, float(cross["Reference UC4 effective intensity"]), f"<{chi_e}")

seasonal = pd.read_csv(R / "seasonal_operational_intensity_window_summary.csv")
report_grid = pd.read_csv(R / "operational_intensity_report_grid.csv")
hourly = pd.read_csv(R / "seasonal_operational_intensity_hourly_decisions.csv")
seed_results = pd.read_csv(R / "seasonal_operational_intensity_seed_results.csv")
reference = seasonal[seasonal.chi_GFLOP_per_Mbit.map(lambda x: math.isclose(x, 0.03625, abs_tol=1e-12))]
check("reference UC4 remains null", (reference.reduction_mean_percent.abs() < 1e-12).all(), reference.reduction_mean_percent.tolist(), "all zero")
check("predeclared envelope contains positive regimes", (seasonal.reduction_mean_percent > 0).any(), float(seasonal.reduction_mean_percent.max()), ">0")
check("seasonal gains are nonnegative", (seasonal.reduction_mean_percent >= -1e-10).all(), float(seasonal.reduction_mean_percent.min()), ">=0")
check(
    "complete seasonal disclosure grid",
    seasonal[["window", "chi_GFLOP_per_Mbit"]].drop_duplicates().shape[0] == 33,
    seasonal[["window", "chi_GFLOP_per_Mbit"]].drop_duplicates().shape[0],
    33,
)
check(
    "positive seasonal cell count",
    int((seasonal.reduction_mean_percent > 0).sum()) == 12,
    int((seasonal.reduction_mean_percent > 0).sum()),
    12,
)
check(
    "11-point static maximum",
    math.isclose(report_grid.carbon_reduction_vs_B5_percent.max(), 19.1468085712094, abs_tol=1e-10),
    float(report_grid.carbon_reduction_vs_B5_percent.max()),
    19.1468085712094,
)
check(
    "every seasonal cell has 168 hourly solves",
    set(hourly.groupby(["window", "chi_GFLOP_per_Mbit"]).size()) == {168},
    sorted(set(hourly.groupby(["window", "chi_GFLOP_per_Mbit"]).size())),
    [168],
)
check(
    "every seasonal cell has five seed totals",
    set(seed_results.groupby(["window", "chi_GFLOP_per_Mbit"]).size()) == {5},
    sorted(set(seed_results.groupby(["window", "chi_GFLOP_per_Mbit"]).size())),
    [5],
)

report = {
    "passed": sum(c["pass"] for c in checks),
    "total": len(checks),
    "all_pass": all(c["pass"] for c in checks),
    "checks": checks,
}
(R / "revised_verification_report.json").write_text(json.dumps(report, indent=2))
print(json.dumps({k: report[k] for k in ("passed", "total", "all_pass")}, indent=2))
if not report["all_pass"]:
    raise SystemExit(1)
