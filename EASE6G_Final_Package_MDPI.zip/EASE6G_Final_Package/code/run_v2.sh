#!/usr/bin/env bash
# Regenerate every result, table, figure and both manuscript files of the revised study.
# Usage: bash code/run_v2.sh <source_manuscript.docx> <source_manuscript.md> <output_ieee_layout.docx> [<output_mdpi.docx>]
#   The IEEE-layout file is the intermediate text build; the MDPI (Future Internet) submission file is
#   written next to it as EASE6G_FutureInternet_MDPI.docx unless a fourth argument is given.
set -euo pipefail
A="$(realpath "$1")"; B="$(realpath "$2")"; C="$(realpath -m "$3")"
D="$(realpath -m "${4:-$(dirname "$C")/EASE6G_FutureInternet_MDPI.docx}")"
cd "$(dirname "$0")"; export PYTHONPATH="$PWD" MPLBACKEND=Agg
python3 ease6g_v2.py                 # core experiments            -> results/v2/
python3 ease6g_des.py > /dev/null     # discrete-event check of the M/D/1 tail quantile -> results/v2/queue_validation.json
python3 ease6g_6g_extensions.py > /dev/null   # split inference, 2030 grid -> results/v2_6g/
python3 ease6g_review_checks.py > /dev/null   # benchmark basis (data/mlperf/), joint factorial, V3 throughput, queueing consistency, capacity against load -> results/v2/review_checks.json
python3 build_numbers.py > /dev/null          # numbers, tables, Figures 2-7 at 600 dpi -> build/, figures_v2/
python3 fig1_tiers.py                         # Figure 1 at 600 dpi -> figures_v2/fig1_tiers.png
python3 verify_equations.py > ../results/v2/equation_verification.txt   # independent check of Equations (1)-(24)
python3 build_manuscript.py "$A" "$B" "$C"    # consistency checks + manuscript text (IEEE layout)
python3 mdpi/convert_to_mdpi.py "$C" ../figures_v2 "$D"   # MDPI Future Internet submission file
