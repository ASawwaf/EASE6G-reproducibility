#!/usr/bin/env python3
"""Communication-and-transport sensitivity analysis for Comment #5.

Independent factors:
- payload scale: 0.5x, 1x, 2x
- effective-rate factor rho_B: 0.4, 0.6, 0.8
- active-transmission power scale: 0.5x, 1x, 1.5x
- transport-intensity scale: 0.5x, 1x, 2x

Total: 81 scenarios. Compares EASE-6G with B5 and reports placement stability.
"""
from __future__ import annotations
import json, sys
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
RESULTS.mkdir(exist_ok=True); FIGURES.mkdir(exist_ok=True)
sys.path.insert(0, str(Path(__file__).resolve().parent))
import ease6g_revision_model as model

PAYLOAD_SCALES=[0.5,1.0,2.0]
RHO_VALUES=[0.4,0.6,0.8]
TX_POWER_SCALES=[0.5,1.0,1.5]
TRANSPORT_SCALES=[0.5,1.0,2.0]

def place(row): return f"{row.tier}-{row.variant}"

def main():
    reference=model.select_static(model.candidates())
    ref={r.uc:place(r) for _,r in reference.iterrows()}
    detail=[]; system=[]; sid=0
    for ps in PAYLOAD_SCALES:
      for rho in RHO_VALUES:
       for ptx in TX_POWER_SCALES:
        for ets in TRANSPORT_SCALES:
          sid+=1
          cand=model.candidates(payload_scale=ps,rho_b=rho,tx_power_scale=ptx,transport_scale=ets)
          ease=model.select_static(cand)
          b5=model.select_baselines(cand); b5=b5[b5.method=='B5'].set_index('uc')
          emE=float(ease.E_total_J.mean()); emC=float(ease.carbon_mg.mean())
          bmE=float(b5.E_total_J.mean()); bmC=float(b5.carbon_mg.mean())
          system.append(dict(scenario_id=sid,payload_scale=ps,rho_B=rho,tx_power_scale=ptx,transport_scale=ets,
                             EASE_mean_energy_J_per_inf=emE,B5_mean_energy_J_per_inf=bmE,
                             EASE_mean_carbon_mg_per_inf=emC,B5_mean_carbon_mg_per_inf=bmC,
                             carbon_reduction_vs_B5_percent=100*(bmC-emC)/bmC,
                             energy_change_vs_B5_percent=100*(emE-bmE)/bmE,
                             number_of_EASE_placement_changes_vs_reference=sum(place(r)!=ref[r.uc] for _,r in ease.iterrows())))
          for _,e in ease.iterrows():
            b=b5.loc[e.uc]
            detail.append(dict(scenario_id=sid,payload_scale=ps,rho_B=rho,tx_power_scale=ptx,transport_scale=ets,
                               uc=e.uc,reference_placement=ref[e.uc],EASE_placement=place(e),placement_changed=place(e)!=ref[e.uc],
                               EASE_access_energy_J_per_inf=float(e.E_access_J),
                               EASE_transport_energy_J_per_inf=float(e.E_transport_J),
                               EASE_comm_energy_J_per_inf=float(e.E_comm_J),
                               EASE_total_energy_J_per_inf=float(e.E_total_J),EASE_carbon_mg_per_inf=float(e.carbon_mg),
                               B5_placement=f"{b.tier}-{b.variant}",B5_total_energy_J_per_inf=float(b.E_total_J),B5_carbon_mg_per_inf=float(b.carbon_mg),
                               carbon_reduction_vs_B5_percent=100*(float(b.carbon_mg)-float(e.carbon_mg))/float(b.carbon_mg),
                               energy_change_vs_B5_percent=100*(float(e.E_total_J)-float(b.E_total_J))/float(b.E_total_J)))
    d=pd.DataFrame(detail); s=pd.DataFrame(system)
    counts=d.groupby(['uc','EASE_placement']).size().reset_index(name='scenario_count').sort_values(['uc','scenario_count'],ascending=[True,False])
    summary=d.groupby('uc').agg(scenarios=('scenario_id','nunique'),placement_changes=('placement_changed','sum'),
        min_comm_energy_J=('EASE_comm_energy_J_per_inf','min'),median_comm_energy_J=('EASE_comm_energy_J_per_inf','median'),max_comm_energy_J=('EASE_comm_energy_J_per_inf','max'),
        min_carbon_reduction_vs_B5_percent=('carbon_reduction_vs_B5_percent','min'),max_carbon_reduction_vs_B5_percent=('carbon_reduction_vs_B5_percent','max')).reset_index()
    d.to_csv(RESULTS/'communication_transport_sensitivity_81_scenarios_detail.csv',index=False)
    s.to_csv(RESULTS/'communication_transport_sensitivity_81_scenarios_system.csv',index=False)
    counts.to_csv(RESULTS/'communication_transport_placement_counts.csv',index=False)
    summary.to_csv(RESULTS/'communication_transport_uc_summary.csv',index=False)
    manuscript=[]
    for uc in model.USE_CASES.uc:
      g=counts[counts.uc==uc]
      stable=int(g.scenario_count.max())
      row=summary[summary.uc==uc].iloc[0]
      manuscript.append(dict(profile=uc,reference_placement=ref[uc],stable_scenarios=f"{stable}/81",
                             carbon_reduction_range_vs_B5=f"{row.min_carbon_reduction_vs_B5_percent:.2f}% to {row.max_carbon_reduction_vs_B5_percent:.2f}%"))
    pd.DataFrame(manuscript).to_csv(RESULTS/'table_XIV_communication_transport_sensitivity.csv',index=False)
    # Figure 7: communication-energy spread across the 81 scenarios.
    groups=[d[d.uc==uc].EASE_comm_energy_J_per_inf.values for uc in model.USE_CASES.uc]
    fig,ax=plt.subplots(figsize=(8.2,4.4)); ax.boxplot(groups,tick_labels=list(model.USE_CASES.uc)); ax.set_yscale('log')
    ax.set_xlabel('Service profile'); ax.set_ylabel('Communication energy (J/inference, log scale)')
    ax.set_title('Communication and transport-energy sensitivity (81 scenarios)')
    ax.text(0.5,0.96,'Reference placements unchanged in 81/81 scenarios for every profile',transform=ax.transAxes,ha='center',va='top',bbox=dict(boxstyle='round',facecolor='white',edgecolor='black'))
    fig.tight_layout(); fig.savefig(FIGURES/'fig7_communication_transport_sensitivity.png',dpi=220,bbox_inches='tight'); plt.close(fig)
    result={
      'scenario_count':81,'parameter_grid':{'payload_scale':PAYLOAD_SCALES,'rho_B':RHO_VALUES,'tx_power_scale':TX_POWER_SCALES,'transport_scale':TRANSPORT_SCALES},
      'reference_placements':ref,'placement_counts':counts.to_dict('records'),
      'system_carbon_reduction_vs_B5_percent':{'min':float(s.carbon_reduction_vs_B5_percent.min()),'max':float(s.carbon_reduction_vs_B5_percent.max())},
      'system_energy_change_vs_B5_percent':{'min':float(s.energy_change_vs_B5_percent.min()),'max':float(s.energy_change_vs_B5_percent.max())},
      'scenarios_with_any_EASE_placement_change':int((s.number_of_EASE_placement_changes_vs_reference>0).sum())}
    (RESULTS/'communication_transport_sensitivity_summary.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
