#!/usr/bin/env python3
"""Reproducible evaluation pipeline for the revised EASE-6G IEEE Access manuscript.

The script implements:
- payload- and path-aware communication energy;
- generic tier-level accelerator energy-efficiency profiles;
- service-layer KPI gating;
- accuracy gating with literature-grounded ImageNet model profiles;
- static placement, operational baselines, Oracle, ablation, weight sweep;
- capacity-stress MILP;
- controlled synthetic 192-hour simulation with 24-hour warm-up;
- trace-driven validation using three seasonal weeks of 2026 regional GB carbon-intensity data;
- deterministic/seed-level descriptive reporting (no pooled hourly significance test).

The MILP is solved with scipy.optimize.milp (HiGHS backend).
"""
from __future__ import annotations

import json
import math
import platform
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Tuple

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy.optimize import Bounds, LinearConstraint, milp

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"
FIG_DIR = ROOT / "figures"
RESULTS_DIR.mkdir(exist_ok=True)
FIG_DIR.mkdir(exist_ok=True)

RHO_B = 0.60  # effective-rate fraction of the use-case access-link bandwidth
DEFAULT_WEIGHTS = (0.40, 0.40, 0.20)
RNG_SEEDS = [17, 29, 43, 71, 101]

CARBON_ARCHIVE = DATA_DIR / "regional_carbon_intensity_archive_through_2026-07-18.csv"
TRACE_WINDOWS = [
    ("Winter 2026", "2026-01-12T00:00:00Z", "2026-01-19T00:00:00Z"),
    ("Spring 2026", "2026-04-13T00:00:00Z", "2026-04-20T00:00:00Z"),
    ("Summer 2026", "2026-07-06T00:00:00Z", "2026-07-13T00:00:00Z"),
]
TIER_REGION_NAMES = {
    "T1": "London",
    "T2": "South East England",
    "T3": "East England",
    "T4": "North Scotland",
    "T5": "North Scotland",
}

def _load_archive() -> pd.DataFrame:
    d = pd.read_csv(CARBON_ARCHIVE)
    if "datetime" not in d.columns:
        raise ValueError(f"Missing datetime column in {CARBON_ARCHIVE}")
    d["datetime"] = pd.to_datetime(d["datetime"], utc=True)
    return d.sort_values("datetime")

def load_carbon_trace_windows() -> Dict[str, pd.DataFrame]:
    """Load three complete 2026 seasonal windows and aggregate 30-min data to hours."""
    raw = _load_archive()
    cols = sorted(set(TIER_REGION_NAMES.values()))
    windows: Dict[str, pd.DataFrame] = {}
    for label, start, end in TRACE_WINDOWS:
        start_ts = pd.Timestamp(start)
        end_ts = pd.Timestamp(end)
        d = raw[(raw.datetime >= start_ts) & (raw.datetime < end_ts)].copy()
        if len(d) != 336:
            raise ValueError(f"{label}: expected 336 half-hour rows, found {len(d)}")
        if d[cols].isna().any().any():
            raise ValueError(f"{label}: missing regional carbon-intensity values")
        hourly = d.set_index("datetime")[cols].resample("1h").mean()
        if len(hourly) != 168:
            raise ValueError(f"{label}: expected 168 hourly rows, found {len(hourly)}")
        windows[label] = hourly
    return windows

def _reference_ci_means() -> Dict[str, float]:
    combined = pd.concat(load_carbon_trace_windows().values(), axis=0)
    return {region: float(combined[region].mean()) / 1000.0 for region in set(TIER_REGION_NAMES.values())}

REFERENCE_CI = _reference_ci_means()

TIERS = pd.DataFrame(
    [
        ["T1", "Remote Cloud", 1.20, REFERENCE_CI["London"], 75.0, 100.0, 0.99999, 5.0, 500.0, 4.0, 12.66, 40000.0, 13, "London"],
        ["T2", "Regional Edge", 1.30, REFERENCE_CI["South East England"], 10.0, 50.0, 0.99999, 2.0, 350.0, 3.0, 6.48, 4000.0, 14, "South East England"],
        ["T3", "Metro Edge", 1.35, REFERENCE_CI["East England"], 5.0, 25.0, 0.99990, 0.5, 275.0, 2.5, 3.39, 400.0, 10, "East England"],
        ["T4", "Far Edge", 1.40, REFERENCE_CI["North Scotland"], 0.5, 10.0, 0.99999, 0.1, 200.0, 2.0, 0.0, 40.0, 1, "North Scotland"],
        ["T5", "On-Device", 1.00, REFERENCE_CI["North Scotland"], 0.05, 1.0, 0.99900, 0.01, 100.0, 0.0, 0.0, 4.0, 1, "North Scotland"],
    ],
    columns=[
        "tier", "name", "PUE", "CI_kg_per_kWh", "service_latency_ms", "bandwidth_Gbps",
        "reliability", "jitter_ms", "accelerator_EE_GFLOPS_per_W", "tx_power_W",
        "transport_energy_nJ_per_bit", "CAP_AI_GFLOPS_per_s", "region_id", "region_name",
    ],
)

VARIANTS = pd.DataFrame(
    [
        ["V1", "DeiT-B FP32 reference", 17.6, 81.80, 1.00, "Touvron et al. (2021)"],
        ["V2", "Distilled DeiT-S FP32", 4.6, 81.20, 1.00, "Touvron et al. (2021)"],
        ["V3", "DeiT-B INT8", 17.6, 81.29, 0.45, "Liu et al. (2021); PTQ literature"],
        ["V4", "DynamicViT-S token-pruned", 2.9, 79.30, 1.00, "Rao et al. (2021)"],
    ],
    columns=["variant", "description", "GFLOPs_per_inference", "accuracy_percent", "precision_energy_factor", "source"],
)

USE_CASES = pd.DataFrame(
    [
        # Access-link values are destination independent. They preserve the
        # reference access conditions used at the nearest feasible tier while
        # separating access airtime from path transport energy.
        ["UC1", "Smart manufacturing", 1.0, 10.0, 0.99999, 0.5, 80.0, 2.0, 10.0, 2.0],
        ["UC2", "Autonomous vehicle", 5.0, 1.0, 0.99999, 1.0, 80.0, 8.0, 10.0, 2.0],
        ["UC3", "Remote surgery", 10.0, 5.0, 0.99990, 2.0, 80.0, 20.0, 10.0, 2.0],
        ["UC4", "HD video analytics", 50.0, 20.0, 0.99900, 10.0, np.nan, 80.0, 25.0, 2.5],
    ],
    columns=[
        "uc", "name", "Lmax_ms", "Bmin_Gbps", "Rmin", "Jmax_ms",
        "Accmin_percent", "payload_Mbit", "access_bandwidth_Gbps", "access_tx_power_W",
    ],
)


def candidates(
    ci_override: Optional[Mapping[str, float]] = None,
    weights: Tuple[float, float, float] = DEFAULT_WEIGHTS,
    payload_scale: float = 1.0,
    ee_scale: Optional[Mapping[str, float]] = None,
    pue_override: Optional[Mapping[str, float]] = None,
    rho_b: float = RHO_B,
    tx_power_scale: float = 1.0,
    transport_scale: float = 1.0,
) -> pd.DataFrame:
    """Return all tier-variant-use-case candidates with gates, metrics and score."""
    rows: List[dict] = []
    for _, uc in USE_CASES.iterrows():
        kpi_raw: Dict[str, float] = {}
        kpi_gate: Dict[str, int] = {}
        for _, tier in TIERS.iterrows():
            kpi_raw[tier.tier] = (
                uc.Lmax_ms / tier.service_latency_ms
                + tier.bandwidth_Gbps / uc.Bmin_Gbps
                + tier.reliability / uc.Rmin
                + uc.Jmax_ms / tier.jitter_ms
            )
            kpi_gate[tier.tier] = int(
                tier.service_latency_ms <= uc.Lmax_ms
                and tier.bandwidth_Gbps >= uc.Bmin_Gbps
                and tier.reliability >= uc.Rmin
                and tier.jitter_ms <= uc.Jmax_ms
            )
        # Infeasible tiers must not set the normalization range of candidates
        # that can actually be selected.
        kpi_max = max(v for t, v in kpi_raw.items() if kpi_gate[t] == 1)
        uc_rows: List[dict] = []
        for _, tier in TIERS.iterrows():
            ci = float(ci_override.get(tier.tier, tier.CI_kg_per_kWh)) if ci_override else float(tier.CI_kg_per_kWh)
            pue = float(pue_override.get(tier.tier, tier.PUE)) if pue_override else float(tier.PUE)
            ee_factor = float(ee_scale.get(tier.tier, 1.0)) if ee_scale else 1.0
            ee = float(tier.accelerator_EE_GFLOPS_per_W) * ee_factor
            k_gate = kpi_gate[tier.tier]
            payload_bits = float(uc.payload_Mbit) * 1e6 * payload_scale
            effective_rate_bps = float(rho_b) * float(uc.access_bandwidth_Gbps) * 1e9
            tx_time_s = 0.0 if tier.tier == "T5" else payload_bits / effective_rate_bps
            e_access = float(uc.access_tx_power_W) * float(tx_power_scale) * tx_time_s
            e_transport = 0.0 if tier.tier == "T5" else payload_bits * float(tier.transport_energy_nJ_per_bit) * float(transport_scale) * 1e-9
            e_comm = e_access + e_transport
            for _, variant in VARIANTS.iterrows():
                a_gate = 1 if pd.isna(uc.Accmin_percent) else int(variant.accuracy_percent >= uc.Accmin_percent)
                e_compute = (
                    pue
                    * float(variant.GFLOPs_per_inference)
                    / ee
                    * float(variant.precision_energy_factor)
                )
                e_total = e_compute + e_comm
                carbon_mg = e_total * ci / 3.6
                uc_rows.append(
                    {
                        "uc": uc.uc,
                        "tier": tier.tier,
                        "variant": variant.variant,
                        "K": k_gate,
                        "A": a_gate,
                        "service_latency_ms": tier.service_latency_ms,
                        "payload_Mbit": uc.payload_Mbit * payload_scale,
                        "access_bandwidth_Gbps": float(uc.access_bandwidth_Gbps),
                        "effective_rate_Gbps": float(rho_b) * float(uc.access_bandwidth_Gbps),
                        "access_tx_power_W": float(uc.access_tx_power_W) * float(tx_power_scale),
                        "rho_B": float(rho_b),
                        "tx_power_scale": float(tx_power_scale),
                        "tx_time_ms": tx_time_s * 1000.0,
                        "transport_energy_nJ_per_bit": float(tier.transport_energy_nJ_per_bit) * float(transport_scale),
                        "transport_scale": float(transport_scale),
                        "E_compute_J": e_compute,
                        "E_access_J": e_access,
                        "E_transport_J": e_transport,
                        "E_comm_J": e_comm,
                        "E_total_J": e_total,
                        "carbon_mg": carbon_mg,
                        "KPI_raw": kpi_raw[tier.tier],
                        "KPI_norm": kpi_raw[tier.tier] / kpi_max,
                        "CI_kg_per_kWh": ci,
                    }
                )
        uc_df = pd.DataFrame(uc_rows)
        feasible = uc_df[(uc_df.K == 1) & (uc_df.A == 1)]
        if feasible.empty:
            raise ValueError(f"{uc.uc}: no candidate satisfies both hard gates")
        e_min, e_max = feasible.E_total_J.min(), feasible.E_total_J.max()
        c_min, c_max = feasible.carbon_mg.min(), feasible.carbon_mg.max()
        uc_df["eta"] = 1.0 if e_max == e_min else 1.0 - (uc_df.E_total_J - e_min) / (e_max - e_min)
        uc_df["carbon_eff"] = 1.0 if c_max == c_min else 1.0 - (uc_df.carbon_mg - c_min) / (c_max - c_min)
        w_e, w_c, w_k = weights
        uc_df["suitability"] = (
            uc_df.K
            * uc_df.A
            * (w_e * uc_df.eta + w_c * uc_df.carbon_eff + w_k * uc_df.KPI_norm)
        )
        rows.append(uc_df)
    return pd.concat(rows, ignore_index=True)


def select_static(cand: pd.DataFrame) -> pd.DataFrame:
    records = []
    for uc in USE_CASES.uc:
        df = cand[(cand.uc == uc) & (cand.K == 1) & (cand.A == 1)].copy()
        if df.empty:
            continue
        row = df.sort_values(["suitability", "carbon_mg", "E_total_J"], ascending=[False, True, True]).iloc[0]
        records.append(row)
    return pd.DataFrame(records)


def select_baselines(cand: pd.DataFrame) -> pd.DataFrame:
    records: List[dict] = []
    for _, ucrow in USE_CASES.iterrows():
        uc = ucrow.uc
        all_df = cand[cand.uc == uc].copy()
        feasible = all_df[(all_df.K == 1) & (all_df.A == 1)].copy()
        # B1 is reported as a deterministic uniform-random expectation over all 20 pairs.
        b1 = {
            "tier": "Expected",
            "variant": "Uniform",
            "E_total_J": all_df.E_total_J.mean(),
            "carbon_mg": all_df.carbon_mg.mean(),
        }
        b2 = all_df.sort_values(["E_total_J", "carbon_mg"]).iloc[0]
        min_l = feasible.service_latency_ms.min()
        b3 = feasible[feasible.service_latency_ms == min_l].sort_values(["E_total_J", "carbon_mg"]).iloc[0]
        lem = feasible.copy()
        lem["LEM"] = lem.service_latency_ms / ucrow.Lmax_ms + lem.E_total_J / lem.E_total_J.max()
        b4 = lem.sort_values(["LEM", "carbon_mg"]).iloc[0]
        b5 = feasible.copy()
        # Carbon-unaware ablation of the default (0.4, 0.4, 0.2) policy:
        # remove carbon and renormalize the remaining weights.
        b5["B5_score"] = (2.0 / 3.0) * b5.eta + (1.0 / 3.0) * b5.KPI_norm
        b5 = b5.sort_values(["B5_score", "E_total_J"], ascending=[False, True]).iloc[0]
        ease = feasible.sort_values(["suitability", "carbon_mg", "E_total_J"], ascending=[False, True, True]).iloc[0]
        oracle = all_df[all_df.K == 1].sort_values(["carbon_mg", "E_total_J"]).iloc[0]
        selections = {"B1": b1, "B2": b2, "B3": b3, "B4": b4, "B5": b5, "EASE-6G": ease, "Oracle": oracle}
        for method, row in selections.items():
            if method == "B1":
                records.append({"method": method, "uc": uc, **row})
            else:
                records.append(
                    {
                        "method": method,
                        "uc": uc,
                        "tier": row.tier,
                        "variant": row.variant,
                        "E_total_J": row.E_total_J,
                        "carbon_mg": row.carbon_mg,
                    }
                )
    return pd.DataFrame(records)


def ablation(cand: pd.DataFrame) -> pd.DataFrame:
    records = []
    configs = {
        "Full EASE-6G": (0.40, 0.40, 0.20, True),
        "No carbon": (2 / 3, 0.0, 1 / 3, True),
        "No KPI score": (0.50, 0.50, 0.0, True),
        "No energy": (0.0, 2 / 3, 1 / 3, True),
        "No accuracy gate": (0.40, 0.40, 0.20, False),
    }
    for name, (we, wc, wk, use_acc) in configs.items():
        for uc in USE_CASES.uc:
            d = cand[(cand.uc == uc) & (cand.K == 1)].copy()
            if use_acc:
                d = d[d.A == 1]
            d["abl_score"] = we * d.eta + wc * d.carbon_eff + wk * d.KPI_norm
            row = d.sort_values(["abl_score", "carbon_mg", "E_total_J"], ascending=[False, True, True]).iloc[0]
            records.append(
                {
                    "ablation": name,
                    "uc": uc,
                    "tier": row.tier,
                    "variant": row.variant,
                    "E_total_J": row.E_total_J,
                    "carbon_mg": row.carbon_mg,
                    "accuracy_valid": bool(row.A),
                }
            )
    return pd.DataFrame(records)


def weight_sweep(cand: pd.DataFrame) -> pd.DataFrame:
    records = []
    vals = np.round(np.arange(0, 1.0001, 0.05), 2)
    for we in vals:
        for wc in vals:
            wk = round(1.0 - we - wc, 2)
            if wk < -1e-9 or wk > 1 + 1e-9:
                continue
            for uc in USE_CASES.uc:
                d = cand[(cand.uc == uc) & (cand.K == 1) & (cand.A == 1)].copy()
                d["score"] = we * d.eta + wc * d.carbon_eff + wk * d.KPI_norm
                row = d.sort_values(["score", "carbon_mg", "E_total_J"], ascending=[False, True, True]).iloc[0]
                records.append({"wE": we, "wC": wc, "wK": wk, "uc": uc, "tier": row.tier, "variant": row.variant})
    return pd.DataFrame(records)


def solve_hour(
    cand: pd.DataFrame,
    rates: Mapping[str, float],
    availability: Mapping[str, int],
    allow_unserved: bool = True,
) -> Tuple[pd.DataFrame, float]:
    """Solve one capacity-constrained assignment MILP."""
    feasible = cand[(cand.K == 1) & (cand.A == 1)].copy()
    feasible = feasible[feasible.tier.map(lambda x: availability.get(x, 1) == 1)].reset_index(drop=True)
    pair_vars = list(feasible.index)
    n_pair = len(pair_vars)
    uc_list = list(USE_CASES.uc)
    n_unserved = len(uc_list) if allow_unserved else 0
    n = n_pair + n_unserved
    if n == 0:
        return pd.DataFrame(), math.inf

    c = np.zeros(n)
    c[:n_pair] = -feasible.suitability.to_numpy()
    if allow_unserved:
        c[n_pair:] = 10.0  # large penalty relative to a unit-scale score

    rows = []
    lb = []
    ub = []
    # Exactly one placement or unserved state per use case.
    for j, uc in enumerate(uc_list):
        coeff = np.zeros(n)
        coeff[:n_pair] = (feasible.uc == uc).astype(float)
        if allow_unserved:
            coeff[n_pair + j] = 1.0
        rows.append(coeff)
        lb.append(1.0)
        ub.append(1.0)
    # Tier capacity.
    for _, tier in TIERS.iterrows():
        coeff = np.zeros(n)
        for i, row in feasible.iterrows():
            if row.tier == tier.tier:
                f = float(VARIANTS.loc[VARIANTS.variant == row.variant, "GFLOPs_per_inference"].iloc[0])
                coeff[i] = float(rates[row.uc]) * f
        rows.append(coeff)
        lb.append(-np.inf)
        ub.append(float(tier.CAP_AI_GFLOPS_per_s))

    res = milp(
        c=c,
        integrality=np.ones(n),
        bounds=Bounds(np.zeros(n), np.ones(n)),
        constraints=LinearConstraint(np.vstack(rows), np.array(lb), np.array(ub)),
        options={"mip_rel_gap": 1e-9, "time_limit": 30.0},
    )
    if not res.success:
        raise RuntimeError(f"MILP failed: {res.message}")
    x = np.rint(res.x).astype(int)
    selected = feasible.loc[x[:n_pair] == 1].copy()
    if allow_unserved:
        for j, uc in enumerate(uc_list):
            if x[n_pair + j] == 1:
                selected = pd.concat(
                    [selected, pd.DataFrame([{"uc": uc, "tier": "UNSERVED", "variant": "-", "suitability": 0.0, "E_total_J": np.nan, "carbon_mg": np.nan}])],
                    ignore_index=True,
                )
    return selected.sort_values("uc"), float(res.fun)


def capacity_stress(cand: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    rates = {"UC1": 4.0, "UC2": 4.0, "UC3": 6.0, "UC4": 100.0}
    local = select_static(cand)
    availability = {tier: 1 for tier in TIERS.tier}
    milp_sel, _ = solve_hour(cand, rates, availability, allow_unserved=False)

    rows = []
    for uc in USE_CASES.uc:
        before = local[local.uc == uc].iloc[0]
        after = milp_sel[milp_sel.uc == uc].iloc[0]
        rows.append(
            {
                "uc": uc,
                "normal_placement": f"{before.tier}-{before.variant}",
                "stress_placement": f"{after.tier}-{after.variant}",
                "latency_delta_ms": after.service_latency_ms - before.service_latency_ms,
                "energy_delta_percent": 100 * (after.E_total_J - before.E_total_J) / before.E_total_J,
                "carbon_delta_percent": 100 * (after.carbon_mg - before.carbon_mg) / before.carbon_mg,
                "accuracy_delta_pp": float(
                    VARIANTS.loc[VARIANTS.variant == after.variant, "accuracy_percent"].iloc[0]
                    - VARIANTS.loc[VARIANTS.variant == before.variant, "accuracy_percent"].iloc[0]
                ),
            }
        )
    per_uc = pd.DataFrame(rows)

    def system_metrics(df: pd.DataFrame) -> dict:
        energy_rate = 0.0
        carbon_rate = 0.0
        t4_load = 0.0
        for _, row in df.iterrows():
            rate = rates[row.uc]
            energy_rate += rate * row.E_total_J
            carbon_rate += rate * row.carbon_mg
            if row.tier == "T4":
                f = float(VARIANTS.loc[VARIANTS.variant == row.variant, "GFLOPs_per_inference"].iloc[0])
                t4_load += rate * f
        return {"energy_J_per_s": energy_rate, "carbon_mg_per_s": carbon_rate, "T4_load_GFLOPS_per_s": t4_load}

    before_m = system_metrics(local)
    after_m = system_metrics(milp_sel)
    system = pd.DataFrame(
        [
            {"case": "Independent local placement", **before_m, "T4_capacity": 40.0, "capacity_feasible": before_m["T4_load_GFLOPS_per_s"] <= 40.0},
            {"case": "Capacity-constrained MILP", **after_m, "T4_capacity": 40.0, "capacity_feasible": after_m["T4_load_GFLOPS_per_s"] <= 40.0},
        ]
    )
    return per_uc, system


def daily_load_fraction(hour: int) -> float:
    # 3GPP-inspired three-level 24-hour profile: 6 low, 10 medium, 8 high hours.
    if 0 <= hour < 6:
        return 0.10
    if 6 <= hour < 16:
        return 0.30
    return 0.50


def rates_for_hour(hour: int, rng: np.random.Generator, scale: float = 1.0) -> Dict[str, float]:
    peak = {"UC1": 6.8, "UC2": 6.8, "UC3": 12.0, "UC4": 200.0}
    frac = daily_load_fraction(hour % 24)
    rates = {}
    for uc, p in peak.items():
        noise = float(np.clip(rng.normal(1.0, 0.08), 0.75, 1.25))
        rates[uc] = scale * p * frac * noise
    return rates


def controlled_simulation(cand: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    records = []
    for seed in RNG_SEEDS:
        rng = np.random.default_rng(seed)
        for h in range(192):
            rates = rates_for_hour(h, rng, scale=1.0)
            # Two deterministic outages totaling seven analyzed hours per seed.
            analyzed_h = h - 24
            outage = analyzed_h in set(range(48, 51)) | set(range(120, 124)) if analyzed_h >= 0 else False
            availability = {tier: 1 for tier in TIERS.tier}
            if outage:
                availability["T4"] = 0
            selected, _ = solve_hour(cand, rates, availability, allow_unserved=True)
            if h < 24:
                continue
            for _, row in selected.iterrows():
                records.append(
                    {
                        "seed": seed,
                        "hour": analyzed_h,
                        "uc": row.uc,
                        "tier": row.tier,
                        "variant": row.variant,
                        "outage": outage,
                        "rate_inf_per_s": rates[row.uc],
                        "E_total_J": row.get("E_total_J", np.nan),
                        "carbon_mg": row.get("carbon_mg", np.nan),
                    }
                )
    paths = pd.DataFrame(records)
    summaries = []
    for seed in RNG_SEEDS:
        d = paths[paths.seed == seed].copy()
        served = d[d.tier != "UNSERVED"]
        summaries.append(
            {
                "seed": seed,
                "served_assignments": len(served),
                "unserved_assignments": int((d.tier == "UNSERVED").sum()),
                "UC3_T3_reassignments": int(((d.uc == "UC3") & (d.tier == "T3")).sum()),
                "UC3_T4_assignments": int(((d.uc == "UC3") & (d.tier == "T4")).sum()),
                "outage_hours": int(d.groupby("hour").outage.first().sum()),
                "weighted_energy_J": float((served.E_total_J * served.rate_inf_per_s * 3600).sum()),
                "weighted_carbon_mg": float((served.carbon_mg * served.rate_inf_per_s * 3600).sum()),
            }
        )
    return paths, pd.DataFrame(summaries)


def trace_driven_simulation() -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    windows = load_carbon_trace_windows()
    b5_static = select_baselines(candidates())
    b5_map = {
        row.uc: (row.tier, row.variant)
        for _, row in b5_static[b5_static.method == "B5"].iterrows()
    }
    records = []
    seed_summaries = []
    for window, hourly in windows.items():
        # Placement and per-inference carbon depend on the trace but not on the
        # stochastic workload seed because capacity/outages are disabled here.
        hourly_decisions = []
        for h, (ts, cirow) in enumerate(hourly.iterrows()):
            ci = {tier: float(cirow[region]) / 1000.0 for tier, region in TIER_REGION_NAMES.items()}
            cand_h = candidates(ci_override=ci)
            decisions = {}
            for uc in USE_CASES.uc:
                d = cand_h[(cand_h.uc == uc) & (cand_h.K == 1) & (cand_h.A == 1)]
                ease = d.sort_values(["suitability", "carbon_mg", "E_total_J"], ascending=[False, True, True]).iloc[0]
                b5_t, b5_v = b5_map[uc]
                b5 = d[(d.tier == b5_t) & (d.variant == b5_v)].iloc[0]
                decisions[uc] = (ease, b5, b5_t, b5_v)
            hourly_decisions.append((h, ts, ci, decisions))

        for seed in RNG_SEEDS:
            rng = np.random.default_rng(seed)
            ease_total = 0.0
            b5_total = 0.0
            for h, ts, ci, decisions in hourly_decisions:
                rates = rates_for_hour(h, rng, scale=0.25)
                for uc in USE_CASES.uc:
                    ease, b5, b5_t, b5_v = decisions[uc]
                    rate = rates[uc]
                    ease_hour = float(ease.carbon_mg * rate * 3600)
                    b5_hour = float(b5.carbon_mg * rate * 3600)
                    ease_total += ease_hour
                    b5_total += b5_hour
                    records.append(
                        {
                            "window": window,
                            "seed": seed,
                            "hour": h,
                            "timestamp": ts,
                            "uc": uc,
                            "ease_tier": ease.tier,
                            "ease_variant": ease.variant,
                            "b5_tier": b5_t,
                            "b5_variant": b5_v,
                            "rate_inf_per_s": rate,
                            "ease_carbon_mg_per_inf": ease.carbon_mg,
                            "b5_carbon_mg_per_inf": b5.carbon_mg,
                            "T2_CI_g_per_kWh": ci["T2"] * 1000.0,
                            "T3_CI_g_per_kWh": ci["T3"] * 1000.0,
                            "T4_CI_g_per_kWh": ci["T4"] * 1000.0,
                        }
                    )
            seed_summaries.append(
                {
                    "window": window,
                    "seed": seed,
                    "EASE_carbon_mg": ease_total,
                    "B5_carbon_mg": b5_total,
                    "reduction_percent": 100.0 * (b5_total - ease_total) / b5_total,
                }
            )
    paths = pd.DataFrame(records)
    summary = pd.DataFrame(seed_summaries)
    first_seed = paths[paths.seed == RNG_SEEDS[0]].copy()
    first_seed["differs_from_B5"] = first_seed.ease_tier != first_seed.b5_tier
    switch = (
        first_seed.groupby(["window", "uc"])
        .agg(
            EASE_tier_counts=("ease_tier", lambda x: json.dumps(x.value_counts().to_dict(), sort_keys=True)),
            hours_different_from_B5=("differs_from_B5", "sum"),
        )
        .reset_index()
    )
    return paths, summary, switch

def sensitivity(cand: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    # Payload and accelerator-efficiency robustness.
    records = []
    for payload_scale in [0.5, 1.0, 2.0]:
        for ee_factor in [0.75, 1.0, 1.25]:
            scale = {tier: ee_factor for tier in TIERS.tier}
            c = candidates(payload_scale=payload_scale, ee_scale=scale)
            s = select_static(c)
            for _, row in s.iterrows():
                records.append(
                    {
                        "payload_scale": payload_scale,
                        "EE_scale": ee_factor,
                        "uc": row.uc,
                        "placement": f"{row.tier}-{row.variant}",
                    }
                )
    robustness = pd.DataFrame(records)

    # Isolate T2/T3 PUE and CI interaction for UC4 while keeping other parameters fixed.
    grid = []
    pue_t3_vals = np.round(np.linspace(1.15, 1.55, 9), 3)
    ci_ratio_vals = np.round(np.linspace(0.30, 1.40, 12), 3)
    t2_ci = float(TIERS.loc[TIERS.tier == "T2", "CI_kg_per_kWh"].iloc[0])
    for pue_t3 in pue_t3_vals:
        for ratio in ci_ratio_vals:
            pue = {"T3": float(pue_t3)}
            ci = {"T2": t2_ci, "T3": t2_ci * float(ratio)}
            c = candidates(ci_override=ci, pue_override=pue)
            d = c[(c.uc == "UC4") & (c.K == 1) & (c.A == 1) & (c.tier.isin(["T2", "T3"])) & (c.variant == "V4")]
            row = d.sort_values(["carbon_mg", "E_total_J"], ascending=[True, True]).iloc[0]
            grid.append({"T3_PUE": pue_t3, "CI_T3_over_T2": ratio, "selected_tier": row.tier})
    return robustness, pd.DataFrame(grid)


def make_figures(
    baselines: pd.DataFrame,
    trace_paths: pd.DataFrame,
    sensitivity_grid: pd.DataFrame,
) -> None:
    # Figure 1: continuum
    fig, ax = plt.subplots(figsize=(9.5, 2.2))
    ax.axis("off")
    xs = np.linspace(0.08, 0.92, 5)
    for x, (_, row) in zip(xs, TIERS.iterrows()):
        ax.text(x, 0.55, f"{row.tier}\n{row['name']}", ha="center", va="center", bbox=dict(boxstyle="round,pad=0.35", facecolor="white", edgecolor="black"))
    for a, b in zip(xs[:-1], xs[1:]):
        ax.annotate("", xy=(b - 0.065, 0.55), xytext=(a + 0.065, 0.55), arrowprops=dict(arrowstyle="<->"))
    ax.text(0.5, 0.12, "One tier-variant pair per use case; hard service and accuracy gates precede capacity-aware placement", ha="center")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig1_continuum.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Figure 2: pipeline
    fig, ax = plt.subplots(figsize=(9.5, 2.2))
    ax.axis("off")
    labels = ["UC requirements", "Tier + variant\nprofiles", "Energy + carbon", "Hard KPI +\naccuracy gates", "Suitability", "MILP"]
    xs = np.linspace(0.06, 0.94, len(labels))
    for x, label in zip(xs, labels):
        ax.text(x, 0.55, label, ha="center", va="center", bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor="black"), fontsize=9)
    for a, b in zip(xs[:-1], xs[1:]):
        ax.annotate("", xy=(b - 0.055, 0.55), xytext=(a + 0.055, 0.55), arrowprops=dict(arrowstyle="->"))
    ax.text(0.5, 0.12, "Communication energy = active access transmission + aggregate path transport", ha="center")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig2_pipeline.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Figure 3: operational baseline comparison by UC.
    operational = baselines[baselines.method.isin(["B3", "B4", "B5", "EASE-6G"])].copy()
    pivot = operational.pivot(index="uc", columns="method", values="carbon_mg")
    ax = pivot.plot(kind="bar", figsize=(8.2, 4.2))
    ax.set_ylabel("Carbon per inference (mg CO$_2$)")
    ax.set_xlabel("Use case")
    ax.set_title("Operational smart-baseline carbon comparison")
    ax.legend(title="Method")
    fig = ax.get_figure()
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig3_baseline_carbon.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Figure 4: seasonal 2026 trace-driven reductions and reassignment counts.
    d = trace_paths.copy()
    d["ease_carbon_hour"] = d.ease_carbon_mg_per_inf * d.rate_inf_per_s * 3600.0
    d["b5_carbon_hour"] = d.b5_carbon_mg_per_inf * d.rate_inf_per_s * 3600.0
    seasonal = (
        d.groupby(["window", "seed"])[["ease_carbon_hour", "b5_carbon_hour"]].sum().reset_index()
    )
    seasonal["reduction_percent"] = 100.0 * (seasonal.b5_carbon_hour - seasonal.ease_carbon_hour) / seasonal.b5_carbon_hour
    reductions = seasonal.groupby("window").reduction_percent.mean().reindex([x[0] for x in TRACE_WINDOWS])
    first = d[d.seed == RNG_SEEDS[0]]
    switch_uc3 = first[first.uc == "UC3"].groupby("window").apply(lambda x: int((x.ease_tier != x.b5_tier).sum()), include_groups=False).reindex(reductions.index)
    switch_uc4 = first[first.uc == "UC4"].groupby("window").apply(lambda x: int((x.ease_tier != x.b5_tier).sum()), include_groups=False).reindex(reductions.index)
    x = np.arange(len(reductions))
    fig, ax = plt.subplots(figsize=(8.2, 4.4))
    bars = ax.bar(x, reductions.values)
    ax.set_ylabel("Cumulative carbon reduction vs B5 (%)")
    ax.set_xticks(x, [w.replace(" 2026", "") for w in reductions.index])
    ax.set_title("Reference topology: seasonal trace outcome")
    for rect, val in zip(bars, reductions.values):
        ax.text(rect.get_x() + rect.get_width()/2, rect.get_height(), f"{val:.2f}%", ha="center", va="bottom", fontsize=8)
    ax2 = ax.twinx()
    ax2.plot(x, switch_uc3.values, marker="o", label="UC3 hours different from B5")
    ax2.plot(x, switch_uc4.values, marker="s", label="UC4 hours different from B5")
    ax2.set_ylabel("Placement-difference hours vs B5")
    ax2.legend(loc="upper right", fontsize=7)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig4_trace_switching.png", dpi=220, bbox_inches="tight")
    plt.close(fig)

    # Figure 5: PUE-CI selection map.
    p = sensitivity_grid.pivot(index="T3_PUE", columns="CI_T3_over_T2", values="selected_tier")
    z = p.replace({"T2": 0, "T3": 1}).astype(float)
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    im = ax.imshow(z.values, origin="lower", aspect="auto", extent=[p.columns.min(), p.columns.max(), p.index.min(), p.index.max()])
    ax.set_xlabel("T3/T2 carbon-intensity ratio")
    ax.set_ylabel("T3 PUE")
    ax.set_title("UC4 carbon-optimal tier under independent PUE and carbon variation")
    cbar = fig.colorbar(im, ax=ax, ticks=[0, 1])
    cbar.ax.set_yticklabels(["T2", "T3"])
    fig.tight_layout()
    fig.savefig(FIG_DIR / "fig5_pue_ci_map.png", dpi=220, bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    TIERS.to_csv(RESULTS_DIR / "table_II_tiers.csv", index=False)
    VARIANTS.to_csv(RESULTS_DIR / "table_III_variants.csv", index=False)
    USE_CASES.to_csv(RESULTS_DIR / "table_IV_use_cases.csv", index=False)

    cand = candidates()
    cand.to_csv(RESULTS_DIR / "all_candidates.csv", index=False)
    static = select_static(cand)
    static.to_csv(RESULTS_DIR / "static_placements.csv", index=False)
    baselines = select_baselines(cand)
    baselines.to_csv(RESULTS_DIR / "baseline_results.csv", index=False)
    abl = ablation(cand)
    abl.to_csv(RESULTS_DIR / "ablation_results.csv", index=False)
    weights = weight_sweep(cand)
    weights.to_csv(RESULTS_DIR / "weight_sweep.csv", index=False)
    per_uc, system = capacity_stress(cand)
    per_uc.to_csv(RESULTS_DIR / "capacity_fallback_per_uc.csv", index=False)
    system.to_csv(RESULTS_DIR / "capacity_system_metrics.csv", index=False)
    controlled_paths, controlled_summary = controlled_simulation(cand)
    controlled_paths.to_csv(RESULTS_DIR / "controlled_simulation_paths.csv", index=False)
    controlled_summary.to_csv(RESULTS_DIR / "controlled_simulation_seed_summary.csv", index=False)
    trace_paths, trace_summary, trace_switch = trace_driven_simulation()
    trace_paths.to_csv(RESULTS_DIR / "trace_simulation_paths.csv", index=False)
    trace_summary.to_csv(RESULTS_DIR / "trace_simulation_seed_summary.csv", index=False)
    trace_switch.to_csv(RESULTS_DIR / "trace_switch_summary.csv", index=False)
    trace_window_summary = trace_summary.groupby("window").reduction_percent.agg(["mean", "std", "min", "max"]).reset_index()
    trace_window_summary.to_csv(RESULTS_DIR / "trace_window_summary.csv", index=False)
    robustness, pue_ci = sensitivity(cand)
    robustness.to_csv(RESULTS_DIR / "payload_ee_robustness.csv", index=False)
    pue_ci.to_csv(RESULTS_DIR / "pue_ci_sensitivity.csv", index=False)

    make_figures(baselines, trace_paths, pue_ci)

    metadata = {
        "python": sys.version,
        "platform": platform.platform(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "scipy": scipy.__version__,
        "matplotlib": plt.matplotlib.__version__,
        "solver": "scipy.optimize.milp with HiGHS backend",
        "mip_relative_gap": 1e-9,
        "time_limit_seconds": 30.0,
        "seeds": RNG_SEEDS,
        "effective_bandwidth_factor": RHO_B,
        "access_profiles": {
            r.uc: {
                "bandwidth_Gbps": float(r.access_bandwidth_Gbps),
                "tx_power_W": float(r.access_tx_power_W),
            }
            for _, r in USE_CASES.iterrows()
        },
        "transport_energy_nJ_per_bit": {r.tier: float(r.transport_energy_nJ_per_bit) for _, r in TIERS.iterrows()},
        "carbon_archive": CARBON_ARCHIVE.name,
        "trace_windows": [{"label": l, "start": s, "end": e} for l, s, e in TRACE_WINDOWS],
    }
    (RESULTS_DIR / "environment.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")

    # Compact summary for manuscript generation and verification.
    op = baselines[baselines.method.isin(["B3", "B4", "B5", "EASE-6G", "Oracle"])].groupby("method")[["E_total_J", "carbon_mg"]].mean()
    summary = {
        "static": static[["uc", "tier", "variant", "E_total_J", "carbon_mg", "suitability"]].to_dict("records"),
        "operational_means": op.reset_index().to_dict("records"),
        "weight_vectors": int(weights[["wE", "wC", "wK"]].drop_duplicates().shape[0]),
        "weight_counts": weights.groupby(["uc", "tier", "variant"]).size().reset_index(name="count").to_dict("records"),
        "controlled_seed_mean": controlled_summary.mean(numeric_only=True).to_dict(),
        "controlled_seed_sd": controlled_summary.std(numeric_only=True, ddof=1).to_dict(),
        "trace_seed_mean": trace_summary.mean(numeric_only=True).to_dict(),
        "trace_seed_sd": trace_summary.std(numeric_only=True, ddof=1).to_dict(),
        "trace_window_summary": trace_window_summary.to_dict("records"),
        "trace_switch": trace_switch.to_dict("records"),
    }
    (RESULTS_DIR / "manuscript_summary.json").write_text(json.dumps(summary, indent=2, default=float), encoding="utf-8")
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
