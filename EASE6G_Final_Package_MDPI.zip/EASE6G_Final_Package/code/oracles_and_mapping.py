#!/usr/bin/env python3
from __future__ import annotations
import itertools, json, math
from pathlib import Path
from typing import Mapping
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import Bounds, LinearConstraint, milp
import ease6g_revision_model as model

ROOT=Path(__file__).resolve().parent.parent
R=ROOT/'results'; F=ROOT/'figures'
R.mkdir(exist_ok=True); F.mkdir(exist_ok=True)

REGIONS=['London','South East England','East England','North Scotland']
REFERENCE={'T1':'London','T2':'South East England','T3':'East England','T4':'North Scotland'}


def oracle_ka_static(cand: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    for uc in model.USE_CASES.uc:
        d=cand[(cand.uc==uc)&(cand.K==1)&(cand.A==1)].copy()
        r=d.sort_values(['carbon_mg','E_total_J','service_latency_ms']).iloc[0]
        rows.append({'method':'Oracle-KA','uc':uc,'tier':r.tier,'variant':r.variant,'E_total_J':r.E_total_J,'carbon_mg':r.carbon_mg})
    return pd.DataFrame(rows)


def oracle_k_static(cand: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    for uc in model.USE_CASES.uc:
        d=cand[(cand.uc==uc)&(cand.K==1)].copy()
        r=d.sort_values(['carbon_mg','E_total_J','service_latency_ms']).iloc[0]
        rows.append({'method':'Oracle-K','uc':uc,'tier':r.tier,'variant':r.variant,'E_total_J':r.E_total_J,'carbon_mg':r.carbon_mg})
    return pd.DataFrame(rows)


def solve_carbon_hour(cand: pd.DataFrame, rates: Mapping[str,float], availability: Mapping[str,int], allow_unserved=False):
    feasible=cand[(cand.K==1)&(cand.A==1)].copy()
    feasible=feasible[feasible.tier.map(lambda x: availability.get(x,1)==1)].reset_index(drop=True)
    n_pair=len(feasible); ucs=list(model.USE_CASES.uc); n_u=len(ucs) if allow_unserved else 0; n=n_pair+n_u
    c=np.zeros(n)
    for i,row in feasible.iterrows():
        c[i]=float(rates[row.uc])*float(row.carbon_mg)
    if allow_unserved: c[n_pair:]=1e6
    A=[]; lb=[]; ub=[]
    for j,uc in enumerate(ucs):
        coeff=np.zeros(n); coeff[:n_pair]=(feasible.uc==uc).astype(float)
        if allow_unserved: coeff[n_pair+j]=1.0
        A.append(coeff); lb.append(1.0); ub.append(1.0)
    for _,tier in model.TIERS.iterrows():
        coeff=np.zeros(n)
        for i,row in feasible.iterrows():
            if row.tier==tier.tier:
                f=float(model.VARIANTS.loc[model.VARIANTS.variant==row.variant,'GFLOPs_per_inference'].iloc[0])
                coeff[i]=float(rates[row.uc])*f
        A.append(coeff); lb.append(-np.inf); ub.append(float(tier.CAP_AI_GFLOPS_per_s))
    res=milp(c=c,integrality=np.ones(n),bounds=Bounds(np.zeros(n),np.ones(n)),constraints=LinearConstraint(np.vstack(A),np.array(lb),np.array(ub)),options={'mip_rel_gap':1e-9,'time_limit':30.0})
    if not res.success: raise RuntimeError(res.message)
    x=np.rint(res.x).astype(int); selected=feasible.loc[x[:n_pair]==1].copy()
    return selected.sort_values('uc')


def build_oracles():
    cand=model.candidates()
    ok=oracle_k_static(cand); oka=oracle_ka_static(cand)
    pd.concat([ok,oka],ignore_index=True).to_csv(R/'oracle_static_results.csv',index=False)
    ease=model.select_static(cand)[['uc','tier','variant','E_total_J','carbon_mg']].copy(); ease['method']='EASE-6G'
    cmp=pd.concat([ease,oka],ignore_index=True)
    cmp.to_csv(R/'oracle_static_comparison.csv',index=False)

    rates={'UC1':4.0,'UC2':4.0,'UC3':6.0,'UC4':100.0}; avail={t:1 for t in model.TIERS.tier}
    ease_cap,_=model.solve_hour(cand,rates,avail,allow_unserved=False)
    oka_cap=solve_carbon_hour(cand,rates,avail,allow_unserved=False)
    rows=[]
    for method,d in [('EASE-6G',ease_cap),('Oracle-KA',oka_cap)]:
        for _,r in d.iterrows():
            rows.append({'method':method,'uc':r.uc,'tier':r.tier,'variant':r.variant,'E_total_J':r.E_total_J,'carbon_mg':r.carbon_mg,'rate_inf_per_s':rates[r.uc]})
    cap=pd.DataFrame(rows); cap.to_csv(R/'oracle_capacity_results.csv',index=False)

    windows=model.load_carbon_trace_windows(); seed_rows=[]; path_rows=[]
    for w,hourly in windows.items():
        decisions=[]
        for h,(ts,cirow) in enumerate(hourly.iterrows()):
            ci={tier:float(cirow[region])/1000.0 for tier,region in model.TIER_REGION_NAMES.items()}
            c=model.candidates(ci_override=ci)
            e=model.select_static(c).set_index('uc'); o=oracle_ka_static(c).set_index('uc')
            decisions.append((h,ts,e,o))
        for seed in model.RNG_SEEDS:
            rng=np.random.default_rng(seed); ec=oc=0.0; same=0
            for h,ts,e,o in decisions:
                rates=model.rates_for_hour(h,rng,scale=0.25)
                for uc in model.USE_CASES.uc:
                    er=e.loc[uc]; orow=o.loc[uc]; rate=rates[uc]
                    ec+=float(er.carbon_mg)*rate*3600; oc+=float(orow.carbon_mg)*rate*3600
                    same+=int((er.tier==orow.tier) and (er.variant==orow.variant))
                    path_rows.append({'window':w,'seed':seed,'hour':h,'timestamp':ts,'uc':uc,'ease_tier':er.tier,'ease_variant':er.variant,'oracle_ka_tier':orow.tier,'oracle_ka_variant':orow.variant,'same_placement':int((er.tier==orow.tier) and (er.variant==orow.variant))})
            seed_rows.append({'window':w,'seed':seed,'EASE_carbon_mg':ec,'Oracle_KA_carbon_mg':oc,'gap_percent':100*(ec-oc)/oc,'placement_match_percent':100*same/(168*4)})
    pd.DataFrame(path_rows).to_csv(R/'oracle_trace_paths.csv',index=False)
    seed_df=pd.DataFrame(seed_rows); seed_df.to_csv(R/'oracle_trace_seed_summary.csv',index=False)
    seed_df.groupby('window').agg(gap_mean_percent=('gap_percent','mean'),gap_sd_percent=('gap_percent','std'),placement_match_mean_percent=('placement_match_percent','mean')).reset_index().to_csv(R/'oracle_trace_window_summary.csv',index=False)


def mapping_robustness():
    windows=model.load_carbon_trace_windows(); combined=pd.concat(windows.values())
    means={r:float(combined[r].mean())/1000.0 for r in REGIONS}
    static_rows=[]; dyn_seed_rows=[]; map_defs=[]
    for mid,perm in enumerate(itertools.permutations(REGIONS),start=1):
        mapping=dict(zip(['T1','T2','T3','T4'],perm)); mapping['T5']=mapping['T4']
        ref=all(mapping[k]==REFERENCE[k] for k in REFERENCE)
        map_defs.append({'mapping_id':mid,'is_reference':ref,**{k:mapping[k] for k in ['T1','T2','T3','T4','T5']}})
        ci={t:means[r] for t,r in mapping.items()}
        c=model.candidates(ci_override=ci); e=model.select_static(c); b=model.select_baselines(c); b5=b[b.method=='B5']; oka=oracle_ka_static(c)
        ec=float(e.carbon_mg.mean()); bc=float(b5.carbon_mg.mean()); oc=float(oka.carbon_mg.mean())
        static_rows.append({'mapping_id':mid,'is_reference':ref,'EASE_mean_carbon_mg':ec,'B5_mean_carbon_mg':bc,'Oracle_KA_mean_carbon_mg':oc,'reduction_vs_B5_percent':100*(bc-ec)/bc,'gap_vs_Oracle_KA_percent':100*(ec-oc)/oc,'EASE_placements':'; '.join(f'{r.uc}:{r.tier}-{r.variant}' for _,r in e.iterrows())})
        for w,hourly in windows.items():
            hourly_dec=[]
            for h,(ts,row) in enumerate(hourly.iterrows()):
                ci_h={t:float(row[r])/1000.0 for t,r in mapping.items()}
                ch=model.candidates(ci_override=ci_h); eh=model.select_static(ch).set_index('uc'); bh=model.select_baselines(ch); b5h=bh[bh.method=='B5'].set_index('uc'); oh=oracle_ka_static(ch).set_index('uc')
                hourly_dec.append((h,eh,b5h,oh))
            for seed in model.RNG_SEEDS:
                rng=np.random.default_rng(seed); ec=bc=oc=0.0
                for h,eh,b5h,oh in hourly_dec:
                    rates=model.rates_for_hour(h,rng,scale=0.25)
                    for uc in model.USE_CASES.uc:
                        rate=rates[uc]; ec+=float(eh.loc[uc].carbon_mg)*rate*3600; bc+=float(b5h.loc[uc].carbon_mg)*rate*3600; oc+=float(oh.loc[uc].carbon_mg)*rate*3600
                dyn_seed_rows.append({'mapping_id':mid,'is_reference':ref,'window':w,'seed':seed,'reduction_vs_B5_percent':100*(bc-ec)/bc,'gap_vs_Oracle_KA_percent':100*(ec-oc)/oc})
    maps=pd.DataFrame(map_defs); static=pd.DataFrame(static_rows); dyn=pd.DataFrame(dyn_seed_rows)
    maps.to_csv(R/'mapping_definitions.csv',index=False); static.to_csv(R/'mapping_static_results.csv',index=False); dyn.to_csv(R/'mapping_trace_seed_results.csv',index=False)
    win=dyn.groupby(['mapping_id','is_reference','window']).agg(reduction_mean_percent=('reduction_vs_B5_percent','mean'),reduction_sd_percent=('reduction_vs_B5_percent','std'),oracle_gap_mean_percent=('gap_vs_Oracle_KA_percent','mean')).reset_index(); win.to_csv(R/'mapping_trace_window_results.csv',index=False)
    summary={
        'static_positive_mappings':int((static.reduction_vs_B5_percent>0).sum()),'mapping_count':len(static),
        'static_median_reduction_percent':float(static.reduction_vs_B5_percent.median()),'static_min_reduction_percent':float(static.reduction_vs_B5_percent.min()),'static_max_reduction_percent':float(static.reduction_vs_B5_percent.max()),
        'dynamic_by_window':{}
    }
    for w,g in win.groupby('window'):
        summary['dynamic_by_window'][w]={'positive_mappings':int((g.reduction_mean_percent>0).sum()),'median_reduction_percent':float(g.reduction_mean_percent.median()),'min_reduction_percent':float(g.reduction_mean_percent.min()),'max_reduction_percent':float(g.reduction_mean_percent.max())}
    (R/'mapping_robustness_summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    order=[x[0] for x in model.TRACE_WINDOWS]
    fig,ax=plt.subplots(figsize=(8.2,4.4))
    data=[win[win.window==w].reduction_mean_percent.values for w in order]
    ax.boxplot(data,labels=[w.replace(' 2026','') for w in order])
    ax.axhline(0,linewidth=1); ax.set_ylabel('Carbon reduction vs B5 across 24 mappings (%)'); ax.set_title('Regional mapping robustness')
    fig.tight_layout(); fig.savefig(F/'fig7_mapping_robustness.png',dpi=220,bbox_inches='tight'); plt.close(fig)
    print(json.dumps(summary,indent=2))

if __name__=='__main__':
    build_oracles(); mapping_robustness()
