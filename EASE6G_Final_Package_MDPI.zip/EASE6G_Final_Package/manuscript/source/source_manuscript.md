Abstract--- Artificial intelligence and machine learning (AI/ML)
inference across the sixth-generation (6G) cloud--edge--device continuum
creates a placement problem that couples hard service and accuracy
constraints with compute energy, access airtime, path transport,
capacity, and time-varying grid carbon. This paper presents EASE-6G, a
regime-aware placement framework. Its communication model separates
destination-independent access time from destination-dependent
path-transport energy. Across four reference use cases (UC1--UC4),
UC1--UC2 are gate dominated and UC3--UC4 transport dominated. B3
(nearest-feasible), B4 (latency--energy), B5 (carbon-unaware), EASE-6G,
and Oracle-KA (feasible minimum-carbon oracle) select identical
placements; three 168-hour seasonal traces yield 0% carbon separation
from B5. We derive pairwise decision boundaries in effective operational
intensity and evaluate the jointly feasible regional-edge (T2) and
metro-edge (T3) tier pair. Its use-case-independent energy crossover is
2.586 GFLOP/Mbit; under UC4 access conditions, its mean-carbon crossover
is 26.086 GFLOP/Mbit. Under a controlled T2--T3 operational-intensity
envelope assuming nonbinding tier capacities, and with default
energy/carbon/KPI weights of 0.40/0.40/0.20, the maximum static carbon
reduction versus B5 across the 11 declared intensity points is 19.15% at
3 GFLOP/Mbit. Complete hourly evaluations across three seasonal windows
yield positive reductions in 12 of 33 window--intensity cells, reaching
58.95%. These weight-dependent results do not establish
capacity-feasible operation at original workload rates. Under capacity
stress, a mixed-integer linear program restores feasibility by moving
only UC3 from far-edge to metro-edge execution with the same model,
increasing system energy and carbon rates by 1.15% and 1.77%. EASE-6G
identifies gate-, transport-, carbon-, and capacity-dominated regimes
rather than assuming universal carbon savings.

**Index Terms---** 6G networks, AI inference placement, Green AI,
carbon-aware computing, edge computing, MEC, MILP, PUE, model
compression, trace-driven simulation.

# I. INTRODUCTION

Sixth-generation (6G) networks are expected to evolve from communication
systems into distributed artificial intelligence (AI) execution fabrics
spanning remote cloud, regional and metro edge, far edge, and user
devices \[1\], \[2\]. The associated placement decision must satisfy
latency, throughput, reliability, jitter, model quality, resource
capacity, and sustainability requirements. Service requirements,
multi-access edge computing (MEC) architecture, edge-intelligence
research, and 6G vision studies provide the basis for this continuum
\[3\]-\[9\].

The central difficulty is that energy and carbon are related but not
interchangeable. A placement with lower joules per inference can emit
more carbon when its electricity supply is more carbon intensive.
Conversely, a less energy-efficient tier can emit less carbon when it
operates on a substantially cleaner grid \[10\]-\[17\]. Model choice
introduces another dimension because full-precision, distilled,
quantized, and dynamically pruned variants have different compute and
accuracy profiles \[18\], \[19\], \[20\]-\[22\].

EASE-6G addresses a sharper question than whether carbon-aware placement
can be formulated: under what combinations of service feasibility,
effective model work per transported bit, path energy, infrastructure
efficiency, grid carbon, and shared capacity does carbon awareness
change a decision that would otherwise be made by a nearest-feasible or
energy-aware policy? The framework combines physically separated compute
and communication models, hard gates, multi-criteria scoring, and
capacity-constrained placement, then derives and tests the boundaries
between the resulting decision regimes.

The contributions are:

1.  **Physically separated energy components:** destination-independent
    access throughput and airtime are separated from
    destination-dependent path transport, while compute energy uses
    generic accelerator efficiency. Access airtime depends on the source
    link, while path length affects transport energy.
2.  **Tier-service-feasible tier-variant placement:** Hard
    destination-tier service KPI and model-accuracy gates exclude
    candidate assignments that violate the modeled tier-level service
    requirements or accuracy thresholds. Source-access throughput is
    modeled separately for communication-energy accounting and is not
    treated as an additional end-to-end feasibility constraint. The
    framework models latency at the destination-tier service level;
    hardware-specific accelerator execution latency remains outside the
    intended system-level abstraction.
3.  **Capacity-aware optimization:** a mixed-integer linear program
    (MILP) jointly assigns tier-variant pairs under aggregate AI
    capacity and availability constraints.
4.  **Benchmark and trace grounding:** model profiles use a consistent
    ImageNet transformer family; dynamic validation combines a
    controlled capacity-and-outage simulation with three pre-specified
    2026 seasonal regional carbon-intensity windows and a 3GPP-inspired
    24-hour traffic profile.
5.  **Decision-boundary evaluation:** effective operational intensity
    reveals when the reference null result is expected and when
    carbon-sensitive alternatives reopen. Static crossovers, predeclared
    intensity sweeps, three seasonal traces, capacity stress, and
    communication-parameter sensitivity are reported without claiming
    universal savings.

# II. RELATED WORK

Table I compares related studies along dimensions required to judge
whether an inference-placement framework can make feasible, carbon-aware
decisions across an entire cloud--edge--device continuum. The columns
distinguish (i) the execution topology and whether requests are placed
or a network is partitioned, (ii) model or variant selection, (iii) hard
latency and service-KPI enforcement, (iv) accuracy or uncertainty
constraints, (v) temporally varying grid carbon intensity (CI), (vi)
shared compute-capacity constraints, (vii) evaluation using real,
monitored, or production traces, and (viii) joint tier--variant
selection from a five-tier candidate architecture, subject to service
and model feasibility constraints. A "Partial" entry indicates that a
capability is present only for a subset of these conditions, rather than
for the complete joint decision.

For this comparison, a tier is a distinct placement layer with its own
admissibility and operational profiles: remote cloud, regional edge,
metro edge, far edge, or on-device. Two-tier and three-tier studies are
classified by the distinct execution layers their optimizers explicitly
consider, not by a claim that their underlying network physically lacks
other nodes. The literature is organized into MEC placement and
offloading (Section II-A), carbon-aware inference and scheduling
(Section II-B), and model variants and benchmarking (Section II-C). This
organization separates where a task executes, how grid carbon affects
that decision, and which model implementation the task executes.

## A. MEC and Edge AI Placement

MEC and edge-computing studies establish computation offloading and
distributed resource allocation across device, edge, and cloud resources
\[23\]-\[25\]. These works commonly optimize latency, energy, or
resource use, but they generally do not combine grid carbon,
model-quality enforcement, and multi-workload capacity-constrained
tier-variant assignment.

## B. Carbon-Aware Edge and Inference Systems

Green AI and carbon-aware computing quantify operational and embodied
emissions and show that location and time can change the preferred
execution point \[10\]-\[17\]. GreenScale studies carbon-aware
scheduling across edge and cloud resources \[26\]. CarbonCP jointly
considers end-to-end operational carbon, latency, edge-device battery
use, and uncertainty-aware deep neural network (DNN) partitioning
\[27\]. CARBONDIS schedules inference requests on heterogeneous GPUs
under latency constraints and time-varying grid carbon \[28\]. EcoServe
addresses operational and embodied carbon in cloud AI serving using
production traces and system rightsizing \[29\]. CarbonEdge extends
adaptive edge inference with carbon estimation and weighted green
scheduling \[30\].

Wu et al. proposed CarbonEdge (HPDC 2025), which exploits mesoscale
spatial variations in grid carbon intensity to place workloads across
distributed edge data centers while satisfying latency and
compute-capacity constraints. It accounts for heterogeneous server
efficiency and power states and evaluates AI inference workloads \[31\].
Unlike EASE-6G, it does not jointly select accuracy-gated model variants
across the cloud--edge--device continuum or explicitly separate
source-access and aggregate path-transport energy.

These systems provide important foundations, but they do not jointly
enforce service and model-accuracy gates while selecting tier-model
pairs under shared five-tier capacity constraints. Weighted-sum
optimization provides a standard way to express preferences among
competing objectives, but the weights influence the selected solution
\[32\], \[33\].

## C. Model Variants and Benchmarking

Quantization and pruning reduce storage, arithmetic cost, or data
movement \[18\], \[19\], \[34\]. Mobile-optimized networks and
transformers illustrate the wider compute-accuracy design space
\[20\]-\[22\], \[34\]-\[36\]. Low-rank adaptation (LoRA) reduces
trainable parameters during adaptation but is not an
inference-compression technique \[37\]; it is therefore not used as a
lower-FLOP variant. MLPerf provides architecture-neutral inference and
power methodology across datacenter, edge, mobile, and tiny systems
\[38\], \[39\]. Table I summarizes the direct feature-level comparison
with the closest related systems; SLO denotes service-level objective.

**TABLE I. DIRECT RELATED-WORK COMPARISON**

  ----------------------------------------------------------------------------------------------------------------------------------------------------
  **Work**     **Edge/cloud   **Model/variant   **Hard          **Accuracy/uncertainty   **Dynamic   **Shared     **Trace/data          **Joint
               placement or   choice**          latency/KPI**   control**                grid CI**   capacity**   evidence**            five-tier
               partition**                                                                                                              assignment**
  ------------ -------------- ----------------- --------------- ------------------------ ----------- ------------ --------------------- --------------
  GreenScale   Yes            No                Partial         No                       Yes         Partial      Yes                   No
  \[26\]                                                                                                                                

  CarbonCP     Partition      Partial           Yes             Yes                      Yes         No           Yes                   No
  \[27\]                                                                                                                                

  CARBONDIS    GPU scheduling No                Yes             No                       Yes         Partial      Yes                   No
  \[28\]                                                                                                                                

  EcoServe     Cloud serving  Hardware/system   SLO             No                       Partial     Yes          Production            No
  \[29\]                                                                                                                                

  CarbonEdge   Edge partition Partial           Yes             Partial                  Yes         Partial      Simulated/monitored   No
  (Zhang et                                                                                                                             
  al.) \[30\]                                                                                                                           

  CarbonEdge   Edge-site      No                Yes             No                       Yes         Yes          Real CI/latency       No
  (Wu et al.)  placement                                                                                          traces                
  \[31\]                                                                                                                                

  EASE-6G      Five tiers     Yes               Yes             Yes                      Yes         Yes          Archived CI forecasts Yes
  ----------------------------------------------------------------------------------------------------------------------------------------------------

For EASE-6G, the trace-based evaluation uses archived National Energy
System Operator (NESO) regional carbon-intensity forecasts together with
synthetic workload profiles; it does not rely on measured operator
traffic or realized regional carbon-intensity observations.

# III. PROBLEM DEFINITION AND SYSTEM MODEL

The placement problem is to assign each inference service uc to one
available execution tier t and one locally available model variant v. An
admissible assignment must meet that service's latency, throughput,
reliability, jitter, and (when defined) model-accuracy requirements,
while competing services share finite tier admission capacity. Among
admissible combinations, the policy assesses active compute and
communication energy, location- and time-dependent operational carbon,
and service-quality headroom. Section III-A defines eligible execution
resources, Section III-B defines the model choice at each resource, and
Section III-C defines the service requirements and payloads that jointly
determine eligibility. Section IV formalizes the resulting decision
rule; Section V supplies the analytical reference values used for
evaluation.

Conceptually, the inputs form three intersecting sets: candidate
execution resources (Section III-A), candidate trained-model
implementations (Section III-B), and service-level requirements (Section
III-C). A service can run at a tier only when the tier meets its
network-service thresholds and an available model implementation meets
its accuracy threshold. This forms the feasible tier-variant set passed
to the EASE-6G evaluation and capacity allocator. Fig. 1 illustrates the
physical five-tier execution continuum, while Fig. 2 presents the
logical decision process that evaluates feasible tier-variant
combinations and allocates shared capacity. Neither representation
assumes that all services use the same model or execution destination.

## A. Edge-to-Cloud Infrastructure

EASE-6G considers five execution tiers: T1 remote cloud, T2 regional
edge, T3 metro edge, T4 far edge, and T5 on-device. Each tier is
represented by service-layer latency, nominal service bandwidth,
reliability, jitter, power usage effectiveness (PUE), grid carbon
intensity (CI), generic accelerator energy efficiency in GFLOP/(s W),
path-transport intensity, and aggregate AI capacity. Access-link
throughput and active transmission power are use-case properties rather
than destination-tier properties.

A tier identifies the destination of inference execution, not the number
of hops in the communication path. Fig. 1 gives a conceptual overview of
the five available execution layers; Fig. 2 depicts the decision
sequence that matches service requirements and eligible model variants
to these layers. The policy outputs a tier-variant routing decision
without transferring model weights at each decision. For each service,
tier capability and model accuracy are checked before energy, carbon,
and shared capacity determine the admissible assignment. The numerical
tier profiles appear in Table II of Section V.

In an operational deployment, a tier--variant pair must satisfy model
availability, serving readiness, and storage and accelerator-memory
requirements before admission. The reference experiments assume that
eligible model variants are pre-positioned and ready to serve; they do
not explicitly simulate or enforce model-loading or memory-readiness
constraints. The implemented placement optimization enforces service
KPI, model accuracy, tier availability, and aggregate computing
capacity.

**Bandwidth-feasibility scope.** The bandwidth gate assesses the nominal
service bandwidth B(t) of the destination execution tier against
B~min~(uc). Separately, the effective source-access rate B~eff,uc~
supports access-airtime and communication-energy accounting. The model
does not impose B~eff,uc~ \>= B~min~(uc) as an additional end-to-end
throughput gate. Accordingly, admitted placements satisfy the defined
tier-service requirements, not a demonstrated end-to-end
radio-throughput guarantee. This is an explicit scope restriction of the
reference evaluation.

**Latency and capacity scope.** L(t) is a deployment-level
service-latency abstraction, not one-way propagation delay or a
communication-energy input. The experiments use fixed analytical values
and do not simulate accelerator queues. CAP~AI~(t) is a schedulable
admission limit with reserved utilization headroom, not physical
saturation throughput, and Eq. (17) prohibits demand above it. An
operational controller can supply queue-aware L(t,h) or reduce
CAP~AI~(t,h). If effective latency exceeds L~max~(uc), the latency
indicator I~L~(t,uc) in the gate of Eq. (9) becomes zero and removes
that tier from the use case\'s feasible set. Explicit execution and
queueing models require deployment calibration.

![Conceptual EASE-6G execution continuum showing five interconnected
tiers: T1 Remote Cloud, T2 Regional Edge, T3 Metro Edge, T4 Far Edge,
and T5 On-Device. Bidirectional arrows illustrate the relationships
between adjacent execution tiers. Numerical reference configurations are
provided separately in Table II.](media/image1.png){width="6.8in"
height="1.269867672790901in"}

Fig. 1. Conceptual five-tier EASE-6G execution continuum. Numerical
reference profiles appear in Table II.

## B. Model-Variant Profiles

A model-variant profile describes a candidate inference implementation
using its nominal floating-point computation per request, predictive
accuracy, and a dimensionless precision-energy factor. EASE-6G considers
a full-precision reference (V1), a distilled smaller network (V2), a
post-training quantization (PTQ) variant (V3), and a dynamically
token-pruned model (V4). The scheduler evaluates variants only where
their model artifacts are ready and their task accuracy meets the
relevant service floor. These are alternative computation--accuracy
choices, not different execution tiers. Their numerical reference
profiles appear in Table III in Section V.

Table III uses one common ImageNet classification benchmark to establish
a controlled accuracy-compute trade-off. The values exercise the
placement-and-accuracy decision defined in Section IV; they do not imply
that one trained classifier represents all four 6G use cases.
Operational deployment would substitute task-specific accuracy and
complexity measurements.

## C. Analytical Service Profiles and Payloads

The service profile is the source of the per-request requirements
against which every tier-variant assignment is checked. UC1 represents
ultra-low-latency control, UC2 mobility-critical operation, UC3
high-reliability interaction, and UC4 high-throughput video analytics.
Each profile specifies a maximum service latency, a minimum bandwidth
and reliability, a maximum jitter, an optional minimum model accuracy,
and bidirectional input-plus-output payload per inference. Such
application labels illustrate distinct constraint regimes and do not
establish performance measurements for a particular deployed use case.
Table IV in Section V records the reference settings; service
constraints then enter the gates in Section IV-D. The selection of
service-latency, throughput, reliability, and jitter dimensions draws on
3GPP service requirements and network KPIs \[3\], \[4\], with the
distributed-execution setting motivated by ETSI MEC \[5\]. These sources
do not prescribe the numerical UC1--UC4 assumptions in Table IV.

# IV. EASE-6G FRAMEWORK

Fig. 2 shows the complete EASE-6G decision process: collect service
requirements and eligible pre-positioned models, read execution-tier and
access/path parameters, exclude infeasible tier-variant pairs, compute
energy and carbon scores for the surviving candidates, and solve for
capacity- and availability-feasible routing assignments. Subsections
IV-A and IV-B specify compute and communication energy; IV-C combines
them into operational energy, carbon, and normalized scores; IV-D
applies hard service and accuracy gates; IV-E constructs KPI headroom
and the weighted suitability score; IV-F enforces shared capacity using
a mixed-integer linear program; and IV-G describes deployment as a
routing policy. The formulas define this study's analytical model; their
underlying measurement concepts draw on PUE \[13\], \[17\], inference
benchmarking \[38\], \[39\], transport-energy modeling \[40\], and
weighted-sum optimization \[32\], \[33\].

![Fig. 2. EASE-6G decision
pipeline.](media/image2.png){width="7.285811461067366in"
height="1.9006463254593176in"}

Fig. 2. EASE-6G decision pipeline.

## A. Compute Energy

Per-inference compute energy uses accelerator energy efficiency and
facility overhead:

$$E_{\text{compute}}(t,v) = \text{PUE}(t)\,\frac{F(v)}{\text{EE}(t)}\,\delta(v).$$
(1)

Here $F(v)$ is in GFLOP/inference, $\text{EE}(t)$ is in GFLOP/(s W), and
therefore $F/\text{EE}$ is joules/inference. $\delta(v)$ captures
precision-dependent arithmetic and memory effects that are not
represented by nominal GFLOP count. PUE accounts for facility overhead
once; T5 uses the on-device configuration specified in Table II. Idle
allocation and named-accelerator calibration remain outside scope.

Specifically, t identifies a destination execution tier, v a model
variant, and F(v) the nominal GFLOP count needed to execute one
inference. F(v) is taken from the cited transformer model profiles
\[20\]--\[22\], rather than calculated from payload D or inferred from
bandwidth; a new application must profile its own model. EE(t) denotes
the tier's modeled accelerator work rate per watt, PUE(t) the
facility-to-IT power ratio, and δ(v) the analytical precision-dependent
energy multiplier. E~compute~(t,v) is measured in J/inference. These
variables are defined here symbolically; their experimental values are
reported in Tables II--III (Section V).

The nominal work F(v) corresponds to the forward-pass operation count
for variant v at the benchmark input configuration, expressed as GFLOP
per inference. For this controlled study, the reported counts are
adopted from the cited model publications and profiles rather than
independently measured on each tier. Computational work, energy per
operation, and capacity are distinct: F(v) controls workload demand,
F(v)/EE(t) controls the modeled active computation energy before PUE and
δ(v), and tier capacity constrains concurrent admitted demand. The
precision-energy factor δ(v) is an analytical multiplier and does not
imply a measured reduction in nominal GFLOP count.

## B. Payload- and Path-Aware Communication Energy

Communication energy separates access-link transmission from path
transport. For use case uc, the effective access throughput is

$$B_{\text{eff,uc}} = \rho_{B}B_{\text{access,uc,}}$$ (2)

and the active access-transmission time is

$$T_{\text{tx,uc}} = \frac{D_{\text{uc}}}{B_{\text{eff,uc}}}.$$ (3)

The bidirectional input-plus-output payload D~uc~ is measured in bits.
Both B~access,uc~ and P~tx,uc~ are independent of the selected
destination tier. With εₜ reported in nJ/bit, total communication energy
is

$$E_{\text{comm}}\left( t,\text{uc} \right) = P_{\text{tx,uc}}T_{\text{tx,uc}} + D_{\text{uc}}\varepsilon_{t} \times 10^{- 9}.$$
(4)

In Eqs. (2)--(4), uc indexes the service profile; D~uc~ is the total
bidirectional bits transferred for one remote inference; B~access,uc~ is
source access-link rate in Gbit/s; ρ~B~ is the dimensionless
effective-rate fraction; B~eff,uc~ is the usable access throughput in
Gbit/s; and T~tx,uc~ is the corresponding active airtime in seconds. In
Eq. (3), D~uc~ is expressed in bits and B~eff,uc~ is converted to bit/s
before division. P~tx,uc~ is the source radio's active transmission
power in W, while εₜ is the destination-dependent aggregate path energy
in nJ/bit. E~comm~(t,uc) adds source-access J/inference to aggregate
path J/inference after unit conversion. The access and transport
separation follows the communication-energy accounting approach
motivated by \[40\], with calibrated source-link values needed for
deployment.

The first term is access energy and is identical across offloaded
destinations for a fixed use case; the second term is
destination-dependent aggregate path transport. The tier-specific
intensity is a configurable analytical input rather than a universal
network constant. Section V specifies the reference values and their
derivation; the communication-parameter sensitivity and
operational-intensity tests assess their consequences.

Equation (4) applies to remote inference at T1--T4. For on-device
inference at T5, E~comm~(T5,uc) = 0 by definition, since neither an
upstream access transmission nor a remote path transport occurs. The
model accounts only for active access airtime plus an aggregate path
term; propagation, queueing, and service latency are not multiplied by
transmission power. Protocol signaling, retransmissions, and radio-state
transitions require deployment-specific calibration and remain outside
scope.

## C. Total Energy and Carbon

$$E_{\text{total}}\left( t,v,\text{uc} \right) = E_{\text{compute}}(t,v) + E_{\text{comm}}\left( t,\text{uc} \right).$$
(5)

For each use case, energy and carbon normalization is performed only
over candidates that satisfy both hard service and accuracy gates. This
prevents infeasible extrema from changing the relative score of
selectable candidates. Lower feasible energy maps to the score

$$\eta\left( t,v,\text{uc} \right) = 1 - \frac{E_{\text{total}}\left( t,v,\text{uc} \right) - E_{\text{min}}\left( \text{uc} \right)}{E_{\text{max}}\left( \text{uc} \right) - E_{\text{min}}\left( \text{uc} \right)}.$$
(6)

With total energy in J/inference and carbon intensity in kg CO₂/kWh,
division by 3.6 converts the product directly to mg CO₂/inference
because 1 kWh=3.6×10^6^ J and 1 kg=10^6^ mg. Equation (7) therefore
reports milligrams of CO₂ per inference:

$$c_{\text{mg}}\left( t,v,\text{uc} \right) = \frac{E_{\text{total}}\left( t,v,\text{uc} \right)\text{CI}(t)}{3.6}.$$
(7)

Using the same hard-feasible candidate set, the carbon-efficiency score
is

$$c_{\text{eff}}\left( t,v,\text{uc} \right) = 1 - \frac{c_{\text{mg}}\left( t,v,\text{uc} \right) - c_{\text{min}}\left( \text{uc} \right)}{c_{\text{max}}\left( \text{uc} \right) - c_{\text{min}}\left( \text{uc} \right)}.$$
(8)

If the feasible energy or carbon range is zero, its normalized score
equals one for all feasible candidates. Equation (7) uses
destination-tier carbon intensity as a proxy for the entire operational
energy total; it does not resolve the electricity mix at individual
access and transport nodes.

For Eqs. (5)--(8), E~total~(t,v,uc) is the sum of compute and
communication joules per inference, CI(t) is the tier-specific
electricity carbon intensity in kg CO₂/kWh, and c~mg~(t,v,uc) is the
resulting operational carbon in mg CO₂/inference. E~min~(uc),
E~max~(uc), c~min~(uc), and c~max~(uc) are extrema calculated only
across candidates passing all hard gates. η(t,v,uc) and c~eff~(t,v,uc)
are dimensionless energy and carbon preference scores, respectively;
they increase as the underlying cost decreases. The use of the
destination CI for the complete energy sum is an explicit modeling
assumption, not a measured carbon accounting of each access or transit
node.

In hourly carbon-trace evaluations, the tier carbon intensity is
represented by CI(t,h), where h denotes the evaluation hour. The
corresponding carbon emissions, carbon-efficiency scores, and placement
suitability are recalculated using the carbon intensity for that hour.
For compact notation, the hourly index is suppressed in the general
formulation. Static evaluations use the specified reference mean carbon
intensities.

## D. Hard Feasibility Gates

Let $I\lbrack z\rbrack$ equal one when condition $z$ is true and zero
otherwise. The four complete KPI indicators are

$$I_{L}\left( t,\text{uc} \right) = I\left\lbrack L(t) \leq L_{\text{max}}\left( \text{uc} \right) \right\rbrack,$$

$$I_{B}\left( t,\text{uc} \right) = I\left\lbrack B(t) \geq B_{\text{min}}\left( \text{uc} \right) \right\rbrack,$$

$$I_{R}\left( t,\text{uc} \right) = I\left\lbrack R(t) \geq R_{\text{min}}\left( \text{uc} \right) \right\rbrack,$$

$$I_{J}\left( t,\text{uc} \right) = I\left\lbrack J(t) \leq J_{\text{max}}\left( \text{uc} \right) \right\rbrack.$$

The service KPI gate is therefore

$$K\left( t,\text{uc} \right) = I_{L}\left( t,\text{uc} \right)I_{B}\left( t,\text{uc} \right)I_{R}\left( t,\text{uc} \right)I_{J}\left( t,\text{uc} \right).$$
(9)

In Eq. (9), I\[condition\] denotes the binary truth indicator. L(t),
B(t), R(t), and J(t) represent service-layer tier latency, offered
bandwidth, reliability, and jitter. The requirements L~max~(uc),
B~min~(uc), R~min~(uc), and J~max~(uc) are the corresponding service
thresholds. I~L~, I~B~, I~R~, and I~J~ denote their individual checks;
K(t,uc) equals one only when all four pass. Specifically, I~B~ compares
destination-tier bandwidth B(t) with B~min~(uc); it does not test
B~eff,uc~. Source-access throughput contributes to Eqs. (2)--(4) and is
not an additional hard throughput gate in this analytical study. This
hard-gate construction implements the service-admissibility principle
motivated by \[3\]--\[5\], rather than a separate queue-delay model.

Because $L(t)$ is defined as service-layer tier latency, explicit
accelerator-card execution latency is not added again. For a use case
with a defined accuracy floor, the accuracy gate is

$$A\left( v,\text{uc} \right) = I\left\lbrack \text{Accuracy}(v) \geq \text{Acc}_{\text{min}}\left( \text{uc} \right) \right\rbrack.$$
(10)

For a use case without an accuracy floor,
$A\left( v,\text{uc} \right) = 1$ for every variant.

Equation (10) defines A(v,uc) as the binary model-accuracy eligibility
condition: Accuracy(v) is the candidate variant's reference accuracy and
Acc~min~(uc) is the minimum acceptable task accuracy, when one exists.
K(t,uc) and A(v,uc) together determine whether a candidate can receive a
nonzero suitability score.

## E. KPI Slack and Suitability

The four headroom components are

$$s_{L}\left( t,\text{uc} \right) = \frac{L_{\text{max}}\left( \text{uc} \right)}{L(t)},\quad\quad s_{B}\left( t,\text{uc} \right) = \frac{B(t)}{B_{\text{min}}\left( \text{uc} \right)},$$

$$s_{R}\left( t,\text{uc} \right) = \frac{R(t)}{R_{\text{min}}\left( \text{uc} \right)},\quad\quad s_{J}\left( t,\text{uc} \right) = \frac{J_{\text{max}}\left( \text{uc} \right)}{J(t)}.$$

Suppressing repeated (t, uc) arguments for compactness, the raw headroom
is the component sum. Its denominator is the maximum over
service-feasible tiers for that use case:

$$\text{KPI}_{\text{raw}}\left( t,\text{uc} \right) = s_{L} + s_{B} + s_{R} + s_{J}.$$
(11)

$$\text{KPI}_{\text{norm}}\left( t,\text{uc} \right) = \frac{\text{KPI}_{\text{raw}}\left( t,\text{uc} \right)}{\underset{t\prime:\ K(t\prime,uc) = 1}{\text{max}}\text{KPI}_{\text{raw}}\left( t\prime,\text{uc} \right)}.$$
(12)

For compact display, let $\eta = \eta\left( t,v,\text{uc} \right)$,
$c = c_{\text{eff}}\left( t,v,\text{uc} \right)$, and
$\kappa = \text{KPI}_{\text{norm}}\left( t,\text{uc} \right)$. The
weighted quality term is

$$Q\left( t,v,\text{uc} \right) = w_{E}\eta + w_{C}c + w_{K}\kappa,$$
(13)

and the gated suitability score is

$$S\left( t,v,\text{uc} \right) = K\left( t,\text{uc} \right)A\left( v,\text{uc} \right)Q\left( t,v,\text{uc} \right).$$
(14)

For Eqs. (11)--(14), s~L~, s~B~, s~R~, and s~J~ are dimensionless
requirement-to-performance or performance-to-requirement ratios, chosen
so that feasible positive headroom rewards service margin. KPI~raw~ is
their sum and KPI~norm~ is that sum divided by the largest value among
service-feasible tiers (K(t,uc) = 1) for the same service. The compact
symbols η, c, and κ denote normalized energy efficiency, normalized
carbon efficiency, and normalized KPI headroom. Q is the weighted
soft-preference term, while S(t,v,uc) applies the multiplicative hard
KPI and accuracy gates. The energy/carbon/KPI coefficients represent
declared design preferences, not learned optimal weights \[32\], \[33\].
The policy weights w~E~, w~C~, and w~K~ are nonnegative and sum to one.
Their reference values and weight-sensitivity analysis appear in Section
V-C.

The KPI-headroom components have different numerical scales. In the
reference configurations, reliability headroom exhibits relatively small
variation among feasible tiers, whereas latency and jitter headroom can
vary more substantially. Consequently, the normalized aggregate KPI
score may be more sensitive to latency and jitter differences.
Nevertheless, reliability remains independently enforced through its
hard feasibility gate. The current formulation retains these analytical
headroom definitions; deployment-specific calibration or component-level
normalization could be considered in future work.

## F. Capacity-Constrained MILP

Let $x_{t,v,\text{uc}} \in \{ 0,1\}$ denote assignment,
$\lambda_{\text{uc}}(h)$ denote inference arrival rate in inferences/s,
and $y_{\text{uc}}(h) \in \{ 0,1\}$ denote an unserved state used only
when no feasible assignment exists during the controlled
capacity-and-outage simulation. Taking $M$ as an unserved-state penalty
greater than the maximum possible aggregate suitability of the
considered services, the hourly objective is

$$\underset{x,y}{\text{max}}\left\lbrack \sum_{\text{uc}}^{}{\sum_{t}^{}{\sum_{v}^{}S}}\left( t,v,\text{uc} \right)x_{t,v,\text{uc}} - M\sum_{\text{uc}}^{}y_{\text{uc}}(h) \right\rbrack.$$
(15)

Equation (15) gives each service profile equal decision importance,
while arrival rate determines aggregate demand in Eq. (17), preventing
request volume alone from allowing a best-effort profile to dominate a
lower-volume critical service. The objective maximizes service-level
suitability; it does not minimize workload-weighted carbon. Agreement
with Oracle-KA therefore holds only in the reported uncongested
envelope, where each use case can select its preferred feasible
candidate. Under asymmetric capacity or availability constraints, the
MILP may accept higher carbon to preserve feasibility or service
fairness. Strict workload-weighted carbon minimization requires a carbon
objective under the same constraints, or a lexicographic objective after
satisfying service priorities.

In Eqs. (15)--(18), x~t,v,uc~ is a binary assignment to a tier-model
pair at the hourly solve h, with the h index suppressed on x in Eqs.
(15)--(18) for readability; λ~uc~(h) is the service arrival rate at hour
h in inferences/s; y~uc~(h) is a binary indicator for unavoidable
unserved demand; and M is the specified penalty for that state. The
objective maximizes the sum of service-level suitability scores and
penalizes unserved profiles. CAP~AI~(t) is the reserved schedulable
capacity of tier t in nominal GFLOP/s, so λ~uc~(h)F(v) is admitted
computing demand, while V~avail~(t,h) indicates tier availability. The
assignment, tier-capacity, availability, KPI, and accuracy constraints
enforce a single admissible outcome per service. The MILP uses standard
binary-constrained optimization rather than a claimed universal
minimum-carbon objective.

The first summation in the objective ranges over service profiles uc and
the eligible tiers t and variants v; the unserved penalty sums over
service profiles only. In the capacity constraint, λ~uc~(h)F(v) converts
inference/s into nominal GFLOP/s. The binary quantity V~avail~(t,h)
represents tier availability only. In the reference implementation, all
tier--variant pairs are initially enumerated, and the solver considers
only pairs passing the KPI and accuracy gates on available tiers. The
implementation does not separately measure or test model readiness or
accelerator-memory sufficiency. It assumes the admitted variants are
pre-positioned and ready to serve, as described in the reference
analytical input configurations in Section V. Deployments lacking a
particular tier--variant pair must exclude it from the candidate set
before optimization.

Each use case is either assigned once or explicitly marked unserved:

$$\sum_{t}^{}{\sum_{v}^{}x_{t,v,\text{uc}}} + y_{\text{uc}}(h) = 1,\quad\forall\text{uc}.$$
(16)

Tier capacity is

$$\sum_{\text{uc}}^{}{\sum_{v}^{}\lambda_{\text{uc}}}(h)F(v)x_{t,v,\text{uc}} \leq \text{CAP}_{\text{AI}}(t),\quad\forall t.$$
(17)

Availability, KPI feasibility, accuracy feasibility, and binary
decisions are enforced by

$$\begin{matrix}
x_{t,v,\text{uc}} & \leq V_{\text{avail}}(t,h), \\
x_{t,v,\text{uc}} & \leq K\left( t,\text{uc} \right), \\
x_{t,v,\text{uc}} & \leq A\left( v,\text{uc} \right), \\
x_{t,v,\text{uc}} & \in \{ 0,1\},\quad y_{\text{uc}}(h) \in \{ 0,1\}.
\end{matrix}$$ (18)

In all experiments except the controlled capacity-and-outage simulation,
$y_{\text{uc}}(h)$ is fixed to zero. Only that simulation permits
unserved assignments, allowing unavoidable service loss to be reported
instead of making the hourly MILP infeasible. The seasonal carbon-trace
and operational-intensity evaluations assume feasible assignments and do
not model outage-driven service loss.

## G. Operational Deployment Interpretation

EASE-6G can operate as a policy engine within an edge-cloud management
and orchestration platform. Its inputs comprise service requirements,
model availability, tier capacity and availability,
infrastructure-efficiency profiles, communication parameters, and
current or forecast regional carbon intensity. The controller resolves
placement periodically or after material events such as a tier outage,
capacity-threshold crossing, carbon-intensity change, or
model-availability update. Its output is a tier-variant routing policy
for subsequent inference requests among pre-positioned instances.
Depending on the deployment, the policy engine may integrate with MEC
orchestration, cloud management, a Service Management and Orchestration
(SMO)-like platform, or a future 6G management function; the framework
does not depend on one specific standardized controller.

# V. EVALUATION METHODOLOGY

This section defines the reference inputs, computational environment,
and evaluation experiments; Section VI presents the results in matching
subsections. Reported measures include selected tier-variant placement,
feasibility and accuracy violations, score and KPI headroom,
per-inference compute, communication, and total energy (J/inference),
operational carbon (mg CO₂/inference), system energy and carbon rates
(J/s and mg CO₂/s), schedulable capacity load (GFLOP/s), unserved
assignments, carbon reduction relative to the B5 baseline, crossover
intensity, and sensitivity of placement to policy and communication
assumptions. Section V-A addresses static placement (results in VI-A),
V-B operational baselines (VI-B), V-C ablation and weights (VI-C), V-D
capacity fallback (VI-D), V-E controlled stress (VI-E), V-F seasonal
carbon (VI-F), and V-G operational-intensity and communication
sensitivity (VI-G).

**Experimental environment and reproducibility.**

The evaluation pipeline uses Python 3.12.14 using NumPy 2.3.5, pandas
2.2.3, SciPy 1.17.0, and Matplotlib 3.10.8. MILPs use
`scipy.optimize.milp` with the HiGHS backend, a relative MIP gap of
$10^{- 9}$, and a 30-s time limit per solve. Experiments run in a Linux
x86-64 environment; the package records dependency versions and solver
settings. Fixed seeds were 17, 29, 43, 71, and 101. The scripts,
parameters, traces, figures, and CSV outputs accompany the manuscript.

Hourly observations are treated as descriptive time-series paths, not
independent statistical samples. Metrics are aggregated by independent
seed and reported as mean $\pm$ standard deviation.

**Implementation correspondence to Eqs. (12) and (18).** In the
submitted Python implementation, the Eq. (12) KPI-headroom denominator
is the maximum KPI raw score across tiers satisfying the service gate
K(t,uc)=1; the model-accuracy gate is not part of that denominator.
Energy and carbon extrema are calculated separately using candidates
satisfying both the KPI and accuracy gates. For Eq. (18), the hourly
MILP filters candidates by those two gates and tier availability, then
enforces aggregate compute capacity. No distinct tier--variant memory,
deployment, or readiness flag is implemented. The reported experiments
instead assume pre-positioned, service-ready variants; the
implementation does not validate loading delay, memory fit, or
cold-start behavior.

**Reference analytical input configurations.**

Tables II--IV specify the controlled evaluation inputs rather than
universal deployment measurements. Table II contains the execution-tier
capabilities and energy profiles, Table III the model-variant benchmark
settings, and Table IV the four service requirements and access-link
assumptions. Section III defines the corresponding conceptual entities,
while Section IV uses them as variables in the placement model.

For communication accounting, Table II defines only the
destination-dependent aggregate path-transport intensity εₜ. Values are
reported in nJ/bit and converted to J/bit in Eq. (4); access-link
parameters are specified with the service profiles.

The PUE and accelerator values in Table II are generic analytical tier
profiles, not claims about named commercial devices. They separate
per-inference efficiency from aggregate capacity: $\text{EE}(t)$
determines per-inference compute energy, whereas
$\text{CAP}_{\text{AI}}(t)$ is used only for aggregate workload
admission. MLPerf's cross-platform inference and power methodology
motivates this architecture-neutral treatment \[38\], \[39\]. Static
carbon intensity uses the mean across the three 2026 seasonal trace
windows described in Section V-F. Table II rounds these means for
display; the scripts retain full precision. Fig. 1 illustrates the
five-tier cloud-edge-radio-device continuum, while Fig. 2 presents the
tier-variant decision pipeline.

**TABLE II. FIVE-TIER REFERENCE CONFIGURATION**

  --------------------------------------------------------------------------------------------------------------------------------------------------------
  **Tier**   **Name**    **PUE**   **CI (kg     **Service   **B          **R**     **J      **EE        $\text{CAP}_{\text{AI}}$   **Trace    **εₜ\
                                   CO₂/kWh)**   latency     (Gbit/s)**             (ms)**   (GFLOP/(s   **(GFLOP/s)**              region**   (nJ/bit)**
                                                (ms)**                                      W))**                                             
  ---------- ----------- --------- ------------ ----------- ------------ --------- -------- ----------- -------------------------- ---------- ------------
  T1         Remote      1.20      0.168        75          100          0.99999   5        500         40,000                     London     12.66
             Cloud                                                                                                                            

  T2         Regional    1.30      0.181        10          50           0.99999   2        350         4,000                      South East 6.48
             Edge                                                                                                                  England    

  T3         Metro Edge  1.35      0.142        5           25           0.99990   0.5      275         400                        East       3.39
                                                                                                                                   England    

  T4         Far Edge    1.40      0.031        0.5         10           0.99999   0.1      200         40                         North      0
                                                                                                                                   Scotland   

  T5         On-Device   1.00      0.031        0.05        1            0.99900   0.01     100         4                          North      0
                                                                                                                                   Scotland   
  --------------------------------------------------------------------------------------------------------------------------------------------------------

**Reference path-energy assumptions.** Table II uses εₜ={12.66, 6.48,
3.39, 0, 0} nJ/bit for T1--T5. The 12.66-nJ/bit T1 value in \[40\] is an
analytical 2000-km path estimate composed of twelve 1.03-nJ/bit router
stages plus a 0.30-nJ/bit gateway. The T1 path-transport estimate
follows the analytical configuration reported by Kopras et al. \[40\],
which derives its component-level router and gateway energy costs from
earlier equipment studies. T2 and T3 are controlled six- and three-stage
instances of the same model, not measured universal constants. These
analytical transport profiles are also varied in the communication
sensitivity and decision-boundary experiments. The zero path-transport
intensity assigned to T4 represents an idealized far-edge deployment
without additional upstream transport stages beyond the source-access
link. Active access-transmission energy remains included. This
assumption does not imply zero network energy in practical far-edge
deployments. Because the transport-sensitivity analysis uses
multiplicative scaling, it does not evaluate positive T4 path-transport
costs.

V1 is the DeiT-B FP32 reference at 17.6 GFLOP/inference and 81.8% top-1
accuracy. V2 is distilled DeiT-S at 4.6 GFLOP/inference and 81.2%
accuracy \[20\]. V3 uses the same nominal work as V1 and the 81.29%
accuracy reported for approximately 8-bit post-training quantization
\[22\]. We assign V3 an analytical precision-energy factor of 0.45.
Reduced-precision hardware \[41\] and edge-inference measurements \[42\]
motivate energy savings, but neither establishes a universal
whole-inference multiplier for this abstraction. V4 uses DynamicViT-S
with a 0.7 token-keeping ratio, 2.9 GFLOP/inference, and 79.3% accuracy
\[21\]. For equal tier and payload, V3 consumes less energy than V2 only
if 17.6δ(V3) \< 4.6, hence δ(V3) \< 0.26136. Both pass the evaluated
accuracy gates, and nominal-work capacity favors V2. Thus V3 cannot
improve energy, carbon, or capacity over V2 at the assumed factor of
0.45; deployment-specific calibration remains necessary.

**TABLE III. LITERATURE-GROUNDED MODEL-VARIANT REFERENCE PROFILES**

  --------------------------------------------------------------------------------------------------
  **Variant**   **Description**   **Nominal           **ImageNet   **Precision-energy   **Source**
                                  GFLOP/inference**   top-1        factor** $\delta(v)$ 
                                                      accuracy**                        
  ------------- ----------------- ------------------- ------------ -------------------- ------------
  V1            DeiT-B FP32       17.6                81.80%       1.00                 \[20\]
                reference                                                               

  V2            Distilled DeiT-S  4.6                 81.20%       1.00                 \[20\]
                FP32                                                                    

  V3            DeiT-B 8-bit PTQ  17.6                81.29%       0.45                 \[22\];
                                                                                        analytical δ
                                                                                        = 0.45

  V4            DynamicViT-S      2.9                 79.30%       1.00                 \[21\]
                token-pruned                                                            
  --------------------------------------------------------------------------------------------------

**Model availability and memory boundary.** Pre-positioning denotes
locally available model artifacts and serving readiness; a tier change
redirects requests rather than transferring weights, and all variants
need not execute concurrently. Simultaneous V1-V4 weight residency is
approximately 0.61 GB before framework, activation, and runtime buffers.
The experiment assumes that each eligible tier, including T5, meets this
condition. A deployment must exclude a tier-variant pair when its
storage, accelerator-memory, or readiness budget is insufficient. T5\'s
4-GFLOP/s value is compute capacity, not memory capacity. Loading,
memory-residency energy, and idle static power remain outside the model.

Table IV defines four analytical service profiles motivated by
representative 6G application classes and the service-dimension concepts
in \[3\]--\[5\]. The requirements, payloads, and access-link settings in
Table IV are explicitly chosen analytical evaluation assumptions, not
numerical targets specified by \[3\]--\[5\] or validation of
manufacturing, mobility, clinical, or video models. Average
bidirectional payloads are controlled profiles rather than universal
packet sizes. The destination-independent access profiles are 10 Gbit/s
and 2 W for UC1--UC3, and 25 Gbit/s and 2.5 W for UC4; the
effective-rate factor is ρ~B~ = 0.60. These analytical source-link
assumptions apply to offloading destinations independently of their
service bandwidth. They do not represent a measured radio link or a
per-hop bottleneck model. In the reported evaluation, the bandwidth KPI
gate checks destination-tier service bandwidth only. The access-rate
profiles determine the transmission-energy term and therefore do not
assert that the stated tier-service bandwidth thresholds are met end to
end. All Mbit and Gbit/s values are converted to bits and bits/s before
evaluating Eqs. (2)--(4).

**TABLE IV. ANALYTICAL SERVICE-PROFILE REQUIREMENTS**

  -----------------------------------------------------------------------------------------------------------------------------------------------------------
  **UC**   **Name**                   $L_{\text{max}}$   $B_{\text{min}}$   $R_{\text{min}}$   $J_{\text{max}}$   $\text{Acc}_{\text{min}}$   **Payload
                                      **(ms)**           **(Gbit/s)**                          **(ms)**                                       (Mbit/inf.)**
  -------- -------------------------- ------------------ ------------------ ------------------ ------------------ --------------------------- ---------------
  UC1      Ultra-low-latency control  1                  10                 0.99999            0.5                80%                         2
           (manufacturing example)                                                                                                            

  UC2      Mobility-critical service  5                  1                  0.99999            1.0                80%                         8
           (vehicle example)                                                                                                                  

  UC3      High-reliability           10                 5                  0.99990            2.0                80%                         20
           interactive service                                                                                                                
           (clinical example)                                                                                                                 

  UC4      High-throughput            50                 20                 0.99900            10.0               None                        80
           video-analytics service                                                                                                            
  -----------------------------------------------------------------------------------------------------------------------------------------------------------

## A. Static Placement

The reference static experiment enumerates every available tier-variant
combination, applies service and accuracy gates, normalizes soft scores
over feasible candidates, and selects placements using the framework
policy. The analysis reports the chosen candidate and decomposed
per-inference metrics in Section VI-A. Capacity stress and outages are
excluded from this reference comparison.

## B. Operational Baselines and Carbon Bounds

We distinguish operational baselines B3--B5 from diagnostic baselines
B1--B2. Two study-defined carbon lower bounds, Oracle-KA and Oracle-K,
complement these methods. Their feasibility conditions and objectives
are specified below.

The primary operational comparison uses B3--B5. B3 selects the
lowest-service-latency feasible tier and then the lowest-energy
admissible variant. B4 minimizes L(t)/L~max~(uc) plus energy divided by
the largest hard-feasible candidate energy for that profile. B5 is the
carbon-unaware counterpart of EASE-6G: it applies the same hard gates,
removes the carbon term from the reference 0.40/0.40/0.20 policy, and
renormalizes the remaining weights to 2/3 energy and 1/3 KPI headroom.
EASE-6G uses Eq. (14) and the capacity-aware optimization in Eqs.
(15)--(18).

Two complementary carbon-only bounds are evaluated. Oracle-KA minimizes
operational carbon subject to service KPI, model-accuracy, assignment,
tier-capacity, and availability constraints; it is the fully feasible
carbon lower bound. Oracle-K applies the KPI conditions without the
accuracy gate, making it a diagnostic measure of accuracy-enforcement
cost. Unlike EASE-6G, these bounds do not reward energy efficiency, KPI
headroom, or balanced service-level suitability. Oracle-KA uses the same
hourly information as EASE-6G, not future carbon knowledge. B1 remains a
diagnostic uniform expectation over all 20 tier--variant pairs (five
tiers and four model variants) per use case, including infeasible pairs,
while B2 is an infeasible raw-energy bound; neither is included in the
primary operational comparison.

## C. Ablation and Weight Sensitivity

The static evaluation uses Tables II--IV. Component ablation removes
energy, carbon, KPI-score, or accuracy-gate terms. The reference
energy/carbon/KPI weights of 0.40/0.40/0.20 give energy and carbon equal
emphasis and KPI headroom a smaller soft preference after hard gating.
These values express policy preferences within weighted-sum optimization
\[32\], \[33\]; they do not represent a calibrated optimum. The
reference-profile weight sweep evaluates all 231 vectors on the simplex
w~E~+w~C~+w~K~=1 at 0.05 increments.

Independent EASE-6G selections break equal-score ties by lower carbon,
then lower energy; B5 uses lower energy. A pure-KPI weighting therefore
retains the EASE-6G carbon tie-break. The uncongested envelope uses
direct enumeration, which gives the exact assignment optimum when
capacity does not couple decisions.

## D. Capacity Fallback Cost

The stress vector is $\lambda_{UC1} = 4$, $\lambda_{UC2} = 4$,
$\lambda_{UC3} = 6$, and $\lambda_{UC4} = 100$ inferences/s. This
creates contention at T4 while preserving a KPI-feasible UC3 fallback at
T3. Results report both per-use-case degradation and system-wide
consequences. The capacity-fallback experiment uses a separate fixed
stress vector and is independent of the stochastic 24-hour workload
profile evaluated in Section V-E.

## E. Controlled Capacity-and-Outage Simulation

A 192-hour simulation removes a 24-hour warm-up and analyzes 168 hours.
Five fixed seeds are used. A 3GPP-inspired daily profile uses six
low-load, ten medium-load, and eight high-load hours \[43\], with
bounded 8% stochastic variation. Two T4 outage windows total seven
analyzed hours per seed. Static trace means are used so that this
experiment isolates capacity and availability behavior. The
unserved-state penalty M is set to 10 for this controlled experiment,
exceeding the maximum aggregate service suitability.

The synthetic arrival rates use reference coefficients of 6.8, 6.8, 12,
and 200 inferences/s for UC1--UC4, respectively. The daily profile
applies load multipliers of 0.10, 0.30, and 0.50 for the six low-load,
ten medium-load, and eight high-load hours. Each hourly rate
incorporates an independent Gaussian multiplier with mean 1 and standard
deviation 0.08, clipped to the interval \[0.75, 1.25\]. The seasonal
carbon-trace experiment additionally scales these arrival rates by 0.25.
These parameters are analytical workload assumptions rather than
measured operator traffic.

## F. Seasonal Carbon Trace Validation

The trace experiment uses three pre-specified complete Monday--Sunday
windows from 2026: 12--18 January (winter), 13--19 April (spring), and
6--12 July (summer). The three selected seven-day windows contain 1,008
half-hour forecast observations per NESO region, aggregated into 504
hourly observations per region \[44\], \[45\]. T1--T4 map to London,
South East England, East England, and North Scotland, respectively. For
the on-device T5 analytical profile, North Scotland serves as the
grid-carbon-intensity proxy. T5 is not selected in the four reference
service profiles because it fails the applicable service-feasibility
gates. Workload rates are scaled to 25% of the controlled scenario so
capacity and outages do not confound carbon-driven placement. Each
hourly solve evaluates routing among pre-positioned tier-model instances
and does not represent live migration of weights or application state.

## G. Operational-Intensity Boundaries and Communication Sensitivity

The intensity experiment analytically compares jointly service-feasible
tier pairs at equal effective model work per payload and then reruns the
declared points on every hourly carbon trace. The sensitivity experiment
varies communication inputs independently and in combinations, while
retaining the hard gates and model-variant profiles. Sections VI-F and
VI-G report the corresponding seasonal outcomes, analytical boundaries,
and robustness findings.

Communication robustness evaluates all 81 combinations of payload scale
(0.5, 1, and 2), effective-rate factor (0.4, 0.6, and 0.8), access-power
scale (0.5, 1, and 1.5), and transport-intensity scale (0.5, 1, and 2).

For the operational-intensity envelope, we evaluate one effective work
demand per Mbit at T2 and T3 and assume nonbinding capacity. Hourly
workload factors weight carbon totals; they do not establish capacity
feasibility for every intensity at the original 80-Mbit payload and
arrival rate.

The UC4 envelope fixes service gates and access conditions and evaluates
effective work per payload, χ = Fδ/D, at {0.01, 0.03, 0.03625, 0.10,
0.23, 0.30, 1, 3, 10, 30, 100} GFLOP/Mbit. Here D uses Mbit. Let a(t) =
PUE(t)/EE(t) in J/GFLOP. Define b(t) as the path intensity converted
from nJ/bit to J/Mbit by multiplying by 10⁻³, and e~acc,uc~ as access
energy per Mbit, obtained from 10⁻³P~tx,uc~/\[ρ~B~ B~access,uc~\] when
bandwidth uses Gbit/s. The energy per Mbit and pairwise boundaries are

$$E(t)/D\  = \ a(t)\chi\  + \ e_{acc,uc}\  + \ b(t),$$ (19)

$$\chi_{E}(i,j)\  = \ \frac{b(j)\  - \ b(i)}{a(i)\  - \ a(j)},$$ (20)

$$\chi_{C}(i,j)\  = \ \frac{\beta(j)\  - \ \beta(i)}{\alpha(i)\  - \ \alpha(j)}.$$
(21)

Here α(t) = CI(t)a(t) and β(t) = CI(t)\[e~acc,uc~ + b(t)\]. Equations
(20)--(21) require nonzero denominators and a common source-access term
for the offloading tiers. Only positive crossovers matter here. Equal
slopes yield either no isolated boundary or identical costs. Access
energy cancels from Eq. (20), but unequal carbon intensities retain it
in Eq. (21). T5 requires its zero-access term. Every declared intensity
uses all 168 hourly carbon values in each seasonal window.

For Eq. (19), E(t) abbreviates the modeled total operational energy at
tier t for a given effective-work intensity and use-case payload; D is
that payload expressed in Mbit, whereas D~uc~ in Eqs. (3)--(4) is
expressed in bits. The coefficient e~acc,uc~ is the access energy per
Mbit and is distinct from the dimensionless normalized carbon score c in
Eq. (13). These definitions hold for the remote T2/T3 pair considered in
the boundary calculation.

# VI. RESULTS AND DISCUSSION

At the reference operating points, UC1--UC2 are primarily gate
dominated, whereas UC3--UC4 occupy a low-intensity regime in which
communication and path-transport energy govern placement. These
conditions explain the convergence of EASE-6G and feasible operational
baselines in the static comparisons, as well as the absence of a carbon
advantage in the seasonal reference evaluations. Following the
experiment sequence in Section V, Sections VI-A and VI-B report static
placements, operational baselines, and carbon bounds; VI-C examines
accuracy constraints, ablation, and weight sensitivity; and VI-D and
VI-E quantify capacity-fallback and outage effects. Section VI-F
presents the seasonal carbon-trace validation, while VI-G identifies the
operational-intensity regimes and communication sensitivities under
which carbon-aware placement can offer benefits. Section VI-H discusses
these findings and their limitations.

## A. Static Placement

Table V reports the reference static result after hard-feasible
normalization. UC1 and UC2 are gate dominated and select T4-V2. UC3 also
selects T4-V2 because the far-edge path adds no upstream transport term
and has the lowest carbon intensity among feasible tiers. UC4 selects
T3-V4: T4 fails the 20-Gbit/s throughput gate, while T3\'s lower
path-transport cost outweighs T2\'s lower compute energy. The winning
score is 1.000 in each profile because its selected candidate is
simultaneously best in the normalized feasible energy, carbon, and KPI
terms; this does not imply that every feasible alternative is
equivalent.

Although the framework includes all five execution tiers, the reference
service requirements restrict the eligible candidates. T1 fails the
latency requirements of all four use cases because its modeled service
latency exceeds their maximum thresholds. T5 remains a candidate in the
device-to-cloud continuum, but its 1-Gbit/s service bandwidth and 0.999
reliability fail one or more requirements in every evaluated profile.
Consequently, the reported placements use only a feasible subset of the
five-tier architecture. Lightweight local tasks could activate T5 in
future evaluations.

**TABLE V. STATIC EASE-6G PLACEMENTS AND PER-INFERENCE METRICS**

  -----------------------------------------------------------------------------------------
  **UC**   **Placement**   **Score**   **Compute E   **Comm. E   **Total E  **Carbon (mg
                                       (J)**         (J)**       (J)**      CO₂)**
  -------- --------------- ----------- ------------- ----------- ---------- ---------------
  UC1      T4-V2           1.000       0.032200      0.000667    0.032867   0.000284

  UC2      T4-V2           1.000       0.032200      0.002667    0.034867   0.000301

  UC3      T4-V2           1.000       0.032200      0.006667    0.038867   0.000336

  UC4      T3-V4           1.000       0.014236      0.284533    0.298770   0.011811
  -----------------------------------------------------------------------------------------

## B. Operational Baselines and Carbon Bounds

The operational-policy comparison evaluates the feasible baselines and
carbon lower bound under the same reference profiles. Tables VI and VII
summarize the corresponding energy, carbon, and oracle outcomes, while
Fig. 3 visualizes the carbon results across services.

**TABLE VI. PRIMARY OPERATIONAL COMPARISON**

  ------------------------------------------------------------------------------
  **Method**   **Mean E     **Mean carbon (mg   **Interpretation**
               (J/inf.)**   CO₂/inf.)**         
  ------------ ------------ ------------------- --------------------------------
  B3           0.101342     0.003183            Nearest feasible service tier

  B4           0.101342     0.003183            Latency-energy minimizer

  B5           0.101342     0.003183            Carbon-unaware suitability

  EASE-6G      0.101342     0.003183            Service-fair carbon-aware
                                                placement

  Oracle-KA    0.101342     0.003183            Minimum carbon under all
                                                operational constraints
  ------------------------------------------------------------------------------

**TABLE VII. OPERATIONAL AND DIAGNOSTIC ORACLE GAPS**

  --------------------------------------------------------------------------------------------
  **UC**   **EASE-6G**   **Oracle-KA**   **EASE-KA     **Oracle-K**   **Accuracy-enforcement
                                         gap**                        gap**
  -------- ------------- --------------- ------------- -------------- ------------------------
  UC1      T4-V2         T4-V2           0.00%         T4-V4          56.76%

  UC2      T4-V2         T4-V2           0.00%         T4-V4          51.81%

  UC3      T4-V2         T4-V2           0.00%         T4-V4          44.13%

  UC4      T3-V4         T3-V4           0.00%         T3-V4          0.00%
  --------------------------------------------------------------------------------------------

![Fig. 3. Static operational carbon comparison under the path-aware
communication model; all feasible methods
coincide.](media/image3.png){width="3.317292213473316in"
height="1.9420330271216097in"}

Fig. 3. Static operational carbon comparison under the path-aware
communication model; all feasible methods coincide.

Table VII reports two diagnostic carbon gaps. The EASE-KA gap is the
percentage difference between EASE-6G and Oracle-KA carbon emissions,
normalized by Oracle-KA emissions. The accuracy-enforcement gap is the
percentage difference between EASE-6G and Oracle-K emissions, normalized
by Oracle-K emissions. Oracle-KA enforces both service KPI and
model-accuracy gates, whereas Oracle-K removes the accuracy gate. The
latter gap therefore quantifies the modeled carbon cost of enforcing
accuracy requirements and does not represent a feasible carbon saving
when those requirements remain mandatory.

Tables VI and VII show that, at the four reference operating points,
B3--B5, EASE-6G, and Oracle-KA select UC1--UC3=T4-V2 and UC4=T3-V4. All
therefore report 0.101342 J/inference and 0.003183 mg CO₂/inference, so
the static reference case has 0% carbon separation among operational
policies. Oracle-K removes the accuracy gate and selects V4 for
UC1--UC3, quantifying the energy and carbon cost of enforcing the 80%
accuracy floor.

This equality follows from the hard gates and reference energy-carbon
ordering. It characterizes the evaluated profiles rather than an
equivalence between the policy objectives.

B1 is 0.174848 J and 0.007004 mg CO₂/inference; B2 is infeasible.

## C. Ablation and Weight Sensitivity

**TABLE VIII. COMPONENT ABLATION**

  ----------------------------------------------------------------------------------------------
  **Configuration**   **Placements**            **Mean E     **Mean carbon  **Accuracy-invalid
                                                (J/inf.)**   (mg            selections**
                                                             CO₂/inf.)**    
  ------------------- ------------------------- ------------ -------------- --------------------
  Full EASE-6G        UC1:T4-V2, UC2:T4-V2,     0.101342     0.003183       0
                      UC3:T4-V2, UC4:T3-V4                                  

  No carbon           UC1:T4-V2, UC2:T4-V2,     0.101342     0.003183       0
                      UC3:T4-V2, UC4:T3-V4                                  

  No KPI score        UC1:T4-V2, UC2:T4-V2,     0.101342     0.003183       0
                      UC3:T4-V2, UC4:T3-V4                                  

  No energy           UC1:T4-V2, UC2:T4-V2,     0.101342     0.003183       0
                      UC3:T4-V2, UC4:T3-V4                                  

  No accuracy gate    UC1:T4-V4, UC2:T4-V4,     0.092417     0.003106       3
                      UC3:T4-V4, UC4:T3-V4                                  
  ----------------------------------------------------------------------------------------------

**TABLE IX. WEIGHT-SWEEP SELECTION COUNTS**

  -----------------------------------------------------------------------
  **UC**             **Placement**                   **Count**
  ------------------ ------------------------------- --------------------
  UC1                T4-V2                           231

  UC2                T4-V2                           231

  UC3                T4-V2                           231

  UC4                T3-V4                           231
  -----------------------------------------------------------------------

Tables VIII and IX report the component ablation and weight-sweep
selections. At the reference operating points, removing the carbon,
KPI-score, or energy term does not change the placements: UC1--UC3
remain at T4-V2 and UC4 at T3-V4. B5 and the no-carbon ablation use the
same renormalized policy by construction. All 231 weight vectors retain
the same reference placements, confirming local weight invariance rather
than universal placement invariance.

Removing the accuracy gate selects V4 for UC1-UC3, reducing mean energy
from 0.101342 to 0.092417 J/inference and mean carbon from 0.003183 to
0.003106 mg CO₂/inference, but creates three accuracy-invalid
selections. This invariance applies only to the static reference
profiles.

The supplementary weight analysis extends the same 231 vectors to all 11
declared intensities and three 168-hour windows in the uncongested T2/T3
envelope, with B5 fixed and the five workload seeds. Only 44/231 vectors
reproduce the default tier in every tested hour; 187 change at least one
selection, and seasonal savings versus B5 range from −60.51% to 58.95%.
Supplement S1 and its accompanying CSV files provide all 7,623 cells and
seed totals; the reference-profile invariance does not imply
weight-independent savings.

## D. Capacity Fallback Cost

**TABLE X. PER-USE-CASE FALLBACK COST UNDER CAPACITY STRESS**

  ------------------------------------------------------------------------------------------
  **UC**   **Normal**   **Stress**   $\Delta$      $\Delta$     $\Delta$     $\Delta$
                                     **latency     **energy**   **carbon**   **accuracy
                                     (ms)**                                  (pp)**
  -------- ------------ ------------ ------------- ------------ ------------ ---------------
  UC1      T4-V2        T4-V2        0.0           0.00%        0.00%        0.0

  UC2      T4-V2        T4-V2        0.0           0.00%        0.00%        0.0

  UC3      T4-V2        T3-V2        4.5           +149.70%     +1043.32%    0.0

  UC4      T3-V4        T3-V4        0.0           0.00%        0.00%        0.0
  ------------------------------------------------------------------------------------------

**TABLE XI. SYSTEM-LEVEL CAPACITY EFFECT**

  --------------------------------------------------------------------------------------------
  **Case**               **T4 load     **T4 capacity **Energy    **Carbon rate  **Feasible**
                         (GFLOP/s)**   (GFLOP/s)**   rate        (mg CO₂/s)**   
                                                     (J/s)**                    
  ---------------------- ------------- ------------- ----------- -------------- --------------
  Independent local      64.4          40            30.381103   1.185501       No
  placement                                                                     

  Capacity-constrained   36.8          40            30.730194   1.206507       Yes
  MILP                                                                          
  --------------------------------------------------------------------------------------------

Tables X and XI quantify the capacity fallback. The independent solution
would load T4 at 64.4 GFLOP/s versus its 40-GFLOP/s schedulable limit.
This 161% case is an intentionally infeasible counterfactual, not an
operating point at which the fixed 0.5-ms T4 latency is claimed to hold.
The MILP enforces Eq. (17) and moves only UC3 from T4-V2 to T3-V2,
reducing T4 load to 36.8 GFLOP/s, or 92% of the stated admission limit;
UC1, UC2, and UC4 remain unchanged. For UC3, the fallback adds 4.5 ms
service latency, increases per-inference energy by 149.70% and carbon by
1043.32%, and preserves accuracy. System energy rate rises from
30.381103 to 30.730194 J/s (+1.15%), while carbon rate rises from
1.185501 to 1.206507 mg/s (+1.77%). The large UC3 percentage uses a
small per-inference baseline, whereas the system percentage is workload
weighted across all services.

## E. Controlled Capacity-and-Outage Simulation

Across each 168-hour analyzed seed, T4 is unavailable for seven hours.
UC1 and UC2 are unserved only during these outage windows because no
remaining tier meets their complete service profiles. UC3 is assigned to
T3 for 63 hours and T4 for 105 hours per seed; the T3 assignments
include outage and capacity-driven fallback. The controlled experiment
therefore averages 63.0 ± 0.0 UC3 T3 assignments and 14.0 ± 0.0 unserved
assignments per seed. Workload-weighted totals vary across seeds, but
the structural behavior is stable.

## F. Seasonal Carbon Trace Validation

Table XII reports the reference-topology seasonal null result from 168
hourly evaluations per window. EASE-6G and B5 select identical
placements in all three windows: UC1--UC3 remain at T4-V2 and UC4 at
T3-V4. Their cumulative carbon is therefore identical. Capacity is
nonbinding and outages are disabled, so the convergence follows from the
low-intensity placement economics.

**TABLE XII. 2026 SEASONAL TRACE-DRIVEN RESULTS**

  -----------------------------------------------------------------------------
  **Window**   **UC3 EASE-6G         **UC4 EASE-6G         **Carbon reduction
               tier-hours**          tier-hours**          vs B5**
  ------------ --------------------- --------------------- --------------------
  Winter       T4:168                T3:168                0.00%

  Spring       T4:168                T3:168                0.00%

  Summer       T4:168                T3:168                0.00%
  -----------------------------------------------------------------------------

## G. Operational-Intensity Boundaries and Communication Sensitivity

The operational-intensity sweep evaluates whether the reference seasonal
null result persists as modeled inference work per transported Mbit
changes. Table XIII reports the declared grid under each seasonal trace,
and Fig. 4 plots the resulting carbon reduction. The pairwise analytical
boundary and communication-parameter robustness tests then establish
when the placement policies diverge and reconverge.

**TABLE XIII. COMPLETE 11-POINT OPERATIONAL-INTENSITY ENVELOPE: CARBON
REDUCTION VS B5 (HOURS WITH A DIFFERENT TIER)**

  ----------------------------------------------------------------------------------
  **χ\         **Regime**     **Winter**          **Spring**   **Summer**
  (GFLOP/\                                                     
  Mbit)**                                                      
  ------------ -------------- ------------------- ------------ ---------------------
  0.01         Transport      0.00% (0 h)         0.00% (0 h)  0.00% (0 h)
               dominated                                       

  0.03         Transport      0.00% (0 h)         0.00% (0 h)  0.00% (0 h)
               dominated                                       

  0.03625      Transport      0.00% (0 h)         0.00% (0 h)  0.00% (0 h)
  (reference   dominated                                       
  UC4)                                                         

  0.10         Transport      0.00% (0 h)         0.00% (0 h)  0.00% (0 h)
               dominated                                       

  0.23         Transport      0.00% (0 h)         0.00% (0 h)  0.00% (0 h)
               dominated                                       

  0.30         Transport      0.00% (0 h)         0.00% (0 h)  0.00% (0 h)
               dominated                                       

  1            Transport      0.00% (0 h)         0.00% (0 h)  0.00% (0 h)
               dominated                                       

  3            Carbon         16.92% (134 h)      58.95% (158  2.60% (36 h)
               sensitive                          h)           

  10           Carbon         8.84% (86 h)        52.58% (152  1.13% (23 h)
               sensitive                          h)           

  30           Trace          6.55% (70 h)        49.96% (147  0.79% (17 h)
               conditional                        h)           

  100          Trace          5.73% (67 h)        48.93% (145  0.71% (16 h)
               conditional                        h)           
  ----------------------------------------------------------------------------------

Table XIII displays all 33 declared window--intensity cells; Fig. 4
plots the same complete grid. Percentages are means across five workload
seeds, and tier-change counts come from 168 hourly decisions per window.
The seven points from χ=0.01 through χ=1 remain null. Positive
reductions occur at χ={3, 10, 30, 100} in all three windows, yielding 12
positive cells. EASE-6G matches Oracle-KA in every positive cell of this
uncongested two-tier envelope. This empirical convergence does not
extend a minimum-carbon guarantee to capacity-constrained multi-tenant
operation.

![Scatter plot of seasonal carbon reduction versus B5 at 11 predeclared
effective operational-intensity values from 0.01 to 100 GFLOP/Mbit on a
logarithmic x-axis. Winter, spring and summer 2026 are shown as separate
unconnected markers. All reductions are zero through intensity 1
GFLOP/Mbit; higher declared intensities can produce positive seasonal
reductions. A dotted line marks the reference UC4 intensity of 0.03625
GFLOP/Mbit. No interpolation is
shown.](media/image5.png){width="7.158467847769029in"
height="3.375063429571304in"}

Fig. 4. Trace-driven carbon benefit across the predeclared
operational-intensity envelope. The reference UC4 point remains in the
null regime. Markers represent only the 11 predeclared intensity points;
no interpolation between points is implied.

The pairwise formulas in Section V-G apply to any jointly feasible tier
pair. For T2/T3, the energy crossover χE\*=2.586 GFLOP/Mbit depends only
on tier coefficients and therefore applies to any service profile whose
feasible set includes both tiers. The mean-carbon crossover χC\*=26.086
GFLOP/Mbit is evaluated under UC4 access conditions because Eq. (7)
weights the common access energy by tier-specific carbon intensity. The
crossover is calculated using full-precision carbon-intensity values
from the simulation dataset rather than the rounded values presented in
Table II. Reference UC3 and UC4 have χ=0.230 and 0.03625 GFLOP/Mbit. The
T2/T3 crossover characterizes that pair; UC3 also has a feasible T4
alternative. Fig. 5 uses a dense grid only to resolve the UC4
boundaries. Under the default policy and mean carbon intensity, below
χE\*, all methods choose T3. Between χE\* and χC\*, B5 chooses T2 while
EASE-6G and Oracle-KA choose T3. Above χC\*, they reconverge at T2.
Across the 11 declared points, the maximum static reduction versus B5 is
19.15% at χ=3 GFLOP/Mbit. The separate dense visualization reaches
21.20%; this value is not the declared-grid maximum.

![Fig. 5. Dense decision-boundary visualization for the UC4 feasibility
envelope under mean carbon intensity. Reported grid results use the 11
declared χ points.](media/image6.png){width="7.192685914260718in"
height="4.308943569553806in"}

Fig. 5. Dense decision-boundary visualization for the UC4 feasibility
envelope under mean carbon intensity. Reported grid results use the 11
declared χ points.

The 81-case communication-and-transport sensitivity test uses the four
reference service profiles and therefore remains in the low-intensity
regime. EASE-6G keeps T4-V2 for UC1--UC3 and T3-V4 for UC4 in all 81
scenarios, and B5 selects the same placements. Table XIV reports this
local stability, while Fig. 6 isolates each parameter's effect on
communication energy using one-parameter slices of the same grid.
Together with Figs. 4--5, this separates robustness of the reference
null result from the existence of a nontrivial carbon-sensitive regime.

**TABLE XIV. COMMUNICATION- AND TRANSPORT-ENERGY SENSITIVITY**

  ------------------------------------------------------------------------------
  **Profile**   **Reference         **Stable        **Carbon-reduction range vs
                placement**         scenarios**     B5**
  ------------- ------------------- --------------- ----------------------------
  UC1           T4-V2               81/81           0.00% to 0.00%

  UC2           T4-V2               81/81           0.00% to 0.00%

  UC3           T4-V2               81/81           0.00% to 0.00%

  UC4           T3-V4               81/81           0.00% to 0.00%
  ------------------------------------------------------------------------------

![Fig. 6. One-parameter slices of the 81-scenario grid:
communication-energy change relative to the reference configuration.
Each panel varies one parameter and fixes the others at their reference
values. UC1--UC3 coincide; in (a), UC4 also coincides. Table XIV reports
placement stability across all 81
combinations.](media/image7.png){width="7.301392169728784in"
height="3.642361111111111in"}

Fig. 6. One-parameter slices of the 81-scenario grid:
communication-energy change relative to the reference configuration.
Each panel varies one parameter and fixes the others at their reference
values. UC1--UC3 coincide; in (a), UC4 also coincides. Table XIV reports
placement stability across all 81 combinations.

## H. Discussion

The results support four regimes. Gate dominance occurs when hard
service and accuracy requirements collapse the feasible set, as in
UC1--UC2. Transport dominance occurs at low effective operational
intensity, where per-bit path energy overwhelms compute differences, as
in reference UC3--UC4. Carbon-sensitive placement occurs between the
analytically derived energy and carbon boundaries or during trace hours
when spatial carbon differences reverse the preferred tier. Capacity
dominance occurs when individually preferred assignments collide at a
constrained tier and the MILP must accept a quantified fallback penalty.

EASE-6G identifies when a nearest-feasible policy already minimizes the
modeled energy and carbon costs and when operational intensity, spatial
carbon differences, or capacity constraints change the preferred
assignment. Its contribution is the explicit boundary and constraint
analysis, together with quantified consequences of crossing these
boundaries.

In the uncongested two-tier operational-intensity analysis, min--max
normalization maps the lower-energy candidate to an energy-efficiency
score of one and the higher-energy candidate to zero whenever their
energy costs differ. The same behavior applies to the carbon-efficiency
scores. Consequently, the normalized scores express relative candidate
ordering rather than the magnitude of the underlying differences. This
can make placement decisions sensitive to the selected policy weights,
particularly near decision boundaries. The reported results therefore
characterize the declared scoring formulation; alternative normalization
methods and deployment-specific utility calibration warrant future
investigation.

# VII. LIMITATIONS AND FUTURE WORK

First, service latency remains a tier-level abstraction. The experiments
treat CAP~AI~ as a schedulable limit with latency headroom, but do not
model utilization-dependent accelerator queueing. A deployment must
calibrate L(t,h) or CAP~AI~(t,h) from accelerator, precision, runtime,
batching, and queue measurements before applying the hard latency gate.
Second, generic efficiency and precision factors are analytical profiles
rather than measurements of a specific deployment. Third, tier-service
bandwidth feasibility and modeled source-access throughput are distinct;
the current study does not verify end-to-end throughput feasibility of a
selected placement. The access profiles and path-transport intensities
are controlled analytical parameters. The 81-case sensitivity and
decision-boundary analysis expose their consequences, but detailed
PHY/MAC behavior, retransmissions, radio-state transitions, protocol
signaling, and router-by-router topology require deployment calibration.
Equation (7) also applies destination carbon intensity to access and
transport energy; spatially resolved network emissions could shift
carbon boundaries. Fourth, the ImageNet variants and four named service
profiles validate framework behavior rather than application-specific
manufacturing, mobility, clinical, or video accuracy. Fifth, the
operational-intensity envelope is a controlled feasibility study, not a
capacity-validated UC4 deployment at every intensity. Actual payload,
nominal work, and arrival rates must satisfy Eq. (17). Sixth, hourly
reassignment assumes pre-positioned replicas and sufficient tier memory.
Memory-residency energy, idle static power, loading delay, redirection
overhead, stateful-session transfer, cold starts, and on-demand
deployment remain outside scope. Finally, three seasonal windows do not
represent full-year or interannual variability, and predictive carbon
forecasting remains future work.

# VIII. CONCLUSION

This paper presented EASE-6G as a regime-aware and reproducible
framework for AI inference placement. The communication model separates
destination-independent access airtime from destination-dependent path
transport. The four reference profiles produce a null result because
hard gates restrict UC1--UC2 and transport energy dominates the feasible
alternatives for UC3--UC4. The T2/T3 energy crossover is 2.586
GFLOP/Mbit. The predeclared operational-intensity envelope then
demonstrates that the null is conditional: under the default
0.40/0.40/0.20 policy, 12 of 33 seasonal window--intensity cells reduce
carbon relative to B5, with a maximum of 58.95%, the extended weight
sweep confirms that placement and savings depend on policy priorities,
and the analytical crossovers explain when the policies diverge and
reconverge. These carbon-sensitive results characterize a controlled
analytical envelope with nonbinding capacity assumptions and should not
be interpreted as achievable savings under the original workload rates
without additional capacity provisioning or validation. Capacity stress
provides a separate contribution by restoring feasibility with only one
reassignment and quantified system costs of +1.15% energy and +1.77%
carbon. EASE-6G therefore does not promise universal carbon savings; it
identifies whether a deployment is gate-, transport-, carbon-, or
capacity-dominated and selects accordingly.

Code and Data Availability--- The reproducibility package accompanying
this manuscript contains the Python implementation, solver
configurations, analytical parameter tables, frozen 2026 NESO regional
carbon-intensity traces, retrieval metadata, generated numerical
results, and figure-generation scripts. Supplement S1 provides the
extended policy-weight sensitivity analysis, with accompanying CSV files
containing the evaluated configurations and results. The package also
includes instructions for obtaining updated official carbon-intensity
data. No confidential operator data were used.

# ACKNOWLEDGMENT

Generative AI was used as an assistive tool for language editing, code
review, and organization of the manuscript \[46\]. The authors
independently verified the technical content, equations, calculations,
citations, and conclusions and take full responsibility for the article.

# FUNDING

This research received no specific grant from any funding agency in the
public, commercial, or not-for-profit sectors.

# CONFLICTS OF INTEREST

The authors declare no competing interests.

# REFERENCES

\[1\] ITU-R M.2160-0, "[Framework and overall objectives of the future
development of IMT for 2030 and
beyond,](https://www.itu.int/rec/R-REC-M.2160-0-202311-I/en)"
International Telecommunication Union, Geneva, 2023.

\[2\] W. Saad, M. Bennis, and M. Chen, "[A vision of 6G wireless
systems: Applications, trends, technologies, and open research
problems,](https://doi.org/10.1109/mnet.001.1900287)" IEEE Netw.,
vol. 34, no. 3, pp. 134--142, 2020, doi: 10.1109/mnet.001.1900287.

\[3\] 3GPP TS 22.261 V18.19.0, "[Service requirements for the 5G
system,](https://www.etsi.org/deliver/etsi_ts/122200_122299/122261/18.19.00_60/ts_122261v181900p.pdf)"
Release 18, 3rd Generation Partnership Project, Feb. 2026.

\[4\] 3GPP TS 28.554 V18.9.0, "[Management and orchestration; 5G
end-to-end key performance
indicators,](https://www.etsi.org/deliver/etsi_ts/128500_128599/128554/18.09.00_60/ts_128554v180900p.pdf)"
Release 18, 3rd Generation Partnership Project, Feb. 2026.

\[5\] ETSI GS MEC 003 V4.1.1, "[Multi-access Edge Computing (MEC);
Framework and Reference
Architecture,](https://www.etsi.org/deliver/etsi_gs/MEC/001_099/003/04.01.01_60/gs_MEC003v040101p.pdf)"
European Telecommunications Standards Institute, May 2025.

\[6\] D. Xu et al., "[Edge intelligence: Empowering intelligence to the
edge of network,](https://doi.org/10.1109/jproc.2021.3119950)" Proc.
IEEE, vol. 109, no. 11, pp. 1778--1837, 2021, doi:
10.1109/jproc.2021.3119950.

\[7\] Y. Shi et al., "[Communication-efficient edge AI: Algorithms and
systems,](https://doi.org/10.1109/comst.2020.3007787)" IEEE Commun.
Surveys Tuts., vol. 22, no. 4, pp. 2167--2191, 2020, doi:
10.1109/comst.2020.3007787.

\[8\] E. Calvanese Strinati et al., "[6G: The next frontier: From
holographic messaging to artificial intelligence using subterahertz and
visible light communication,](https://doi.org/10.1109/mvt.2019.2921162)"
IEEE Veh. Technol. Mag., vol. 14, no. 3, pp. 42--50, 2019, doi:
10.1109/mvt.2019.2921162.

\[9\] D. C. Nguyen et al., "[6G Internet of Things: A comprehensive
survey,](https://doi.org/10.1109/jiot.2021.3103320)" IEEE Internet
Things J., vol. 9, no. 1, pp. 359--383, 2022, doi:
10.1109/jiot.2021.3103320.

\[10\] D. Patterson et al., "[Carbon emissions and large neural network
training,](https://arxiv.org/abs/2104.10350)" arXiv:2104.10350, 2021.

\[11\] E. Strubell, A. Ganesh, and A. McCallum, "[Energy and policy
considerations for deep learning in
NLP,](https://aclanthology.org/P19-1355/)" in Proc. 57th Annu. Meeting
Assoc. Comput. Linguistics, 2019, pp. 3645--3650, doi:
10.18653/v1/P19-1355.

\[12\] R. Schwartz, J. Dodge, N. A. Smith, and O. Etzioni, "[Green
AI,](https://doi.org/10.1145/3381831)" Commun. ACM, vol. 63, no. 12,
pp. 54--63, 2020, doi: 10.1145/3381831.

\[13\] The Green Grid, "[Green Grid data center power efficiency
metrics: PUE and
DCiE,](https://www.thegreengrid.org/resources/library-and-tools/green-grid-data-center-power-efficiency-metrics-pue-and-dcie)"
White Paper 6, 2008.

\[14\] E. Masanet et al., "[Recalibrating global data center energy-use
estimates,](https://doi.org/10.1126/science.aba3758)" Science, vol. 367,
no. 6481, pp. 984--986, 2020, doi: 10.1126/science.aba3758.

\[15\] J. Dodge et al., "[Measuring the carbon intensity of AI in cloud
instances,](https://doi.org/10.1145/3531146.3533234)" in Proc. ACM
FAccT, 2022, pp. 1877--1894, doi: 10.1145/3531146.3533234.

\[16\] L. Lannelongue, J. Grealey, and M. Inouye, "[Green algorithms:
Quantifying the carbon footprint of
computation,](https://doi.org/10.1002/advs.202100707)" Adv. Sci.,
vol. 8, no. 12, Art. no. 2100707, 2021, doi: 10.1002/advs.202100707.

\[17\] The Green Grid, "[PUE: A comprehensive examination of the
metric,](https://archive.thegreengrid.org/en/resources/library-and-tools/237-WP)"
White Paper 49, 2012.

\[18\] B. Jacob et al., "[Quantization and training of neural networks
for efficient integer-arithmetic-only
inference,](https://doi.org/10.1109/cvpr.2018.00286)" in Proc. CVPR,
2018, doi: 10.1109/cvpr.2018.00286.

\[19\] M. Zhu and S. Gupta, "[To prune, or not to prune: Exploring the
efficacy of pruning for model
compression,](https://arxiv.org/abs/1710.01878)" in Proc. ICLR Workshop,
2018.

\[20\] H. Touvron, M. Cord, M. Douze, F. Massa, A. Sablayrolles, and H.
Jégou, "[Training data-efficient image transformers & distillation
through attention,](https://proceedings.mlr.press/v139/touvron21a.html)"
in Proc. 38th Int. Conf. Machine Learning, PMLR 139, pp. 10347--10357,
2021.

\[21\] Y. Rao, W. Zhao, B. Liu, J. Lu, J. Zhou, and C.-J. Hsieh,
"DynamicViT: Efficient vision transformers with dynamic token
sparsification," in Advances in Neural Information Processing Systems,
vol. 34, pp. 13937--13949, 2021.

\[22\] Z. Liu, Y. Wang, K. Han, W. Zhang, S. Ma, and W. Gao,
"[Post-training quantization for vision
transformer,](https://proceedings.neurips.cc/paper_files/paper/2021/hash/ec8956637a99787bd197eacd77acce5e-Abstract.html)"
in Advances in Neural Information Processing Systems, vol. 34,
pp. 28092--28103, 2021.

\[23\] P. Mach and Z. Becvar, "[Mobile edge computing: A survey on
architecture and computation
offloading,](https://doi.org/10.1109/comst.2017.2682318)" IEEE Commun.
Surveys Tuts., vol. 19, no. 3, pp. 1628--1656, 2017, doi:
10.1109/comst.2017.2682318.

\[24\] A. Asheralieva and D. Niyato, "[Hierarchical game-theoretic and
reinforcement learning framework for computational offloading in
UAV-enabled mobile edge computing networks with multiple service
providers,](https://doi.org/10.1109/jiot.2019.2923702)" IEEE Internet
Things J., vol. 6, no. 5, pp. 8753--8769, 2019, doi:
10.1109/JIOT.2019.2923702.

\[25\] X. Chen et al., "[Optimized computation offloading performance in
virtual edge computing systems via deep reinforcement
learning,](https://doi.org/10.1109/jiot.2018.2876279)" IEEE Internet
Things J., vol. 6, no. 3, pp. 4005--4018, 2019, doi:
10.1109/jiot.2018.2876279.

\[26\] Y. G. Kim, U. Gupta, A. McCrabb, Y. Son, V. Bertacco, D. Brooks,
and C.-J. Wu, "GreenScale: Carbon-aware systems for edge computing,"
arXiv:2304.00404, 2023.

\[27\] H. Ke, W. Jin, and H. Wang, "CarbonCP: Carbon-aware DNN
partitioning with conformal prediction for sustainable edge
intelligence," arXiv:2404.16970, 2024.

\[28\] S. M. Nabavinejad, W. Jia, S. Taneja, and T. Guo, "[CARBONDIS:
Carbon-aware DNN inference scheduling on heterogeneous
GPUs,](https://doi.org/10.1109/ccgrid64434.2025.00032)" in Proc. 25th
IEEE/ACM Int. Symp. Cluster, Cloud and Internet Computing (CCGrid),
2025, pp. 315--324, doi: 10.1109/CCGRID64434.2025.00032.

\[29\] Y. Li, Z. Hu, E. Choukse, R. Fonseca, G. E. Suh, and U. Gupta,
"EcoServe: Designing carbon-aware AI inference systems,"
arXiv:2502.05043, 2025.

\[30\] G. Zhang, W. Guo, Z. Tan, C. Sun, and H. Jiang, "CarbonEdge:
Carbon-aware deep learning inference framework for sustainable edge
computing," in Proc. 2026 Int. Wireless Commun. Mobile Comput. Conf.
(IWCMC), Wuzhou, China, 2026, pp. 445--450, doi:
10.1109/IWCMC69287.2026.11580067.

\[31\] L. Wu, W. A. Hanafy, A. Souza, K. Nguyen, J. Harkes, D. Irwin, M.
Satyanarayanan, and P. Shenoy, "CarbonEdge: Leveraging mesoscale spatial
carbon-intensity variations for low carbon edge computing," in Proc.
34th ACM Int. Symp. High-Performance Parallel and Distributed Computing
(HPDC), 2025, pp. 1--13, doi: 10.1145/3731545.3731576.

\[32\] R. T. Marler and J. S. Arora, "[Survey of multi-objective
optimization methods for
engineering,](https://doi.org/10.1007/s00158-003-0368-6)" Struct.
Multidiscipl. Optim., vol. 26, pp. 369--395, 2004, doi:
10.1007/s00158-003-0368-6.

\[33\] R. T. Marler and J. S. Arora, "[The weighted sum method for
multi-objective optimization: new
insights,](https://doi.org/10.1007/s00158-009-0460-7)" Struct.
Multidiscipl. Optim., vol. 41, pp. 853--862, 2010, doi:
10.1007/s00158-009-0460-7.

\[34\] V. Sze, Y.-H. Chen, T.-J. Yang, and J. S. Emer, "[Efficient
processing of deep neural networks: A tutorial and
survey,](https://doi.org/10.1109/jproc.2017.2761740)" Proc. IEEE,
vol. 105, no. 12, pp. 2295--2329, 2017, doi: 10.1109/jproc.2017.2761740.

\[35\] A. G. Howard et al., "MobileNets: Efficient convolutional neural
networks for mobile vision applications," arXiv:1704.04861, 2017.

\[36\] A. Vaswani et al., "[Attention is all you
need,](https://arxiv.org/abs/1706.03762)" in Advances in Neural
Information Processing Systems, vol. 30, pp. 5998--6008, 2017.

\[37\] E. J. Hu et al., "LoRA: Low-rank adaptation of large language
models," in Proc. ICLR, 2022.

\[38\] V. J. Reddi et al., "MLPerf inference benchmark," in Proc.
ACM/IEEE 47th Annual Int. Symp. Computer Architecture, pp. 446--459,
2020, doi: 10.1109/ISCA45697.2020.00045.

\[39\] A. Tschand et al., "MLPerf Power: Benchmarking the energy
efficiency of machine learning systems from Watts to MWatts for
sustainable AI," in Proc. 31st IEEE Int. Symp. High-Performance Computer
Architecture (HPCA), pp. 1201--1216, 2025, doi:
10.1109/HPCA61900.2025.00092.

\[40\] B. Kopras, F. Idzikowski, B. Bossy, P. Kryszkiewicz, and H.
Bogucka, "[Communication and computing task allocation for
energy-efficient fog networks,](https://doi.org/10.3390/s23020997)"
Sensors, vol. 23, no. 2, Art. no. 997, 2023, doi: 10.3390/s23020997.

\[41\] P.-S. Wu, Y.-C. Lin, and C.-H. Yang, "[A 99.2 TOPS/W Transformer
learning processor with approximated attention score gradient
computation and ternary vector-based
speculation,](https://doi.org/10.1109/vlsitechnologyandcir46783.2024.10631391)"
in Proc. 2024 IEEE Symp. VLSI Technology and Circuits, Honolulu, HI,
USA, 2024, pp. 1--2, doi:
10.1109/VLSITechnologyandCir46783.2024.10631391.

\[42\] L. Rey, A. M. Bernardos, A. D. Dobrzycki, D. Carramiñana, L.
Bergesio, J. A. Besada, and J. R. Casar, "[A performance analysis of You
Only Look Once models for deployment on constrained computational edge
devices in drone
applications,](https://doi.org/10.3390/electronics14030638)"
Electronics, vol. 14, no. 3, Art. no. 638, 2025, doi:
10.3390/electronics14030638.

\[43\] 3GPP TR 32.972 V18.0.0, "[Study on system and functional aspects
of energy efficiency in 5G
networks,](https://www.etsi.org/deliver/etsi_tr/132900_132999/132972/18.00.00_60/tr_132972v180000p.pdf)"
Release 18, May 2024.

\[44\] National Energy System Operator, "[Regional Carbon Intensity
Forecast,](https://www.neso.energy/data-portal/regional-carbon-intensity-forecast)"
NESO Data Portal, dataset. \[Online\]. Available:
https://www.neso.energy/data-portal/regional-carbon-intensity-forecast.
Accessed: Jul. 16, 2026.

\[45\] A. R. W. Bruce, L. Ruff, J. Kelloway, F. MacMillan, and A.
Rogers, "[Carbon Intensity Regional Forecast
Methodology,](https://api.neso.energy/dataset/bf3d723b-b4ae-4ec7-9fc9-e584c651a9da/resource/1d817f4c-a126-45c8-baf0-218bf57d37be/download/neso-ci-regional-methodology_v2.pdf)"
National Energy System Operator, issue May 2024. \[Online\]. Available:
https://api.neso.energy/dataset/bf3d723b-b4ae-4ec7-9fc9-e584c651a9da/resource/1d817f4c-a126-45c8-baf0-218bf57d37be/download/neso-ci-regional-methodology_v2.pdf

\[46\] OpenAI, "[GPT-5.6: Frontier intelligence that scales with your
ambition,](https://openai.com/index/gpt-5-6/)" Jul. 9, 2026. \[Online\].
Available: https://openai.com/index/gpt-5-6/. Accessed: Sep. 18, 2026.

# AUTHOR BIOGRAPHIES

**Ahmed Mostafa Saleh ElSawaf** is a master's researcher with the
Faculty of Computers and Artificial Intelligence, Cairo University,
Egypt, and a telecommunications technology strategy and architecture
leader. His research interests include AI-native networks, edge and
cloud computing, sustainable AI, distributed inference, and 6G
architecture.

**Nour Eldeen M. Khalifa** is a Professor of Information Technology with
the Faculty of Computers and Artificial Intelligence, Cairo University,
Egypt, and a Member of IEEE. His research interests include artificial
intelligence, deep learning, computer networks, cloud computing, and
edge systems.

**Mohamed Hamed N. Taha** is an Associate Professor of Information
Technology with the Faculty of Computers and Artificial Intelligence,
Cairo University, Egypt.

**Shaimaa M. Mohamed** is an Assistant Professor with the Faculty of
Computers and Artificial Intelligence, Cairo University, Egypt. Her
research interests include cloud computing, parallel and distributed
systems, network architecture, virtualization, and network security.
