# EASE-6G submission and reproducibility package

This package accompanies **EASE-6G: Regime-Aware Energy and Carbon Placement for AI/ML in 6G Cloud–Edge Networks**. It contains the final 12-page Word/PDF manuscript, frozen NESO traces, parameter tables, numerical outputs, seven manuscript figures, Supplement S1, and executable code.

## Reproduce

Use Python 3.12. Install dependencies with `python -m pip install -r requirements.txt`, then run `bash code/run_all.sh` from the extracted package root. The frozen data support an offline rerun. The downloader is optional and is not called by the pipeline. Current data should not replace the frozen archive when reproducing these results.

The pipeline runs the base model, oracles, mapping experiment, communication sensitivity, operational-intensity envelope, invariant checks, weight sweep, seven manuscript figures, and independent manuscript checks. It does not automatically edit the manuscript. Numerical output changes must be reconciled with the manuscript before using a different parameter set. The archive checksum manifest identifies the supplied snapshot; a rerun may update generated-file hashes.

## Equations and scope

For offloaded inference, access bandwidth and active power depend on the service profile, not the destination. The access airtime is payload bits divided by 0.60 times access bandwidth in bit/s. Communication energy adds active access power times airtime to payload bits times the destination path intensity converted from nJ/bit to J/bit. T5 has no access/path energy. Carbon in mg CO₂/inference is total energy in joules times destination CI in kg CO₂/kWh, divided by 3.6. Destination CI is a proxy for the entire energy total; spatially resolved access/path carbon is outside this model.

For payload in Mbit, define a(t)=PUE(t)/EE(t) in J/GFLOP, b(t)=0.001 epsilon(t) in J/Mbit, and c(uc)=0.001 Ptx(uc)/(0.60 Baccess(uc)) in J/Mbit when bandwidth uses Gbit/s. Then e(t)=a(t) chi+c(uc)+b(t). The energy crossover cancels common access energy; the carbon crossover generally retains it. The T2/T3 energy boundary is 2.586195652 GFLOP/Mbit and the UC4-access mean-carbon boundary is 26.085950238 GFLOP/Mbit.

The intensity envelope assumes nonbinding capacity and scales effective work per Mbit. Its hourly weights aggregate carbon; it does not establish capacity feasibility at the original UC4 payload and arrival rate for every intensity. Fixed tier latency, accelerator efficiency, path profiles, and V3 precision factor are analytical assumptions. V3's code label INT8 denotes the analytical 8-bit PTQ profile; the factor 0.45 is not a measured universal whole-inference energy ratio.

## Reproduced results

- Reference placements: UC1–UC3 T4-V2; UC4 T3-V4.
- Declared 11-point static maximum: 19.1468085712% at chi=3 GFLOP/Mbit. Dense visualization maximum: 21.1953382274%; this is a separate grid.
- All 33 seasonal cells are disclosed; 12 have positive savings. Maximum default-policy seasonal saving: 58.9453286050%.
- Capacity stress moves only UC3 to T3-V2; energy/carbon rates rise 1.15%/1.77% to restore feasibility.
- Weight sweep: 44/231 weights retain every default hourly selection; 187 change at least one. Savings range from -60.508779% to 58.945329%.
- Fresh rerun and manuscript audit: 241/241 checks passed; core invariants: 43/43. The portable manuscript verifier has 230 checks; the other 11 recorded checks compare the fresh rerun against the previous archived numerical datasets.

## Contents

`code/`: runnable pipeline and figure generator. `data/`: frozen traces, provenance and methodology. `parameters/`: inputs. `results/`: generated numerical evidence and execution environment. `figures/`: seven final images. `manuscript/`: matching Word and PDF. `supplements/`: full weight analysis. `audit/`: reference metadata, source links, corrections, verification evidence, and independent manuscript verifier.

## Publication record

No public archive DOI or repository URL has been assigned in this package. If a persistent public repository is required by the reviewer response, deposit this package and insert its assigned DOI/URL before claiming that requirement is closed. Earlier response-letter page numbers refer to the earlier manuscript and must be checked against this PDF.

Figure 7 uses one-parameter slices of the existing 81-scenario grid. The plotting script exports all 48 plotted use-case/parameter/value observations to `results/figure7_one_parameter_slices.csv`. UC1–UC3 have identical normalized responses and share a curve. No simulation inputs or scientific results changed.
