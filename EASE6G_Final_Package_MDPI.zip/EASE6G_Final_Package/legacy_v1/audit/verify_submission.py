"""Independent arithmetic, manuscript table, reference and package checks."""
from pathlib import Path
import json,re,sys
import numpy as np
import pandas as pd
from docx import Document
from lxml import etree
ROOT=Path(__file__).resolve().parent;R=ROOT.parent/'results'
D=Document(ROOT.parent/'manuscript/EASE6G_IEEE_Access_Submission.docx')
checks=[]
def check(name,ok,detail=''):checks.append({'name':name,'pass':bool(ok),'detail':detail})
def eq(name,a,b,atol=1e-10):check(name,np.allclose(a,b,rtol=1e-11,atol=atol),float(np.max(np.abs(np.asarray(a)-np.asarray(b)))))
T=pd.read_csv(R/'table_II_tiers.csv').set_index('tier');V=pd.read_csv(R/'table_III_variants.csv').set_index('variant');U=pd.read_csv(R/'table_IV_use_cases.csv').set_index('uc')
C=pd.read_csv(R/'all_candidates.csv')
for row in C.itertuples():
 t=T.loc[row.tier];v=V.loc[row.variant];u=U.loc[row.uc]
 e=t.PUE*v.GFLOPs_per_inference*v.precision_energy_factor/t.accelerator_EE_GFLOPS_per_W
 time=0 if row.tier=='T5' else u.payload_Mbit*1e6/(.6*u.access_bandwidth_Gbps*1e9)
 comm=0 if row.tier=='T5' else u.access_tx_power_W*time+u.payload_Mbit*1e6*t.transport_energy_nJ_per_bit*1e-9
 eq(f'{row.uc}/{row.tier}/{row.variant} Eqs 1–7',[row.E_compute_J,row.tx_time_ms,row.E_comm_J,row.E_total_J,row.carbon_mg],[e,time*1000,comm,e+comm,(e+comm)*t.CI_kg_per_kWh/3.6])
for uc,g in C.groupby('uc'):
 f=g[(g.K==1)&(g.A==1)]
 eta=1-(f.E_total_J-f.E_total_J.min())/(f.E_total_J.max()-f.E_total_J.min())
 carb=1-(f.carbon_mg-f.carbon_mg.min())/(f.carbon_mg.max()-f.carbon_mg.min())
 eq(f'{uc} Eqs 6,8,13,14',f.suitability,.4*eta+.4*carb+.2*f.KPI_norm)
 static=pd.read_csv(R/'static_placements.csv').set_index('uc').loc[uc]
 vals=[float(x.text) for x in D.tables[4].rows[int(uc[-1])].cells[2:]]
 eq(f'Table V {uc}',vals,[static.suitability,static.E_compute_J,static.E_comm_J,static.E_total_J,static.carbon_mg],atol=.500001e-6)

static=pd.read_csv(R/'static_placements.csv')
for row in D.tables[5].rows[1:]:
 eq('Table VI '+row.cells[0].text,[float(row.cells[1].text),float(row.cells[2].text)],[static.E_total_J.mean(),static.carbon_mg.mean()],atol=.500001e-6)
stress=pd.read_csv(R/'capacity_system_metrics.csv')
for i,row in stress.iterrows():
 vals=[float(D.tables[10].cell(i+1,j).text) for j in range(1,5)]
 eq(f'Table XI row {i}',vals,[row.T4_load_GFLOPS_per_s,row.T4_capacity,row.energy_J_per_s,row.carbon_mg_per_s],atol=.500001e-6)
base=stress.iloc[0];new=stress.iloc[1]
eq('System energy/carbon increases',[(new.energy_J_per_s/base.energy_J_per_s-1)*100,(new.carbon_mg_per_s/base.carbon_mg_per_s-1)*100],[1.15,1.77],atol=.005)

seas=pd.read_csv(R/'seasonal_operational_intensity_window_summary.csv')
for row in D.tables[12].rows[1:]:
 chi=float(row.cells[0].text.split()[0])
 for col,window in enumerate(['Winter 2026','Spring 2026','Summer 2026'],2):
  v=seas[(seas.window==window)&np.isclose(seas.chi_GFLOP_per_Mbit,chi)].iloc[0]
  nums=re.findall(r'[\d.]+',row.cells[col].text)
  eq(f'Table XIII {window} {chi} reduction',float(nums[0]),v.reduction_mean_percent,atol=.005)
  # Last column of CSV stores different-tier hourly count.
  countcol=[c for c in seas.columns if 'different' in c or 'differ' in c][0]
  eq(f'Table XIII {window} {chi} hours',float(nums[1]),v[countcol])

g=pd.read_csv(R/'operational_intensity_report_grid.csv')
eq('Declared-grid maximum',g.carbon_reduction_vs_B5_percent.max(),19.146808571209398)
eq('Seasonal maximum',seas.reduction_mean_percent.max(),58.94532860497765)
check('Seasonal positive cells',sum(seas.reduction_mean_percent>1e-10)==12)
a=T.PUE/T.accelerator_EE_GFLOPS_per_W;b=T.transport_energy_nJ_per_bit*1e-3;ci=T.CI_kg_per_kWh
c=U.loc['UC4','access_tx_power_W']/(.6*U.loc['UC4','access_bandwidth_Gbps'])*1e-3
xe=(b.T3-b.T2)/(a.T2-a.T3);xc=(ci.T3*(c+b.T3)-ci.T2*(c+b.T2))/(ci.T2*a.T2-ci.T3*a.T3)
eq('Eqs 19–21 dimensional crossover values',[xe,xc],[2.586195652173912,26.085950237863457])

# Cross-check the remaining numerical result tables at their displayed precision.
oracles=pd.read_csv(R/'oracle_static_results.csv')
for i,row in static.iterrows():
 cells=D.tables[6].rows[i+1].cells;o=oracles[(oracles.uc==row.uc)&(oracles.method=='Oracle-K')].iloc[0]
 eq('Table VII '+row.uc+' accuracy gap',float(cells[5].text.rstrip('%')),100*(row.carbon_mg/o.carbon_mg-1),atol=.005)
 check('Table VII '+row.uc+' placements',cells[1].text==cells[2].text==row.tier+'-'+row.variant and cells[4].text==o.tier+'-'+o.variant)
ab=pd.read_csv(R/'ablation_results.csv')
for cells in [r.cells for r in D.tables[7].rows[1:]]:
 g=ab[ab.ablation==cells[0].text]
 eq('Table VIII '+cells[0].text,[float(cells[2].text),float(cells[3].text),float(cells[4].text)],[g.E_total_J.mean(),g.carbon_mg.mean(),sum(~g.accuracy_valid)],atol=.500001e-6)
w=pd.read_csv(R/'weight_sweep.csv')
for cells in [r.cells for r in D.tables[8].rows[1:]]:
 g=w[w.uc==cells[0].text];check('Table IX '+cells[0].text,len(g)==int(cells[2].text) and set(g.tier+'-'+g.variant)=={cells[1].text})
f=pd.read_csv(R/'capacity_fallback_per_uc.csv')
for i,row in f.iterrows():
 cells=D.tables[9].rows[i+1].cells
 check('Table X '+row.uc+' placements',[cells[1].text,cells[2].text]==[row.normal_placement,row.stress_placement])
 eq('Table X '+row.uc+' deltas',[float(c.text.strip('%+')) for c in cells[3:]],[row.latency_delta_ms,row.energy_delta_percent,row.carbon_delta_percent,row.accuracy_delta_pp],atol=.005)
tr=pd.read_csv(R/'trace_simulation_paths.csv')
for cells in [r.cells for r in D.tables[11].rows[1:]]:
 window=cells[0].text+' 2026';g=tr[tr.window==window]
 for uc,col in [('UC3',1),('UC4',2)]:
  z=g[g.uc==uc];tier=cells[col].text.split(':')[0]
  check('Table XII '+window+' '+uc,len(z)==168*5 and set(z.ease_tier)=={tier})
 eq('Table XII '+window+' carbon',g.ease_carbon_mg_per_inf,g.b5_carbon_mg_per_inf)
cs=pd.read_csv(R/'communication_transport_sensitivity_81_scenarios_detail.csv')
for cells in [r.cells for r in D.tables[13].rows[1:]]:
 g=cs[cs.uc==cells[0].text]
 check('Table XIV '+cells[0].text,len(g)==81 and not g.placement_changed.any() and set(g.EASE_placement)=={cells[1].text})
 eq('Table XIV '+cells[0].text+' reductions',g.carbon_reduction_vs_B5_percent,0)

# Every reference must exist once, be cited, and first occur in sequence.
alltext=[''.join(n.text or '' for n in e.iter() if etree.QName(n).localname in ['t']) for e in D.element.body]
refidx=next(i for i,t in enumerate(alltext) if t=='REFERENCES')
refs=[int(m[1]) for t in alltext[refidx+1:] if (m:=re.match(r'^\[(\d+)\]',t))]
cited=[]
for t in alltext[:refidx]:
 t=re.sub(r'\[(\d+)\]\s*[-–]\s*\[(\d+)\]',lambda m:' '.join('['+str(n)+']' for n in range(int(m[1]),int(m[2])+1)),t)
 cited += [int(n) for n in re.findall(r'\[(\d+)\]',t)]
check('45 references contiguous and unique',refs==list(range(1,46)),refs)
check('All references cited and no undefined citations',set(refs)==set(cited),{'uncited':sorted(set(refs)-set(cited)),'undefined':sorted(set(cited)-set(refs))})
check('First citation order',list(dict.fromkeys(cited))==refs)
links=json.loads((ROOT/'reference_links.json').read_text());check('45 references have source links',len(links)==45)
check('No tracked changes or comments',len(D.element.xpath('//w:ins|//w:del|//w:commentRangeStart|//w:commentReference'))==0)
for token in ['reviewer','rebuttal','restored','rebuilt','corrected communication','physical error','interpolat']:
 check('No revision wording '+token,token not in '\n'.join(alltext[:refidx]).lower())
check('Seven figures',len(D.inline_shapes)==7)
check('Fourteen tables',len(D.tables)==14)
for n,s in enumerate(D.inline_shapes,1):
 check(f'Figure {n} current alt text',s._inline.docPr.get('descr','').startswith(f'Fig. {n}.'))
check('No obsolete unit forms',not re.search(r'GFLOPS/s|Gbps|GFLOP/s/W|c_micro','\n'.join(alltext)))

report={'passed':sum(x['pass'] for x in checks),'total':len(checks),'all_pass':all(x['pass'] for x in checks),'checks':checks}
(ROOT/'package_verification.json').write_text(json.dumps(report,indent=2))
print({k:v for k,v in report.items() if k!='checks'})
for x in checks:
 if not x['pass']:print(x)
if not report['all_pass']:sys.exit(1)
