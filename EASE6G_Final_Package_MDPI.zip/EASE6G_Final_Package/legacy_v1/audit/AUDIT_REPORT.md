# Final manuscript audit, 20 September 2026

This is a technical and editorial audit, not an IEEE acceptance decision.

## Completed

- Reran the numerical pipeline using frozen traces. All 11 compared numerical datasets reproduced prior results within the stated tolerance.
- Independently checked energy, access time, communication, carbon and suitability, crossover units, and Tables V–XIV. The audit passed 241/241 checks; the original invariant suite passed 43/43.
- Checked all 45 references for citation/bibliography mapping and first-use order. No missing, uncited or undefined reference numbers remain. Corrected source metadata and added primary-source/DOI links. Source identity was checked against publisher-deposited metadata and primary sources; this does not guarantee that every publisher URL is reachable from every network.
- Regenerated all seven figures from the rerun outputs and visually inspected every page of the final 12-page PDF. Standardized prose typography, textual mathematical identifiers and displayed units. Retained a dedicated math font.
- Removed manuscript wording about reviewer responses and editorial repairs. Retained scientific limitations, funding, conflict declarations and AI-use acknowledgment.
- Corrected the explicit nJ/bit-to-J/Mbit conversion in the decision-boundary formulation without changing the numerical model or results. Distinguished the declared-grid 19.15% maximum from the dense-plot 21.20% maximum.
- Clarified nonbinding-capacity envelope assumptions, destination-CI proxy, objective versus carbon minimization, queue abstraction, memory pre-positioning, analytical precision factor, and tie-breaking.

## Remaining author/submission items

- The requested persistent public code/data DOI or repository URL is not available. The complete package is supplied, but this publication requirement cannot be marked closed without an actual public deposit.
- Confirm author details, affiliations, corresponding-author information, biographies and submission-system identifiers. These personal declarations are not independently certified by this audit.
- Reconcile any earlier response-letter page citations with this PDF before submitting that letter.
- The preserved two-column manuscript was checked for readable layout; exact conformance to the current official journal template and submission-system validation remains an author submission check.
