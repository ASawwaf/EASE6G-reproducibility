#!/usr/bin/env python3
"""Reviewer-response diagnostics for EASE-6G (additive; does not alter the frozen pipeline).

R0  kernel validation against ease6g_revision_model
R1  latency/capacity consistency (execution-time gate, joint rescale invariance)
R2  far-edge (T4) non-zero path-transport sweep
R3  on-device (T5) gate: bandwidth gate removed for local execution
R4  tier-to-region mapping permutations: gap to Oracle-KA per scoring rule
R5  candidate high-intensity service profile (UC5) evaluated end to end
R6  scoring alternatives (min-max, ratio, carbon-first with energy budget) on the UC4 envelope
R7  MILP scaling
"""
from __future__ import annotations
import itertools, json, time
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import lil_matrix
import ease6g_revision_model as model

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "results" / "revision"
OUT.mkdir(parents=True, exist_ok=True)
TIER = list(model.TIERS.tier)
VAR = list(model.VARIANTS.variant)
REGIONS = ["London", "South East England", "East England", "North Scotland"]
W = model.DEFAULT_WEIGHTS

UC5 = dict(uc="UC5", name="Interactive visual recognition (candidate)", Lmax_ms=100.0, Bmin_Gbps=1.0,
           Rmin=0.999, Jmax_ms=10.0, Accmin_percent=80.0, payload_Mbit=1.2,
           access_bandwidth_Gbps=10.0, access_tx_power_W=2.0)


def uc_row(name):
    if name == "UC5":
        return pd.Series(UC5)
    return model.USE_CASES[model.USE_CASES.uc == name].iloc[0]


def build(uc, eps=None, t5_local=False, stream_rate=None, payload_Mbit=None):
    """Energy matrix [T,V], feasibility mask [T,V], KPI_norm [T] for one service profile."""
    t = model.TIERS; v = model.VARIANTS
    F = v.GFLOPs_per_inference.to_numpy(float); d = v.precision_energy_factor.to_numpy(float)
    acc = v.accuracy_percent.to_numpy(float)
    e_comp = (t.PUE.to_numpy(float) / t.accelerator_EE_GFLOPS_per_W.to_numpy(float))[:, None] * (F * d)[None, :]
    D = float(uc.payload_Mbit if payload_Mbit is None else payload_Mbit) * 1e6
    eps = t.transport_energy_nJ_per_bit.to_numpy(float) if eps is None else np.asarray(eps, float)
    access = float(uc.access_tx_power_W) * D / (model.RHO_B * float(uc.access_bandwidth_Gbps) * 1e9)
    comm = access + D * eps * 1e-9
    comm[TIER.index("T5")] = 0.0
    E = e_comp + comm[:, None]
    L = t.service_latency_ms.to_numpy(float); B = t.bandwidth_Gbps.to_numpy(float)
    R = t.reliability.to_numpy(float); J = t.jitter_ms.to_numpy(float)
    gB = B >= uc.Bmin_Gbps
    if t5_local:
        gB[TIER.index("T5")] = True
    K = (L <= uc.Lmax_ms) & gB & (R >= uc.Rmin) & (J <= uc.Jmax_ms)
    A = np.ones(len(VAR), bool) if pd.isna(uc.Accmin_percent) else acc >= uc.Accmin_percent
    mask = K[:, None] & A[None, :]
    if stream_rate is not None:
        exec_ms = 1000.0 * F[None, :] / np.asarray(stream_rate, float)[:, None]
        mask &= (L[:, None] + exec_ms) <= uc.Lmax_ms
    raw = uc.Lmax_ms / L + B / uc.Bmin_Gbps + R / uc.Rmin + uc.Jmax_ms / J
    kpi = raw / raw[K].max() if K.any() else raw * 0
    return E, mask, kpi


def _pick(score, C, E):
    """Row-wise argmax(score) with ties broken by lower carbon, then lower energy."""
    best = score.max(1, keepdims=True)
    tie = score >= best - 1e-12
    cm = np.where(tie, C, np.inf); cmin = cm.min(1, keepdims=True)
    tie2 = cm <= cmin * (1 + 1e-12)
    return np.where(tie2, E[None, :], np.inf).argmin(1)


def decide(E, mask, kpi, ci, rule="minmax", weights=W, budget=0.10):
    """ci: [H,T] kg/kWh. Returns dict policy -> (flat index [H], carbon mg [H], energy J [H])."""
    ci = np.atleast_2d(ci)
    idx = np.flatnonzero(mask.ravel()); ti = idx // len(VAR)
    e = E.ravel()[idx]; k = kpi[ti]
    C = e[None, :] * ci[:, ti] / 3.6
    emin, emax = e.min(), e.max()
    cmin, cmax = C.min(1, keepdims=True), C.max(1, keepdims=True)
    if rule == "minmax":
        eta = np.ones_like(e) if emax == emin else 1 - (e - emin) / (emax - emin)
        with np.errstate(invalid="ignore", divide="ignore"):
            ce = np.where(cmax == cmin, 1.0, 1 - (C - cmin) / (cmax - cmin))
    else:  # ratio: best-over-candidate, bounded in (0,1], magnitude preserving
        eta = emin / e
        ce = np.where(C > 0, cmin / np.where(C > 0, C, 1), 1.0)
    we, wc, wk = weights
    out = {}
    s = we * eta[None, :] + wc * ce + wk * k[None, :]
    out["EASE"] = _pick(s, C, e)
    out["B5"] = _pick(np.repeat(((2 / 3) * eta + (1 / 3) * k)[None, :], len(ci), 0), np.repeat(e[None, :], len(ci), 0), e)
    out["Oracle"] = _pick(-C, C, e)
    # carbon-first with an energy budget: min carbon s.t. E <= (1+budget) * Emin
    ok = e <= (1 + budget) * emin
    out["CarbonFirst"] = _pick(np.where(ok[None, :], -C, -np.inf), C, e)
    rows = np.arange(len(ci))
    return {p: (idx[j], C[rows, j], e[j]) for p, j in out.items()}


def label(flat):
    return f"{TIER[flat // len(VAR)]}-{VAR[flat % len(VAR)]}"


def ci_static(mapping=None):
    ref = dict(zip(TIER, model.TIERS.CI_kg_per_kWh))
    if mapping is None:
        return np.array([[ref[t] for t in TIER]])
    w = pd.concat(model.load_carbon_trace_windows().values())
    return np.array([[float(w[mapping[t]].mean()) / 1000 for t in TIER]])


WINDOWS = model.load_carbon_trace_windows()
REFMAP = dict(model.TIER_REGION_NAMES)


def ci_hourly(window, mapping):
    h = WINDOWS[window]
    return np.stack([h[mapping[t]].to_numpy(float) / 1000 for t in TIER], 1)


def rates(window_len=168, scale=0.25, uc5_peak=50.0):
    """Original UC1-UC4 streams are preserved exactly; UC5 uses an independent stream."""
    out = {}
    for seed in model.RNG_SEEDS:
        rng = np.random.default_rng(seed); rng5 = np.random.default_rng(seed + 1000)
        rows = []
        for h in range(window_len):
            r = model.rates_for_hour(h, rng, scale=scale)
            r["UC5"] = scale * uc5_peak * model.daily_load_fraction(h % 24) * float(np.clip(rng5.normal(1, 0.08), 0.75, 1.25))
            rows.append(r)
        out[seed] = pd.DataFrame(rows)
    return out


RATES = rates()
S = {}

# ---------------------------------------------------------------- R0 validation
cand = model.candidates(); ref_sel = model.select_static(cand).set_index("uc")
ok = True
for u in model.USE_CASES.uc:
    E, m, k = build(uc_row(u)); d = decide(E, m, k, ci_static())
    r = ref_sel.loc[u]
    ok &= label(d["EASE"][0][0]) == f"{r.tier}-{r.variant}" and abs(d["EASE"][1][0] - r.carbon_mg) < 1e-12 and abs(d["EASE"][2][0] - r.E_total_J) < 1e-12
S["R0_kernel_matches_frozen_static"] = bool(ok)

# ---------------------------------------------------------------- R1 latency / capacity
F = model.VARIANTS.GFLOPs_per_inference.to_numpy(float)
cap = model.TIERS.CAP_AI_GFLOPS_per_s.to_numpy(float); L = model.TIERS.service_latency_ms.to_numpy(float)
r1 = []
for u in model.USE_CASES.uc:
    r = ref_sel.loc[u]; ti = TIER.index(r.tier); vi = VAR.index(r.variant); lm = float(uc_row(u).Lmax_ms)
    exec_ms = 1000 * F[vi] / cap[ti]
    r1.append(dict(uc=u, placement=f"{r.tier}-{r.variant}", tier_latency_ms=L[ti], Lmax_ms=lm,
                   exec_ms_if_request_gets_whole_tier=exec_ms,
                   min_capacity_multiplier_for_feasibility=(1000 * F[vi] / (lm - L[ti])) / cap[ti]))
r1 = pd.DataFrame(r1); r1.to_csv(OUT / "R1_exec_latency.csv", index=False)
inv = {}
for kx in (1, 250, 1000):
    pl = {}
    for u in model.USE_CASES.uc:
        E, m, k = build(uc_row(u), stream_rate=cap * kx)
        pl[u] = label(decide(E, m, k, ci_static())["EASE"][0][0]) if m.any() else "INFEASIBLE"
    inv[f"x{kx}"] = pl
S["R1"] = dict(min_joint_scale=float(r1.min_capacity_multiplier_for_feasibility.max()), placements_with_exec_gate=inv)

# ---------------------------------------------------------------- R2 T4 transport sweep
r2 = []
base_eps = model.TIERS.transport_energy_nJ_per_bit.to_numpy(float)
for e4 in (0.0, 0.5, 1.03, 2.06, 3.39):
    eps = base_eps.copy(); eps[TIER.index("T4")] = e4
    row = dict(T4_eps_nJ_per_bit=e4)
    for u in model.USE_CASES.uc:
        E, m, k = build(uc_row(u), eps=eps); d = decide(E, m, k, ci_static())
        row[u] = label(d["EASE"][0][0]); row[u + "_E_J"] = float(d["EASE"][2][0])
    r2.append(row)
pd.DataFrame(r2).to_csv(OUT / "R2_T4_transport.csv", index=False)
S["R2_placements_stable"] = bool(all(r[u] == r2[0][u] for r in r2 for u in model.USE_CASES.uc))

# ---------------------------------------------------------------- R3 T5 local gate
r3 = []
for u in model.USE_CASES.uc:
    E0, m0, k0 = build(uc_row(u)); d0 = decide(E0, m0, k0, ci_static())
    E1, m1, k1 = build(uc_row(u), t5_local=True); d1 = decide(E1, m1, k1, ci_static())
    r3.append(dict(uc=u, reference=label(d0["EASE"][0][0]), t5_local_gate=label(d1["EASE"][0][0]),
                   B5_t5_local=label(d1["B5"][0][0]), oracle_t5_local=label(d1["Oracle"][0][0]),
                   energy_change_percent=100 * (d1["EASE"][2][0] / d0["EASE"][2][0] - 1),
                   carbon_change_percent=100 * (d1["EASE"][1][0] / d0["EASE"][1][0] - 1)))
r3 = pd.DataFrame(r3); r3.to_csv(OUT / "R3_T5_local_gate.csv", index=False)
u4 = uc_row("UC4")
S["R3"] = dict(table=r3.to_dict("records"),
               device_rate_GFLOPs_below_which_T5_fails_UC4_latency=float(1000 * 2.9 / (u4.Lmax_ms - L[TIER.index("T5")])))

# ---------------------------------------------------------------- R4/R5 mappings x rules x services
SERV = list(model.USE_CASES.uc) + ["UC5"]
BUILT = {u: build(uc_row(u)) for u in SERV}
RULES = [("minmax", "EASE"), ("ratio", "EASE"), ("minmax", "CarbonFirst")]
rows = []; static_rows = []
for mid, perm in enumerate(itertools.permutations(REGIONS), 1):
    mp = dict(zip(TIER[:4], perm)); mp["T5"] = mp["T4"]
    isref = all(mp[t] == REFMAP[t] for t in TIER)
    cs = ci_static(mp)
    for u in SERV:
        E, m, k = BUILT[u]
        dm = decide(E, m, k, cs); dr = decide(E, m, k, cs, rule="ratio")
        static_rows.append(dict(mapping_id=mid, is_reference=isref, uc=u, B5=label(dm["B5"][0][0]), Oracle=label(dm["Oracle"][0][0]),
                                EASE_minmax=label(dm["EASE"][0][0]), EASE_ratio=label(dr["EASE"][0][0]), CarbonFirst10=label(dm["CarbonFirst"][0][0]),
                                C_B5=dm["B5"][1][0], C_Oracle=dm["Oracle"][1][0], C_minmax=dm["EASE"][1][0], C_ratio=dr["EASE"][1][0], C_cf=dm["CarbonFirst"][1][0],
                                E_B5=dm["B5"][2][0], E_Oracle=dm["Oracle"][2][0], E_minmax=dm["EASE"][2][0], E_ratio=dr["EASE"][2][0], E_cf=dm["CarbonFirst"][2][0]))
    for wname in WINDOWS:
        ch = ci_hourly(wname, mp)
        dec = {u: {"minmax": decide(*BUILT[u], ch), "ratio": decide(*BUILT[u], ch, rule="ratio")} for u in SERV}
        for seed, rt in RATES.items():
            for scope, ucs in (("UC1-4", SERV[:4]), ("UC5", ["UC5"]), ("UC1-5", SERV)):
                tot = {}
                for name, (rule, pol) in zip(("minmax", "ratio", "carbonfirst10"), RULES):
                    c = sum((dec[u][rule][pol][1] * rt[u].to_numpy() * 3600).sum() for u in ucs)
                    e = sum((dec[u][rule][pol][2] * rt[u].to_numpy() * 3600).sum() for u in ucs)
                    tot[name] = (c, e)
                cb = sum((dec[u]["minmax"]["B5"][1] * rt[u].to_numpy() * 3600).sum() for u in ucs)
                eb = sum((dec[u]["minmax"]["B5"][2] * rt[u].to_numpy() * 3600).sum() for u in ucs)
                co = sum((dec[u]["minmax"]["Oracle"][1] * rt[u].to_numpy() * 3600).sum() for u in ucs)
                for name, (c, e) in tot.items():
                    rows.append(dict(mapping_id=mid, is_reference=isref, window=wname, seed=seed, scope=scope, policy=name,
                                     reduction_vs_B5_percent=100 * (cb - c) / cb, gap_vs_oracle_percent=100 * (c - co) / co,
                                     energy_change_vs_B5_percent=100 * (e - eb) / eb))
dyn = pd.DataFrame(rows); dyn.to_csv(OUT / "R4R5_mapping_trace_seed.csv", index=False)
st = pd.DataFrame(static_rows); st.to_csv(OUT / "R4R5_mapping_static.csv", index=False)
cell = dyn.groupby(["mapping_id", "is_reference", "window", "scope", "policy"]).mean(numeric_only=True).drop(columns="seed").reset_index()
cell.to_csv(OUT / "R4R5_mapping_trace_cells.csv", index=False)
summ = (cell.groupby(["scope", "policy"]).agg(
    cells=("reduction_vs_B5_percent", "size"),
    positive_cells=("reduction_vs_B5_percent", lambda x: int((x > 1e-9).sum())),
    negative_cells=("reduction_vs_B5_percent", lambda x: int((x < -1e-9).sum())),
    reduction_median=("reduction_vs_B5_percent", "median"), reduction_min=("reduction_vs_B5_percent", "min"), reduction_max=("reduction_vs_B5_percent", "max"),
    gap_median=("gap_vs_oracle_percent", "median"), gap_max=("gap_vs_oracle_percent", "max"),
    energy_change_median=("energy_change_vs_B5_percent", "median"), energy_change_max=("energy_change_vs_B5_percent", "max")).reset_index())
summ.to_csv(OUT / "R4R5_summary.csv", index=False)
refc = cell[cell.is_reference].drop(columns=["mapping_id", "is_reference"])
refc.to_csv(OUT / "R4R5_reference_mapping_cells.csv", index=False)
S["R4R5_summary"] = summ.round(3).to_dict("records")
S["R5_UC5_reference_static"] = st[(st.uc == "UC5") & st.is_reference].iloc[0].to_dict()
E5 = BUILT["UC5"][0]; m5 = BUILT["UC5"][1]
S["R5_UC5_chi_by_variant"] = {v: float(model.VARIANTS.GFLOPs_per_inference[i] * model.VARIANTS.precision_energy_factor[i] / UC5["payload_Mbit"]) for i, v in enumerate(VAR)}
S["R5_UC5_energy_J_feasible"] = {label(i): float(E5.ravel()[i]) for i in np.flatnonzero(m5.ravel())}

# ---------------------------------------------------------------- R6 UC4 envelope under each rule
import operational_intensity_analysis as oi
kp = oi.kpi_norms(); kvec = np.array([kp["T2"], kp["T3"]])
r6 = []
for wname in WINDOWS:
    ch = np.stack([WINDOWS[wname][REFMAP[t]].to_numpy(float) / 1000 for t in ("T2", "T3")], 1)
    for chi in oi.REPORT_GRID:
        e = np.array([oi.energy_per_mbit(t, float(chi)) for t in ("T2", "T3")])
        C = e[None, :] * ch / 3.6
        eta_mm = 1 - (e - e.min()) / (e.max() - e.min()); eta_r = e.min() / e
        ce_mm = 1 - (C - C.min(1, keepdims=True)) / (C.max(1, keepdims=True) - C.min(1, keepdims=True)); ce_r = C.min(1, keepdims=True) / C
        pick = {"minmax": _pick(W[0] * eta_mm + W[1] * ce_mm + W[2] * kvec, C, e), "ratio": _pick(W[0] * eta_r + W[1] * ce_r + W[2] * kvec, C, e),
                "B5": _pick(np.repeat(((2 / 3) * eta_mm + (1 / 3) * kvec)[None, :], len(C), 0), np.repeat(e[None, :], len(C), 0), e),
                "oracle": C.argmin(1), "carbonfirst10": _pick(np.where((e <= 1.1 * e.min())[None, :], -C, -np.inf), C, e)}
        for seed, rt in RATES.items():
            w = rt["UC4"].to_numpy() * 3600; rr = np.arange(len(C))
            cb = (C[rr, pick["B5"]] * w).sum(); eb = (e[pick["B5"]] * w).sum(); co = (C[rr, pick["oracle"]] * w).sum()
            for p in ("minmax", "ratio", "carbonfirst10"):
                c = (C[rr, pick[p]] * w).sum(); en = (e[pick[p]] * w).sum()
                r6.append(dict(window=wname, chi=chi, seed=seed, policy=p, reduction_vs_B5_percent=100 * (cb - c) / cb,
                               gap_vs_oracle_percent=100 * (c - co) / co, energy_change_vs_B5_percent=100 * (en - eb) / eb,
                               hours_differ=int((pick[p] != pick["B5"]).sum())))
r6 = pd.DataFrame(r6).groupby(["window", "chi", "policy"]).mean(numeric_only=True).drop(columns="seed").reset_index()
r6.to_csv(OUT / "R6_envelope_by_rule.csv", index=False)
S["R6_minmax_matches_paper_max"] = float(r6[r6.policy == "minmax"].reduction_vs_B5_percent.max())
S["R6_energy_cost_at_paper_cells"] = r6[(r6.policy == "minmax") & (r6.chi >= 3)].round(3).to_dict("records")

# ---------------------------------------------------------------- R7 MILP scaling
def solve_n(n_services, seed=0):
    rng = np.random.default_rng(seed)
    types = rng.choice(SERV[:4], size=n_services)
    lam = {"UC1": 4.0, "UC2": 4.0, "UC3": 6.0, "UC4": 100.0}
    pairs = []
    for s, u in enumerate(types):
        E, m, k = BUILT[u]; d_ci = ci_static()
        idx = np.flatnonzero(m.ravel()); ti = idx // len(VAR); e = E.ravel()[idx]; c = e * d_ci[0, ti] / 3.6
        eta = 1 - (e - e.min()) / (e.max() - e.min()) if e.max() > e.min() else np.ones_like(e)
        ce = 1 - (c - c.min()) / (c.max() - c.min()) if c.max() > c.min() else np.ones_like(c)
        sc = W[0] * eta + W[1] * ce + W[2] * k[ti]
        r = lam[u] * rng.uniform(0.5, 1.5)
        for j, i in enumerate(idx):
            pairs.append((s, i // len(VAR), r * F[i % len(VAR)], sc[j]))
    n = len(pairs) + n_services
    A = lil_matrix((n_services + len(TIER), n)); c = np.zeros(n)
    for col, (s, ti, load, sc) in enumerate(pairs):
        A[s, col] = 1; A[n_services + ti, col] = load; c[col] = -sc
    for s in range(n_services):
        A[s, len(pairs) + s] = 1; c[len(pairs) + s] = 10.0
    scale = n_services / 4 * 0.8
    lb = np.r_[np.ones(n_services), -np.inf * np.ones(len(TIER))]; ub = np.r_[np.ones(n_services), cap * scale]
    t0 = time.perf_counter()
    res = milp(c=c, integrality=np.ones(n), bounds=Bounds(0, 1), constraints=LinearConstraint(A.tocsr(), lb, ub), options={"mip_rel_gap": 1e-6, "time_limit": 30})
    return dict(services=n_services, binaries=n, solve_s=time.perf_counter() - t0, status=int(res.status), unserved=int(np.rint(res.x[len(pairs):]).sum()) if res.x is not None else None)

r7 = pd.DataFrame([solve_n(n, s) for n in (4, 40, 200, 1000) for s in (0, 1, 2)])
r7.to_csv(OUT / "R7_milp_scaling.csv", index=False)
S["R7"] = r7.groupby("services").agg(binaries=("binaries", "first"), solve_s_mean=("solve_s", "mean"), solve_s_max=("solve_s", "max"), unserved_mean=("unserved", "mean")).reset_index().round(4).to_dict("records")

(OUT / "revision_summary.json").write_text(json.dumps(S, indent=2, default=float))
print(json.dumps(S, indent=2, default=float))
