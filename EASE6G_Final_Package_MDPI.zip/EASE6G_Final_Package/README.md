# EASE-6G revised reproducibility package

**Numbering.** Tables, sections, figures and equations are cited here as in the MDPI manuscript (main text: Tables 1-13, Sections 1-9, Figures 1-6, Equations (1)-(24); Appendices A-E with Tables A1, A2, C1, C2, D1, E1 and Figures C1, C2). The text build in the earlier IEEE layout (`manuscript/EASE6G_Revised_Manuscript.docx`) and the file names in `parameters/` and `results/` keep the earlier Roman numbers. The MDPI edition layer (`code/mdpi/mdpi_edition.py`) maps them as follows:

| MDPI manuscript | IEEE-layout build |
|---|---|
| Tables 1-10 | Tables I-X |
| Table 11 (IMT-2030 capabilities) | Table XVI |
| Table 12 (design rules) | new; built in `mdpi_edition.py` from numbers already in the text |
| Table 13 (AI-RAN compute rates) | Table XVIII |
| Tables A1, A2 (conditions, robustness) | Tables XIV, XV |
| Tables C1, C2 (trace envelope, published efficiencies) | Tables XII, XIII |
| Table D1 (24 tier-to-grid mappings) | Table XI |
| Table E1 (2030 grid scenarios) | Table XVII |
| Figures 1-5 | Figs. 1-5 |
| Figure 6 (regime map) | new: `figures_v2/fig_regime_map.png`, data `results/v2/regime_map_grid.csv` |
| Figures C1, C2 | Figs. 6, 7 |
| Section 7.2 Design Rules | VII-B rules, rewritten as Table 12, with VII-F |
| Section 7.3 | VII-D |
| Appendix A | VI-I (from "Benchmark basis."), the benchmark-scenario detail of V-A and the check design of V-C |
| Appendix B | the outage paragraph of VI-E and the simulation design of V-C |
| Appendix C | the hourly envelope of VI-H with Tables XII, XIII and Figs. 6, 7 |
| Appendix D | Table XI |
| Appendix E.1, E.2 | VII-C, VII-E |

`parameters/v2/table_III_tiers.csv`, `table_IV_variants.csv` and `table_V_use_cases.csv` are Tables 3, 4 and 5.

Regenerates every result, table, figure and the manuscript of the revised study, including the MDPI *Future Internet* submission file.

    pip install -r code/requirements.txt      # pandoc must be on PATH
    bash code/run_v2.sh manuscript/source/source_manuscript.docx manuscript/source/source_manuscript.md manuscript/EASE6G_Revised_Manuscript.docx

This writes `manuscript/EASE6G_Revised_Manuscript.docx` (the text build in the earlier IEEE layout) and `manuscript/EASE6G_FutureInternet_MDPI.docx` (the submission file in MDPI layout). A fourth argument sets a different path for the MDPI file.

| Path | Content |
|---|---|
| `code/ease6g_v2.py` | Revised model and all core experiments -> `results/v2/` |
| `code/ease6g_des.py` | Discrete-event check of the M/D/1 tail quantile, incl. bursty arrivals -> `results/v2/queue_validation.json` |
| `code/ease6g_6g_extensions.py` | Split inference and 2030 grid scenarios -> `results/v2_6g/` |
| `code/mlperf_anchor.py` | Efficiency and latency anchors computed from the frozen MLPerf logs in `data/mlperf/` -> `results/v2/mlperf_anchor.json` |
| `code/ease6g_review_checks.py` | Final-review checks: latency-bound benchmark basis, server/device efficiency factors, joint factorial, V3 throughput factor, queueing consistency, capacity against load -> `results/v2/review_checks.json`, `results/v2/review_*.csv` |
| `code/build_numbers.py` | Collects numbers, builds tables, Figures 2-5, C1, C2 and the regime map (Figure 6, Equations (21)-(24) evaluated on a grid; asserted against the reported crossovers and band) at 600 dpi -> `build/`, `figures_v2/`, `results/v2/regime_map_grid.csv` |
| `code/fig1_tiers.py` | Draws Figure 1 (five-tier continuum with the request path, the latency, PUE and path energy of Table 3, the grid region and carbon intensity of each tier, and the AI-RAN marker) at 600 dpi from `parameters/v2/table_III_tiers.csv` -> `figures_v2/fig1_tiers.png` |
| `code/verify_equations.py` | Independent re-implementation of Equations (1)-(24) and checks of Tables 3, 7, C2, A1, 13 and Figure C2; writes `results/v2/equation_verification.csv` |
| `code/build_manuscript.py` | Runs consistency checks, fills `build/manuscript_template.md`, writes the manuscript text (IEEE layout) |
| `code/mdpi/convert_to_mdpi.py` | Converts that file to the MDPI *Future Internet* submission file: MDPI layout and styles, front and back matter, numbered headings, Arabic table numbers, MDPI citation and reference style (`mdpi_refs.py`), the 200-word abstract (`mdpi_abstract.txt`), abbreviations defined at first use, and the 600-dpi figures. Equations are carried over unchanged (asserted; two inline symbols in removed abbreviation glosses are the only removals) |
| `code/mdpi/mdpi_template.py` | Applies MDPI's official Future Internet Word template (`code/mdpi/template/futureinternet-template.dot`): left-column box, abstract heading and rule, equations in the template's two-cell table, three-line tables, references with the template's numbering, back-matter order, Abbreviations section, Publisher's Note, page setup. `mdpi_parts.py` takes the template's styles, numbering, headers and footers |
| `code/mdpi/mdpi_edition.py` | MDPI edition layer, run inside the converter: title, appendices A-E (supporting material moved from the main text, with a short summary left in place), the regime map as Figure 6, Section 7.2 as design rules (Table 12), renumbering of tables, figures, sections and citations, and reference order by first citation. Every number it writes must already occur in the generated text (asserted) |
| `code/ease6g_revision_model.py` | Original model; supplies parameters, traces and the load profile to the revised model |
| `parameters/v2/` | Parameter tables as used by the revised model (match Tables 3-5) |
| `parameters/`, `data/` | Original input tables and frozen 2026 NESO regional carbon-intensity traces |
| `data/mlperf/` | LoadGen summary and detail logs and power-analyzer samples of the four MLPerf Inference runs behind the efficiency inputs (see `data/mlperf/README.md`) |
| `MANIFEST.sha256` | SHA-256 checksum of every file in the package (`sha256sum -c MANIFEST.sha256`) |
| `results/` (top level) | Outputs of the original-model scripts. File names follow the previous manuscript's table numbers (`table_II_tiers.csv` is now Table 3). The revised results are in `results/v2/` and `results/v2_6g/`. |
| `manuscript/source/` | The authors' previous manuscript; unchanged passages and page styles are taken from it |
| `legacy_v1/` | Results, figures, audit and manuscript of the previous model. They do not describe the revised manuscript. |

Every number in Sections 6 and 7 and Appendices A-E of the manuscript is inserted from `build/numbers.json`, and every result table from `build/tables.json`. `build_manuscript.py` stops if a prose claim (for example "never higher than the baseline") is contradicted by the results.

Model changes relative to `legacy_v1`: ratio scoring for energy and carbon; each headroom ratio capped at 2; a tail-latency gate (access transmission + execution + the R_min-quantile of the M/D/1 waiting time at rho_max = 0.7, `code/ease6g_queue.py`); carbon charged by where energy is consumed (compute at the destination grid, access at the user's grid, path energy split 50/50) and floored at 11 g CO2/kWh; efficiencies on one MLPerf basis (730 GFLOP/J for T1-T4, Orin NX 461 GFLOP/J and 2,890 GFLOP/s for the device); one JPEG-compressed image (0.12 Mbit) per inference; static results weighted by request volume over the served profiles (UC1 is unserved under the tail gate); the energy minimizer E-min as the primary comparator, baselines B3 (latency-first), B4 and B5 (carbon weight moved to energy), and the myopic oracles; a weight frontier over all 24 mappings; a RAN-co-located (AI-RAN) 6G scenario in `ease6g_6g_extensions.py`. The previous reference inputs are rerun as sensitivity cases (`results/v2/v2_summary.json`, key `sensitivity.variants`). The conditions for the headline saving (Table A1) are under `sensitivity.efficiency_profiles_savings`, `single_tier_efficiency_savings`, `efficiency_level_x_path_savings`, `payload_kB_savings` and `B5_headroom_weight`; the efficiency band under `disagreement_band_UC4`; the hourly crossover structure under `crossover_by_window`.

Robustness checks of the carbon signal and volumes (Table A2) are under `robustness_review` in `results/v2/v2_summary.json`.

## Final-review checks (`results/v2/review_checks.json`)

| Review comment | Key | What it holds | Manuscript |
|---|---|---|---|
| A reference dependence | `A_factorial`, `review_joint_factorial.csv` | 180-cell factorial: basis x relative T2 efficiency x path energy x payload x regional carbon spread | Appendix A "Joint variation" |
| B benchmark conditions | `mlperf`, `B_latency_bound`, `B_derating`, `B_rate`, `review_server_only_derating.csv`, `review_efficiency_basis_grid.csv` | Offline, Server and SingleStream efficiencies and latencies from the logs; headline on the latency-bound basis, with measured server latency, and over separate server and device efficiency factors | Section 5.1, Appendix A "Benchmark scenarios" and "Benchmark basis", Table A1 |
| C precision multiplier | `C_V3_throughput` | Throughput factor on V3 execution time and capacity (1, 1/delta, 4, 8) | Section 5.1, Appendix A, Table A2 |
| D queueing consistency | `D_queue`, `review_mixed_variant_tier_hours.csv` | Pooled (M/D/c) against random dispatch; two-variant service-time queue; conservative gate over every simulated placement | Section 4.4, Appendix A "Queueing consistency" |
| E static vs capacity | `E_capacity`, `review_capacity_load_sweep.csv` | Capacity-constrained EASE-6G, E-min and Oracle-KA at 5% to 100% of the peak arrival coefficients | Abstract, Sections 5.1, 6.5, 8, 9, Table A2 |
| F reproducibility | `MANIFEST.sha256`, `code/run_v2.sh` | One command rebuilds results, tables, figures and manuscript; clean-copy rebuild reproduces the manuscript text | Code and Data Availability |

`build_manuscript.py` asserts each of the new prose claims against `review_checks.json` before it writes the manuscript.

## Reproducing

    pip install -r code/requirements.txt      # pandoc must be on PATH
    bash code/run_v2.sh manuscript/source/source_manuscript.docx manuscript/source/source_manuscript.md /tmp/rebuilt.docx
    pandoc /tmp/rebuilt.docx -t plain --wrap=none | diff - <(pandoc manuscript/EASE6G_Revised_Manuscript.docx -t plain --wrap=none)   # no output = identical text
    pandoc /tmp/EASE6G_FutureInternet_MDPI.docx -t plain --wrap=none | diff - <(pandoc manuscript/EASE6G_FutureInternet_MDPI.docx -t plain --wrap=none)   # MDPI submission file: no output = identical text

The run takes about three minutes on one core. Two result files record solver wall-clock times (`results/v2/milp_scaling.csv` and the `milp_scaling` block of `results/v2/v2_summary.json`) and therefore differ between runs; no manuscript number depends on them beyond the statement that 1,000 services solve in under one second.



`parameters/v2/` holds the parameter tables exactly as used by the revised model and printed in Tables 3-5 (written by `build_numbers.py`). The files directly under `parameters/` are the original inputs that `ease6g_revision_model.py` reads; the revised model overrides them as listed above.

## Equations and symbols in the code

| Manuscript | Code (`code/ease6g_v2.py` unless stated) |
|---|---|
| Equation (1) compute energy | `build()`: `e_comp = PUE/EE * F * DELTA` |
| Equations (2)-(4) access and path energy, transmission time | `build()`: `e_acc`, `e_tr`, `ttx`; `RHO` = ρ_B, `EPS` = ε_t (nJ/bit) |
| Equation (5) total energy | `build()`: `E = e_comp + comm` |
| Equations (6), (8) energy and carbon ratio scores | `scores()`: `eta`, `ce` |
| Equation (7) carbon, with CI_path | `carbon()`; `PHI` = φ (share of path energy at the destination grid) |
| Equation (9) tail-latency gate | `build()`: `leff`; `code/ease6g_queue.py`: `md1_quantile()` (Erlang's formula, 60 digits); validated in `code/ease6g_des.py`; `exq=` replaces the execution and queueing terms by a measured latency (review check B) |
| Equations (10)-(11) KPI and accuracy gates | `build()`: `K`, `A`, `mask` |
| Equations (12)-(13) headroom score | `build()`: `raw`, `kpi` (= κ = KPI_norm); `CAP_RATIO` = s_cap |
| Equations (14)-(15) weighted suitability | `decide()`: `W` = (w_E, w_C, w_K) |
| Equations (16)-(19) MILP | `solve()`; unserved penalty M = n + 1; `CAPV` = CAP_AI |
| Equations (20)-(21) energy per Mbit, energy crossover | `epm()`, `a_()` = a(t), `b_()` = b(t), `eacc` = e_acc,uc, `chi_E()` |
| Equation (22) existence condition | `chi_E()` returns `None` when it fails |
| Equation (23) carbon crossover | `chi_C()` |
| Equation (24) disagreement set | envelope column `hours_in_disagreement`; `S["disagreement_band_UC4"]` |

Figure files are generated by `code/build_numbers.py` and named by manuscript number: `fig2_pipeline.png` (with the equations of each stage) and `fig3`-`fig7`. Figure 1 is drawn by `code/fig1_tiers.py` to match the authors' original drawing. Parameter files in `parameters/v2/` are named by table: `table_III_tiers.csv`, `table_IV_variants.csv`, `table_V_use_cases.csv`.
