# MLPerf Inference logs behind the efficiency inputs

Copied unchanged from the public MLCommons result repositories (Apache License 2.0), renamed with a system and scenario prefix.

| Prefix | Repository and commit | Path |
|---|---|---|
| `r282_z93_q5_offline_`, `r282_z93_q5_server_` | `mlcommons/inference_results_v1.0` @ `f7759baf2fdb9e17d97f07326db6d461d6dc1ef2` | `closed/Qualcomm/results/r282_z93_q5-qaic-v1.3.14-aic100/resnet50/{offline,server}/performance/run_1/` |
| `orin_nx_maxq_offline_`, `orin_nx_maxq_singlestream_` | `mlcommons/inference_results_v3.1` @ `f7b504d40dfb65180fe59438d4b4d6f9f8598647` | `closed/NVIDIA/results/Orin_NX_TRT_MaxQ/resnet50/{Offline,SingleStream}/performance/run_1/` |

Each run has three files: `mlperf_log_summary.txt` (throughput and latency), `mlperf_log_detail.txt` (the `power_begin` and `power_end` timestamps) and `spl.txt` (one power-analyzer sample per second).
`code/mlperf_anchor.py` averages the samples between the two timestamps and converts throughput at 4.1 GFLOP per ResNet-50 image:

| Run | Throughput | Average power | Efficiency |
|---|---|---|---|
| Gigabyte R282-Z93 5x QAIC100, Offline | 100,077 samples/s | 561.9 W | 730 GFLOP/J |
| Gigabyte R282-Z93 5x QAIC100, Server (Poisson arrivals) | 78,502 samples/s | 533.8 W | 603 GFLOP/J |
| NVIDIA Orin NX MaxQ, Offline | 1,682 samples/s | 14.95 W | 461 GFLOP/J |
| NVIDIA Orin NX MaxQ, SingleStream | 697 samples/s (1.419 ms at the 90th percentile) | 13.50 W | 212 GFLOP/J |
