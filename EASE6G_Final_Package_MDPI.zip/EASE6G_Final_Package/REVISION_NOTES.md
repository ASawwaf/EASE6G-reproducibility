# EASE-6G revision notes

## Round 12: aligned with MDPI's official Future Internet Word template (latest)

The MDPI file now follows MDPI's official Word template, `code/mdpi/template/futureinternet-template.dot`, supplied by the authors. Model, results and text are unchanged, apart from items 5 to 8.

| # | Change | Where |
|---|---|---|
| 1 | All styles, the list numbering, theme, fonts and the page headers and footers are taken from the template unchanged; only the year and volume in the running heads are set (2026, 18). This gives the template's line spacing (at least 14 pt), its heading sizes, and the first-page header with the journal and MDPI logos. The page setup (margins, header and footer distances, line numbering) is also the template's. | `code/mdpi/mdpi_parts.py`, `mdpi_template.py` |
| 2 | Front matter as in the template. The left-column box (Academic Editor, Received, Revised, Accepted, Published, Citation, Copyright, in that order) is the template's floating table. "Abstract" is on its own line, and a rule follows the keywords. | `mdpi_template.py` |
| 3 | Display equations sit in the template's two-cell table: the equation centred, its number on the right. All 26 equations are unchanged and in order (asserted). | `mdpi_template.py` |
| 4 | Tables use the template's three-line rules. Narrow tables (8, 9, 11, 13) sit in the text column, as in the template; wide tables span the page. Table text stays at 9 pt (8 pt in the widest tables); the template's 10 pt would not fit these tables. A 1-mm cell side margin is kept so that left-aligned columns do not run together. | `mdpi_template.py` |
| 5 | Back matter in the template's order and styles. The Institutional Review Board and Informed Consent statements ("Not applicable") are omitted, because the template does not list them and the study involves no human or animal subjects. An Abbreviations section is added (22 entries, each defined in the text, asserted), and the Disclaimer/Publisher's Note closes the file. | `mdpi_template.py` |
| 6 | References are numbered by the template's automatic list (MDPI_8.1_references), with titles no longer hyperlinked; DOIs stay linked. Appendix subsections are headed "Appendix E.1." and "Appendix E.2.", as in the template. | `mdpi_template.py`, `mdpi_edition.py` |
| 7 | Author Contributions: M.H.N.T. added to supervision, as agreed by the authors. | `code/mdpi/mdpi_layout.py` |
| 8 | Data Availability Statement: link to the public repository https://github.com/ASawwaf/EASE6G-reproducibility added. | `build/manuscript_template.md` |

LibreOffice cannot place the template's page-anchored left-column box and pushes page 1's content to page 2; this happens with MDPI's own template file as well. Word places it correctly. The preview PDF in the delivery is therefore rendered from a copy in which the box is anchored to the text; the submission file keeps the template's anchoring.

## Round 11: MDPI edition: shorter main text, regime map, design rules (earlier)

| # | Change | Where |
|---|---|---|
| 1 | Title: "When Does Carbon-Aware AI Inference Placement Pay? A Closed-Form Regime Analysis across the Edge–Cloud Continuum and Design Rules for 6G Compute Placement". | `code/mdpi/mdpi_edition.py`, `mdpi_parts.py` |
| 2 | Supporting material moved from the main text to Appendices A-E. Nothing was deleted, and each move leaves a summary in place. The appendices are lettered in order of first mention. **A** holds the sensitivity and robustness checks (Tables A1, A2), the benchmark-scenario detail of Section 5.1 and the check design of Section 5.3. **B** is the capacity-and-outage simulation. **C** is the trace-driven intensity envelope and the published-efficiency crossovers (Tables C1, C2; Figures C1, C2). **D** is the table of all 24 tier-to-grid mappings (Table D1). **E** has the 2030 grid scenarios (Table E1) and split inference. The main text (Introduction to Conclusions) shrinks from 26.0 to 20.6 pages, about 21%. The moved material is about 26% of the previous main text; the new Figure 6 and Table 12 offset the difference. | `code/mdpi/mdpi_edition.py` |
| 3 | Regime map as the central figure (Figure 6, Section 6.8). It shows the disagreement set of Equation (24) over work per transported bit and the facility-adjusted T2/T3 efficiency ratio, bounded by Equations (21) and (23), with UC4 (17.0%), the uncompressed input (0.0%), the 10-20 kB payload range and the efficiency band. It is computed from the model's coefficients, and asserted against the reported crossovers (45.1 and 5.11 GFLOP/Mbit) and the band (7.4%, 19.1%). | `code/build_numbers.py`, `results/v2/regime_map_grid.csv`, `figures_v2/fig_regime_map.png` |
| 4 | Section 7.2 rewritten as seven design rules for a 6G compute-placement function (Table 12: rule, condition, threshold found, input the function needs). The former four-rule paragraph and the former Section 7.6 (inputs to expose) are merged into it. Contribution 4 and the conclusions now name the design rules. | `code/mdpi/mdpi_edition.py` |
| 5 | Tables, figures, sections and cross-references renumbered in one pass. Cross-references whose target moved now point to the appendix (each asserted to fire once). Citations renumbered by first appearance over the main text and then the appendices; the reference list is re-ordered to match (66 references). | `code/mdpi/mdpi_edition.py` |
| 6 | Guards: every number written by the edition layer must already occur in the generated text. Display equations are identical and in order (26). The only removed inline objects are the two in abbreviation glosses. | `code/mdpi/mdpi_edition.py`, `convert_to_mdpi.py` |
| 7 | Data Availability and the GenAI acknowledgment now cover Appendices A-E. | `code/mdpi/mdpi_edition.py` |
| 8 | Figure 1 redrawn from `parameters/v2/table_III_tiers.csv`. It now shows the request going from the user device directly to the executing tier (replacing the hop-by-hop arrows), the service latency, PUE and path energy of each tier, the grid region and mean carbon intensity of each tier in the reference mapping, and the far edge marked as the AI-RAN tier of the 6G what-if (Section 7.3). The caption describes these elements; this caption is the only text change in the IEEE-layout build. | `code/fig1_tiers.py`, `build/manuscript_template.md` |

Model and results are unchanged. The IEEE-layout text build changes only in the Figure 1 caption. Checks on the MDPI file: citations 1-66 in order of first appearance; main-text Tables 1-13 and Figures 1-6 cited in order; appendix tables and figures cited in order within each appendix; abstract 200 words.

## Round 10: MDPI Future Internet submission (earlier)

| # | Change | Where |
|---|---|---|
| 1 | Submission file in MDPI layout, written by the pipeline: `manuscript/EASE6G_FutureInternet_MDPI.docx`. MDPI front matter (authors, affiliations, correspondence), numbered headings, Tables 1-18 with sentence-case captions, Figure/Equation cross-references, citations as [1,2] and [3-9], MDPI reference style (66 references, numbered in order of first citation), and MDPI back matter (Supplementary Materials, Author Contributions, Funding, IRB and Informed Consent "Not applicable", Data Availability, Acknowledgments with the GenAI disclosure in MDPI wording, Conflicts of Interest). | `code/mdpi/`, `code/run_v2.sh` |
| 2 | Abstract shortened from 247 to 200 words for MDPI; every number in it is unchanged from the body. | `code/mdpi/mdpi_abstract.txt` |
| 3 | Abbreviations defined at first use in the main text: PUE, EE, KPI, GPU, FP32, PTQ, RAN, AI-RAN, 5G, 3GPP, IMT-2030, ML; Table 11 region names spelled out. | `code/mdpi/mdpi_layout.py` |
| 4 | Figures 2-7 exported at 600 dpi; Figure 2 box labels now read "Tables 4 and 5" and "Table 3". Figure 1 is drawn by `code/fig1_tiers.py` at 600 dpi. Figure data are unchanged. | `code/build_numbers.py`, `code/fig1_tiers.py` |
| 5 | Reference 27: page range 1728-1739 added (Crossref). References 55, 56, 61, 62 (53, 54, 59, 60 before item 8): access date 19 November 2026. | `code/mdpi/mdpi_refs.py` |
| 6 | Manuscript template brought in line with the final text: symbol q for the waiting-time quantile in Equation (9), Equation (13) normalised over K = A = 1 with its explanatory sentence, the separate-requirements sentence after Equation (9), the request-volume and backhaul sentence in Section 4.4, and "so end-to-end throughput is not assured" in limitation 6. | `build/manuscript_template.md` |
| 7 | Code brought in line with Equation (13): the headroom score is normalised over the hard-feasible set (K = A = 1) in `ease6g_v2.py` and in the independent check `verify_equations.py`. Only the unreported suitability score of UC2's single feasible pair changes (0.9987 to 1.0000); every placement, table and number in the manuscript is unchanged, and the equation check passes 82/82. | `code/ease6g_v2.py`, `code/verify_equations.py` |
| 8 | Two closely related papers added to Section 2.2 and the reference list (new references 42 and 43; later references move up by two): Zhu, Hurley and Tabatabaee Malazi, UCC 2025, DOI 10.1145/3773274.3774929, and Kribaa, Välisuo and Elmusrati, Future Generation Computer Systems 188 (2027) 108898, DOI 10.1016/j.future.2026.108898. Both bibliographic records were checked against Crossref. | `build/manuscript_template.md`, `code/mdpi/mdpi_refs.py` |

The package was rebuilt from a clean copy: the IEEE-layout text equals the final manuscript text, and the MDPI file is reproduced exactly.

## Round 9: confirmed findings on the Round 8 text (earlier)

| # | Finding | Change |
|---|---|---|
| 1 | Abstract: "outside the reference conditions at most 2.3%" contradicts Table XIV | Abstract, introduction and discussion now name the condition: the 2.3% ceiling applies where the energy- and carbon-optimal tiers coincide (cleaner tier more than 7.4% more efficient, uncompressed input, or device as energy optimum). |
| 2 | IV-D: aggregate admission does not bound realized per-server utilization | Reworded as a bound on long-run mean utilization; fluctuations are what the M/D/1 waiting-time distribution describes; the gate is stated to hold for stationary Poisson arrivals only. |
| 3 | 63% threshold vs 5% sweep grid | VI-E gives the calculation, 400,000/(200,000 x 2.9 + 12,000 x 4.6) = 0.630, says the grid brackets it (60%, 65%) and that a bisection on the MILP returns the same value. |
| 4 | Gate depends on Poisson arrivals | Stated in IV-D, limitation 5 and the conclusion: no guarantee under arbitrary arrival processes; with bursty arrivals UC2 misses its limit. |
| 5 | Analytical vs hardware-validated feasibility; "two headline services jointly realizable" overstated | Corrected: with measured server latency only UC4 keeps its reference placement; UC5 is validated at the regional tier, not the cloud (misses by 2.2 ms); UC2 and UC3 are analytical only. Stated in V-A, VI-A, VI-I, limitation 5 and the conclusion. |
| 6 | Reproduction cannot be confirmed without the package | No text change; submit this ZIP with the manuscript. |

**Audit after these edits:** one font family (Times New Roman) with 9-pt body, 7-pt tables and 9-pt equations throughout; 64 references, numbered in order of first citation, all cited, three consecutive citations now written as a range ([29]-[31]); Tables I-XVIII and Figs. 1-7 cited in order; Eqs. (1)-(24) sequential. Figures are regenerated unchanged except Fig. 6(b), where the "UC4 (V4)" label no longer overlaps a data point. Abstract: 247 words.

## Round 8: response to the final review, comments A-F (earlier)

| # | Reviewer point | Response and change |
|---|---|---|
| A | The 17.0% headline depends on the reference configuration; show it is a meaningful regime | New 180-cell factorial (benchmark basis x relative T2 efficiency x path energy x payload x regional carbon spread). The energy- and carbon-optimal tiers of UC4 differ in 103 cells (57%); saving 0.0-18.3% there (median 9.8%), at most 2.3% elsewhere, never negative. With the measured carbon spread the saving reaches 10% in 45 of 90 cells; with half the spread in 2 of 90. Stated plainly: the reference is not an isolated point but lies near the top of the range. New paragraph "Joint variation" in VI-I; limitation 3 updated. |
| B | Efficiency (Offline) and device rate (SingleStream) come from different benchmark conditions | The MLPerf logs of the same two systems are now frozen in `data/mlperf/` and parsed by `mlperf_anchor.py`. They reproduce the reference inputs (730 and 461 GFLOP/J, 2,890 GFLOP/s) and give a latency-bound basis: 603 GFLOP/J for the server in the Server scenario (0.83 of Offline) and 212 GFLOP/J for the device in SingleStream (0.46). On that basis the saving is 16.9% (+1.6% energy); with the measured server latency replacing the execution and queueing terms of Eq. (9), UC2 and UC3 become infeasible, UC5 moves to the regional tier, and the saving over UC4 and UC5 is 18.4%. Closed-form two-factor condition added (server factor >= 0.54 and >= the metro-device tie value, 0.91 if the device keeps its Offline efficiency, 0.40 at the measured device factor); verified on a 40-cell grid. Disclosed: with servers derated alone the headline is fragile below 0.91 (9-12%, then about 2%), and the assumed 40,000 GFLOP/s rate is about 24 times faster than the measured server, so the UC2 and UC3 placements are not supported by a published measurement. Changes: V-A (two paragraphs), VI-I "Benchmark basis", four new rows in Table XIV, limitations 1 and 5, abstract, conclusion, reference [53]. |
| C | The precision multiplier changes energy but not execution time or capacity | Sensitivity added: a throughput factor of 1/delta = 2.2 on V3's execution time and capacity changes no decision of EASE-6G, E-min, Oracle-KA or B3 and no capacity-stress assignment; the headline is unchanged. V3 would need 3.8x throughput to match V2's execution time and delta < 0.26 to match its energy; at a factor of 4 only B3 selects it. Stated in V-A, VI-I "Input variants", Table XV, limitation 1. |
| D | The queueing approximation needs a stronger consistency test | IV-D now states the four assumptions that the gate, the admission rule and the validation share. New simulations: (i) pooled FCFS dispatch (M/D/c as c interleaved Erlang-c/D/1 queues) waits 8.1 service times at 1-1e-5 for two servers and 1.0 for fifteen, against 16.7 under random dispatch, so the gate is conservative; (ii) the only mixed-variant tier-hours are E-min's metro tier (315 of 840 over five seeds; none under EASE-6G or Oracle-KA); a two-point service-time queue stays between the M/D/1 quantiles of the shorter and longer service time; (iii) recomputing all 9,975 simulated service-tier-hours with the longest service time in the queueing term violates no latency limit. The seed range of the 1-1e-5 Poisson quantile (15.9-17.4) is now reported next to the analytic 16.7. The hourly experiments are stated to be fluid. |
| E | Static and capacity-constrained results are different operating conditions | New load sweep with capacity enforced for all three policies. The headline (16.9-17.1%) holds up to 63% of the peak arrival coefficients; above that the metro tier cannot hold UC4, E-min is displaced to the regional tier that EASE-6G selects, and the saving is 2.0-2.2% (2.2% at peak, all from UC5). The static EASE-6G and E-min assignments are capacity-feasible only up to 46% and 38% of peak. This is now explicit in the abstract, introduction, V-A, VI-B, a new paragraph in VI-E, the discussion (third practical point), limitation 7, the conclusion, and Table XV. |
| F | The reproducibility statement needs verification | The package was rebuilt from a clean copy: the unchanged package reproduced the previous manuscript text exactly, and the final package reproduces the final text exactly. Added `MANIFEST.sha256`, a "Reproducing" section in the README with the one-line text comparison, and the MLPerf logs. The availability statement now says the package is submitted as supplementary material and describes the one-command rebuild. If the package is also deposited in a public archive, add its DOI to that statement. |

Model code change: `build()` in `ease6g_v2.py` takes an optional `exq` callable (measured execution-plus-queueing latency); the default leaves every earlier result unchanged. Manuscript: 20 pages; abstract 242 words. No table, figure or equation was renumbered.

## Round 7: final audit (earlier)

**Checked and found consistent**
- **Equations vs code:** Eqs. (1)–(24) each map to one function; the map is now in the package README. An independent re-implementation passes 82/82 checks.
- **Citations:** 64 references, numbered in order of first citation, all cited.
- **Cross-references:** Tables I–XVIII and Figs. 1–7 are cited in order. All section and equation references resolve.
- **Clean rebuild:** a rebuild from the package alone gives identical text and byte-identical figures.

**Fixed**
- **Citations:** the B5 paragraph pointed to Table VI instead of VII. Fig. 3 was never cited. The early mention of Table XIII broke the citation order.
- **Symbols:** the code's `KAPPA` is now `PHI`, matching φ in Eq. (7). Reference [45] title now reads "μWatts".
- **Fonts:**
  - All table text is 7 pt, with italic symbols matching the equations (χ_E, CAP_AI, L_max, δ…).
  - Every equation is sized to its paragraph (9 pt body, 10 pt abstract, 8 pt captions).
  - Figures use a Times-matched serif with STIX math.
- **Diagrams:**
  - Fig. 2 is now generated from code, and each stage is labelled with its equations.
  - Fig. 5(b) is in kg CO₂/week.
  - Fig. 6 labels no longer overlap.
  - The Fig. 7 legend reads "T2/T3 GFLOP/J".
- **Package:** parameter files are renamed to match Tables III–V. The README lists the checked tables correctly and includes symbol→code and equation→function maps.

**Note:** export the final PDF from Word. LibreOffice ignores equation font sizes.

## Round 6: response to the sixth review (major revision) (earlier)

| # | Reviewer point | Response and change |
|---|---|---|
| M1 | Headline depends on a strong assumption | The abstract now says "Under reference conditions (compressed inputs, equal server efficiency, regional spread) … 17.0%", adds "Outside the reference conditions the saving is at most 2.3%", and gives the UC4-dominated volume caveat. A new paragraph in the introduction states that the headline is a reference-condition result, not a general finding. |
| M2 | Justify the carbon floor | §V-A explains why the ratio score needs regularization and that the floor is a constant, not life-cycle accounting. New tests: a floor of 1/5/11 g in the score only with unfloored accounting, and a floor-free zero-safe score (c_min+c0)/(c+c0). At most 10 of 2,112 decisions change; savings move by <0.01 pp. Unfloored operational accounting gives 17.1% (mapping max 78.3%), so the floor is conservative (Table XV). |
| M3 | ResNet-50 INT8 vs FP32 transformers | Closed-form threshold: χ_E scales with the efficiency level k, so the result needs k ≥ 0.54, i.e. transformer efficiency at least about half the benchmark. Below that the saving is <1%. Now stated as the primary limitation (§V-A, §VIII). No MLPerf power result exists for ViTs. |
| M4 | Synthetic workload; UC4 dominance | Volume-mix sensitivity: UC4 at 75/50/25/10/0% gives 16.0/14.5/13.2/12.6/12.2%; equal volumes give 22.1%. UC4's dominance is now stated in the abstract, VI-B and the conclusion. |
| M5 | Attribution framing | The abstract and introduction now say "location-based attributed operational emissions, not marginal or avoided". New bounded marginal scenario (Hawkes GB MEF 0.69 kg/kWh): 75/50/25/0% regional weight gives 6.0/1.4/-1.1/0.0%. Two recent average-vs-marginal refs added [Sukprasert 2024; Gorka 2025]. |
| M6 | Validate the M/D/1 approximation | New discrete-event simulation (`ease6g_des.py`, 1×10⁸ arrivals). Poisson quantiles 9.9/13.30/17.0 vs analytic 9.9/13.30/16.7. Bursty arrivals (H2, SCV 4) roughly triple the quantiles: UC2 becomes infeasible (6.25 ms > 5 ms), and a far-edge ceiling of 0.6 restores it. Disclosed in §VI-I and §VIII. |
| M7 | Moderate 6G framing | The abstract now calls the framework "generation-neutral" and AI-RAN a "what-if". The title keeps "With Implications for 6G" (your earlier choice); §VII already states the scope. |
| m1 | Abstract too dense | Cut from 249 to 196 words; the efficiency band moved to the introduction and §VI-I. |
| m2 | Notation | a, b, α, β, χ are defined immediately before Eqs. (20)–(23); β now uses CI_path. No other change. |
| m3 | Table III CI values | Now stated as trace-window means used only in static runs; hourly runs use hourly values. |
| m4 | UC1 earlier | Stated in §III-C. |
| m5 | Variant degeneracy | Stated in contribution 2. |
| m6 | B5 near-tie | Explained: a 2.9% energy advantage vs a 10.7% headroom advantage balance at a headroom weight of 0.212. Remedies stated. |
| m7 | Figures | Already 9-pt fonts at 7-in width; please check them in the final PDF. |
| m8 | Terminology | "Reduces attributed (operational) carbon" in the abstract, VI-B, VI-J and the conclusion. |
| m9 | Recent references | Added Sukprasert et al. (e-Energy 2024), Gorka et al. (e-Energy 2025) and Rajashekar et al. (ScaleSys 2025), all checked online. |
| m10 | Density | VI-H split into 4 paragraphs; the new checks are in Table XV instead of prose. |
| Q6 | Carbon data in practice | §VII-F names grid-operator regional forecasts (NESO). Forecast-error test: 10% per-hour error keeps the savings positive in all weeks; at 25% the summer week turns negative (-1.4%). |

Tables renumbered: the new Table XV is robustness; IMT-2030, 2030 grid and AI-RAN are now XVI–XVIII. Manuscript: 19 pages.

## Round 5c: reviewer minor comments, Table II source check, equation rendering (earlier)
- **Eq. (9):** already correct (10³ multiplies a bracket holding both terms). The text now says so explicitly.
- **Capacity:** stated as non-binding in the trace and mapping runs. The peak hourly load is 38.6% (far edge), 24.1% (metro) and 2.2% (regional) of the admission limits, across all policies, mappings, windows and seeds.
- **Outage simulation:** now compares E-min and Oracle-KA under the same outages. All three policies leave UC2 unserved for 7 h. EASE-6G emits 17.0% less carbon than E-min (+2.6% energy) and matches Oracle-KA hour by hour.
- **Table X:** column headers now read "Carbon saved vs …".
- **Refs:** [45] now says "μWatts"; TR 22.874 is cited as V18.2.0, Dec. 2021.
- **Table II:** checked against the source papers. Corrected cells:
  - [55] excludes PUE (only [37] uses PUE 1.5);
  - [46] does model deadlines, latency and capacity;
  - [54] treats migration energy qualitatively and uses deadlines only.
- **Equations:** rendered with LibreOffice Math and inspected.
  - The inline Erlang formula's brackets broke in non-Word renderers; this is fixed.
  - Eq. (7) overflowed the column; it is now shortened with CI_path(t), and β(t) in Eq. (23) uses the same symbol.
  - Δ definitions are typeset as math.
- **Authors to do:** add Taha's research interests, Khalifa's A'Sharqiyah affiliation, and the repository DOI.

## Round 5b: novelty table (earlier)
- New **Table II** in Section II compares this paper with classical offloading [52], cloud/fog energy studies [37], [55] and carbon-aware shifting [46], [54]. It covers 9 aspects: number of execution options, objective, transport energy, PUE, carbon accounting, break-even point, disagreement condition, existence condition, and service gates.
- Former Tables II–XVI are renumbered III–XVII; all citations are in order. No change to code results or equations; 82/82 checks pass.

## Round 5: fixes for the fourth independent review (earlier)
The fourth review found the 17.0% headline fragile and some claims overstated. Every item is fixed; 82/82 independent checks pass, and a clean-room rebuild reproduces the manuscript text exactly.

**Major concerns**
1. **Comparator.** E-min (pure energy minimizer, no weights) is now the primary comparator throughout (abstract, Tables VI, IX, X, XV, Figs. 4–5). The 17.0% holds against it and stays 15.2–17.7% for 10–20-kB payloads. B5's fragility is disclosed: its UC4 choice is a near-tie (margin 0.0017); at headroom weight ≥0.22 or payload ≤14.4 kB the saving against B5 is 1.7–2.0%.
2. **Equal-efficiency premise.** New Table XIII and a derived band. The saving needs the two edge tiers' facility-adjusted efficiencies within 7.4% (cleaner tier ahead) or 19.1% (dirtier tier ahead); the reference gap is 3.8%. Across 35 variants it is 10.3–17.7% in the 17 where energy and carbon disagree, and 0–2.3% in the 18 where they agree. For k·m ≤ 0.5 (9 of 12 cases) it is 0.4–0.6%. The abstract now states this condition. The Offline vs SingleStream pairing and the unsourced r are disclosed, with the minimum rate each placement needs.
3. **Disagreement condition.** New Eq. (24) gives a general sign condition: the set lies between the crossovers when the slopes agree in sign and beyond them when they do not. Per-window hourly χ_C and opposite-slope hours are reported (summer: 124 of 168). Fig. 6(b) and Table XI now count disagreement hours:
   - every cell with a saving has such hours;
   - 18 of 1,246 departures are headroom near-ties (≤3.5% carbon cost).
   "Reconverge", "only in spring" and "tell in advance" are removed.
4. **Accounting.** Results are now called location-based attributed emissions. A uniform-intensity (marginal-unit) case gives 0% by construction. The floor is described as a regularizer of the score, and it is conservative: removing it raises the saving (17.1%, mapping max 78.3%).
5. **Frontier.** Claims are corrected. EASE matches the oracle in all 24 mappings only from w_C = 0.30. At 0.10–0.25 it departs in 6 or 4 mappings (≤9.4%), with a minimum saving of 1.5%.
6. **6G section.**
   - The Table XVI far-edge row at 1 − 10⁻⁷ is now "Not reachable" (reliability gate).
   - AI-RAN is labeled a what-if, and the no-preemption caveat is added.
   - IMT-2030 targets are labeled end-to-end stress tests.
   - "Beyond today's accelerators" is replaced by "up to 7.5× the reference rate".
7. **Overclaims.** The "≤7.4% conflict" claim now reports the hourly maximum (19.4% energy for a 28.4% cut). The split-inference oracle gap is now reported: 26.2% static, 8.8–64.8% weekly. "Bounding that cost" is removed.

**Minor items:**
- Section references fixed.
- Tables are cited in order.
- "Latency-first" is used throughout.
- 1.59/1.64 ms corrected.
- Simulation range given as 54–60 h, SD 2.2.
- Table I: capacity binds under stress; variant choice is one family.
- Table X shows min–max.
- χ labels fixed; figure files are renamed to match manuscript numbers.
- Ablation renormalization is proportional.
- The oracle is described as myopic.
- Absolute magnitudes are given (0.25 µg/inference, 1.14 kg/week).
- UC3's 76 summer hours at T3 are stated.
- The GreenScale reference was checked against IEEE Xplore/OpenAlex and is correct.
- Abstract: 249 words.

**Authors to do:** add the second author's A'Sharqiyah affiliation to the biography.

## Round 4: your decisions (realistic inputs, 6G element, all three extras) (earlier)
**Inputs changed.** The previous reference became a sensitivity case.
- **Efficiencies:** one published basis. T1-T4 use 730 GFLOP/J (MLPerf data-center system) and differ only in PUE. The device uses 461 GFLOP/J (Orin NX).
- **Payload:** one JPEG-compressed image of 0.12 Mbit. The raw 1.2-Mbit tensor is now a sensitivity case.
- **Carbon signal:** floored at 11 g/kWh, the life-cycle median for wind (Dolan & Heath 2012). The zero-carbon degeneracy is gone.
- **Latency gate:** uses the R_min-quantile of the M/D/1 waiting time (Erlang's formula, 60-digit arithmetic; Gross et al. 2008). B3 is renamed "latency-first".

**What the paper now says.** Two crossovers bound a disagreement interval. With compressed inputs the services sit inside it, so carbon awareness pays:
- **Reference mapping, static (volume-weighted):** 17.0% less carbon than carbon-unaware B5, for +2.6% energy. Against latency-first B3: 18.1% less carbon and 4.7% less energy. EASE-6G matches the oracle.
- **Seasonal vs B5:** 4.8–50.2% less carbon, for +0.7–2.5% energy.
- **All 24 mappings:** 3.4–73.2% less carbon, for at most +7.4% energy. EASE-6G equals the oracle in every mapping.
- **Weights:** a carbon weight of 0.10 is enough (new weight frontier, Fig. 4).
- **Where the benefit vanishes:** with the raw tensor (services fall below the interval) and with no regional spread.

**Other effects.**
- **UC1 (1 ms at 10⁻⁵):** infeasible under the tail gate.
- **New 6G section VII-D (AI-RAN co-located tier):** makes UC1 feasible at 0.84 ms. Table XV gives the compute rates needed at IMT-2030 targets: 76–300 TFLOP/s for 0.5–0.25 ms.
- **Capacity:** now binds under stress (UC3 falls back to T3).
- **Split inference:** never pays with compressed input.

**Minor items fixed.**
- The accuracy-gap definition in the code now matches the text.
- requirements.txt now matches the software versions stated in the manuscript (adds mpmath).
- The parameter CSVs use the manuscript labels.
- The IMT-2030 capability name is corrected.
- The latency-KPI caveat is stated.
- A note on Scotland–England transmission constraints is added.

**Checks.**
- 66/66 equation, figure and table checks pass. They now include an independent M/D/1 quantile check and Table XV.
- Build asserts pass.
- The Word file validates.

## Round 3 (earlier)

## Round 3 details
| Reviewer concern | Fix |
|---|---|
| B5 also changed the headroom weight | B5 now keeps headroom at 0.20 and moves the carbon weight to energy. The envelope (Table XI, Fig. 5) compares against a pure energy minimizer (E-min). |
| Fig. 6(b) used the old carbon accounting | Redrawn with Eq. (7). `verify_equations.py` now checks that the plotted curves cross at the Table XII values. |
| Latency gate omitted transmission time | T_tx added to Eq. (9). UC1 now has 0.05 ms of slack and needs r >= 33,222 GFLOP/s; it is infeasible in 36 of 81 communication scenarios. |
| Queueing bound inconsistent at T4 | Each tier now has c(t) = ceil(CAP/(rho_max r)) servers (2 at T4) with random dispatch, so each server is M/D/1 at utilisation <= 0.7. The M/G/1 case is noted. |
| Device favoured by asymmetric efficiencies | Table XII gains a T2-vs-device crossover: 5.8 GFLOP/Mbit at 1,274 GFLOP/J and 17.1 at 730. Rule (ii), the abstract scope and the conclusion are made conditional. |
| Headline mappings unrealistic | Disclosed: EASE-6G returns to the B3 placement there (4.1% vs B3), the saving is about 0.5 kg/week, and path energies do not match the geography. |
| Marginal emissions | The no-spread scenario is identified as the marginal-emissions reading for one synchronous grid (Hawkes 2010). |
| Oracle and capacity overclaims | The oracle definition is corrected. The static oracle gap would exceed the T3 admission limit. Table I now says capacity is "modeled; not binding here". A limitation is added. |
| Overclaims | "Within 0.5% hour by hour" now reads "weekly". The k·m and device-200 moves are described as carbon-driven. The hourly effect of the accounting extremes is reported. Access energy is stated to cancel only between network tiers. The disagreement claim is limited to pure minimizers. |
| Notation | The user's tier is now t_0 (u stays upstream). L_eff(t,v,uc). |
| Missing citations | Added and verified: Baliga 2011, Jalali 2016, Neurosurgeon 2017, Hawkes 2010, Gupta 2021, 3GPP TR 22.874. The irrelevant LoRA sentence and reference were removed. |
| Minor items | 198 tokens; Table VII gap definitions; oracle UC4 spring hours; device reliability boundary; 2,000-km path disclosed; access assumptions; timing hardware; trace-week metadata corrected; UTC load profile. |

**Unchanged by design.** The network-tier efficiency profile (now bounded by the device-crossover column). The single model family. The 5G-class profiles. Capacity binds only under outages and scaling.

**Checks.** 67/67 equation and figure checks pass. Build asserts pass. Word validation passes.

## Round 2 (earlier)

## Round 2 details
Title now ends "With Implications for 6G"; IMT-2030 dropped from the index terms.

| Reviewer concern | Fix | Effect on results |
|---|---|---|
| Carbon charged to the destination grid for all energy | Eq. (7): compute at destination, access at the user's grid, path split 50/50; extremes tested (Sec. VI-I) | Access now cancels from both crossovers; chi_C = 1.15 (was 0.84); placements identical under all three rules |
| Unweighted headline | Static results weighted by request volume (UC4 = 87.1%); Table VI rebuilt | Headline vs nearest-feasible: 6.3% carbon, 7.3% energy (unweighted would be 19.6%) |
| Payloads not matched to the model | 1.2 Mbit (one 224x224x3 input) for every profile | All services now chi = 2.4-3.8 GFLOP/Mbit |
| Device understated (100 GFLOP/J, 4 GFLOP/s) | T5 = Jetson Orin NX MaxQ, MLPerf v3.1: 461 GFLOP/J, 2,890 GFLOP/s | UC4 and UC5 run on the device; sensitivity 4-2,890 GFLOP/s and 100-461 GFLOP/J |
| No queueing | Eq. (9) adds the M/D/1 mean wait at rho_max = 0.7; CAP_AI is the admission limit | UC1 needs r >= 19,933 GFLOP/s; infeasible at rho_max = 0.9 |
| Missing prior work | Sukprasert et al. (EuroSys 2024) and Hanafy et al. (HotCarbon 2023) added, both verified | Positioned in intro, related work, discussion, Sec. VII-C |
| "PUE penalty" wording | Condition (22) now stated as "upstream tier needs less facility energy per unit of work (PUE/EE)" | Wording only |
| Variant choice inert | Disclosed in Sec. VI-A and limitations | - |
| Zero-carbon percentages | Ratio-score caveat in Sec. IV-C; zero-carbon cells reported in kg (Table X, Fig. 4b) | - |
| Scale invariance presented as a result | Now a property in Sec. IV-C; removed from the abstract | - |
| MILP penalty, unserved runs | M = n + 1; unserved draws reported | 2 of 3 five-service draws leave one service unserved |
| Parameters not matching Table II | `parameters/v2/` exported from the model | - |
| T1 path length fixed across mappings | Disclosed in Sec. V-A and limitations | - |
| B1, AI tools as references | B1 removed; GPT and Claude moved to the Acknowledgment (no reference entries) | - |

**What the paper now says.** Energy awareness delivers the savings. Under the reference mapping the carbon-unaware policy makes the same static decisions, and hour by hour it is within 0.5%. Carbon awareness changes a static decision in only 6 of the 24 mappings: those that place the user on the North Scotland grid. There it saves 31.5-38.7% of carbon for 3.4% more energy. Halving the regional spread cuts the largest saving to 8.7%, and removing the spread removes the benefit. A capable device beats every network tier on energy.

**Checks.**
- Independent equation check: 63/63 passed.
- Build asserts tie every prose claim to the results.
- The Word file passes schema validation.
- The clean-room rebuild matches the delivered file.
- An independent reviewer ran on a clean copy.

## Round 1 (earlier)

## What changed in the manuscript
- **Title:** "EASE-6G: A Regime Analysis of Carbon-Aware AI Inference Placement Across the Edge-Cloud Continuum Toward 6G".
- **Narrative:** abstract, introduction, discussion and conclusion now lead with the question "when does carbon awareness change the placement?".
- **Model:** ratio scores (Eqs. 6, 8), execution-time latency gate (new Eq. 9, Eq. 10), capped headroom (Eq. 12), existence condition for the energy crossover (new Eq. 22). 23 equations in total; the previous 21 are renumbered from (9) onward. All symbols in the running text are now Word equation objects, in the same style as the display equations.
- **Inputs:** UC5 added; rule-based tier-to-grid mapping; far-edge path energy 0.30 nJ/bit; per-request compute rate; capacity and load scaled by 1,000; efficiency values anchored to MLPerf.
- **Results:** all regenerated. New: 24-mapping robustness, crossover range under published efficiencies, energy cost beside every saving, MILP scaling.
- **New Section VII:** IMT-2030 mapping, design rules, 2030 grid scenarios, split inference.
- **Removed:** constant tables (old IX, XII, XIV), old Fig. 6, the supplement reference, the memory-boundary paragraph, repeated scope caveats.
- **Related work:** Clover added; last column of Table I removed.

## Reviewer concerns and where they are answered
| Concern | Where |
|---|---|
| Savings only in an unreachable regime | UC5 (Sec. III-C, VI-A, VI-B); Sec. VI-G |
| Oracle match by construction | Ratio scores (Sec. IV-C); UC3 gap disclosed (Sec. VI-G) |
| Inputs predetermine placements | Mapping rule (Sec. V-A); six and 24 mappings (Sec. VI-G) |
| Latency vs capacity | Eq. (9); rate sensitivity (Sec. VI-I) |
| MILP barely exercised | Scaling (Sec. VI-I) |
| Crossover not reproducible | Full precision in scripts; range in Table XII |
| Title oversells | New title; Sec. VII states the scope |
| Thin related work | Clover; Table I |

## To do before submission (authors)
1. **Open the file in Word and check every equation.** My preview tool does not render Word equations (it did not render them in your original either), so I checked them only structurally.
2. **Reference [44] (MLPerf results):** pin the MLPerf figures to MLCommons result IDs. I took the Qualcomm figures from press reports of the v1.0 and v2.1 rounds.
3. **Table I, Clover row:** confirm the entries against the paper; I verified the citation and the abstract, not every cell.
4. **Reference [28] (GreenScale):** a journal version appears to exist in the IEEE Internet of Things Journal (doi: 10.1109/JIOT.2025.3555153). Confirm the title, volume and pages and replace the arXiv entry. For [29] (CarbonCP) and [31] (EcoServe) a web search found only the arXiv versions; check once more before submission.
5. **Assumptions to be ready to defend:** cloud on a remote low-carbon grid; per-request rate of 40,000 GFLOP/s (UC1 needs at least 9,200).
6. **Software versions** in Sec. V are those of my rerun (Python 3.13.18, NumPy 2.5.3, pandas 3.0.5, SciPy 1.18.1, Matplotlib 3.11.2). Rerun on your machine and update if they differ.
7. **Name:** "EASE-6G" is kept; the paper states the model is generation-neutral. Rename if you prefer.
8. **AI-use disclosure:** the Acknowledgment names one AI tool, reference [53]. This revision was prepared with Claude (Anthropic); update the disclosure to match IEEE policy.
9. **IEEE Access formalities:** funding in the first-page footnote, a DOI for the package, fuller biographies.
10. **Section VII-E** is a short text statement, not a figure. Check it against current standards work.
11. **Co-authors** should review the new framing and results before submission.

## Not fixed by this revision
- No hardware measurements; one model family; UK-only, three-week forecast traces.
- Split inference assumes 8-bit feature compression is accuracy-neutral.


## Checks run on this version
- Full pipeline rerun from a clean copy of the package; the rebuilt manuscript text is identical to the delivered file.
- Word file passes schema validation; all 23 numbered equations are present as Word equation objects.
- The Clover citation [33] was verified against the ACM record.

## Verification pass (equations, citations, figures, style)
- **Equations:** each of Eqs. (1)-(23) was re-implemented independently from the values printed in Tables II-IV (`code/verify_equations.py`) and compared with the rerun and with the printed tables: 59 of 59 checks pass (`results/v2/equation_verification.csv`). Eqs. (16)-(19) were checked by exhaustive search over all assignments in place of the MILP.
- **Fixes from this pass:** Eq. (2) had a comma inside a subscript; Table II now prints carbon intensity to four decimals so the carbon crossover (0.84) is reproducible from the table; a cross-reference to a non-existent Section V-F now points to Section V-C.
- **Citations:** all references are cited and numbered in order of first appearance; ranges use en dashes. The map from the authors' original numbering is in `build/citation_renumbering.json`.
- **Cross-references:** every equation, table (I-XIV), figure (1-6) and section reference resolves.
- **Figures:** Figs. 1-2 are conceptual and agree with the tier list and the order of Eqs. (9)-(19); Figs. 3-6 are drawn by the same script that writes Tables VI, X, XI and XII.
- **Equation style:** all 25 display equations share one paragraph format (centred equation, right-aligned number); the two unnumbered lines are the gate indicators above Eq. (10).

## Audit pass (equations, consistency, narrative, novelty)
Corrected in the manuscript:
- **Crossover range overstated.** Abstract, contribution 1 and conclusion said "1.6 to 30.9 GFLOP/Mbit under published MLPerf efficiencies", but 30.9 is the hypothetical equal-efficiency case. Published pairs give 1.6 to 18.4; Section VI-H now states both.
- **Oracle agreement overstated.** "The one documented case" (contribution 4) and the conclusion ignored hourly gaps (up to 8.2%). Both now separate static agreement from the hourly gap.
- **Related work overclaimed** that nearest-feasible is "already optimal" below the boundary; the results show it is energy-optimal there and carbon-optimal only if the grids do not differ strongly (UC4 in spring). Corrected.
- **Efficiency anchoring:** "200 to 500 lie within or just below" the published ranges was inaccurate for T4 (200) and T5 (100). Corrected.
- **IMT-2030 mapping:** video analytics (UC4) was mapped to immersive communication; now AI and communication. The reliability statement now says UC1 and UC2 reach the loosest end of the IMT-2030 range.
- **Split computing [52]:** the survey was cited for a 6G claim it does not make; reworded, with IMT-2030 [1] cited for the 6G link.
- **Units and notation:** efficiency now in GFLOP/J throughout (equivalence stated once); Eq. (20) uses E_total and D_uc, matching Eq. (5); remaining plain-text variables (t, v, u, d) are now math; Section III-C said UC1-UC4 instead of UC1-UC5.
- **Style:** the code-font solver name is now body text; math in table headers is now the same size as the header text.
- **Missing prior art (novelty):** the core metric extends the classical offloading criterion of Kumar and Lu [23] (offloading saves energy only when computation is large relative to transferred data), and its name comes from the roofline model [24]. Neither was cited; both are now cited and the contribution is positioned as an extension of them.

Still for the authors to decide:
1. **EASE-6G is never expanded** (also not in your original). Add the expansion at first use or treat it as a name.
2. **AI-use disclosure** names one tool [53]; this revision was also prepared with Claude (Anthropic).
3. **Notation reuse (minor):** k indexes both the headroom terms in Eq. (12) and the split block in Section VII-D; J is both jitter and the joule unit.

## Trimming pass (Sections III-IV)
- Sections III and IV rewritten around the decision rule: III from 933 to 420 words, IV from 1,394 to about 1,010 words (equations excluded). All 23 equations, Figs. 1-2 and every citation are kept.
- Former contribution 2 (execution time in the latency gate, ratio scores, capped headroom) is now stated in the opening of Section IV as method; the introduction lists four contributions.
- Each scope caveat now appears once: pre-positioned variants in Section IV-F (as a model assumption) and Section VIII (as a limitation); queueing, radio signaling and retransmissions, base-station energy, and the nominal-bandwidth gate in Section VIII only. The duplicate service-profile caveat under Table IV was removed.
- Manuscript length: about 12,060 to about 11,100 words.

## Wording correction
- Section V-A said the mapping rule was "stated before any result". The rule was chosen after the first results, so the phrase could read as pre-registration; it now reads "The reference mapping follows one rule". The 24-mapping results remain the safeguard against selection.

## Pre-submission items completed on the authors' behalf
- **Efficiency anchors re-derived from the official MLPerf records** (MLCommons GitHub result logs, power averaged over the official measurement window, 4.1 GFLOP/image):
  - Gigabyte R282-Z93, 5x Cloud AI 100 (Datacenter v1.0): 100,077 samples/s at 561.94 W = 730 GFLOP/J.
  - Foxconn Gloria Highend, 1x Cloud AI 100 (Edge v2.1): 9,224.17 samples/s at 29.67 W = 1,274 GFLOP/J. MLPerf classes this as an edge system, so "data-center systems" was wrong; the text now says server-class systems (two data-center systems and one edge server with a data-center accelerator card). The value was 1,275 by rounding; now 1,274.
  - Jetson AGX Orin MaxQ: 627 GFLOP/J (Edge v3.0) and 613 GFLOP/J (Edge v3.1). The paper used 615; now 613. Table XII "mid" crossover moves from 7.46 to 7.33 GFLOP/Mbit; the abstract range (1.6 to 18.4) is unchanged.
  - Jetson Orin NX MaxQ (Edge v3.1): 461 GFLOP/J, confirmed.
  - 471 GFLOP/J: the MLPerf Power paper's 8.7 mJ/sample for ResNet on a large-scale data-center system (round not stated in that paper).
- **Reference [44] (MLPerf)** now names the exact systems, rounds and repository.
- **Reference [28] (GreenScale)** replaced by the journal version: IEEE Internet Things J., vol. 12, no. 16, pp. 32379-32393, 2025 (new title and author order).
- **Table I:** Clover's accuracy control is a soft trade-off, now "Partial (soft)"; evidence "GPU testbed; real CI traces". GreenScale evidence now "Real devices; traces" (journal version).
- **EASE-6G expanded** in the abstract and at first use as "Energy-Aware Sustainable Edge for 6G". This expansion was chosen for you; change it if the authors intended another.
- **AI-use disclosure** (Acknowledgment) now names both systems, GPT-5.6 [53] and Claude [54], with what each was used for, as IEEE policy requires. Its last sentence states that the authors reviewed and verified the content: make sure that is true before submitting.
